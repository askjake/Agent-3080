#!/bin/bash
# Dish-Chat Stop Script
# Updated: 2026-04-28

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${YELLOW}▶${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_error() { echo -e "${RED}✗${NC} $1"; }

echo "========================================"
echo "  Stopping Dish-Chat Services"
echo "========================================"

# Find and kill uvicorn processes
PIDS=$(pgrep -f "uvicorn app.main:app" || echo "")

if [ -z "$PIDS" ]; then
    log_info "No running processes found"
    exit 0
fi

log_info "Found processes: $PIDS"

for pid in $PIDS; do
    log_info "Stopping process $pid..."
    kill "$pid" 2>/dev/null || true
done

sleep 2

# Force kill if still running
STILL_RUNNING=$(pgrep -f "uvicorn app.main:app" || echo "")
if [ -n "$STILL_RUNNING" ]; then
    log_info "Force killing remaining processes..."
    pkill -9 -f "uvicorn app.main:app" || true
fi

# Clean up PID files
rm -f ~/dish-chat/backend.pid 2>/dev/null || true
rm -f ~/Jakes-agent/dish-chat/backend.pid 2>/dev/null || true

log_success "All processes stopped"
echo "========================================"
