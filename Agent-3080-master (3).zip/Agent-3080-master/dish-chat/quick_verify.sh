#!/bin/bash
# Quick verification script for Memory Enhancement deployment
# Checks all components are in place

set -e

DISH_CHAT_DIR="${1:-~/dish-chat}"
ERRORS=0

echo "=== Memory Enhancement Deployment Verification ==="
echo "Checking: $DISH_CHAT_DIR"
echo ""

# Function to check file existence
check_file() {
    local file="$1"
    local description="$2"
    
    if [ -f "$file" ]; then
        echo "✅ $description"
        echo "   Size: $(du -h "$file" | cut -f1)"
    else
        echo "❌ MISSING: $description"
        echo "   Expected: $file"
        ((ERRORS++))
    fi
}

# Phase 1: Foundation (should already exist)
echo "=== Phase 1: Foundation ==="
check_file "$DISH_CHAT_DIR/app/core/memory/models.py" "Data models"
check_file "$DISH_CHAT_DIR/app/core/memory/embedding_service.py" "Embedding service"
check_file "$DISH_CHAT_DIR/app/core/memory/__init__.py" "Memory __init__"
echo ""

# Phase 2: Services
echo "=== Phase 2: Services ==="
check_file "$DISH_CHAT_DIR/app/core/memory/context_metadata.py" "Context metadata"
check_file "$DISH_CHAT_DIR/app/core/memory/context_service.py" "Context service"
check_file "$DISH_CHAT_DIR/app/core/memory/summarization_service.py" "Summarization service"
check_file "$DISH_CHAT_DIR/app/core/memory/tool_memory_service.py" "Tool memory service"
echo ""

# Phase 2B: Integration
echo "=== Phase 2B: Integration ==="
check_file "$DISH_CHAT_DIR/app/agent/memory_integration.py" "Memory integration"
check_file "$DISH_CHAT_DIR/app/agent/agents/memory_tools.py" "Memory tools"
echo ""

# Phase 3: Context Injection
echo "=== Phase 3: Context Injection ==="
check_file "$DISH_CHAT_DIR/app/agent/context_injection.py" "Context injection"
echo ""

# Database Migration
echo "=== Database Migration ==="
check_file "$DISH_CHAT_DIR/migrate_db.py" "Migration script"
echo ""

# Check Python imports
echo "=== Python Import Check ==="
cd "$DISH_CHAT_DIR"

python3 -c "
import sys
sys.path.insert(0, '.')

try:
    from app.core.memory.context_metadata import ContextMetadata
    print('✅ ContextMetadata imports successfully')
except Exception as e:
    print(f'❌ ContextMetadata import failed: {e}')
    sys.exit(1)

try:
    from app.core.memory.context_service import ContextService
    print('✅ ContextService imports successfully')
except Exception as e:
    print(f'❌ ContextService import failed: {e}')
    sys.exit(1)

try:
    from app.core.memory.tool_memory_service import get_tool_memory_service
    print('✅ ToolMemoryService imports successfully')
except Exception as e:
    print(f'❌ ToolMemoryService import failed: {e}')
    sys.exit(1)

try:
    from app.agent.context_injection import MemoryAwareToolNode
    print('✅ MemoryAwareToolNode imports successfully')
except Exception as e:
    print(f'❌ MemoryAwareToolNode import failed: {e}')
    sys.exit(1)

print('\n✅ All imports successful')
" || ((ERRORS++))

echo ""

# Check database connection
echo "=== Database Check ==="
python3 -c "
import os
import sys
from sqlalchemy import create_engine, text

db_url = os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/dish_chat')

try:
    # Convert async URL to sync for quick check
    sync_url = db_url.replace('postgresql+asyncpg://', 'postgresql://')
    engine = create_engine(sync_url)
    
    with engine.connect() as conn:
        result = conn.execute(text('SELECT version();'))
        version = result.scalar()
        print(f'✅ Database connection successful')
        print(f'   PostgreSQL version: {version[:50]}...')
        
        # Check if pgvector extension exists
        result = conn.execute(text("""
            SELECT EXISTS (
                SELECT FROM pg_available_extensions 
                WHERE name = 'vector'
            );
        """))
        has_pgvector = result.scalar()
        
        if has_pgvector:
            print('✅ pgvector extension available')
        else:
            print('⚠️  pgvector extension NOT available (install required)')
            
except Exception as e:
    print(f'❌ Database connection failed: {e}')
    sys.exit(1)
" || echo "⚠️  Database check failed (migration may still work)"

echo ""

# Summary
echo "=== Verification Summary ==="
if [ $ERRORS -eq 0 ]; then
    echo "✅ All checks passed! Ready for deployment."
    echo ""
    echo "Next steps:"
    echo "  1. Run database migration:"
    echo "     cd $DISH_CHAT_DIR && python3 migrate_db.py"
    echo ""
    echo "  2. Restart backend:"
    echo "     systemctl restart dish-chat-backend"
    echo ""
    echo "  3. Enable memory (optional):"
    echo "     export ENABLE_MEMORY_INTEGRATION=true"
    echo ""
    exit 0
else
    echo "❌ $ERRORS error(s) found. Please fix before deploying."
    exit 1
fi
