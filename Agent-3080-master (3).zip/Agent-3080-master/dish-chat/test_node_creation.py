#!/usr/bin/env python3
"""
Direct node creation test - bypasses graph compilation
"""
import sys
sys.path.insert(0, '/home/montjac/dish-chat')

print("[TEST] Testing node creation directly")

print("\n[TEST] Step 1: Import context_injection module")
from app.agent.context_injection import create_memory_aware_tool_node

print("\n[TEST] Step 2: Import tools")
from app.agent.agents.tools.registry import get_tools_set
tools = get_tools_set("search")
print(f"  - Got {len(tools)} tools")

print("\n[TEST] Step 3: Call create_memory_aware_tool_node (should trigger debug message)")
node = create_memory_aware_tool_node(tools)

print(f"\n[TEST] Step 4: Node created: {type(node)}")
print(f"  - Node type: {node.__class__.__name__}")
print(f"  - Has ainvoke: {hasattr(node, 'ainvoke')}")

print("\n[TEST] ✅ Direct node creation successful")
print("[TEST] Expected message: '[DEBUG] Creating MemoryAwareToolNode with X tools'")
