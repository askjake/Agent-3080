#!/bin/bash

echo "================================================"
echo "FINAL MEMORY INTEGRATION TEST"
echo "================================================"
echo

# Get current count
BEFORE=$(PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -t -c "SELECT COUNT(*) FROM tool_executions;")
echo "Executions BEFORE: $BEFORE"
echo

# Check for debug message in logs
echo "Checking for node creation in logs..."
if grep -q "DEBUG.*Creating MemoryAwareToolNode" ~/dish-chat/logs/backend.log 2>/dev/null; then
    echo "✅ Node creation logged!"
else
    echo "❌ Node creation NOT logged"
fi
echo

# Send test query
echo "Sending test query (this will use cluster_inspect tool)..."
curl -s -X POST http://localhost:8001/rest/api/v1/chats/3b97d263-25a9-4367-9bab-1633aa461daa/messages \
  -H "Content-Type: application/json" \
  -d '{"content": "List all namespaces", "namespace": "generic"}' > /dev/null

echo "Query sent. Waiting 5 seconds for processing..."
sleep 5
echo

# Get new count
AFTER=$(PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -t -c "SELECT COUNT(*) FROM tool_executions;")
echo "Executions AFTER: $AFTER"
echo

# Calculate difference
DIFF=$((AFTER - BEFORE))

if [ $DIFF -gt 0 ]; then
    echo "================================================"
    echo "✅ SUCCESS! $DIFF new execution(s) stored!"
    echo "================================================"
    echo
    echo "Latest execution:"
    PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -c "SELECT id, tool_name, success, created_at FROM tool_executions ORDER BY id DESC LIMIT 1;"
    exit 0
else
    echo "================================================"
    echo "❌ FAILED: No new executions stored"
    echo "================================================"
    echo
    echo "Checking for debug messages in last 100 lines of log:"
    tail -100 ~/dish-chat/logs/backend.log | grep -E "DEBUG|Creating|MemoryAware|ainvoke" | tail -10
    exit 1
fi
