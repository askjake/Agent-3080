#!/bin/bash
#
# Dish-Chat Agent Backend Versioning & Restoration System
# Version: 1.0
# Date: 2026-04-30
#
# This script provides comprehensive version control and restoration capabilities
# for the dish-chat agent backend, including:
#   - Automated state snapshots
#   - Quick rollback to any previous state
#   - Version tagging and annotation
#   - Health verification
#   - Dependency tracking
#

set -e  # Exit on error

# Configuration
PROJECT_DIR="$HOME/dish-chat"
BACKUP_BASE_DIR="$PROJECT_DIR/backups/versioned"
SERVICE_PORT=8001
DB_HOST="127.0.0.1"
DB_PORT=5434
DB_NAME="dishchat"
DB_USER="dev_user"
DB_PASS="dev123"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Helper functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Get current timestamp
get_timestamp() {
    date +"%Y%m%d_%H%M%S"
}

# Check if service is running
check_service() {
    if pgrep -f "uvicorn app.main:app.*--port $SERVICE_PORT" > /dev/null; then
        return 0
    else
        return 1
    fi
}

# Get service PID
get_service_pid() {
    pgrep -f "uvicorn app.main:app.*--port $SERVICE_PORT" | head -1
}

# Health check
health_check() {
    local response=$(curl -s http://localhost:$SERVICE_PORT/rest/api/v1/health 2>/dev/null)
    if echo "$response" | grep -q '"status"'; then
        echo "$response"
        return 0
    else
        return 1
    fi
}

# Create snapshot
create_snapshot() {
    local version_tag="$1"
    local description="$2"
    local timestamp=$(get_timestamp)
    local snapshot_dir="$BACKUP_BASE_DIR/snapshot_${timestamp}_${version_tag}"
    
    log_info "Creating snapshot: $version_tag"
    mkdir -p "$snapshot_dir"
    
    # Metadata
    cat > "$snapshot_dir/METADATA.txt" << EOF
Snapshot Timestamp: $(date)
Version Tag: $version_tag
Description: $description
Git Branch: $(cd $PROJECT_DIR && git branch --show-current)
Git Commit: $(cd $PROJECT_DIR && git rev-parse HEAD)
Service Status: $(check_service && echo "RUNNING" || echo "STOPPED")
EOF
    
    # Capture git state
    log_info "Capturing git state..."
    cd "$PROJECT_DIR"
    git status > "$snapshot_dir/git_status.txt"
    git diff > "$snapshot_dir/git_diff.txt"
    git log --oneline -20 > "$snapshot_dir/git_log.txt"
    
    # Backup critical files
    log_info "Backing up configuration files..."
    cp -a .env "$snapshot_dir/" 2>/dev/null || log_warning ".env not found"
    cp -a .env.* "$snapshot_dir/" 2>/dev/null || true
    
    # Backup entire app directory
    log_info "Backing up app directory..."
    tar -czf "$snapshot_dir/app_backup.tar.gz" app/
    
    # Backup Python dependencies
    log_info "Capturing Python dependencies..."
    source .venv/bin/activate
    pip freeze > "$snapshot_dir/requirements_frozen.txt"
    pip list > "$snapshot_dir/pip_list.txt"
    deactivate
    
    # Database schema
    log_info "Capturing database schema..."
    PGPASSWORD=$DB_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME \
        -c "\dt" > "$snapshot_dir/db_tables.txt" 2>&1 || log_warning "DB schema capture failed"
    
    # Alembic migration state
    log_info "Capturing migration state..."
    PGPASSWORD=$DB_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME \
        -c "SELECT * FROM alembic_version" > "$snapshot_dir/alembic_version.txt" 2>&1 || log_warning "Alembic state capture failed"
    
    # Service logs snapshot
    if [ -f logs/backend.log ]; then
        log_info "Capturing recent logs..."
        tail -1000 logs/backend.log > "$snapshot_dir/backend_logs_tail.txt"
    fi
    
    # Health check
    if check_service; then
        log_info "Running health check..."
        health_check > "$snapshot_dir/health_check.json" 2>&1 || log_warning "Health check failed"
    fi
    
    # Create manifest
    find "$snapshot_dir" -type f -ls > "$snapshot_dir/MANIFEST.txt"
    
    log_success "Snapshot created: $snapshot_dir"
    echo "$snapshot_dir"
}

# List snapshots
list_snapshots() {
    log_info "Available snapshots:"
    echo ""
    for snapshot in $(ls -dt $BACKUP_BASE_DIR/snapshot_* 2>/dev/null); do
        if [ -f "$snapshot/METADATA.txt" ]; then
            echo -e "${GREEN}$(basename $snapshot)${NC}"
            grep -E "Timestamp|Version Tag|Description" "$snapshot/METADATA.txt" | sed 's/^/  /'
            echo ""
        fi
    done
}

# Restore snapshot
restore_snapshot() {
    local snapshot_name="$1"
    local snapshot_dir="$BACKUP_BASE_DIR/$snapshot_name"
    
    if [ ! -d "$snapshot_dir" ]; then
        log_error "Snapshot not found: $snapshot_name"
        return 1
    fi
    
    log_warning "This will restore the system to snapshot: $snapshot_name"
    log_warning "Current state will be backed up first"
    read -p "Continue? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        log_info "Restoration cancelled"
        return 0
    fi
    
    # Create pre-restore backup
    log_info "Creating pre-restore backup..."
    local pre_restore_backup=$(create_snapshot "pre_restore_$(get_timestamp)" "Auto-backup before restoring $snapshot_name")
    
    # Stop service
    if check_service; then
        log_info "Stopping service..."
        local pid=$(get_service_pid)
        kill $pid
        sleep 2
        if check_service; then
            log_warning "Service still running, forcing..."
            kill -9 $pid
        fi
    fi
    
    cd "$PROJECT_DIR"
    
    # Restore .env
    if [ -f "$snapshot_dir/.env" ]; then
        log_info "Restoring .env file..."
        cp -a "$snapshot_dir/.env" .env
    fi
    
    # Restore app directory
    if [ -f "$snapshot_dir/app_backup.tar.gz" ]; then
        log_info "Restoring app directory..."
        rm -rf app.backup
        mv app app.backup 2>/dev/null || true
        tar -xzf "$snapshot_dir/app_backup.tar.gz"
    fi
    
    # Restore Python dependencies
    if [ -f "$snapshot_dir/requirements_frozen.txt" ]; then
        log_info "Restoring Python dependencies..."
        source .venv/bin/activate
        pip install -r "$snapshot_dir/requirements_frozen.txt" --quiet
        deactivate
    fi
    
    log_success "Restoration complete!"
    log_info "Pre-restore backup saved to: $pre_restore_backup"
    log_info "Please restart the service manually"
    log_info "Command: cd $PROJECT_DIR && source .venv/bin/activate && python -m uvicorn app.main:app --host 0.0.0.0 --port $SERVICE_PORT"
}

# Compare snapshots
compare_snapshots() {
    local snap1="$1"
    local snap2="$2"
    
    log_info "Comparing snapshots..."
    log_info "Snapshot 1: $snap1"
    log_info "Snapshot 2: $snap2"
    
    diff -u "$BACKUP_BASE_DIR/$snap1/METADATA.txt" "$BACKUP_BASE_DIR/$snap2/METADATA.txt" || true
}

# Verify system health
verify_health() {
    log_info "Running system health verification..."
    local issues=0
    
    # Check service
    if check_service; then
        log_success "Service is running"
    else
        log_error "Service is NOT running"
        ((issues++))
    fi
    
    # Check health endpoint
    if health_check > /dev/null 2>&1; then
        log_success "Health endpoint responding"
    else
        log_error "Health endpoint NOT responding"
        ((issues++))
    fi
    
    # Check database
    if PGPASSWORD=$DB_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SELECT 1" > /dev/null 2>&1; then
        log_success "Database connection OK"
    else
        log_error "Database connection FAILED"
        ((issues++))
    fi
    
    # Check critical dependencies
    cd "$PROJECT_DIR"
    source .venv/bin/activate
    
    if python -c "import pgvector" 2>/dev/null; then
        log_success "pgvector package installed"
    else
        log_error "pgvector package NOT installed"
        ((issues++))
    fi
    
    if python -c "import asyncpg" 2>/dev/null; then
        log_success "asyncpg package installed"
    else
        log_error "asyncpg package NOT installed"
        ((issues++))
    fi
    
    deactivate
    
    # Check recent errors in logs
    if [ -f logs/backend.log ]; then
        local error_count=$(tail -100 logs/backend.log | grep -c "ERROR\|Exception" || true)
        if [ "$error_count" -gt 0 ]; then
            log_warning "Found $error_count errors in recent logs"
            ((issues++))
        else
            log_success "No recent errors in logs"
        fi
    fi
    
    echo ""
    if [ $issues -eq 0 ]; then
        log_success "System health: GOOD"
        return 0
    else
        log_error "System health: ISSUES FOUND ($issues)"
        return 1
    fi
}

# Quick fix common issues
quick_fix() {
    log_info "Running quick fix for common issues..."
    
    cd "$PROJECT_DIR"
    source .venv/bin/activate
    
    # Install missing pgvector
    if ! python -c "import pgvector" 2>/dev/null; then
        log_info "Installing pgvector..."
        pip install pgvector
    fi
    
    # Fix requirements.txt
    if ! grep -q "pgvector" requirements.txt; then
        log_info "Adding pgvector to requirements.txt..."
        echo "pgvector==0.3.6" >> requirements.txt
    fi
    
    deactivate
    log_success "Quick fix complete"
}

# Main menu
show_menu() {
    echo ""
    echo "=========================================="
    echo "  Dish-Chat Versioning & Restoration"
    echo "=========================================="
    echo "1. Create Snapshot"
    echo "2. List Snapshots"
    echo "3. Restore Snapshot"
    echo "4. Compare Snapshots"
    echo "5. Verify System Health"
    echo "6. Quick Fix Common Issues"
    echo "7. Exit"
    echo "=========================================="
}

# Main execution
case "${1:-menu}" in
    create)
        create_snapshot "${2:-manual_snapshot}" "${3:-Manual snapshot}"
        ;;
    list)
        list_snapshots
        ;;
    restore)
        if [ -z "$2" ]; then
            log_error "Usage: $0 restore <snapshot_name>"
            exit 1
        fi
        restore_snapshot "$2"
        ;;
    compare)
        if [ -z "$2" ] || [ -z "$3" ]; then
            log_error "Usage: $0 compare <snapshot1> <snapshot2>"
            exit 1
        fi
        compare_snapshots "$2" "$3"
        ;;
    verify)
        verify_health
        ;;
    fix)
        quick_fix
        ;;
    menu)
        while true; do
            show_menu
            read -p "Select option: " choice
            case $choice in
                1) 
                    read -p "Enter version tag: " tag
                    read -p "Enter description: " desc
                    create_snapshot "$tag" "$desc"
                    ;;
                2) list_snapshots ;;
                3) 
                    read -p "Enter snapshot name: " snap
                    restore_snapshot "$snap"
                    ;;
                4)
                    read -p "Enter first snapshot: " snap1
                    read -p "Enter second snapshot: " snap2
                    compare_snapshots "$snap1" "$snap2"
                    ;;
                5) verify_health ;;
                6) quick_fix ;;
                7) exit 0 ;;
                *) log_error "Invalid option" ;;
            esac
            echo ""
            read -p "Press Enter to continue..."
        done
        ;;
    *)
        echo "Usage: $0 {create|list|restore|compare|verify|fix|menu}"
        exit 1
        ;;
esac
