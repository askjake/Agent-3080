from functools import cache
from typing import Optional
import logging
import asyncio
from datetime import datetime, timedelta

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.runnables import ConfigurableField
from langchain_aws import ChatBedrockConverse
from botocore.exceptions import ClientError

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

# Store model instances with token expiry tracking
_model_cache = {
    "efficient": {"model": None, "expires_at": None},
    "primary": {"model": None, "expires_at": None}
}

# Background task for token refresh
_refresh_task = None
_refresh_lock = asyncio.Lock()
_task_started = False  # Flag to prevent multiple task starts

def _get_next_token_expiry() -> datetime:
    """
    Calculate when AWS tokens will expire (top of next hour).
    Refresh 10 minutes before expiry to be safe.
    """
    now = datetime.utcnow()
    # Round up to next hour
    next_hour = (now + timedelta(hours=1)).replace(minute=0, second=0, microsecond=0)
    # Refresh 10 minutes early
    refresh_time = next_hour - timedelta(minutes=10)
    return refresh_time


def _is_aws_provider(provider: Optional[str]) -> bool:
    return provider == "aws-bedrock"


def _create_ollama_model(
    model_name: str,
    max_tokens: int,
    num_ctx: Optional[int],
    base_url: Optional[str] = None,
) -> BaseChatModel:
    """Create a ChatOllama model instance."""
    try:
        from langchain_ollama import ChatOllama
    except ImportError as e:
        raise ImportError(
            "Ollama provider selected, but langchain-ollama is not installed. "
            "Install it with: pip install -U langchain-ollama"
        ) from e

    logger.info(f"Creating new Ollama model instance for {model_name}")
    kwargs = {
        "model": model_name,
        "num_predict": max_tokens,
        "validate_model_on_init": False,
        "disable_streaming": False,
    }
    if num_ctx:
        kwargs["num_ctx"] = num_ctx
    if base_url:
        kwargs["base_url"] = base_url

    return ChatOllama(**kwargs)


def _provider_for_cache_key(cache_key: str) -> Optional[str]:
    if cache_key == "efficient" and settings.ELLM_MODEL:
        return settings.ELLM_PROVIDER
    return settings.PLLM_PROVIDER


def _create_model_for_cache_key(cache_key: str) -> BaseChatModel:
    efficient = cache_key == "efficient"

    if efficient and settings.ELLM_MODEL:
        provider = settings.ELLM_PROVIDER
        model_name = settings.ELLM_MODEL
        num_ctx = settings.ELLM_CTX_LEN
        max_tokens = 4096
        api_base = settings.ELLM_API_BASE
    else:
        provider = settings.PLLM_PROVIDER
        model_name = settings.PLLM_MODEL
        num_ctx = settings.PLLM_CTX_LEN
        max_tokens = settings.MAX_OUTPUT_COUNT
        api_base = settings.PLLM_API_BASE

    if provider == "aws-bedrock":
        return _create_bedrock_model(model_name, max_tokens)
    if provider == "ollama":
        return _create_ollama_model(model_name, max_tokens=max_tokens, num_ctx=num_ctx, base_url=api_base)

    raise NotImplementedError(f"Provider {provider} not implemented yet")

def _create_bedrock_model(model_name: str, max_tokens: int) -> ChatBedrockConverse:
    """
    Create a new ChatBedrockConverse instance with fresh credentials.
    
    Args:
        model_name: The Bedrock model identifier
        max_tokens: Maximum tokens for the model
        
    Returns:
        A new ChatBedrockConverse instance
    """
    logger.info(f"Creating new Bedrock model instance for {model_name}")
    return ChatBedrockConverse(
        model=model_name,
        max_tokens=max_tokens,
        region_name=settings.AWS_REGION,
        disable_streaming=False
    )

async def _refresh_models_periodically():
    """Background task to refresh models before token expiry."""
    while True:
        try:
            # Calculate sleep time until next refresh
            refresh_time = _get_next_token_expiry()
            now = datetime.utcnow()
            sleep_seconds = (refresh_time - now).total_seconds()
            
            # Ensure minimum delay to prevent infinite loops
            if sleep_seconds > 0:
                logger.info(f"Next token refresh scheduled in {sleep_seconds/60:.1f} minutes")
                await asyncio.sleep(sleep_seconds)
            else:
                # Token already expired, wait minimum time before refreshing
                logger.warning(f"Token already expired (sleep_seconds={sleep_seconds:.1f}), waiting 5 minutes before refresh")
                await asyncio.sleep(300)
            
            # Refresh all cached models WITHOUT triggering task restart
            logger.info("Proactively refreshing AWS tokens for all models")
            for cache_key in ["efficient", "primary"]:
                if _model_cache[cache_key]["model"] is not None:
                    provider = _provider_for_cache_key(cache_key)
                    if not _is_aws_provider(provider):
                        continue

                    # Direct model refresh without calling get_model to avoid loop
                    model = _create_model_for_cache_key(cache_key)

                    # Update cache directly (AWS-backed providers only)
                    _model_cache[cache_key] = {
                        "model": model,
                        "expires_at": _get_next_token_expiry()
                    }
                    logger.info(f"Refreshed {cache_key} model with new AWS tokens")
                        
        except Exception as e:
            logger.error(f"Error in token refresh background task: {e}", exc_info=True)
            # On error, wait 5 minutes and try again
            await asyncio.sleep(300)

async def start_token_refresh_task():
    """Start the background token refresh task (only once)."""
    global _refresh_task, _task_started
    
    # Use lock to prevent race condition
    async with _refresh_lock:
        # Check if task already started
        if _task_started:
            return
            
        if _refresh_task is None or _refresh_task.done():
            _refresh_task = asyncio.create_task(_refresh_models_periodically())
            _task_started = True
            logger.info("Started AWS token refresh background task")

def get_model(efficient: bool = False, force_refresh: bool = False) -> BaseChatModel:
    """
    Get chat model objects with automatic credential refresh on expiry.
    
    Args:
        efficient: use smaller and more cost friendly model
        force_refresh: force creation of new model instance (useful after token expiry)

    Returns:
        A Langchain chat model object.
    """
    cache_key = "efficient" if efficient else "primary"
    
    # Check if model exists and token hasn't expired
    cache_entry = _model_cache[cache_key]
    if not force_refresh and cache_entry["model"] is not None:
        # For non-AWS providers, expires_at is None and cache can be reused indefinitely
        if cache_entry["expires_at"] is None or datetime.utcnow() < cache_entry["expires_at"]:
            return cache_entry["model"]
        else:
            logger.warning(f"{cache_key.capitalize()} model token expired, refreshing")
    
    # Create new model instance
    model = _create_model_for_cache_key(cache_key)
    provider = _provider_for_cache_key(cache_key)

    # Cache the new model. Only AWS-backed providers need expiry tracking.
    _model_cache[cache_key] = {
        "model": model,
        "expires_at": _get_next_token_expiry() if _is_aws_provider(provider) else None
    }
    
    logger.debug(f"Created new {cache_key} model instance, expires at {_model_cache[cache_key]['expires_at']}")
    
    # Ensure AWS token refresh task is running only for AWS-backed providers
    if _is_aws_provider(provider):
        try:
            asyncio.create_task(start_token_refresh_task())
        except RuntimeError:
            # Event loop not running yet, will start on first async call
            pass
    
    return model

async def invoke_with_retry(
    model: BaseChatModel,
    messages,
    efficient: bool = False,
    max_retries: int = 2
) -> any:
    """
    Invoke model with automatic retry on ExpiredTokenException.
    
    Args:
        model: The model to invoke
        messages: The messages to send (list of Message objects or compatible format)
        efficient: Whether this is an efficient model (for refresh)
        max_retries: Maximum number of retries on token expiry
        
    Returns:
        Model response
        
    Raises:
        Exception: If all retries fail
    """
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return await model.ainvoke(messages)
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            last_exception = e
            
            if error_code == 'ExpiredTokenException':
                if attempt < max_retries:
                    logger.warning(
                        f"AWS token expired during invocation, "
                        f"refreshing and retrying (attempt {attempt + 1}/{max_retries + 1})"
                    )
                    # Get fresh model with new credentials
                    model = get_model(efficient=efficient, force_refresh=True)
                    # Small delay before retry
                    await asyncio.sleep(1)
                    continue
                else:
                    logger.error(
                        f"AWS token expired and max retries ({max_retries}) reached. "
                        "This should not happen with proactive refresh. Check token refresh task."
                    )
                    raise
            else:
                # Re-raise non-token-expiry errors immediately
                logger.error(f"AWS Bedrock error (non-token): {error_code} - {str(e)}")
                raise
                
        except Exception as e:
            # Handle other exceptions
            logger.error(f"Unexpected error during model invocation: {type(e).__name__} - {str(e)}")
            raise
    
    # Should never reach here
    if last_exception:
        raise last_exception
    raise Exception("Unexpected error in invoke_with_retry")

async def stream_with_retry(
    model: BaseChatModel,
    messages,
    efficient: bool = False,
    max_retries: int = 2
):
    """
    Stream model response with automatic retry on ExpiredTokenException.
    
    Args:
        model: The model to invoke
        messages: The messages to send
        efficient: Whether this is an efficient model
        max_retries: Maximum number of retries on token expiry
        
    Yields:
        Streaming response chunks
        
    Raises:
        Exception: If all retries fail
    """
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            async for chunk in model.astream(messages):
                yield chunk
            return  # Success, exit
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            last_exception = e
            
            if error_code == 'ExpiredTokenException':
                if attempt < max_retries:
                    logger.warning(
                        f"AWS token expired during streaming, "
                        f"refreshing and retrying (attempt {attempt + 1}/{max_retries + 1})"
                    )
                    # Get fresh model with new credentials
                    model = get_model(efficient=efficient, force_refresh=True)
                    await asyncio.sleep(1)
                    continue
                else:
                    logger.error(f"AWS token expired and max retries ({max_retries}) reached")
                    raise
            else:
                logger.error(f"AWS Bedrock error during streaming: {error_code} - {str(e)}")
                raise
                
        except Exception as e:
            logger.error(f"Unexpected error during model streaming: {type(e).__name__} - {str(e)}")
            raise
    
    if last_exception:
        raise last_exception
    raise Exception("Unexpected error in stream_with_retry")
