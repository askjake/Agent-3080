"""
Tool Memory Service - High-level interface for memory system.
Coordinates context storage, retrieval, and injection.
"""
from typing import Dict, Any, List, Optional
import asyncio
import logging

from app.core.memory.context_service import ContextService
from app.core.memory.summarization_service import SummarizationService

logger = logging.getLogger(__name__)


class ToolMemoryService:
    """
    High-level service for tool execution memory management.
    Coordinates all memory-related operations.
    """
    
    def __init__(self):
        """Initialize the tool memory service."""
        self.context_service = ContextService()
        self.summarization_service = SummarizationService()
        self._enabled = False
        
    def enable(self):
        """Enable memory system."""
        self._enabled = True
        logger.info("Tool memory system enabled")
    
    def disable(self):
        """Disable memory system."""
        self._enabled = False
        logger.info("Tool memory system disabled")
    
    @property
    def enabled(self) -> bool:
        """Check if memory system is enabled."""
        return self._enabled
    
    async def store_execution(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        tool_output: str,
        execution_time: float,
        success: bool = True,
        error_message: Optional[str] = None,
        user_query: Optional[str] = None
    ) -> Optional[int]:
        """
        Store a tool execution in memory.
        
        Args:
            tool_name: Name of the executed tool
            tool_parameters: Parameters passed to tool
            tool_output: Output from tool
            execution_time: Execution time in seconds
            success: Whether execution succeeded
            error_message: Error message if failed
            user_query: Original user query
            
        Returns:
            Execution ID if stored, None if memory disabled
        """
        if not self._enabled:
            return None
        
        try:
            # Summarize output if too long
            summarized_output = self.summarization_service.summarize_tool_output(
                tool_name=tool_name,
                tool_output=tool_output,
                success=success
            )
            
            # Store in database
            execution_id = await self.context_service.store_tool_execution(
                tool_name=tool_name,
                tool_parameters=tool_parameters,
                tool_output=summarized_output,
                execution_time=execution_time,
                success=success,
                error_message=error_message,
                user_query=user_query
            )
            
            logger.debug(
                f"Stored execution: {tool_name} (ID: {execution_id}, "
                f"success: {success}, time: {execution_time:.2f}s)"
            )
            
            return execution_id
            
        except Exception as e:
            logger.error(f"Failed to store execution: {e}", exc_info=True)
            return None
    
    async def get_relevant_context(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        max_contexts: int = 3,
        similarity_threshold: float = 0.7
    ) -> str:
        """
        Get relevant context for a tool execution.
        
        Args:
            tool_name: Name of tool about to execute
            tool_parameters: Parameters for tool
            max_contexts: Maximum contexts to retrieve
            similarity_threshold: Minimum similarity score
            
        Returns:
            Formatted context string (empty if disabled)
        """
        if not self._enabled:
            return ""
        
        try:
            context = await self.context_service.assemble_context(
                tool_name=tool_name,
                tool_parameters=tool_parameters,
                max_contexts=max_contexts
            )
            
            if context:
                logger.debug(f"Retrieved context for {tool_name} ({len(context)} chars)")
            
            return context
            
        except Exception as e:
            logger.error(f"Failed to retrieve context: {e}", exc_info=True)
            return ""
    
    async def get_statistics(
        self,
        tool_name: Optional[str] = None,
        days: int = 7
    ) -> Dict[str, Any]:
        """
        Get execution statistics.
        
        Args:
            tool_name: Filter by tool name (optional)
            days: Number of days to look back
            
        Returns:
            Statistics dictionary
        """
        if not self._enabled:
            return {
                "enabled": False,
                "message": "Memory system is disabled"
            }
        
        try:
            stats = await self.context_service.get_execution_statistics(
                tool_name=tool_name,
                days=days
            )
            stats["enabled"] = True
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}", exc_info=True)
            return {
                "enabled": True,
                "error": str(e)
            }
    
    async def clear_old_executions(self, days: int = 30) -> int:
        """
        Clear executions older than specified days.
        
        Args:
            days: Age threshold in days
            
        Returns:
            Number of executions cleared
        """
        if not self._enabled:
            return 0
        
        try:
            from datetime import datetime, timedelta
            from sqlalchemy import delete
            from app.core.memory.models import ToolExecution
            from app.db import get_db_session
            
            cutoff_date = datetime.utcnow() - timedelta(days=days)
            
            async for db in get_db_session():
                stmt = delete(ToolExecution).where(
                    ToolExecution.created_at < cutoff_date
                )
                result = await db.execute(stmt)
                await db.commit()
                
                count = result.rowcount
                logger.info(f"Cleared {count} old executions (older than {days} days)")
                return count
                
        except Exception as e:
            logger.error(f"Failed to clear old executions: {e}", exc_info=True)
            return 0
    
    def get_health_status(self) -> Dict[str, Any]:
        """
        Get health status of memory system.
        
        Returns:
            Health status dictionary
        """
        return {
            "enabled": self._enabled,
            "context_service": "initialized",
            "summarization_service": "initialized",
            "status": "healthy" if self._enabled else "disabled"
        }


# Global instance
_tool_memory_service: Optional[ToolMemoryService] = None


def get_tool_memory_service() -> ToolMemoryService:
    """Get or create the global tool memory service instance."""
    global _tool_memory_service
    
    if _tool_memory_service is None:
        _tool_memory_service = ToolMemoryService()
        
        # Check settings for auto-enable
        try:
            from app.config import get_settings
            settings = get_settings()
            if settings.ENABLE_MEMORY_INTEGRATION:
                _tool_memory_service.enable()
                logger.info("Tool memory system auto-enabled from settings")
        except Exception as e:
            logger.warning(f"Could not read ENABLE_MEMORY_INTEGRATION setting: {e}")
    
    return _tool_memory_service
