"""
Database Models for Memory Enhancement (Production Version)
Imports Base from app.db.base for integration with existing models
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, Float, DateTime, Boolean, ForeignKey, JSON, Index
from sqlalchemy.dialects.postgresql import UUID

# Production import
from app.db.base import Base

# Import pgvector type
try:
    from pgvector.sqlalchemy import Vector
except ImportError:
    print("WARNING: pgvector not installed. Vector columns will fail.")
    from sqlalchemy.dialects.postgresql import ARRAY
    Vector = lambda dim: ARRAY(Float)


class ConversationSummary(Base):
    """
    Stores periodic summaries of conversations with embeddings for semantic search.
    Generated every N messages to provide context in future conversations.
    """
    __tablename__ = "conversation_summaries"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(UUID(as_uuid=True), ForeignKey("chat.chat_id", ondelete="CASCADE"), nullable=False)
    summary = Column(Text, nullable=False)
    embedding = Column(Vector(384), nullable=True)  # pgvector type
    message_count = Column(Integer, default=0)  # Number of messages summarized
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    # Indexes for performance
    __table_args__ = (
        Index('idx_conversation_summaries_chat_id', 'chat_id'),
        Index('idx_conversation_summaries_created_at', 'created_at'),
    )


class ToolExecutionMemory(Base):
    """
    Base table for tool execution memories.
    Stores common fields across all tool types.
    """
    __tablename__ = "tool_execution_memory"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, nullable=False)
    chat_id = Column(UUID(as_uuid=True), ForeignKey("chat.chat_id", ondelete="CASCADE"), nullable=False)
    tool_name = Column(String(100), nullable=False)
    tool_category = Column(String(50), nullable=False)
    
    # Execution details
    execution_timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    execution_data = Column(JSON, nullable=False)
    result_summary = Column(Text, nullable=True)
    embedding = Column(Vector(384), nullable=True)
    
    # Memory management
    scope = Column(String(20), default="ephemeral")
    utility_score = Column(Float, default=0.0)
    retrieval_count = Column(Integer, default=0)
    last_retrieved = Column(DateTime, nullable=True)
    
    # Metadata
    confidence_score = Column(Float, default=1.0)
    deprecated = Column(Boolean, default=False)
    deprecated_reason = Column(String(200), nullable=True)
    deprecated_at = Column(DateTime, nullable=True)
    
    __table_args__ = (
        Index('idx_tool_execution_user_id', 'user_id'),
        Index('idx_tool_execution_chat_id', 'chat_id'),
        Index('idx_tool_execution_tool_category', 'tool_category'),
        Index('idx_tool_execution_scope', 'scope'),
        Index('idx_tool_execution_deprecated', 'deprecated'),
        Index('idx_tool_execution_timestamp', 'execution_timestamp'),
    )


class NetraExecutionMemory(Base):
    """
    Specialized memory for Netra (receiver analysis) tool executions.
    """
    __tablename__ = "netra_execution_memory"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    memory_id = Column(Integer, ForeignKey("tool_execution_memory.id", ondelete="CASCADE"), nullable=False)
    
    # Netra-specific fields
    receiver_id = Column(String(12), nullable=False)
    analysis_type = Column(String(50), nullable=True)
    error_types_found = Column(JSON, nullable=True)
    health_score = Column(Float, nullable=True)
    recommendations = Column(JSON, nullable=True)
    
    __table_args__ = (
        Index('idx_netra_memory_receiver_id', 'receiver_id'),
        Index('idx_netra_memory_memory_id', 'memory_id'),
    )


class ToolInsight(Base):
    """
    Aggregated patterns learned from tool executions.
    """
    __tablename__ = "tool_insights"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    tool_category = Column(String(50), nullable=False)
    pattern_description = Column(Text, nullable=False)
    pattern_data = Column(JSON, nullable=True)
    
    # Statistics
    confidence_score = Column(Float, default=0.0)
    occurrence_count = Column(Integer, default=1)
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    
    # Metadata
    created_by = Column(String(50), default="pattern_aggregator")
    deprecated = Column(Boolean, default=False)
    
    __table_args__ = (
        Index('idx_tool_insights_tool_category', 'tool_category'),
        Index('idx_tool_insights_confidence', 'confidence_score'),
        Index('idx_tool_insights_deprecated', 'deprecated'),
    )


class MemoryCorrection(Base):
    """
    User corrections to memories (crowd-sourced validation).
    """
    __tablename__ = "memory_corrections"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    memory_id = Column(Integer, ForeignKey("tool_execution_memory.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(Integer, nullable=False)
    
    # Correction details
    correction_type = Column(String(20), nullable=False)
    correction_reason = Column(Text, nullable=True)
    temporal_constraint = Column(String(200), nullable=True)
    
    # Voting
    vote_weight = Column(Float, default=1.0)
    vote_count = Column(Integer, default=1)
    
    # Status
    auto_deprecated = Column(Boolean, default=False)
    requires_review = Column(Boolean, default=False)
    
    # Timestamps
    first_correction_timestamp = Column(DateTime, default=datetime.utcnow)
    last_correction_timestamp = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index('idx_memory_corrections_memory_id', 'memory_id'),
        Index('idx_memory_corrections_user_id', 'user_id'),
        Index('idx_memory_corrections_auto_deprecated', 'auto_deprecated'),
    )


class UserReputation(Base):
    """
    Tracks user reputation for memory corrections per tool category.
    """
    __tablename__ = "user_reputation"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, nullable=False)
    tool_category = Column(String(50), nullable=False)
    
    # Reputation metrics
    reputation_score = Column(Float, default=0.5)
    total_corrections = Column(Integer, default=0)
    validated_corrections = Column(Integer, default=0)
    
    # Recency tracking
    last_correction_at = Column(DateTime, nullable=True)
    last_validated_at = Column(DateTime, nullable=True)
    
    __table_args__ = (
        Index('idx_user_reputation_user_id', 'user_id'),
        Index('idx_user_reputation_tool_category', 'tool_category'),
        Index('idx_user_reputation_score', 'reputation_score'),
    )


class ToolExecution(Base):
    """
    Simple tool execution storage for memory enhancement.
    Used by context_service for storing and retrieving tool executions.
    """
    __tablename__ = "tool_executions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    tool_name = Column(String(255), nullable=False)
    tool_parameters = Column(JSON, nullable=False)
    tool_output = Column(Text, nullable=False)
    embedding = Column(Vector(384), nullable=True)
    metadata_ = Column(JSON, nullable=True)
    user_query = Column(Text, nullable=True)
    success = Column(Boolean, default=True)
    execution_time = Column(Float, nullable=True)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index('idx_tool_executions_tool_name', 'tool_name'),
        Index('idx_tool_executions_created_at', 'created_at'),
        Index('idx_tool_executions_success', 'success'),
    )
