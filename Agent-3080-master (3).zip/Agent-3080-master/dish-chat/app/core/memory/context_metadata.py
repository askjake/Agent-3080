"""
Context metadata management for memory system.
Handles metadata extraction, normalization, and confidence scoring.
"""
from typing import Dict, Any, Optional, List
from datetime import datetime
import json
from enum import Enum


class ContextType(str, Enum):
    """Types of context information."""
    TOOL_EXECUTION = "tool_execution"
    USER_QUERY = "user_query"
    SYSTEM_STATE = "system_state"
    ERROR_RESOLUTION = "error_resolution"


class ContextMetadata:
    """Manages metadata for context entries."""
    
    @staticmethod
    def extract_metadata(
        tool_name: str,
        tool_parameters: Dict[str, Any],
        tool_output: str,
        execution_time: float,
        success: bool,
        error_message: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Extract and normalize metadata from tool execution.
        
        Args:
            tool_name: Name of the executed tool
            tool_parameters: Parameters passed to the tool
            tool_output: Output returned by the tool
            execution_time: Time taken to execute (seconds)
            success: Whether execution was successful
            error_message: Error message if execution failed
            
        Returns:
            Dictionary of normalized metadata
        """
        metadata = {
            "tool_name": tool_name,
            "timestamp": datetime.utcnow().isoformat(),
            "execution_time_ms": round(execution_time * 1000, 2),
            "success": success,
            "context_type": ContextType.TOOL_EXECUTION.value,
            "parameter_count": len(tool_parameters),
            "output_length": len(tool_output),
            "has_error": bool(error_message),
        }
        
        # Add parameter types
        metadata["parameter_types"] = {
            k: type(v).__name__ for k, v in tool_parameters.items()
        }
        
        # Add error details if present
        if error_message:
            metadata["error_message"] = error_message
            metadata["error_type"] = ContextMetadata._classify_error(error_message)
        
        # Add semantic tags
        metadata["tags"] = ContextMetadata._generate_tags(
            tool_name, tool_parameters, success
        )
        
        # Add complexity score
        metadata["complexity_score"] = ContextMetadata._calculate_complexity(
            tool_parameters, tool_output
        )
        
        return metadata
    
    @staticmethod
    def _classify_error(error_message: str) -> str:
        """Classify error type from error message."""
        error_lower = error_message.lower()
        
        if "timeout" in error_lower:
            return "timeout"
        elif "permission" in error_lower or "denied" in error_lower:
            return "permission"
        elif "not found" in error_lower or "404" in error_lower:
            return "not_found"
        elif "connection" in error_lower or "network" in error_lower:
            return "network"
        elif "invalid" in error_lower or "validation" in error_lower:
            return "validation"
        elif "database" in error_lower or "sql" in error_lower:
            return "database"
        else:
            return "unknown"
    
    @staticmethod
    def _generate_tags(
        tool_name: str,
        tool_parameters: Dict[str, Any],
        success: bool
    ) -> List[str]:
        """Generate semantic tags for better search."""
        tags = [tool_name]
        
        # Add success/failure tag
        tags.append("success" if success else "failure")
        
        # Add parameter-based tags
        for key in tool_parameters.keys():
            if key in ["query", "search", "keyword"]:
                tags.append("search_operation")
            elif key in ["file", "path", "filename"]:
                tags.append("file_operation")
            elif key in ["cluster", "namespace", "pod"]:
                tags.append("kubernetes")
            elif key in ["aws", "s3", "lambda", "ec2"]:
                tags.append("aws")
        
        # Add tool category tags
        if "search" in tool_name.lower():
            tags.append("search")
        elif "cluster" in tool_name.lower() or "kubectl" in tool_name.lower():
            tags.append("infrastructure")
        elif "python" in tool_name.lower() or "shell" in tool_name.lower():
            tags.append("execution")
        elif "git" in tool_name.lower():
            tags.append("version_control")
        
        return list(set(tags))  # Remove duplicates
    
    @staticmethod
    def _calculate_complexity(
        tool_parameters: Dict[str, Any],
        tool_output: str
    ) -> float:
        """
        Calculate complexity score (0.0 - 1.0).
        Higher score = more complex operation.
        """
        score = 0.0
        
        # Parameter complexity (max 0.3)
        param_count = len(tool_parameters)
        if param_count > 0:
            score += min(0.3, param_count * 0.05)
        
        # Parameter depth (nested structures)
        max_depth = ContextMetadata._get_max_depth(tool_parameters)
        score += min(0.2, max_depth * 0.05)
        
        # Output complexity (max 0.3)
        output_lines = tool_output.count('\n')
        if output_lines > 0:
            score += min(0.3, output_lines / 1000)
        
        # Output size (max 0.2)
        output_size = len(tool_output)
        if output_size > 0:
            score += min(0.2, output_size / 50000)
        
        return round(min(1.0, score), 3)
    
    @staticmethod
    def _get_max_depth(obj: Any, current_depth: int = 0) -> int:
        """Get maximum nesting depth of a dictionary/list."""
        if not isinstance(obj, (dict, list)):
            return current_depth
        
        if isinstance(obj, dict):
            if not obj:
                return current_depth
            return max(
                ContextMetadata._get_max_depth(v, current_depth + 1)
                for v in obj.values()
            )
        else:  # list
            if not obj:
                return current_depth
            return max(
                ContextMetadata._get_max_depth(item, current_depth + 1)
                for item in obj
            )
    
    @staticmethod
    def calculate_relevance_score(
        query_embedding: List[float],
        candidate_embedding: List[float],
        metadata: Dict[str, Any],
        query_tool_name: str
    ) -> float:
        """
        Calculate relevance score combining semantic similarity and metadata.
        
        Args:
            query_embedding: Embedding of current query
            candidate_embedding: Embedding of candidate context
            metadata: Metadata of candidate context
            query_tool_name: Name of tool being executed
            
        Returns:
            Relevance score (0.0 - 1.0)
        """
        # Cosine similarity (base score)
        similarity = ContextMetadata._cosine_similarity(
            query_embedding, candidate_embedding
        )
        
        # Boost score if same tool
        if metadata.get("tool_name") == query_tool_name:
            similarity *= 1.2
        
        # Reduce score for failed executions
        if not metadata.get("success", True):
            similarity *= 0.8
        
        # Boost score for recent executions
        timestamp = metadata.get("timestamp")
        if timestamp:
            recency_boost = ContextMetadata._calculate_recency_boost(timestamp)
            similarity *= recency_boost
        
        return round(min(1.0, similarity), 4)
    
    @staticmethod
    def _cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        import math
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        magnitude1 = math.sqrt(sum(a * a for a in vec1))
        magnitude2 = math.sqrt(sum(b * b for b in vec2))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        return dot_product / (magnitude1 * magnitude2)
    
    @staticmethod
    def _calculate_recency_boost(timestamp: str) -> float:
        """Calculate recency boost factor (1.0 - 1.5)."""
        try:
            execution_time = datetime.fromisoformat(timestamp)
            age_hours = (datetime.utcnow() - execution_time).total_seconds() / 3600
            
            # More recent = higher boost
            if age_hours < 1:
                return 1.5
            elif age_hours < 24:
                return 1.3
            elif age_hours < 168:  # 1 week
                return 1.1
            else:
                return 1.0
        except:
            return 1.0
    
    @staticmethod
    def format_context_for_injection(
        contexts: List[Dict[str, Any]],
        max_contexts: int = 3
    ) -> str:
        """
        Format retrieved contexts for injection into agent prompt.
        
        Args:
            contexts: List of context dictionaries with scores
            max_contexts: Maximum number of contexts to include
            
        Returns:
            Formatted context string
        """
        if not contexts:
            return ""
        
        formatted_parts = []
        formatted_parts.append("## Relevant Past Executions\n")
        
        for i, ctx in enumerate(contexts[:max_contexts], 1):
            score = ctx.get("score", 0.0)
            metadata = ctx.get("metadata", {})
            content = ctx.get("content", "")
            
            formatted_parts.append(f"### Context {i} (Relevance: {score:.2%})\n")
            formatted_parts.append(f"**Tool:** {metadata.get('tool_name', 'unknown')}\n")
            formatted_parts.append(f"**Status:** {'✅ Success' if metadata.get('success') else '❌ Failed'}\n")
            
            if metadata.get("execution_time_ms"):
                formatted_parts.append(f"**Duration:** {metadata['execution_time_ms']}ms\n")
            
            if metadata.get("timestamp"):
                formatted_parts.append(f"**When:** {metadata['timestamp']}\n")
            
            # Truncate long content
            max_content_length = 500
            if len(content) > max_content_length:
                content = content[:max_content_length] + "... (truncated)"
            
            formatted_parts.append(f"**Details:**\n```\n{content}\n```\n\n")
        
        return "\n".join(formatted_parts)
