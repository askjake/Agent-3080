"""
Summarization service for memory context management.
Handles intelligent summarization of tool outputs for efficient storage and retrieval.
"""
from typing import Dict, Any, List, Optional
import re


class SummarizationService:
    """Service for summarizing tool outputs and contexts."""
    
    def __init__(self, max_summary_length: int = 500):
        """
        Initialize summarization service.
        
        Args:
            max_summary_length: Maximum length of summaries in characters
        """
        self.max_summary_length = max_summary_length
    
    def summarize_tool_output(
        self,
        tool_name: str,
        tool_output: str,
        success: bool = True
    ) -> str:
        """
        Create an intelligent summary of tool output.
        
        Args:
            tool_name: Name of the tool that produced output
            tool_output: Full output from the tool
            success: Whether the execution was successful
            
        Returns:
            Summarized output
        """
        if len(tool_output) <= self.max_summary_length:
            return tool_output
        
        # Apply tool-specific summarization strategy
        if "search" in tool_name.lower():
            return self._summarize_search_results(tool_output)
        elif "cluster" in tool_name.lower() or "kubectl" in tool_name.lower():
            return self._summarize_kubernetes_output(tool_output)
        elif "shell" in tool_name.lower() or "python" in tool_name.lower():
            return self._summarize_execution_output(tool_output)
        else:
            return self._generic_summarization(tool_output)
    
    def _summarize_search_results(self, output: str) -> str:
        """Summarize search results focusing on key findings."""
        lines = output.split('\n')
        
        # Extract key information
        summary_lines = []
        for line in lines[:10]:  # First 10 lines usually contain headers
            if any(keyword in line.lower() for keyword in ['result', 'found', 'match', 'total']):
                summary_lines.append(line)
        
        # Add sample results
        summary_lines.append("\n[Sample results]")
        summary_lines.extend(lines[10:15])  # Next 5 lines
        
        summary = "\n".join(summary_lines)
        return self._truncate_to_limit(summary)
    
    def _summarize_kubernetes_output(self, output: str) -> str:
        """Summarize Kubernetes command output."""
        lines = output.split('\n')
        
        # Keep headers and first few entries
        summary_lines = []
        
        # Get header
        if lines:
            summary_lines.append(lines[0])
        
        # Get first few data rows
        data_lines = [l for l in lines[1:] if l.strip()]
        summary_lines.extend(data_lines[:5])
        
        # Add count if there are more
        remaining = len(data_lines) - 5
        if remaining > 0:
            summary_lines.append(f"\n... and {remaining} more entries")
        
        summary = "\n".join(summary_lines)
        return self._truncate_to_limit(summary)
    
    def _summarize_execution_output(self, output: str) -> str:
        """Summarize script/command execution output."""
        lines = output.split('\n')
        
        # Look for errors first
        error_lines = [l for l in lines if any(
            keyword in l.lower() for keyword in ['error', 'exception', 'failed', 'traceback']
        )]
        
        if error_lines:
            # Focus on errors
            summary_lines = ["[Error Output]"]
            summary_lines.extend(error_lines[:10])
        else:
            # Focus on beginning and end
            summary_lines = ["[Beginning]"]
            summary_lines.extend(lines[:5])
            
            if len(lines) > 10:
                summary_lines.append("\n[...]\n")
                summary_lines.append("[End]")
                summary_lines.extend(lines[-5:])
        
        summary = "\n".join(summary_lines)
        return self._truncate_to_limit(summary)
    
    def _generic_summarization(self, output: str) -> str:
        """Generic summarization strategy."""
        # Take first and last portions
        if len(output) > self.max_summary_length:
            first_part_len = self.max_summary_length // 2
            last_part_len = self.max_summary_length // 2
            
            first_part = output[:first_part_len]
            last_part = output[-last_part_len:]
            
            return f"{first_part}\n\n[... truncated ...]\n\n{last_part}"
        
        return output
    
    def _truncate_to_limit(self, text: str) -> str:
        """Ensure text doesn't exceed maximum length."""
        if len(text) <= self.max_summary_length:
            return text
        
        return text[:self.max_summary_length - 20] + "\n\n[... truncated]"
    
    def summarize_context_for_prompt(
        self,
        contexts: List[Dict[str, Any]],
        max_total_length: int = 2000
    ) -> str:
        """
        Summarize multiple contexts for prompt injection.
        
        Args:
            contexts: List of context dictionaries
            max_total_length: Maximum total length of all contexts
            
        Returns:
            Summarized context string
        """
        if not contexts:
            return ""
        
        # Calculate budget per context
        budget_per_context = max_total_length // len(contexts)
        
        summarized_contexts = []
        for ctx in contexts:
            output = ctx.get("tool_output", "")
            
            if len(output) > budget_per_context:
                # Summarize this context
                summarized = self._generic_summarization(output)
                if len(summarized) > budget_per_context:
                    summarized = summarized[:budget_per_context - 20] + "\n[truncated]"
                ctx["tool_output"] = summarized
            
            summarized_contexts.append(ctx)
        
        return summarized_contexts
    
    def extract_key_points(self, text: str, max_points: int = 5) -> List[str]:
        """
        Extract key points from text.
        
        Args:
            text: Input text
            max_points: Maximum number of key points to extract
            
        Returns:
            List of key point strings
        """
        # Simple heuristic: look for lines that start with markers
        lines = text.split('\n')
        
        key_points = []
        for line in lines:
            line = line.strip()
            
            # Check for common markers of important information
            if any(line.startswith(marker) for marker in ['✅', '❌', '•', '-', '*', '1.', '2.', '3.']):
                key_points.append(line)
            elif any(keyword in line.lower() for keyword in ['error:', 'warning:', 'success:', 'failed:', 'completed:']):
                key_points.append(line)
            
            if len(key_points) >= max_points:
                break
        
        return key_points[:max_points]
