"""
Context service for memory-enhanced tool execution.
Handles context storage, retrieval, and relevance scoring.
"""
from typing import Dict, Any, List, Optional
from datetime import datetime
import json
import asyncio
from sqlalchemy import select, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.memory.models import ToolExecution
from app.core.memory.embedding_service import EmbeddingService
from app.core.memory.context_metadata import ContextMetadata
from app.db import get_db_session


class ContextService:
    """Service for context-aware tool execution memory."""
    
    def __init__(self):
        self.embedding_service = EmbeddingService()
        self.context_metadata = ContextMetadata()
        
    async def store_tool_execution(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        tool_output: str,
        execution_time: float,
        success: bool = True,
        error_message: Optional[str] = None,
        user_query: Optional[str] = None
    ) -> int:
        """
        Store a tool execution with embeddings for future retrieval.
        
        Args:
            tool_name: Name of the tool that was executed
            tool_parameters: Parameters passed to the tool
            tool_output: Output returned by the tool
            execution_time: Time taken to execute (seconds)
            success: Whether the execution was successful
            error_message: Error message if execution failed
            user_query: Original user query that triggered this execution
            
        Returns:
            ID of the stored execution
        """
        # Generate embedding for semantic search
        # Combine tool name, parameters, and output for embedding
        embedding_text = f"{tool_name}\n{json.dumps(tool_parameters)}\n{tool_output[:1000]}"
        embedding = self.embedding_service.embed_text(embedding_text).tolist()
        
        # Extract metadata
        metadata = self.context_metadata.extract_metadata(
            tool_name=tool_name,
            tool_parameters=tool_parameters,
            tool_output=tool_output,
            execution_time=execution_time,
            success=success,
            error_message=error_message
        )
        
        # Store in database
        async for db in get_db_session():
            execution = ToolExecution(
                tool_name=tool_name,
                tool_parameters=tool_parameters,
                tool_output=tool_output,
                embedding=embedding,
                metadata_=metadata,
                user_query=user_query,
                success=success,
                execution_time=execution_time,
                error_message=error_message
            )
            
            db.add(execution)
            await db.commit()
            await db.refresh(execution)
            
            return execution.id
    
    async def retrieve_relevant_context(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        top_k: int = 3,
        similarity_threshold: float = 0.7
    ) -> List[Dict[str, Any]]:
        """
        Retrieve relevant past executions for context injection.
        
        Args:
            tool_name: Name of the tool about to be executed
            tool_parameters: Parameters for the tool
            top_k: Maximum number of contexts to retrieve
            similarity_threshold: Minimum similarity score (0.0 - 1.0)
            
        Returns:
            List of relevant context dictionaries with scores
        """
        # Generate query embedding
        query_text = f"{tool_name}\n{json.dumps(tool_parameters)}"
        query_embedding = self.embedding_service.embed_text(query_text)
        
        # Search for similar past executions
        async for db in get_db_session():
            # Get all successful executions of the same tool
            stmt = select(ToolExecution).where(
                and_(
                    ToolExecution.tool_name == tool_name,
                    ToolExecution.success == True
                )
            ).order_by(desc(ToolExecution.created_at)).limit(20)
            
            result = await db.execute(stmt)
            candidates = result.scalars().all()
            
            # Calculate relevance scores
            scored_contexts = []
            for candidate in candidates:
                score = self.context_metadata.calculate_relevance_score(
                    query_embedding=query_embedding,
                    candidate_embedding=candidate.embedding,
                    metadata=candidate.metadata_,
                    query_tool_name=tool_name
                )
                
                if score >= similarity_threshold:
                    scored_contexts.append({
                        "id": candidate.id,
                        "tool_name": candidate.tool_name,
                        "tool_parameters": candidate.tool_parameters,
                        "tool_output": candidate.tool_output,
                        "metadata": candidate.metadata_,
                        "user_query": candidate.user_query,
                        "score": score,
                        "timestamp": candidate.created_at.isoformat()
                    })
            
            # Sort by score and return top_k
            scored_contexts.sort(key=lambda x: x["score"], reverse=True)
            return scored_contexts[:top_k]
    
    async def assemble_context(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        max_contexts: int = 3
    ) -> str:
        """
        Assemble formatted context for injection into agent prompt.
        
        Args:
            tool_name: Name of the tool about to be executed
            tool_parameters: Parameters for the tool (FIXED: renamed from 'parameters')
            max_contexts: Maximum number of contexts to include
            
        Returns:
            Formatted context string ready for injection
        """
        contexts = await self.retrieve_relevant_context(
            tool_name=tool_name,
            tool_parameters=tool_parameters,
            top_k=max_contexts
        )
        
        if not contexts:
            return ""
        
        return self.context_metadata.format_context_for_injection(
            contexts=contexts,
            max_contexts=max_contexts
        )
    
    async def get_execution_statistics(
        self,
        tool_name: Optional[str] = None,
        days: int = 7
    ) -> Dict[str, Any]:
        """
        Get statistics about tool executions.
        
        Args:
            tool_name: Filter by specific tool (optional)
            days: Number of days to look back
            
        Returns:
            Dictionary with execution statistics
        """
        from datetime import timedelta
        
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        async for db in get_db_session():
            stmt = select(ToolExecution).where(
                ToolExecution.created_at >= cutoff_date
            )
            
            if tool_name:
                stmt = stmt.where(ToolExecution.tool_name == tool_name)
            
            result = await db.execute(stmt)
            executions = result.scalars().all()
            
            total = len(executions)
            successful = sum(1 for e in executions if e.success)
            failed = total - successful
            
            avg_execution_time = (
                sum(e.execution_time for e in executions) / total
                if total > 0 else 0
            )
            
            return {
                "total_executions": total,
                "successful": successful,
                "failed": failed,
                "success_rate": successful / total if total > 0 else 0,
                "avg_execution_time_ms": round(avg_execution_time * 1000, 2),
                "tool_name": tool_name,
                "period_days": days
            }
