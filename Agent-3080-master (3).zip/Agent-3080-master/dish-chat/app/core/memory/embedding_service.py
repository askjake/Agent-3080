"""
Embedding Service for Memory Enhancement
Provides text-to-vector conversion using sentence-transformers
"""
import numpy as np
from typing import List, Union
from sentence_transformers import SentenceTransformer
import logging

logger = logging.getLogger(__name__)

class EmbeddingService:
    """
    Generates embeddings for text using sentence-transformers.
    Model: all-MiniLM-L6-v2 (384 dimensions, fast, good quality)
    """
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize embedding service.
        
        Args:
            model_name: Sentence transformer model name
        """
        logger.info(f"Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.dimension = self.model.get_sentence_embedding_dimension()
        logger.info(f"Model loaded. Embedding dimension: {self.dimension}")
    
    def embed_text(self, text: str) -> np.ndarray:
        """
        Generate embedding for a single text.
        
        Args:
            text: Input text to embed
            
        Returns:
            np.ndarray: Embedding vector (384 dimensions)
        """
        if not text or not text.strip():
            logger.warning("Empty text provided for embedding")
            return np.zeros(self.dimension)
        
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding
    
    def embed_batch(self, texts: List[str]) -> np.ndarray:
        """
        Generate embeddings for multiple texts (batch processing).
        
        Args:
            texts: List of texts to embed
            
        Returns:
            np.ndarray: Array of embeddings (N x 384)
        """
        if not texts:
            logger.warning("Empty text list provided for batch embedding")
            return np.zeros((0, self.dimension))
        
        # Filter out empty texts
        valid_texts = [t if t and t.strip() else " " for t in texts]
        
        embeddings = self.model.encode(
            valid_texts, 
            convert_to_numpy=True,
            show_progress_bar=len(valid_texts) > 100
        )
        return embeddings
    
    def get_dimension(self) -> int:
        """Return embedding dimension."""
        return self.dimension

# Global singleton instance (lazy loaded)
_embedding_service = None

def get_embedding_service() -> EmbeddingService:
    """
    Get or create global embedding service instance.
    """
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service
