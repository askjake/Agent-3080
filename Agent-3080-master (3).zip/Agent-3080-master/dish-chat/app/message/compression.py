"""
Message history compression and token management utilities.
"""
import logging
from typing import List, Optional
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage, ToolMessage
from langchain_core.messages import trim_messages
import tiktoken

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

# Token counter - using cl100k_base (GPT-4/Claude approximation)
try:
    _tokenizer = tiktoken.get_encoding("cl100k_base")
except Exception as e:
    logger.warning(f"Could not load tiktoken encoder, using character-based fallback: {e}")
    _tokenizer = None

def count_tokens(text: str) -> int:
    """
    Count approximate tokens in text.
    
    Args:
        text: Text to count tokens for
        
    Returns:
        Approximate token count
    """
    if _tokenizer:
        try:
            return len(_tokenizer.encode(text))
        except Exception as e:
            logger.warning(f"Token counting error, using fallback: {e}")
    
    # Fallback: rough approximation (1 token ≈ 4 characters)
    return len(text) // 4

def count_message_tokens(messages: List[BaseMessage]) -> int:
    """
    Count total tokens in a list of messages.
    
    Args:
        messages: List of LangChain messages
        
    Returns:
        Total token count
    """
    total = 0
    for msg in messages:
        # Count message content
        if isinstance(msg.content, str):
            total += count_tokens(msg.content)
        elif isinstance(msg.content, list):
            # Handle complex content (images, etc)
            for item in msg.content:
                if isinstance(item, dict) and "text" in item:
                    total += count_tokens(item["text"])
                elif isinstance(item, str):
                    total += count_tokens(item)
        
        # Add overhead for message structure (~10 tokens per message)
        total += 10
    
    return total

def trim_message_history(
    messages: List[BaseMessage],
    max_tokens: Optional[int] = None,
    strategy: str = "last",
    keep_system: bool = True,
    token_counter = None
) -> List[BaseMessage]:
    """
    Trim message history to fit within token limit.
    
    Args:
        messages: List of messages to trim
        max_tokens: Maximum tokens to keep (default: 80% of model context)
        strategy: Trimming strategy - "last" keeps most recent messages
        keep_system: Whether to always keep system messages
        token_counter: Optional custom token counter function
        
    Returns:
        Trimmed list of messages
    """
    if not messages:
        return messages
    
    # Use 80% of model context window by default (leave room for response)
    if max_tokens is None:
        # For Claude Sonnet 4.5: 200k context, but keep to 160k for safety
        max_tokens = int(settings.ELLM_CTX_LEN * 0.8)
    
    # Use custom counter or default
    counter = token_counter or count_message_tokens
    
    # Check if we're already under limit
    current_tokens = counter(messages)
    if current_tokens <= max_tokens:
        logger.debug(f"Message history within limit: {current_tokens}/{max_tokens} tokens")
        return messages
    
    logger.info(f"Trimming message history: {current_tokens} -> {max_tokens} tokens")
    
    # Separate system messages if we're keeping them
    system_messages = []
    other_messages = []
    
    for msg in messages:
        if isinstance(msg, SystemMessage) and keep_system:
            system_messages.append(msg)
        else:
            other_messages.append(msg)
    
    # Calculate tokens used by system messages
    system_tokens = counter(system_messages) if system_messages else 0
    available_tokens = max_tokens - system_tokens
    
    if available_tokens <= 0:
        logger.error("System messages exceed token limit!")
        return messages[:1]  # Return just first message
    
    # Try using langchain's trim_messages (if available)
    try:
        from langchain_core.messages import trim_messages as lc_trim
        
        # Trim other messages to fit
        trimmed_others = lc_trim(
            other_messages,
            max_tokens=available_tokens,
            strategy=strategy,
            token_counter=lambda msgs: counter(msgs),
            include_system=False,
            allow_partial=False,
            start_on="human"  # Always start with a human message
        )
        
        result = system_messages + trimmed_others
        final_tokens = counter(result)
        logger.info(f"Trimmed to {len(result)} messages ({final_tokens} tokens)")
        return result
        
    except ImportError:
        # Fallback: simple last-N strategy
        logger.warning("langchain trim_messages not available, using simple fallback")
        return _simple_trim(messages, max_tokens, keep_system, counter)

def _simple_trim(
    messages: List[BaseMessage],
    max_tokens: int,
    keep_system: bool,
    counter
) -> List[BaseMessage]:
    """
    Simple fallback trimming: keep system message + most recent messages.
    """
    system_msg = None
    other_msgs = []
    
    for msg in messages:
        if isinstance(msg, SystemMessage) and keep_system and system_msg is None:
            system_msg = msg
        else:
            other_msgs.append(msg)
    
    # Start with system message if present
    result = [system_msg] if system_msg else []
    current_tokens = counter(result)
    
    # Add messages from the end (most recent first)
    for msg in reversed(other_msgs):
        msg_tokens = counter([msg])
        if current_tokens + msg_tokens <= max_tokens:
            result.insert(1 if system_msg else 0, msg)
            current_tokens += msg_tokens
        else:
            break
    
    logger.info(f"Simple trim kept {len(result)} messages ({current_tokens} tokens)")
    return result

def should_compress_history(messages: List[BaseMessage]) -> bool:
    """
    Check if message history should be compressed.
    
    Args:
        messages: List of messages to check
        
    Returns:
        True if compression is recommended
    """
    token_count = count_message_tokens(messages)
    # Compress if we're using more than 70% of context
    threshold = int(settings.ELLM_CTX_LEN * 0.7)
    
    if token_count > threshold:
        logger.info(f"Message history compression recommended: {token_count}/{threshold} tokens")
        return True
    
    return False

def get_compression_stats(messages: List[BaseMessage]) -> dict:
    """
    Get statistics about message history for monitoring.
    
    Args:
        messages: List of messages
        
    Returns:
        Dictionary with token counts and message stats
    """
    total_tokens = count_message_tokens(messages)
    
    message_types = {}
    for msg in messages:
        msg_type = type(msg).__name__
        message_types[msg_type] = message_types.get(msg_type, 0) + 1
    
    return {
        "total_messages": len(messages),
        "total_tokens": total_tokens,
        "context_usage_pct": (total_tokens / settings.ELLM_CTX_LEN) * 100,
        "message_types": message_types,
        "avg_tokens_per_message": total_tokens // len(messages) if messages else 0
    }

# ADD TO: ~/Jakes-agent/dish-chat/app/message/compression.py
# INSERT AFTER: existing functions (around line 200)

def intelligent_compress_messages(
    messages: List[BaseMessage],
    target_tokens: int,
    preserve_recent: int = 20,
    use_llm: bool = False
) -> List[BaseMessage]:
    """
    Intelligently compress message history while preserving conversation flow.
    
    This function uses a multi-tier compression strategy:
    - Tier 1 (Recent): Keep last N messages completely intact
    - Tier 2 (Middle): Selective compression based on content type
    - Tier 3 (Old): Aggressive compression into summary messages
    
    Args:
        messages: List of messages to compress
        target_tokens: Target token count after compression
        preserve_recent: Number of recent messages to keep intact (default: 20)
        use_llm: Whether to use LLM for summarization (slower but better quality)
        
    Returns:
        Compressed list of messages that fits within target_tokens
    """
    if not messages:
        return messages
    
    current_tokens = count_message_tokens(messages)
    
    # If already under target, no compression needed
    if current_tokens <= target_tokens:
        logger.debug(f"No compression needed: {current_tokens}/{target_tokens} tokens")
        return messages
    
    logger.info(
        f"Starting intelligent compression: {len(messages)} msgs, "
        f"{current_tokens} -> {target_tokens} tokens "
        f"({int((1 - target_tokens/current_tokens) * 100)}% reduction needed)"
    )
    
    # Categorize messages into tiers
    recent, middle, old = _categorize_messages(messages, preserve_recent)
    
    # Keep recent messages intact
    compressed_recent = recent
    recent_tokens = count_message_tokens(recent)
    
    # Calculate remaining budget for middle and old tiers
    remaining_budget = target_tokens - recent_tokens
    
    if remaining_budget <= 0:
        logger.warning(
            f"Recent messages alone ({recent_tokens} tokens) exceed target! "
            f"Keeping only last {preserve_recent} messages"
        )
        return recent
    
    # Compress middle and old tiers
    compressed_middle = []
    compressed_old = []
    
    if old:
        # Allocate 20% of remaining budget to old messages
        old_budget = int(remaining_budget * 0.2)
        compressed_old = _compress_old_tier(old, old_budget, use_llm)
        old_tokens = count_message_tokens(compressed_old)
        
        # Remaining goes to middle tier
        middle_budget = remaining_budget - old_tokens
    else:
        middle_budget = remaining_budget
    
    if middle:
        compressed_middle = _compress_middle_tier(middle, middle_budget, use_llm)
    
    # Combine all tiers
    result = compressed_old + compressed_middle + compressed_recent
    
    final_tokens = count_message_tokens(result)
    compression_ratio = (1 - final_tokens / current_tokens) * 100
    
    logger.info(
        f"Compression complete: {len(messages)} -> {len(result)} msgs, "
        f"{current_tokens} -> {final_tokens} tokens "
        f"({compression_ratio:.1f}% reduction)"
    )
    
    return result


def _categorize_messages(
    messages: List[BaseMessage],
    preserve_recent: int
) -> tuple[List[BaseMessage], List[BaseMessage], List[BaseMessage]]:
    """
    Split messages into three tiers based on recency.
    
    Returns:
        (recent, middle, old) tuple of message lists
    """
    total = len(messages)
    
    if total <= preserve_recent:
        return messages, [], []
    
    # Recent: last N messages (keep intact)
    recent = messages[-preserve_recent:]
    
    # Middle: messages 21-50 from the end (selective compression)
    middle_start = max(0, total - 50)
    middle_end = total - preserve_recent
    middle = messages[middle_start:middle_end] if middle_end > middle_start else []
    
    # Old: everything before middle (aggressive compression)
    old = messages[:middle_start] if middle_start > 0 else []
    
    logger.debug(
        f"Categorized {total} messages: "
        f"{len(old)} old, {len(middle)} middle, {len(recent)} recent"
    )
    
    return recent, middle, old


def _compress_middle_tier(
    messages: List[BaseMessage],
    target_tokens: int,
    use_llm: bool
) -> List[BaseMessage]:
    """
    Selectively compress middle-tier messages.
    
    Strategy:
    - Keep user messages mostly intact
    - Compress long AI responses
    - Summarize tool results
    """
    if not messages:
        return []
    
    compressed = []
    current_tokens = 0
    
    for msg in messages:
        if current_tokens >= target_tokens:
            # Budget exhausted, compress remaining messages into summary
            remaining = messages[messages.index(msg):]
            if len(remaining) > 3:
                summary = _create_chunk_summary(remaining)
                compressed.append(summary)
            break
        
        # Process message based on type
        if msg.type in ["human", "user"]:
            # Keep user messages mostly intact
            msg_tokens = count_message_tokens([msg])
            if msg_tokens > 1000:
                # Very long user message, compress it
                compressed_msg = _compress_single_message(msg, max_tokens=500, use_llm=use_llm)
                compressed.append(compressed_msg)
                current_tokens += count_message_tokens([compressed_msg])
            else:
                compressed.append(msg)
                current_tokens += msg_tokens
                
        elif msg.type == "ai":
            # Compress AI responses more aggressively
            msg_tokens = count_message_tokens([msg])
            if msg_tokens > 300:
                # Compress long AI response
                target_size = max(150, int(msg_tokens * 0.4))  # 60% reduction
                compressed_msg = _compress_single_message(msg, max_tokens=target_size, use_llm=use_llm)
                compressed.append(compressed_msg)
                current_tokens += count_message_tokens([compressed_msg])
            else:
                compressed.append(msg)
                current_tokens += msg_tokens
                
        elif isinstance(msg, ToolMessage):
            # Compress tool results
            compressed_msg = _compress_tool_message(msg)
            compressed.append(compressed_msg)
            current_tokens += count_message_tokens([compressed_msg])
        else:
            # Other message types: keep as-is
            compressed.append(msg)
            current_tokens += count_message_tokens([msg])
    
    logger.debug(
        f"Middle tier: {len(messages)} -> {len(compressed)} msgs, "
        f"{count_message_tokens(messages)} -> {current_tokens} tokens"
    )
    
    return compressed


def _compress_old_tier(
    messages: List[BaseMessage],
    target_tokens: int,
    use_llm: bool
) -> List[BaseMessage]:
    """
    Aggressively compress old messages into summaries.
    
    Strategy:
    - Group messages into chunks
    - Create summary message for each chunk
    - Preserve key information only
    """
    if not messages:
        return []
    
    # Determine chunk size based on target
    # Aim for ~200 tokens per summary
    num_summaries = max(1, target_tokens // 200)
    chunk_size = max(1, len(messages) // num_summaries)
    
    compressed = []
    
    for i in range(0, len(messages), chunk_size):
        chunk = messages[i:i + chunk_size]
        summary = _create_chunk_summary(chunk)
        compressed.append(summary)
    
    logger.debug(
        f"Old tier: {len(messages)} -> {len(compressed)} summary msgs, "
        f"{count_message_tokens(messages)} -> {count_message_tokens(compressed)} tokens"
    )
    
    return compressed


def _compress_single_message(
    message: BaseMessage,
    max_tokens: int,
    use_llm: bool = False
) -> BaseMessage:
    """
    Compress a single message to fit within token limit.
    
    Uses extractive summarization (first + last sentences) or LLM if enabled.
    """
    content = message.content if isinstance(message.content, str) else str(message.content)
    current_tokens = count_tokens(content)
    
    if current_tokens <= max_tokens:
        return message
    
    # Simple extractive summary: first + last
    sentences = content.split('. ')
    
    if len(sentences) <= 2:
        # Already minimal, just truncate
        target_chars = max_tokens * 4  # Rough approximation
        compressed_content = content[:target_chars] + "..."
    else:
        # Take first and last sentences, fill middle if budget allows
        compressed_content = f"{sentences[0]}. "
        
        if len(sentences) > 3:
            compressed_content += f"[...{len(sentences)-2} sentences compressed...] "
        
        compressed_content += sentences[-1]
        
        if not sentences[-1].endswith('.'):
            compressed_content += '.'
    
    # Create new message with same type
    if isinstance(message, HumanMessage):
        return HumanMessage(content=f"[COMPRESSED] {compressed_content}")
    elif isinstance(message, AIMessage):
        return AIMessage(content=f"[COMPRESSED] {compressed_content}")
    else:
        return message


def _compress_tool_message(message: ToolMessage) -> ToolMessage:
    """
    Compress a tool message by summarizing the result.
    """
    content = message.content if isinstance(message.content, str) else str(message.content)
    current_tokens = count_tokens(content)
    
    if current_tokens <= 200:
        return message
    
    # Extract first and last lines for context
    lines = content.split('\n')
    
    if len(lines) <= 3:
        compressed_content = content[:400] + "..."
    else:
        compressed_content = (
            f"{lines[0]}\n"
            f"[...{len(lines)-2} lines compressed...]\n"
            f"{lines[-1]}"
        )
    
    # Create new tool message
    return ToolMessage(
        content=f"[COMPRESSED] {compressed_content}",
        tool_call_id=message.tool_call_id if hasattr(message, 'tool_call_id') else None
    )


def _create_chunk_summary(messages: List[BaseMessage]) -> HumanMessage:
    """
    Create a summary message representing a chunk of messages.
    
    Extracts:
    - User queries/intents
    - Tools used
    - Key outcomes/decisions
    """
    user_queries = []
    ai_actions = []
    tools_used = set()
    errors = []
    
    for msg in messages:
        if msg.type in ["human", "user"]:
            # Extract user intent (first 100 chars)
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            user_queries.append(content[:100])
            
        elif msg.type == "ai":
            # Look for action keywords
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            if any(keyword in content.lower() for keyword in ['analyzed', 'found', 'created', 'fixed', 'updated']):
                ai_actions.append(content[:80])
                
        elif isinstance(msg, ToolMessage):
            # Track tool usage
            if hasattr(msg, 'name'):
                tools_used.add(msg.name)
            # Check for errors
            content_str = msg.content if isinstance(msg.content, str) else str(msg.content)
            if 'error' in content_str.lower():
                errors.append(content_str[:80])
    
    # Build summary
    summary_parts = [f"[COMPRESSED {len(messages)} messages]"]
    
    if user_queries:
        summary_parts.append(f"User: {'; '.join(user_queries[:2])}")
        if len(user_queries) > 2:
            summary_parts[-1] += f" (+{len(user_queries)-2} more queries)"
    
    if tools_used:
        summary_parts.append(f"Tools: {', '.join(list(tools_used)[:5])}")
    
    if ai_actions:
        summary_parts.append(f"Actions: {'; '.join(ai_actions[:2])}")
    
    if errors:
        summary_parts.append(f"⚠️ Errors encountered: {'; '.join(errors[:1])}")
    
    summary_text = ". ".join(summary_parts) + "."
    
    return HumanMessage(content=summary_text)


def get_compression_metrics(
    original_messages: List[BaseMessage],
    compressed_messages: List[BaseMessage]
) -> dict:
    """
    Calculate metrics about compression effectiveness.
    
    Returns:
        Dictionary with compression statistics
    """
    orig_count = len(original_messages)
    comp_count = len(compressed_messages)
    orig_tokens = count_message_tokens(original_messages)
    comp_tokens = count_message_tokens(compressed_messages)
    
    return {
        "original_messages": orig_count,
        "compressed_messages": comp_count,
        "message_reduction": orig_count - comp_count,
        "message_reduction_pct": ((orig_count - comp_count) / orig_count * 100) if orig_count > 0 else 0,
        "original_tokens": orig_tokens,
        "compressed_tokens": comp_tokens,
        "token_reduction": orig_tokens - comp_tokens,
        "token_reduction_pct": ((orig_tokens - comp_tokens) / orig_tokens * 100) if orig_tokens > 0 else 0,
        "compression_ratio": comp_tokens / orig_tokens if orig_tokens > 0 else 1.0
    }
