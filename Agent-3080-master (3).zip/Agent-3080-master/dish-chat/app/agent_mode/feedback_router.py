from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
from app.agent_mode.feedback import FeedbackCollector, FeedbackRating, FeedbackCategory
import os

router = APIRouter(prefix="/rest/api/v1/feedback", tags=["feedback"])

# Lazy initialization of collector
_collector = None

def get_collector():
    global _collector
    if _collector is None:
        storage_path = os.environ.get("FEEDBACK_STORAGE_PATH")
        if not storage_path:
            # Use writable location
            storage_path = os.path.expanduser("~/dish-chat/data/feedback.json")
        
        # Create directory if needed
        storage_dir = os.path.dirname(storage_path)
        if storage_dir:
            os.makedirs(storage_dir, exist_ok=True)
        
        _collector = FeedbackCollector(storage_path=storage_path)
    return _collector

class FeedbackRequest(BaseModel):
    message_id: str
    chat_id: str
    rating: FeedbackRating
    categories: Optional[List[FeedbackCategory]] = None
    comment: Optional[str] = None

@router.post("/")
async def submit_feedback(feedback: FeedbackRequest):
    """Submit feedback on an agent response"""
    collector = get_collector()
    user_id = "current_user"
    
    result = collector.collect_feedback(
        message_id=feedback.message_id,
        chat_id=feedback.chat_id,
        user_id=user_id,
        rating=feedback.rating,
        categories=feedback.categories or [],
        comment=feedback.comment
    )
    
    return {"feedback_id": str(result.feedback_id), "status": "recorded"}

@router.get("/stats")
async def get_feedback_stats(time_range_days: Optional[int] = None):
    """Get overall feedback statistics"""
    collector = get_collector()
    stats = collector.get_stats(time_range_days=time_range_days)
    return stats.to_dict()

@router.get("/report")
async def get_improvement_report():
    """Get detailed improvement report"""
    collector = get_collector()
    report = collector.generate_improvement_report()
    return {"report": report, "content_type": "text/markdown"}
