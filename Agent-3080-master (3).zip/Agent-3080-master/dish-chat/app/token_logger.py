"""
Multi-Agent Hub Token Logging Client

Easy integration for agents to report token usage to the central hub.
"""

import requests
import time
from typing import Optional, Dict, Any
from functools import wraps
import logging

logger = logging.getLogger(__name__)

class TokenLogger:
    """Client for logging token usage to Multi-Agent Hub"""
    
    def __init__(self, hub_url: str = "http://localhost:5000", agent_id: Optional[int] = None, 
                 agent_name: Optional[str] = None, enabled: bool = True):
        """
        Initialize token logger
        
        Args:
            hub_url: URL of the Multi-Agent Hub API
            agent_id: ID of this agent in the hub (optional if agent_name provided)
            agent_name: Name of this agent (optional if agent_id provided)
            enabled: Whether logging is enabled (disable for development)
        """
        self.hub_url = hub_url.rstrip('/')
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.enabled = enabled
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json'})
        
    def log_tokens(self, prompt_tokens: int, completion_tokens: int, 
                   endpoint: str = "/chat", request_type: str = "chat",
                   response_time: Optional[float] = None) -> bool:
        """
        Log token usage to the hub
        
        Args:
            prompt_tokens: Number of tokens in the prompt
            completion_tokens: Number of tokens in the completion
            endpoint: API endpoint that was called
            request_type: Type of request (chat, completion, etc.)
            response_time: Response time in seconds (optional)
            
        Returns:
            True if logging successful, False otherwise
        """
        if not self.enabled:
            return False
            
        try:
            payload = {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "endpoint": endpoint,
                "request_type": request_type
            }
            
            if self.agent_id:
                payload["agent_id"] = self.agent_id
            elif self.agent_name:
                payload["agent_name"] = self.agent_name
            else:
                logger.warning("TokenLogger: No agent_id or agent_name provided")
                return False
            
            if response_time is not None:
                payload["response_time"] = response_time
            
            response = self.session.post(
                f"{self.hub_url}/api/tokens/log",
                json=payload,
                timeout=2  # Short timeout to not block main app
            )
            
            if response.status_code == 200:
                logger.debug(f"Token usage logged: {prompt_tokens + completion_tokens} tokens")
                return True
            else:
                logger.warning(f"Failed to log tokens: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.warning(f"Error logging tokens: {e}")
            return False
    
    def log_evolution(self, version: str, change_type: str, 
                     change_description: str, metrics: Optional[Dict] = None) -> bool:
        """
        Log agent evolution/improvement
        
        Args:
            version: Version string (e.g., "2.1")
            change_type: Type of change (prompt_update, methodology, etc.)
            change_description: Description of what changed
            metrics: Optional metrics dict
            
        Returns:
            True if logging successful, False otherwise
        """
        if not self.enabled:
            return False
            
        try:
            payload = {
                "version": version,
                "change_type": change_type,
                "change_description": change_description
            }
            
            if self.agent_id:
                payload["agent_id"] = self.agent_id
            elif self.agent_name:
                payload["agent_name"] = self.agent_name
            
            if metrics:
                payload["metrics"] = metrics
            
            response = self.session.post(
                f"{self.hub_url}/api/evolution/log",
                json=payload,
                timeout=2
            )
            
            return response.status_code == 200
            
        except Exception as e:
            logger.warning(f"Error logging evolution: {e}")
            return False
    
    def log_safety_violation(self, violation_type: str, description: str, 
                            prevented: bool = True) -> bool:
        """
        Log safety violation
        
        Args:
            violation_type: Type of violation
            description: Description of the violation
            prevented: Whether the violation was prevented
            
        Returns:
            True if logging successful, False otherwise
        """
        if not self.enabled:
            return False
            
        try:
            payload = {
                "violation_type": violation_type,
                "description": description,
                "prevented": prevented
            }
            
            if self.agent_id:
                payload["agent_id"] = self.agent_id
            elif self.agent_name:
                payload["agent_name"] = self.agent_name
            
            response = self.session.post(
                f"{self.hub_url}/api/safety/violation",
                json=payload,
                timeout=2
            )
            
            return response.status_code == 200
            
        except Exception as e:
            logger.warning(f"Error logging violation: {e}")
            return False
    
    def get_stats(self, days: int = 7) -> Optional[Dict]:
        """
        Get token usage statistics for this agent
        
        Args:
            days: Number of days to look back
            
        Returns:
            Statistics dict or None if failed
        """
        if not self.agent_id:
            logger.warning("Cannot get stats without agent_id")
            return None
            
        try:
            response = self.session.get(
                f"{self.hub_url}/api/tokens/stats/{self.agent_id}?days={days}",
                timeout=5
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
                
        except Exception as e:
            logger.warning(f"Error getting stats: {e}")
            return None
    
    def decorator(self, extract_tokens_fn=None):
        """
        Decorator to automatically log token usage from function returns
        
        Usage:
            token_logger = TokenLogger(agent_name="my-agent")
            
            @token_logger.decorator()
            def my_llm_call():
                # Your LLM call
                return {"response": "...", "usage": {"prompt_tokens": 10, "completion_tokens": 20}}
            
        Or with custom extraction:
            @token_logger.decorator(lambda result: result['token_usage'])
            def my_llm_call():
                return {"text": "...", "token_usage": {"prompt": 10, "completion": 20}}
        """
        def decorator_wrapper(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                start_time = time.time()
                result = func(*args, **kwargs)
                response_time = time.time() - start_time
                
                # Extract token usage
                if extract_tokens_fn:
                    usage = extract_tokens_fn(result)
                elif isinstance(result, dict):
                    # Try common patterns
                    usage = result.get('usage') or result.get('token_usage') or result.get('tokens')
                else:
                    usage = None
                
                if usage:
                    prompt_tokens = usage.get('prompt_tokens') or usage.get('prompt') or 0
                    completion_tokens = usage.get('completion_tokens') or usage.get('completion') or 0
                    
                    self.log_tokens(
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        endpoint=f"/{func.__name__}",
                        response_time=response_time
                    )
                
                return result
            return wrapper
        return decorator_wrapper


# Convenience function for quick integration
def create_token_logger(agent_name: str, hub_url: str = "http://localhost:5000", 
                       enabled: bool = True) -> TokenLogger:
    """
    Quick way to create a token logger
    
    Args:
        agent_name: Name of your agent
        hub_url: URL of the Multi-Agent Hub API
        enabled: Whether logging is enabled
        
    Returns:
        TokenLogger instance
        
    Example:
        from token_logger import create_token_logger
        
        logger = create_token_logger("my-agent")
        logger.log_tokens(prompt_tokens=100, completion_tokens=50)
    """
    return TokenLogger(hub_url=hub_url, agent_name=agent_name, enabled=enabled)
