"""
AWS Credential Manager with Auto-Refresh
Monitors ~/.aws/credentials and reloads credentials when file changes
"""
import os
import logging
import asyncio
from pathlib import Path
from datetime import datetime
from functools import cache
from typing import Optional
import boto3.session
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

logger = logging.getLogger(__name__)

class AWSCredentialManager:
    """Manages AWS credentials with automatic refresh on file change"""
    
    def __init__(self, region: str = "us-west-2"):
        self.region = region
        self.credentials_file = Path.home() / ".aws" / "credentials"
        self._session: Optional[boto3.session.Session] = None
        self._last_modified: Optional[float] = None
        self._observer: Optional[Observer] = None
        self._cached_clients = {}
        
        # Initialize session
        self._load_session()
        logger.info(f"AWS Credential Manager initialized for region {region}")
    
    def _load_session(self):
        """Load or reload the boto3 session"""
        try:
            # Check file modification time
            if self.credentials_file.exists():
                current_mtime = self.credentials_file.stat().st_mtime
                
                if self._last_modified != current_mtime:
                    logger.info(f"Credentials file changed (mtime: {datetime.fromtimestamp(current_mtime)}), reloading session")
                    
                    # Clear cached clients
                    self._cached_clients.clear()
                    
                    # Create new session (boto3 will read from ~/.aws/credentials)
                    self._session = boto3.session.Session(region_name=self.region)
                    self._last_modified = current_mtime
                    
                    logger.info("✓ AWS session reloaded with fresh credentials")
            else:
                logger.warning(f"Credentials file not found: {self.credentials_file}")
                self._session = boto3.session.Session(region_name=self.region)
                
        except Exception as e:
            logger.error(f"Failed to load AWS session: {e}", exc_info=True)
            # Fall back to default session
            self._session = boto3.session.Session(region_name=self.region)
    
    def get_client(self, service_name: str, **kwargs):
        """Get AWS client with auto-refresh credentials"""
        # Check if credentials file changed
        if self.credentials_file.exists():
            current_mtime = self.credentials_file.stat().st_mtime
            if self._last_modified != current_mtime:
                logger.info(f"Detected credential update, refreshing {service_name} client")
                self._load_session()
        
        # Return client from current session
        if self._session:
            return self._session.client(service_name, **kwargs)
        return None
    
    def start_file_watcher(self):
        """Start watching credentials file for changes"""
        class CredentialsFileHandler(FileSystemEventHandler):
            def __init__(self, manager):
                self.manager = manager
                
            def on_modified(self, event):
                if event.src_path == str(self.manager.credentials_file):
                    logger.info(f"Credentials file modified: {event.src_path}")
                    self.manager._load_session()
        
        if self._observer is None and self.credentials_file.exists():
            self._observer = Observer()
            handler = CredentialsFileHandler(self)
            watch_dir = self.credentials_file.parent
            self._observer.schedule(handler, str(watch_dir), recursive=False)
            self._observer.start()
            logger.info(f"✓ Started file watcher for {self.credentials_file}")
    
    def stop_file_watcher(self):
        """Stop the file watcher"""
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._observer = None
            logger.info("File watcher stopped")
    
    async def periodic_refresh_check(self, interval_seconds: int = 60):
        """Periodic check for credential changes (backup to file watcher)"""
        while True:
            try:
                await asyncio.sleep(interval_seconds)
                if self.credentials_file.exists():
                    current_mtime = self.credentials_file.stat().st_mtime
                    if self._last_modified != current_mtime:
                        logger.info("Periodic check: credentials changed, reloading")
                        self._load_session()
            except Exception as e:
                logger.error(f"Error in periodic refresh check: {e}")


# Global credential manager instance
_credential_manager: Optional[AWSCredentialManager] = None

def initialize_aws_credentials(region: str = "us-west-2"):
    """Initialize the global AWS credential manager"""
    global _credential_manager
    _credential_manager = AWSCredentialManager(region=region)
    _credential_manager.start_file_watcher()
    return _credential_manager

def get_credential_manager() -> AWSCredentialManager:
    """Get the global credential manager instance"""
    if _credential_manager is None:
        raise RuntimeError("AWS Credential Manager not initialized. Call initialize_aws_credentials() first.")
    return _credential_manager

def shutdown_aws_credentials():
    """Shutdown the credential manager"""
    global _credential_manager
    if _credential_manager:
        _credential_manager.stop_file_watcher()
        _credential_manager = None
