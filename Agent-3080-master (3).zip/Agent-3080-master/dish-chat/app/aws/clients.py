"""
AWS Clients with Auto-Refreshing Credentials
"""
from app.config import get_settings
from app.aws.credential_manager import get_credential_manager

settings = get_settings()

def get_s3_client():
    """Get S3 client with auto-refreshing credentials"""
    manager = get_credential_manager()
    return manager.get_client("s3")
