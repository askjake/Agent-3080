"""
Context injection for memory-aware tool execution.
Wraps LangGraph ToolNode to inject relevant context before execution.
"""
from typing import Any, Callable, Dict, List, Optional, Sequence, Union
import time
import logging

from langchain_core.runnables import RunnableConfig
from langchain_core.tools import BaseTool
from langgraph.prebuilt import ToolNode

from app.agent.memory_integration import get_memory_integration

print("[MODULE LOAD] context_injection.py loaded", flush=True)
logger = logging.getLogger(__name__)


class MemoryAwareToolNode(ToolNode):
    """
    Extended ToolNode that injects relevant context before tool execution
    and stores results after execution.
    """
    
    def __init__(
        self,
        tools: Sequence[Union[BaseTool, Callable]],
        *,
        name: str = "tools",
        tags: Optional[list[str]] = None,
        handle_tool_errors: Optional[bool] = None
    ) -> None:
        """
        Initialize memory-aware tool node.
        
        Args:
            tools: List of tools available for execution
            name: Name of the node
            tags: Tags for the node
            handle_tool_errors: Whether to handle tool errors
        """
        super().__init__(
            tools,
            name=name,
            tags=tags,
            handle_tool_errors=handle_tool_errors
        )
        self.memory_integration = get_memory_integration()
        logger.info("MemoryAwareToolNode initialized - memory enabled: %s", self.memory_integration.is_enabled())
    
    async def ainvoke(
        self,
        input: Dict[str, Any],
        config: Optional[RunnableConfig] = None
    ) -> Dict[str, Any]:
        """
        Async invoke with memory integration.
        
        Workflow:
        1. Extract tool call information
        2. Retrieve relevant context from memory
        3. Inject context into tool execution
        4. Execute tool
        5. Store execution result in memory
        
        Args:
            input: Input containing messages with tool calls
            config: Runnable configuration
        logger.info("MemoryAwareToolNode.ainvoke called - memory enabled: %s", self.memory_integration.is_enabled())
            
        Returns:
            Tool execution results
        """
        # Check if memory is enabled
        if not self.memory_integration.is_enabled():
            # Memory disabled - use default behavior
            return await super().ainvoke(input, config)
        
        # Extract tool calls from messages
        messages = input.get("messages", [])
        if not messages:
            return await super().ainvoke(input, config)
        
        last_message = messages[-1]
        tool_calls = getattr(last_message, "tool_calls", [])
        
        if not tool_calls:
            return await super().ainvoke(input, config)
        
        # Process each tool call
        for tool_call in tool_calls:
            await self._process_tool_call_with_memory(
                tool_call=tool_call,
                input=input,
                config=config
            )
        
        # Execute tools with standard ToolNode
        start_time = time.time()
        result = await super().ainvoke(input, config)
        execution_time = time.time() - start_time
        
        # Storing tool results
        # Store execution results
        await self._store_tool_results(
            tool_calls=tool_calls,
            result=result,
            execution_time=execution_time
        )
        
        return result
    
    async def _process_tool_call_with_memory(
        self,
        tool_call: Dict[str, Any],
        input: Dict[str, Any],
        config: Optional[RunnableConfig]
    ) -> None:
        """
        Process a tool call with memory context injection.
        
        Args:
            tool_call: Tool call information
            input: Original input
            config: Runnable configuration
        """
        try:
            tool_name = tool_call.get("name")
            tool_parameters = tool_call.get("args", {})  # FIXED: was "parameters"
            
            if not tool_name:
                return
            
            # Retrieve relevant context
            context = await self.memory_integration.get_context_for_tool(
                tool_name=tool_name,
                tool_parameters=tool_parameters
            )
            
            if context:
                # Inject context into tool call (as a system message)
                logger.debug(f"Injecting context for {tool_name}: {len(context)} chars")
                
                # Add context to messages
                if "messages" in input:
                    # Create a context message
                    from langchain_core.messages import SystemMessage
                    context_message = SystemMessage(
                        content=f"## Relevant Context from Memory\n\n{context}"
                    )
                    # Insert before last message (which contains tool call)
                    input["messages"].insert(-1, context_message)
                    
        except Exception as e:
            logger.error(f"Error processing tool call with memory: {e}", exc_info=True)
    
    async def _store_tool_results(
        self,
        tool_calls: List[Dict[str, Any]],
        result: Dict[str, Any],
        execution_time: float
    ) -> None:
        """
        Store tool execution results in memory.
        
        Args:
            tool_calls: List of tool calls that were executed
            result: Execution results
            execution_time: Total execution time
        """
        try:
            # Extract tool messages from result
            result_messages = result.get("messages", [])
            
            # Match tool calls with results
            for i, tool_call in enumerate(tool_calls):
                tool_name = tool_call.get("name")
                tool_parameters = tool_call.get("args", {})  # FIXED: was "parameters"
                
                if not tool_name:
                    continue
                
                # Find corresponding result message
                tool_output = ""
                success = True
                error_message = None
                
                if i < len(result_messages):
                    result_msg = result_messages[i]
                    tool_output = getattr(result_msg, "content", "")
                    
                    # Check for errors
                    if hasattr(result_msg, "status"):
                        success = result_msg.status != "error"
                    if hasattr(result_msg, "error"):
                        error_message = result_msg.error
                
                # Store in memory
                await self.memory_integration.record_tool_execution(
                    tool_name=tool_name,
                    tool_parameters=tool_parameters,
                    tool_output=str(tool_output),
                    execution_time=execution_time / len(tool_calls),  # Approximate
                    success=success,
                    error_message=error_message
                )
                
                logger.debug(f"Stored execution: {tool_name} (success: {success})")
                
        except Exception as e:
            logger.error(f"Error storing tool results: {e}", exc_info=True)


def create_memory_aware_tool_node(
    tools: Sequence[Union[BaseTool, Callable]],
    **kwargs
) -> MemoryAwareToolNode:
    """
    Factory function to create a memory-aware tool node.
    
    Args:
        tools: List of tools
        **kwargs: Additional arguments for ToolNode
        
    Returns:
        MemoryAwareToolNode instance
    """
    logger.info("Creating MemoryAwareToolNode with %d tools", len(tools))
    print("[DEBUG] Creating MemoryAwareToolNode with", len(tools), "tools", flush=True)
    node = MemoryAwareToolNode(tools, **kwargs)
    logger.info("Created node type: %s", type(node).__name__)
    return node
