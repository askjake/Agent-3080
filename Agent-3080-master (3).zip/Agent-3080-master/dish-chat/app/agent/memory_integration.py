"""
Memory integration for agent backend.
Provides hooks for memory storage during tool execution.
"""
from typing import Dict, Any, Optional
import time
import logging

from app.core.memory.tool_memory_service import get_tool_memory_service

logger = logging.getLogger(__name__)


class MemoryIntegration:
    """Integration layer for memory system in agent backend."""
    
    def __init__(self):
        """Initialize memory integration."""
        self.memory_service = get_tool_memory_service()
    
    async def record_tool_execution(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any],
        tool_output: str,
        execution_time: float,
        success: bool = True,
        error_message: Optional[str] = None,
        user_query: Optional[str] = None
    ) -> Optional[int]:
        """
        Record a tool execution to memory.
        
        Args:
            tool_name: Name of executed tool
            tool_parameters: Parameters passed to tool
            tool_output: Output from tool
            execution_time: Time taken (seconds)
            success: Whether execution succeeded
            error_message: Error message if failed
            user_query: Original user query
            
        Returns:
            Execution ID if stored, None otherwise
        """
        if not self.memory_service.enabled:
            return None
        
        try:
            execution_id = await self.memory_service.store_execution(
                tool_name=tool_name,
                tool_parameters=tool_parameters,
                tool_output=tool_output,
                execution_time=execution_time,
                success=success,
                error_message=error_message,
                user_query=user_query
            )
            return execution_id
        except Exception as e:
            logger.error(f"Memory integration error: {e}", exc_info=True)
            return None
    
    async def get_context_for_tool(
        self,
        tool_name: str,
        tool_parameters: Dict[str, Any]
    ) -> str:
        """
        Get relevant context for a tool about to execute.
        
        Args:
            tool_name: Name of tool
            tool_parameters: Parameters for tool
            
        Returns:
            Formatted context string (empty if disabled)
        """
        if not self.memory_service.enabled:
            return ""
        
        try:
            context = await self.memory_service.get_relevant_context(
                tool_name=tool_name,
                tool_parameters=tool_parameters
            )
            return context
        except Exception as e:
            logger.error(f"Context retrieval error: {e}", exc_info=True)
            return ""
    
    def is_enabled(self) -> bool:
        """Check if memory system is enabled."""
        return self.memory_service.enabled
    
    def enable(self):
        """Enable memory system."""
        self.memory_service.enable()
    
    def disable(self):
        """Disable memory system."""
        self.memory_service.disable()


# Global instance
_memory_integration: Optional[MemoryIntegration] = None


def get_memory_integration() -> MemoryIntegration:
    """Get or create global memory integration instance."""
    global _memory_integration
    
    if _memory_integration is None:
        _memory_integration = MemoryIntegration()
    
    return _memory_integration
