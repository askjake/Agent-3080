import logging
from typing import Annotated, Any
from typing_extensions import TypedDict
from functools import cache
from langchain_core.runnables import RunnableConfig
from langchain_core.messages import BaseMessage, SystemMessage, AIMessage, ToolMessage
from botocore.exceptions import ClientError
from langgraph.graph.message import add_messages
from langgraph.graph import END, StateGraph, START
from langgraph.prebuilt import ToolNode

from app.core.llm import get_model
from app.config import get_settings
from app.core.utils import get_datestr_now
from app.message.compression import count_message_tokens, count_tokens, intelligent_compress_messages, get_compression_metrics

from ..db_utils import get_checkpointer
from ..utils import aggressive_cachept, cleanup_cachept, set_model_config
from .utils import get_prompt
from .tools import get_tools_set

logger = logging.getLogger(__name__)
settings = get_settings()

system_prompt = SystemMessage(
    content=get_prompt("chat_system").format(today=get_datestr_now())
)

# Maximum number of messages to keep in context
MAX_MESSAGES = 100


class AgentState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]
    model_config: dict[str, Any]
    consecutive_tool_calls: int  # Counter for consecutive tool calls
    consecutive_tool_errors: int  # Counter for consecutive tool errors


def sanitize_tool_messages(messages: list[BaseMessage]) -> list[BaseMessage]:
    """
    Remove orphaned tool calls and tool results from the message list.

    An orphaned tool call is an AIMessage with tool_calls where one or more
    corresponding ToolMessages are missing. An orphaned tool result is a
    ToolMessage whose parent AIMessage was dropped.

    This must be called both before and after any truncation to ensure
    the message list is always valid for the Bedrock Converse API.
    """
    # Strip any leading ToolMessages (can appear after truncation)
    while messages and isinstance(messages[0], ToolMessage):
        messages = messages[1:]

    # Pass 1: Collect all tool result IDs present in the message list
    tool_results_present: set[str] = set()
    for msg in messages:
        if isinstance(msg, ToolMessage):
            tool_call_id = getattr(msg, 'tool_call_id', None)
            if tool_call_id:
                tool_results_present.add(tool_call_id)

    # Pass 2: Walk messages, keeping only complete tool call/result pairs
    kept_tool_call_ids: set[str] = set()
    cleaned: list[BaseMessage] = []

    for msg in messages:
        if isinstance(msg, AIMessage) and getattr(msg, 'tool_calls', None):
            # Only keep this AIMessage if ALL of its tool calls have results
            if all(tc.get('id') in tool_results_present for tc in msg.tool_calls):
                for tc in msg.tool_calls:
                    kept_tool_call_ids.add(tc.get('id'))
                cleaned.append(msg)
            else:
                logger.warning(
                    f"Dropping AIMessage with incomplete tool calls: "
                    f"{[tc.get('id') for tc in msg.tool_calls]}"
                )
        elif isinstance(msg, ToolMessage):
            # Only keep if its parent AIMessage was kept
            if getattr(msg, 'tool_call_id', None) in kept_tool_call_ids:
                cleaned.append(msg)
            else:
                logger.warning(
                    f"Dropping orphaned ToolMessage: tool_call_id={getattr(msg, 'tool_call_id', None)}"
                )
        else:
            cleaned.append(msg)

    return cleaned


def estimate_tool_tokens(tools: list) -> int:
    """
    Estimate tokens used by tool definitions.
    
    Each tool typically uses 100-300 tokens depending on complexity.
    This provides a conservative estimate.
    
    Args:
        tools: List of tool definitions
        
    Returns:
        Estimated token count for all tools
    """
    if not tools:
        return 0
    
    # Conservative estimate: 200 tokens per tool on average
    # Some tools are simpler (~100), others more complex (~400)
    base_tokens = len(tools) * 200
    
    # Try to get more accurate count if possible
    try:
        total = 0
        for tool in tools:
            # Tool definitions contain name, description, and schema
            tool_text = ""
            if hasattr(tool, 'name'):
                tool_text += str(tool.name)
            if hasattr(tool, 'description'):
                tool_text += str(tool.description)
            if hasattr(tool, 'args_schema'):
                tool_text += str(tool.args_schema)
            
            if tool_text:
                total += count_tokens(tool_text)
        
        # Use the higher of the two estimates for safety
        return max(total, base_tokens)
    except Exception as e:
        logger.warning(f"Could not accurately count tool tokens: {e}, using estimate")


def smart_fallback_truncation(
    messages: list,
    available_tokens: int,
    token_counter,
    initial_request_msg=None
) -> list:
    """
    SMART FALLBACK: When trim_messages fails, intelligently preserve context.
    
    Strategy:
    1. Keep initial user request (critical for understanding task)
    2. Generate summary of trimmed messages (preserve context)
    3. Keep recent 20 messages (maintain conversation flow)
    4. Ensure result fits in available_tokens
    5. VALIDATE: First message MUST be human (Bedrock requirement)
    
    This prevents the "amnesia" problem where only 1 message is kept.
    """
    logger.warning(
        f"🔧 Smart fallback truncation triggered! "
        f"Original messages: {len(messages)}, Available tokens: {available_tokens}"
    )
    
    # Step 1: Identify the initial user request
    if initial_request_msg:
        initial_msg = initial_request_msg
    else:
        # Find first human message
        for msg in messages:
            if msg.type == "human":
                initial_msg = msg
                break
        else:
            initial_msg = None
    
    # Step 2: Keep recent N messages (default 20)
    recent_message_count = 20
    recent_messages = messages[-recent_message_count:] if len(messages) > recent_message_count else messages
    
    # Step 3: Generate summary of middle messages (if any)
    if len(messages) > recent_message_count + 1:
        middle_messages = messages[1:-recent_message_count]  # Exclude first and recent
        
        # Create concise summary
        summary_parts = []
        for msg in middle_messages[-10:]:  # Summarize last 10 of middle section
            content_preview = str(msg.content)[:200].replace("\n", " ")
            summary_parts.append(f"- {msg.type}: {content_preview}...")
        
        summary_text = (
            f"[Context Summary: {len(middle_messages)} messages omitted. "
            f"Recent highlights:\n" + "\n".join(summary_parts[-5:]) + "]"
        )
        
        summary_msg = AIMessage(content=summary_text)
    else:
        summary_msg = None
    
    # Step 4: Assemble the preserved messages
    preserved = []
    
    if initial_msg:
        preserved.append(initial_msg)
    
    if summary_msg:
        preserved.append(summary_msg)
    
    preserved.extend(recent_messages)
    
    # CRITICAL: Validate first message is human (Bedrock requirement)
    if preserved and preserved[0].type != "human":
        logger.warning(
            f"First message is {preserved[0].type}, not human! "
            f"Finding first human message..."
        )
        # Find first human message in preserved list
        first_human_idx = None
        for i, msg in enumerate(preserved):
            if msg.type == "human":
                first_human_idx = i
                break
        
        if first_human_idx is not None:
            # Reorder: move first human to front, keep rest in order
            preserved = [preserved[first_human_idx]] + preserved[:first_human_idx] + preserved[first_human_idx+1:]
            logger.info(f"Reordered: moved human message from index {first_human_idx} to front")
        else:
            logger.error("No human message found in preserved list! This should not happen!")
            # Fallback: use initial_msg or find one from original messages
            if initial_msg:
                preserved = [initial_msg] + preserved
            else:
                # Find ANY human message from original
                for msg in messages:
                    if msg.type == "human":
                        preserved = [msg] + preserved
                        break
    
    # Step 5: Ensure we fit in available_tokens
    preserved_tokens = token_counter(preserved)
    
    logger.info(
        f"Smart fallback result: {len(preserved)} messages, "
        f"{preserved_tokens} tokens (limit: {available_tokens})"
    )
    
    # If still too large, progressively trim
    if preserved_tokens > available_tokens:
        logger.warning(
            f"Smart fallback still too large ({preserved_tokens} > {available_tokens}), "
            f"reducing recent messages..."
        )
        
        # Try reducing recent messages count
        for reduced_count in [15, 10, 5, 3, 1]:
            test_preserved = []
            
            if initial_msg:
                test_preserved.append(initial_msg)
            
            if summary_msg:
                test_preserved.append(summary_msg)
            
            test_preserved.extend(messages[-reduced_count:])
            
            # Ensure first is human
            if test_preserved and test_preserved[0].type != "human":
                for i, msg in enumerate(test_preserved):
                    if msg.type == "human":
                        test_preserved = [test_preserved[i]] + test_preserved[:i] + test_preserved[i+1:]
                        break
            
            test_tokens = token_counter(test_preserved)
            
            if test_tokens <= available_tokens:
                logger.info(
                    f"Reduced to {len(test_preserved)} messages "
                    f"({test_tokens} tokens)"
                )
                return test_preserved
        
        # Last resort: just initial + last message
        logger.error(
            f"Even minimal preservation exceeds limit! "
            f"Keeping only initial + last message"
        )
        
        last_resort = []
        if initial_msg:
            last_resort.append(initial_msg)
        else:
            # Find first human message
            for msg in messages:
                if msg.type == "human":
                    last_resort.append(msg)
                    break
        
        # Add last message if it's human, otherwise find last human
        if messages[-1].type == "human":
            last_resort.append(messages[-1])
        else:
            for msg in reversed(messages):
                if msg.type == "human":
                    last_resort.append(msg)
                    break
        
        # Truncate content if needed
        last_resort_tokens = token_counter(last_resort)
        if last_resort_tokens > available_tokens and last_resort:
            # Truncate content (rough estimate: 1 token ≈ 3 chars)
            char_limit = int(available_tokens * 3)
            last_resort[-1].content = str(last_resort[-1].content)[:char_limit]
        
        return last_resort
    
    return preserved


def truncate_messages(
    messages: list[BaseMessage], 
    max_messages: int,
    system_prompt_tokens: int = 0,
    tool_tokens: int = 0
) -> list[BaseMessage]:
    """
    Truncate message history by token count first, then by message count.
    Always preserves the most recent messages.
    
    Args:
        messages: List of messages to truncate
        max_messages: Maximum number of messages to keep
        system_prompt_tokens: Tokens used by system prompt
        tool_tokens: Tokens used by tool definitions
        
    Returns:
        Truncated list of messages
    """
    # First truncate by message count as a safety limit
    if len(messages) > max_messages:
        logger.info(f"Truncating message history from {len(messages)} to {max_messages}")
        
        # CRITICAL FIX: Preserve at least the LAST human message before truncation
        # In tool-heavy conversations, naive [-max_messages:] can lose all human messages
        last_human_idx = None
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].type in ["human", "user"]:
                last_human_idx = i
                break
        
        if last_human_idx is not None and last_human_idx < len(messages) - max_messages:
            # The last human message would be lost! Include it + recent messages
            logger.warning(
                f"Last human message at index {last_human_idx} would be lost. "
                f"Preserving it + {max_messages-1} most recent messages."
            )
            # Take: [last_human_msg] + [most recent max_messages-1 messages]
            messages = [messages[last_human_idx]] + messages[-(max_messages-1):]
        else:
            # Safe to truncate normally
            messages = messages[-max_messages:]

    # Calculate available tokens for messages
    # Claude Sonnet 4.5: 200k context, reserve 20k for output, subtract system + tools
    max_context = settings.PLLM_CTX_LEN  # 200,000
    reserved_output = settings.MAX_OUTPUT_COUNT  # 12,000
    safety_margin = 35_000  # Extra safety buffer
    
    available_for_messages = (
        max_context 
        - reserved_output 
        - system_prompt_tokens 
        - tool_tokens 
        - safety_margin
    )
    
    logger.info(
        f"Token budget breakdown: "
        f"total={max_context}, "
        f"output={reserved_output}, "
        f"system={system_prompt_tokens}, "
        f"tools={tool_tokens}, "
        f"safety={safety_margin}, "
        f"available_for_messages={available_for_messages}"
    )

    # Then truncate by token count to prevent exceeding model limits
    try:
        from langchain_core.messages import trim_messages
        
        # Count tokens BEFORE truncation
        initial_tokens = count_message_tokens(messages)
        logger.info(f"Message tokens before truncation: {initial_tokens}")
        
        # CRITICAL FIX: Capture last user message for fallback
        last_user_msg = None
        for msg in reversed(messages):
            if msg.type in ["human", "user"]:
                last_user_msg = msg
                break
        
        if not last_user_msg:
            logger.critical(
                "🚨 CRITICAL BUG: No user message found after human-preserving truncation! "
                "This should never happen. Returning emergency Continue message. "
                "Message count: %d, Message types: %s",
                len(messages),
                [msg.type for msg in messages[:10]]  # Show first 10 types for debugging
            )
            from langchain_core.messages import HumanMessage
            return [HumanMessage(content="Continue.")]
        

        if initial_tokens > available_for_messages:
            # Use intelligent compression instead of simple truncation
            logger.info(
                f"Applying intelligent compression: {initial_tokens} -> {available_for_messages} tokens "
                f"({len(messages)} messages)"
            )
            
            try:
                messages = intelligent_compress_messages(
                    messages=messages,
                    target_tokens=available_for_messages,
                    preserve_recent=20
                )
                
                final_tokens = count_message_tokens(messages)
                logger.info(
                    f"Intelligent compression complete: "
                    f"{initial_tokens} -> {final_tokens} tokens, "
                    f"{len(messages)} messages, "
                    f"total_with_overhead={final_tokens + system_prompt_tokens + tool_tokens}"
                )
                
            except Exception as e:
                logger.error(f"Intelligent compression failed: {e}", exc_info=True)
                # Fallback to smart truncation
                messages_before_trim = messages
                messages = smart_fallback_truncation(
                    messages=messages_before_trim,
                    available_tokens=available_for_messages,
                    token_counter=count_message_tokens,
                    initial_request_msg=last_user_msg
                )
                logger.warning(f"Used smart fallback: {len(messages)} messages preserved")
        else:
            logger.info(
                f"No truncation needed: {initial_tokens} tokens < {available_for_messages} available"
            )
            
    except Exception as e:
        logger.error(f"Token-based truncation failed: {e}", exc_info=True)
        # Fallback to aggressive message count truncation
        fallback_count = min(20, len(messages))
        messages = messages[-fallback_count:]
        logger.warning(f"Using fallback: kept last {fallback_count} messages")

    # Re-sanitize after truncation since the cut point may have split a pair
    return sanitize_tool_messages(messages)


### Nodes
async def call_model(state: AgentState, config=None):
    """
    Call the model with tools enabled.
    The model can choose to use tools or respond directly.
    """
    messages = list(state["messages"])

    # Step 1: Get tools first (needed for token calculation)
    tools = (
        get_tools_set("search") + 
        get_tools_set("agent_mode") +
        get_tools_set("jira_mcp") +
        get_tools_set("confluence_mcp") +
        get_tools_set("netdetective") +
        get_tools_set("beta_report")
    )
    
    # Step 2: Calculate token overhead
    system_prompt_tokens = count_tokens(system_prompt.content)
    tool_tokens = estimate_tool_tokens(tools)
    
    logger.info(
        f"Pre-truncation overhead: "
        f"system_prompt={system_prompt_tokens} tokens, "
        f"tools={tool_tokens} tokens ({len(tools)} tools)"
    )

    # Step 3: Sanitize - remove orphaned tool calls and results
    messages = sanitize_tool_messages(messages)

    # Step 4: Truncate to max context window with proper token accounting
    messages = truncate_messages(
        messages, 
        MAX_MESSAGES,
        system_prompt_tokens=system_prompt_tokens,
        tool_tokens=tool_tokens
    )

    # Step 5: Handle cachepoints
    cleanup_cachept(messages)
    messages = aggressive_cachept(messages, settings.MAX_CACHEPOINT_CNT)

    # Step 6: Set up model
    model = get_model()
    set_model_config(model, state["model_config"])
    model_with_tools = model.bind_tools(tools)

    # Step 7: Log message state for debugging
    logger.info(f"Calling model with {len(messages)} messages")
    for i, msg in enumerate(messages):
        msg_tokens = count_message_tokens([msg])
        logger.info(
            f"  [{i}] {type(msg).__name__} "
            f"({msg_tokens} tokens) "
            f"- tool_calls: {bool(getattr(msg, 'tool_calls', None))}"
            f", tool_call_id: {getattr(msg, 'tool_call_id', None)}"
        )

    # Step 8: Final validation
    total_tokens = (
        system_prompt_tokens 
        + tool_tokens 
        + count_message_tokens(messages) 
        + settings.MAX_OUTPUT_COUNT
    )
    
    logger.info(
        f"Final token count: {total_tokens} / {settings.PLLM_CTX_LEN} "
        f"({(total_tokens / settings.PLLM_CTX_LEN * 100):.1f}%)"
    )
    
    if total_tokens > settings.PLLM_CTX_LEN:
        logger.error(
            f"ERROR: Token count {total_tokens} exceeds model limit {settings.PLLM_CTX_LEN}! "
            f"This should not happen. Applying emergency truncation."
        )
        # Emergency truncation - keep only last 5 messages
        messages = messages[-5:]
        logger.warning(f"Emergency truncation: kept last 5 messages only")

    # Step 9: Invoke the model
    # Retry logic for expired AWS tokens (V2 - improved exception handling)
    max_retries = 2
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            logger.debug(f"Model invocation attempt {attempt + 1}/{max_retries + 1}")
            response = await model_with_tools.ainvoke([system_prompt, *messages], config=config)
            logger.debug("Model invocation successful")
            break  # Success, exit retry loop
            
        except Exception as e:
            # Catch ALL exceptions and check if it's a token issue
            logger.error(f"Model invocation failed: {type(e).__name__}: {str(e)[:200]}")
            last_exception = e
            
            # Check if it's a ClientError with ExpiredToken
            is_expired_token = False
            if hasattr(e, '__class__') and e.__class__.__name__ == 'ClientError':
                try:
                    error_code = e.response.get("Error", {}).get("Code", "")
                    is_expired_token = (error_code == "ExpiredTokenException")
                except:
                    pass
            
            # Also check error message for token expiry
            error_msg = str(e).lower()
            if not is_expired_token and any(phrase in error_msg for phrase in [
                'expired', 'expiredtoken', 'security token', 'token included in the request'
            ]):
                is_expired_token = True
                logger.warning(f"Detected token expiry from error message: {error_msg[:100]}")
            
            if is_expired_token:
                if attempt < max_retries:
                    logger.warning(
                        f"AWS token expired during model invocation "
                        f"(attempt {attempt + 1}/{max_retries + 1}). "
                        f"Refreshing model and retrying..."
                    )
                    # Force refresh the model to get new credentials
                    model = get_model(efficient=False, force_refresh=True)
                    model_with_tools = model.bind_tools(tools)
                    logger.info("Model refreshed with new credentials, retrying...")
                    # Small delay before retry
                    import asyncio
                    await asyncio.sleep(1)
                    continue
                else:
                    logger.error(
                        f"AWS token expired and max retries ({max_retries}) reached. "
                        f"Credentials may not be refreshing properly."
                    )
                    raise
            
            # Check for input too long errors
            if "Input is too long" in error_msg or "ValidationException" in error_msg:
                logger.error(
                    f"Model rejected input as too long! "
                    f"Calculated tokens: {total_tokens}, "
                    f"Messages: {len(messages)}, "
                    f"This indicates token counting may be inaccurate."
                )
            
            # Re-raise all non-token-expiry errors
            raise

    # Step 10: Clean up cachepoints so they're not stored persistently
    cleanup_cachept(messages)

    return {"messages": [response]}



async def track_tool_execution(state: AgentState):
    """Track tool calls and errors to prevent infinite loops."""
    messages = state["messages"]
    consecutive_calls = state.get("consecutive_tool_calls", 0)
    consecutive_errors = state.get("consecutive_tool_errors", 0)
    
    # Check last message for tool calls or errors
    last_msg = messages[-1] if messages else None
    
    if isinstance(last_msg, AIMessage) and last_msg.tool_calls:
        consecutive_calls += 1
        logger.debug(f"Tool call detected. Consecutive count: {consecutive_calls}/{settings.MAX_TOOL_CALLS_PER_TURN}")
    elif isinstance(last_msg, ToolMessage):
        # Check if the tool message contains an error
        if "error" in str(last_msg.content).lower():
            consecutive_errors += 1
            logger.warning(f"Tool error detected. Consecutive errors: {consecutive_errors}/{settings.MAX_CONSECUTIVE_TOOL_ERRORS}")
    
    return {
        "consecutive_tool_calls": consecutive_calls,
        "consecutive_tool_errors": consecutive_errors,
    }


async def reset_tool_counters(state: AgentState):
    """Reset tool call counters when agent generates a text response."""
    logger.debug("Resetting tool call counters (agent generated response)")
    return {
        "consecutive_tool_calls": 0,
        "consecutive_tool_errors": 0,
    }


def should_continue(state: AgentState) -> str:
    """
    Determine if we should continue to tools or end.
    Includes safety checks for tool call limits and errors.
    """
    consecutive_calls = state.get("consecutive_tool_calls", 0)
    consecutive_errors = state.get("consecutive_tool_errors", 0)
    last_message = state["messages"][-1]

    # Safety check: Too many consecutive tool calls
    if consecutive_calls >= settings.MAX_TOOL_CALLS_PER_TURN:
        logger.warning(
            f"Tool call limit reached ({consecutive_calls}/{settings.MAX_TOOL_CALLS_PER_TURN}). "
            "Forcing response without more tools."
        )
        return END

    # Safety check: Too many consecutive tool errors
    if consecutive_errors >= settings.MAX_CONSECUTIVE_TOOL_ERRORS:
        logger.error(
            f"Tool error limit reached ({consecutive_errors}/{settings.MAX_CONSECUTIVE_TOOL_ERRORS}). "
            "Stopping tool execution."
        )
        return END

    # Normal flow: continue to tools if model requested them
    if isinstance(last_message, AIMessage) and last_message.tool_calls:
        return "tools"

    return END


### Graph


#@cache

async def tools_with_memory(state: AgentState, config: RunnableConfig) -> AgentState:
    """Tool execution with memory context injection."""
    tools = (
        get_tools_set("search") +
        get_tools_set("agent_mode") +
        get_tools_set("jira_mcp") +
        get_tools_set("confluence_mcp") +
        get_tools_set("netdetective") +
        get_tools_set("beta_report")
    )

    if settings.ENABLE_MEMORY_INTEGRATION:
        try:
            from app.agent.context_injection import create_memory_aware_tool_node
            tool_node = create_memory_aware_tool_node(tools)
            logger.debug("Using MemoryAwareToolNode for tool execution")
        except Exception as e:
            logger.warning(f"Memory-aware tool node creation failed, falling back to ToolNode: {e}")
            tool_node = ToolNode(tools)
    else:
        tool_node = ToolNode(tools)

    result = await tool_node.ainvoke(state, config)
    return result


def get_graph():
    tools = (
        get_tools_set("search") + 
        get_tools_set("agent_mode") +
        get_tools_set("jira_mcp") +
        get_tools_set("confluence_mcp") +
        get_tools_set("netdetective") +
        get_tools_set("beta_report")
    )

    workflow = StateGraph(AgentState)

    workflow.add_node("agent", call_model)
    workflow.add_node("tools", tools_with_memory)
    workflow.add_node("track_tool_execution", track_tool_execution)
    workflow.add_node("reset_tool_counters", reset_tool_counters)

    # Start -> track -> agent
    workflow.add_edge(START, "track_tool_execution")
    workflow.add_edge("track_tool_execution", "agent")
    
    # Agent decides: tools or end
    workflow.add_conditional_edges(
        "agent",
        should_continue,
        {
            "tools": "tools",
            END: "reset_tool_counters",
        },
    )
    
    # Tools -> track (loop back with safety checks)
    workflow.add_edge("tools", "track_tool_execution")
    
    # Reset counters -> END
    workflow.add_edge("reset_tool_counters", END)

    return workflow.compile(checkpointer=get_checkpointer())
