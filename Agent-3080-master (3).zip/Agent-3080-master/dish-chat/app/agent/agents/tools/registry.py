import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Dict, List

from langchain_core.tools import BaseTool

from app.config import get_settings
from app.agent.agents.utils import get_mcp_tools
from app.tools.enhanced_web_search import public_web_search_enhanced
# from app.tools.internal_search import internal_search
# NOTE: internal_search has been replaced by individual MCPs (confluence_search, jira_search)
from app.tools.cluster_inspect import cluster_inspect
from app.agent_mode.tools import (
    agent_git_clone,
    agent_create_venv,
    agent_run_python,
    agent_list_artifacts,
    agent_run_shell,
)
from app.tools.log_assist_gateway import (
    logassist_web_search,
    logassist_get_journal_files,
    logassist_append_journal,
    logassist_trigger_workflow,
    logassist_embed_content,
)

logger = logging.getLogger(__name__)
settings = get_settings()

_ASYNC_TOOL_CACHE: Dict[str, List[BaseTool]] = {}
_TOOL_FACTORIES: Dict[str, Callable[[], List[BaseTool]]] = {}
_ASYNC_TOOL_FACTORIES: Dict[str, Callable[[], Awaitable[List[BaseTool]] | List[BaseTool]]] = {}

if settings.BETAREPORT_MCP_CONFIG:
    _ASYNC_TOOL_FACTORIES["beta_report"] = lambda: get_mcp_tools(
        settings.BETAREPORT_MCP_CONFIG
    )

# Individual MCP tool sets (loaded separately for better control)
if settings.JIRA_MCP_CONFIG:
    _ASYNC_TOOL_FACTORIES["jira_mcp"] = lambda: get_mcp_tools(
        settings.JIRA_MCP_CONFIG
    )

if settings.CONFLUENCE_MCP_CONFIG:
    _ASYNC_TOOL_FACTORIES["confluence_mcp"] = lambda: get_mcp_tools(
        settings.CONFLUENCE_MCP_CONFIG
    )

# if settings.NETRA_MCP_CONFIG:
#     _ASYNC_TOOL_FACTORIES["netra_mcp"] = lambda: get_mcp_tools(
#         settings.NETRA_MCP_CONFIG
#     )
if settings.NETDETECTIVE_MCP_CONFIG:
    _ASYNC_TOOL_FACTORIES["netdetective"] = lambda: get_mcp_tools(
        settings.NETDETECTIVE_MCP_CONFIG
    )


# Legacy internal_tools bundle (kept for backward compatibility, but individual MCPs preferred)
if getattr(settings, "ENABLE_INTERNAL_TOOLS_MCP", False) and not settings.JIRA_MCP_CONFIG:
    _ASYNC_TOOL_FACTORIES["internal_tools"] = lambda: get_mcp_tools(
        settings.INTERNAL_TOOLS_MCP_CONFIG
    )

_TOOL_FACTORIES.update(
    {
        "search": lambda: [public_web_search_enhanced, cluster_inspect],  # internal_search removed - using individual MCPs
        "log_assist": lambda: [
            logassist_web_search,
            logassist_get_journal_files,
            logassist_append_journal,
            logassist_trigger_workflow,
            logassist_embed_content,
        ],
        "agent_mode": lambda: [
            agent_git_clone,
            agent_create_venv,
            agent_run_python,
            agent_list_artifacts,
            agent_run_shell,
        ],
    }
)

async def initialize_mcp_tools() -> None:
    global _ASYNC_TOOL_CACHE, _TOOL_FACTORIES
    if _ASYNC_TOOL_CACHE:
        return
    for name, factory in _ASYNC_TOOL_FACTORIES.items():
        try:
            tools = factory()
            if asyncio.iscoroutine(tools) or isinstance(tools, Awaitable):
                tools = await tools
            _ASYNC_TOOL_CACHE[name] = list(tools)
            logger.info(
                "Loaded MCP tool set '%s' with %d tools",
                name,
                len(_ASYNC_TOOL_CACHE[name]),
            )
        except Exception as exc:
            logger.warning(
                "Failed to initialise MCP tool set %s: %s; continuing with it disabled.",
                name,
                exc,
            )
            _ASYNC_TOOL_CACHE[name] = []
    for name in _ASYNC_TOOL_FACTORIES.keys():
        if name not in _TOOL_FACTORIES:
            _TOOL_FACTORIES[name] = lambda n=name: _ASYNC_TOOL_CACHE.get(n, [])

def get_tools_set(tool_type: str) -> List[BaseTool]:
    factory = _TOOL_FACTORIES.get(tool_type)
    if not factory:
        logger.warning("Unknown tool_type %r requested; returning empty tool list.", tool_type)
        return []
    return list(factory())
