"""
Memory management tools for agent access.
Provides tools for viewing, clearing, and managing execution memory.
"""
from typing import Dict, Any, Optional
import logging

from app.core.memory.tool_memory_service import get_tool_memory_service

logger = logging.getLogger(__name__)


async def get_memory_statistics(
    tool_name: Optional[str] = None,
    days: int = 7
) -> Dict[str, Any]:
    """
    Get statistics about stored tool executions.
    
    Args:
        tool_name: Filter by specific tool (optional)
        days: Number of days to look back
        
    Returns:
        Statistics dictionary
    """
    memory_service = get_tool_memory_service()
    stats = await memory_service.get_statistics(tool_name=tool_name, days=days)
    return stats


async def enable_memory_system() -> Dict[str, str]:
    """
    Enable the tool memory system.
    
    Returns:
        Status message
    """
    memory_service = get_tool_memory_service()
    memory_service.enable()
    return {
        "status": "success",
        "message": "Tool memory system enabled"
    }


async def disable_memory_system() -> Dict[str, str]:
    """
    Disable the tool memory system.
    
    Returns:
        Status message
    """
    memory_service = get_tool_memory_service()
    memory_service.disable()
    return {
        "status": "success",
        "message": "Tool memory system disabled"
    }


async def get_memory_health() -> Dict[str, Any]:
    """
    Get health status of memory system.
    
    Returns:
        Health status dictionary
    """
    memory_service = get_tool_memory_service()
    return memory_service.get_health_status()


async def clear_old_memories(days: int = 30) -> Dict[str, Any]:
    """
    Clear tool execution memories older than specified days.
    
    Args:
        days: Age threshold in days (default: 30)
        
    Returns:
        Result with number of cleared entries
    """
    memory_service = get_tool_memory_service()
    count = await memory_service.clear_old_executions(days=days)
    return {
        "status": "success",
        "cleared_count": count,
        "days_threshold": days
    }


# Tool definitions for LangGraph agent
MEMORY_TOOLS = [
    {
        "name": "get_memory_statistics",
        "description": (
            "Get statistics about stored tool executions in memory. "
            "Shows total executions, success rate, and average execution time. "
            "Optionally filter by specific tool name."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "tool_name": {
                    "type": "string",
                    "description": "Filter by specific tool name (optional)"
                },
                "days": {
                    "type": "integer",
                    "description": "Number of days to look back (default: 7)",
                    "default": 7
                }
            }
        },
        "function": get_memory_statistics
    },
    {
        "name": "enable_memory_system",
        "description": (
            "Enable the tool execution memory system. "
            "Once enabled, all tool executions will be stored and "
            "relevant past executions will be retrieved for context."
        ),
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": enable_memory_system
    },
    {
        "name": "disable_memory_system",
        "description": (
            "Disable the tool execution memory system. "
            "No new executions will be stored and no context will be retrieved."
        ),
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": disable_memory_system
    },
    {
        "name": "get_memory_health",
        "description": (
            "Get health status of the memory system. "
            "Shows whether system is enabled and operational."
        ),
        "parameters": {
            "type": "object",
            "properties": {}
        },
        "function": get_memory_health
    },
    {
        "name": "clear_old_memories",
        "description": (
            "Clear tool execution memories older than specified days. "
            "Helps manage database size and remove outdated context."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "days": {
                    "type": "integer",
                    "description": "Age threshold in days (default: 30)",
                    "default": 30
                }
            }
        },
        "function": clear_old_memories
    }
]
