# app/agent/tools/web_search_tool_enhanced.py
"""
Enhanced web search tool for agent use.

Key improvements:
1. Caching with configurable TTL
2. Better error handling with retry logic
3. Query sanitization
4. Relevance scoring
5. Result deduplication
6. Performance tracking
"""
from __future__ import annotations

import logging
import hashlib
import time
import re
import asyncio
from typing import Dict, Any, Optional
from datetime import datetime

import httpx

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)


class SimpleCache:
    """Lightweight cache for search results."""
    
    def __init__(self, ttl_seconds: int = 1800):
        self._cache: Dict[str, tuple[str, float]] = {}
        self._ttl = ttl_seconds
    
    def get(self, query: str) -> Optional[str]:
        key = hashlib.md5(query.lower().strip().encode()).hexdigest()
        if key in self._cache:
            value, expiry = self._cache[key]
            if time.time() < expiry:
                logger.debug(f"Cache hit for: {query[:50]}")
                return value
            del self._cache[key]
        return None
    
    def set(self, query: str, value: str):
        key = hashlib.md5(query.lower().strip().encode()).hexdigest()
        expiry = time.time() + self._ttl
        self._cache[key] = (value, expiry)
        
        # Simple size limit
        if len(self._cache) > 500:
            oldest = min(self._cache.items(), key=lambda x: x[1][1])[0]
            del self._cache[oldest]


_cache = SimpleCache(ttl_seconds=1800)


def sanitize_query(query: str) -> str:
    """Clean and validate search query."""
    # Remove control characters
    query = re.sub(r'[\x00-\x1f\x7f]', '', query)
    
    # Limit length
    if len(query) > 500:
        query = query[:500]
        logger.warning("Query truncated to 500 chars")
    
    # Remove excessive special chars (keep basic punctuation)
    query = re.sub(r'[^\w\s.,!?;:()'-]', ' ', query, flags=re.UNICODE)
    query = re.sub(r'\s+', ' ', query).strip()
    
    return query


def score_result(result: Dict[str, Any], query: str) -> float:
    """Calculate relevance score for a result."""
    score = 0.0
    query_terms = set(query.lower().split())
    
    title = result.get("title", "").lower()
    snippet = result.get("snippet", "").lower()
    
    # Title matches weighted 3x
    score += sum(3.0 for term in query_terms if term in title)
    # Snippet matches weighted 1x
    score += sum(1.0 for term in query_terms if term in snippet)
    
    return score / len(query_terms) if query_terms else 0.0


async def search_with_retry(
    client: httpx.AsyncClient,
    query: str,
    max_retries: int = 3
) -> Dict[str, Any]:
    """Execute search with exponential backoff retry."""
    last_error = None
    
    for attempt in range(max_retries):
        try:
            resp = await client.post("/web-search", json={"query": query})
            resp.raise_for_status()
            return resp.json()
        except (httpx.HTTPStatusError, httpx.TimeoutException, httpx.NetworkError) as e:
            if attempt < max_retries - 1:
                delay = 1.0 * (2 ** attempt)
                logger.warning(f"Search attempt {attempt + 1} failed, retrying in {delay}s")
                await asyncio.sleep(delay)
                last_error = e
            else:
                raise e
    
    raise last_error if last_error else Exception("Max retries exceeded")


async def web_search(query: str, use_cache: bool = True) -> str:
    """
    Search the public web via the local gateway's /web-search endpoint.
    
    Enhanced with caching, retry logic, sanitization, and relevance scoring.
    Use this when the user asks about current events, weather, news,
    or anything that changes over time.
    
    Returns a concise, text-only summary of the top results.
    """
    start_time = time.time()
    
    # Sanitize query
    query = sanitize_query(query)
    if not query:
        return "[web_search] Error: Empty or invalid query."
    
    # Check cache
    if use_cache:
        cached = _cache.get(query)
        if cached:
            return cached
    
    try:
        async with httpx.AsyncClient(
            base_url=settings.COVERITY_GATEWAY_URL,
            timeout=20.0,
        ) as client:
            data = await search_with_retry(client, query, max_retries=3)
    except Exception as e:
        logger.exception(f"web_search({query!r}) failed: {e}")
        return f"[web_search] Failed to fetch results for {query!r}: {str(e)}"

    # Extract results
    results = data.get("results") or data.get("response", {}).get("results") or []

    if not results:
        result_str = f"[web_search] No results for query: {query!r}"
        if use_cache:
            _cache.set(query, result_str)
        return result_str

    # Score and sort results
    scored_results = []
    for item in results[:10]:
        item["_score"] = score_result(item, query)
        scored_results.append(item)
    
    scored_results.sort(key=lambda x: x["_score"], reverse=True)

    # Format top 5 results
    lines = []
    seen_urls = set()
    
    for i, item in enumerate(scored_results[:5], start=1):
        url = item.get("url", "")
        
        # Deduplicate by base URL
        base_url = re.sub(r'[?#].*$', '', url.lower())
        if base_url in seen_urls:
            continue
        seen_urls.add(base_url)
        
        title = item.get("title") or "<no title>"
        snippet = (item.get("snippet") or item.get("text") or "").replace("\n", " ").strip()
        
        if len(snippet) > 200:
            snippet = snippet[:200] + "..."
        
        lines.append(f"{i}. {title}\n   {url}\n   {snippet}")

    result_str = "\n".join(lines)
    
    # Cache result
    if use_cache:
        _cache.set(query, result_str)
    
    elapsed = time.time() - start_time
    logger.info(f"web_search completed in {elapsed:.2f}s: {len(lines)} results for '{query[:50]}'")
    
    return result_str
