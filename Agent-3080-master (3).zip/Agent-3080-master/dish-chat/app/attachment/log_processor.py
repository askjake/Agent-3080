"""
Log file processor for automatic analysis integration.
Detects log files and triggers log-analyzer tools.
"""
from typing import Optional, BinaryIO
import os
import logging
from pathlib import Path

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)


def is_log_file(filename: str, media_type: str) -> bool:
    """
    Determine if a file is a log file based on extension and MIME type.
    """
    file_ext = Path(filename).suffix.lower()
    if file_ext in settings.LOG_FILE_EXTENSIONS:
        return True
    
    log_mime_types = ["text/x-log", "application/x-log", "application/log"]
    if media_type in log_mime_types:
        return True
    
    if media_type == "application/octet-stream" and file_ext in settings.LOG_FILE_EXTENSIONS:
        return True
        
    return False


def normalize_mime_type(filename: str, original_mime: str) -> str:
    """
    Normalize MIME type for log files and numbered extensions.
    """
    file_ext = Path(filename).suffix.lower()
    
    if file_ext in settings.LOG_FILE_EXTENSIONS:
        if file_ext in [".txt", ".log"]:
            return "text/plain"
        return "text/x-log"
    
    return original_mime


async def process_log_file(
    attachment_id: str,
    file_obj: BinaryIO,
    filename: str,
    email: str
) -> dict:
    """
    Process a log file and trigger log-analyzer tool.
    """
    if not settings.AUTO_ANALYZE_LOGS:
        return {"status": "skipped", "reason": "auto_analyze disabled"}
    
    try:
        file_obj.seek(0)
        log_content = file_obj.read()
        
        if isinstance(log_content, bytes):
            try:
                log_content = log_content.decode("utf-8")
            except UnicodeDecodeError:
                try:
                    log_content = log_content.decode("latin-1")
                except Exception as e:
                    logger.error(f"Failed to decode log file {filename}: {e}")
                    return {"status": "error", "reason": "decode_failed"}
        
        try:
            from app.tools.log_assist_gateway import logassist_embed_content
            
            context = f"""Log File: {filename}
Owner: {email}
Attachment ID: {attachment_id}
Size: {len(log_content)} bytes

Log Content:
{log_content[:10000]}"""
            
            result = await logassist_embed_content.ainvoke({
                "text": context,
                "filename": filename
            })
            
            logger.info(f"Log file {filename} processed by log-analyzer")
            return {"status": "success", "result": result}
            
        except ImportError:
            logger.warning("Log assist gateway not available")
            return {"status": "skipped", "reason": "log_assist_unavailable"}
        except Exception as e:
            logger.error(f"Failed to process log file {filename}: {e}")
            return {"status": "error", "reason": str(e)}
    
    except Exception as e:
        logger.error(f"Error processing log file {filename}: {e}")
        return {"status": "error", "reason": str(e)}
