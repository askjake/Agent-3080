# LOGalyzer Integration Guide

## Overview

This guide explains how to integrate the log analysis module into the existing Dish-Chat application.

## Current Status

**✅ READY FOR INTEGRATION**
- All components implemented and tested
- Database schema operational
- API endpoints defined (but not integrated)
- Full pipeline working standalone

## Integration Steps

### Step 1: Review Components (5 minutes)

All components are located in `/home/montjac/dish-chat/app/log_analysis/`:

```
app/log_analysis/
├── parsing/          # Log parsing (Phase 1)
├── enrichment/       # Severity classification (Phase 1)
├── ml/              # ML models (Phase 2)
├── storage/         # Model persistence (Phase 2)
├── pipeline.py      # End-to-end pipeline (Phase 3)
├── api_endpoints.py # API endpoint templates (Phase 3)
├── cli_tool.py      # Testing CLI
└── utils/           # Testing utilities
```

### Step 2: Create FastAPI Router (15 minutes)

Create a new file `app/routes/log_analysis.py`:

```python
from fastapi import APIRouter, HTTPException
from app.log_analysis.api_endpoints import (
    analyze_logs_endpoint,
    get_receiver_stats_endpoint,
    get_recent_anomalies_endpoint,
    AnalyzeLogsRequest,
    AnalyzeLogsResponse,
    ReceiverStatsResponse,
    RecentAnomaliesResponse
)

router = APIRouter(
    prefix="/api/v1/log-analysis",
    tags=["Log Analysis"]
)

@router.post("/analyze", response_model=AnalyzeLogsResponse)
async def analyze_logs(request: AnalyzeLogsRequest):
    """Analyze log lines for a receiver."""
    return analyze_logs_endpoint(request)

@router.get("/receiver/{receiver_id}/stats", response_model=ReceiverStatsResponse)
async def get_receiver_stats(receiver_id: str):
    """Get analysis statistics for a receiver."""
    return get_receiver_stats_endpoint(receiver_id)

@router.get("/anomalies/recent", response_model=RecentAnomaliesResponse)
async def get_recent_anomalies(receiver_id: str = None, limit: int = 10):
    """Get recent anomalies."""
    return get_recent_anomalies_endpoint(receiver_id, limit)
```

### Step 3: Add Router to Main App (5 minutes)

In your main FastAPI application file (e.g., `app/main.py`):

```python
from app.routes import log_analysis

# Add this line where other routers are included
app.include_router(log_analysis.router)
```

### Step 4: Test Endpoints (5 minutes)

Test the new endpoints:

```bash
# Test analyze endpoint
curl -X POST http://localhost:8000/api/v1/log-analysis/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "receiver_id": "RX12345",
    "log_lines": [
      "[ERROR] Connection timeout",
      "[INFO] Service started"
    ],
    "store_results": false
  }'

# Test stats endpoint
curl http://localhost:8000/api/v1/log-analysis/receiver/RX12345/stats

# Test anomalies endpoint
curl http://localhost:8000/api/v1/log-analysis/anomalies/recent?limit=5
```

## Authentication & Authorization

### Adding Authentication

If your application uses authentication, wrap the endpoints:

```python
from fastapi import Depends
from app.auth import get_current_user  # Your auth dependency

@router.post("/analyze", response_model=AnalyzeLogsResponse)
async def analyze_logs(
    request: AnalyzeLogsRequest,
    current_user = Depends(get_current_user)
):
    # Add user context if needed
    return analyze_logs_endpoint(request)
```

### Adding Rate Limiting

Add rate limiting for production:

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@router.post("/analyze", response_model=AnalyzeLogsResponse)
@limiter.limit("10/minute")
async def analyze_logs(request: AnalyzeLogsRequest):
    return analyze_logs_endpoint(request)
```

## Background Jobs (Optional)

### Setting Up Automated Analysis

Create a background job for continuous log analysis:

```python
from fastapi_utils.tasks import repeat_every

@app.on_event("startup")
@repeat_every(seconds=300)  # Every 5 minutes
async def analyze_recent_logs():
    """Analyze recent logs from all receivers."""
    from app.log_analysis.pipeline import LogAnalysisPipeline
    
    pipeline = LogAnalysisPipeline()
    # Fetch recent logs from your log source
    # logs = fetch_recent_logs()
    # pipeline.analyze_logs(logs, receiver_id="...", store_results=True)
```

## Configuration

### Environment Variables

Add to your `.env` file:

```bash
# Log Analysis Configuration
LOG_ANALYSIS_ENABLED=true
LOG_ANALYSIS_USE_ML=false  # Enable when LSTM models are trained
LOG_ANALYSIS_BATCH_SIZE=100
LOG_ANALYSIS_AUTO_PROCESS=false
```

### Using Configuration

```python
from pydantic import BaseSettings

class Settings(BaseSettings):
    log_analysis_enabled: bool = True
    log_analysis_use_ml: bool = False
    log_analysis_batch_size: int = 100

settings = Settings()

# Use in pipeline
pipeline = LogAnalysisPipeline(use_ml=settings.log_analysis_use_ml)
```

## Monitoring

### Health Check

Add a health check endpoint:

```python
@router.get("/health")
async def health_check():
    """Check log analysis system health."""
    from app.log_analysis.pipeline import LogAnalysisPipeline
    
    try:
        pipeline = LogAnalysisPipeline()
        # Test database connection
        stats = pipeline.get_receiver_stats("HEALTH_CHECK")
        return {"status": "healthy", "database": "connected"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
```

### Metrics

Add Prometheus metrics (if using):

```python
from prometheus_client import Counter, Histogram

logs_analyzed = Counter('logs_analyzed_total', 'Total logs analyzed')
analysis_duration = Histogram('analysis_duration_seconds', 'Analysis duration')

@router.post("/analyze")
async def analyze_logs(request: AnalyzeLogsRequest):
    with analysis_duration.time():
        result = analyze_logs_endpoint(request)
        logs_analyzed.inc(len(request.log_lines))
        return result
```

## Testing in Production

### 1. Deploy to Staging

Deploy to staging environment first:

```bash
# Deploy staging
git checkout staging
git pull origin main
# Deploy process...
```

### 2. Run Integration Tests

```bash
# Run tests against staging
pytest tests/integration/test_log_analysis.py --env=staging
```

### 3. Monitor Performance

Watch for:
- Response times (<100ms for most requests)
- Database query performance
- Memory usage
- Error rates

### 4. Gradual Rollout

```python
# Feature flag for gradual rollout
from app.feature_flags import is_enabled

@router.post("/analyze")
async def analyze_logs(request: AnalyzeLogsRequest):
    if not is_enabled("log_analysis", request.receiver_id):
        raise HTTPException(status_code=403, detail="Feature not enabled")
    return analyze_logs_endpoint(request)
```

## Rollback Plan

If issues occur, rollback is simple:

1. **Disable endpoints:**
   ```python
   # In router file
   if not settings.log_analysis_enabled:
       raise HTTPException(status_code=503, detail="Service disabled")
   ```

2. **Remove router:**
   ```python
   # Comment out in main.py
   # app.include_router(log_analysis.router)
   ```

3. **Database rollback (if needed):**
   ```sql
   -- Remove data
   DELETE FROM log_analysis_results;
   -- Or drop tables entirely
   DROP TABLE IF EXISTS log_analysis_results;
   DROP TABLE IF EXISTS ml_models;
   ```

Rollback time: < 5 minutes

## Performance Tuning

### Database Indexes

Ensure indexes are created:
```sql
-- Already created in schema, but verify:
SELECT indexname FROM pg_indexes 
WHERE tablename IN ('ml_models', 'log_analysis_results');
```

### Batch Processing

For large volumes, use batch processing:
```python
def analyze_logs_batch(logs: List[str], batch_size: int = 100):
    for i in range(0, len(logs), batch_size):
        batch = logs[i:i+batch_size]
        pipeline.analyze_logs(batch, ...)
```

### Caching

Add caching for frequently accessed data:
```python
from functools import lru_cache

@lru_cache(maxsize=100)
def get_cached_stats(receiver_id: str):
    return pipeline.get_receiver_stats(receiver_id)
```

## Troubleshooting

### Common Issues

**Issue: Slow performance**
- Check database indexes
- Reduce batch size
- Enable connection pooling

**Issue: Memory usage high**
- Limit concurrent requests
- Reduce cache sizes
- Use streaming for large files

**Issue: Database connection errors**
- Check connection pool settings
- Verify credentials
- Check network connectivity

### Debug Mode

Enable detailed logging:
```python
import logging

logging.getLogger('app.log_analysis').setLevel(logging.DEBUG)
```

## Support

**Documentation:**
- README: `/home/montjac/dish-chat/app/log_analysis/README.md`
- MOP: `/home/montjac/COMPLETE_MOP_LOGalyzer_Integration.txt`

**Testing:**
- CLI tool: `python app/log_analysis/cli_tool.py --help`
- Unit tests: `pytest tests/test_log_parsing.py`

**Contact:**
- Implementation team
- DevOps for deployment
- DBA for database questions
