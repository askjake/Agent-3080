"""
Field extraction module with 16+ specialized regex patterns.
Adapted from LOGalyzer enricher.py
"""
import re
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)


class FieldExtractor:
    """Extract specialized fields from log data using 16+ regex patterns."""
    
    def __init__(self):
        # Initialize all regex patterns
        self.patterns = {
            'interface_status': re.compile(r'Interface (\w+) (Connected|Not Connected)\(?(- \d+)?\)?'),
            'auto_ip_thread': re.compile(r'Need to start Auto IP thread for (\w+), thread \(([^)]+)\), event (-?\d+)'),
            'arping': re.compile(r'Arping for (\d+\.\d+\.\d+\.\d+)'),
            'packet_mac': re.compile(r'(Destin\.|Source) MAC: ([0-9A-Fa-f:]+)'),
            'arp_details': re.compile(r'(Sender|Target) (IP|MAC)\s*:\s*([0-9A-Fa-f:.]+)'),
            'sgs_msg': re.compile(r'SGS Msg <(\d+):(\w+)> took <(\d+) ms> SGS Return Code:<(\d+):(\w+)> rx_id:<([\w-]+)>'),
            'mac_select': re.compile(r'MAC Select thread running on <(\w+)> interface'),
            'worker_thread': re.compile(r'starting thread:<(\w+ thread)>, version:<(\d+)>'),
            'malloc_occupied': re.compile(r'total size of memory occupied by chunks handed out by malloc:(\d+)'),
            'free_chunks': re.compile(r'total size of memory occupied by free \(not in use\) chunks\.:(\d+)'),
            'topmost_chunk': re.compile(r'size of the top-most releasable chunk.*?:(\d+)'),
            'freed_bytes': re.compile(r'Freed up bytes:\s*(\d+)'),
            'used_memory_before': re.compile(r'Used memory before GC:\s*(\d+)'),
            'used_memory_after': re.compile(r'Used memory after GC:\s*(\d+)'),
            'allocated_mmap': re.compile(r'Allocated\s*(\d+)\s*bytes\s*in\s*(\d+)\s*chunks\.\s*\(via mmap\)'),
            'allocated_malloc': re.compile(r'Allocated\s*(\d+)\s*bytes\s.*\(via malloc\)'),
        }
        
        # Customer-marked log patterns
        self.mark_patterns = [
            "ES_STB_MSG_TYPE_VIDEO_DUMP_BRCM_PROC",
            "DUMPING FILE",
            "CUSTOMER_MARK",
            "USER_INITIATED_DUMP",
        ]
        
        logger.info(f"FieldExtractor initialized with {len(self.patterns)} patterns")
    
    def extract_fields(self, log_data: str) -> Dict[str, Any]:
        """
        Extract specialized fields from log data string.
        
        Args:
            log_data: Raw log data string
        
        Returns:
            Dictionary of extracted fields
        """
        extracted = {}
        data_str = str(log_data or "").strip().strip('"')
        
        # Check for customer-marked logs
        if any(pattern in data_str for pattern in self.mark_patterns):
            extracted['customer_marked_flag'] = 'YES'
            logger.debug("Customer-marked log detected")
        
        # Interface status
        m = self.patterns['interface_status'].search(data_str)
        if m:
            extracted['interface'] = m.group(1)
            extracted['connection_status'] = m.group(2)
            if m.group(3):
                extracted['interface_status_code'] = m.group(3)
        
        # Auto IP thread
        m = self.patterns['auto_ip_thread'].search(data_str)
        if m:
            extracted['auto_ip_interface'] = m.group(1)
            extracted['auto_ip_thread'] = m.group(2)
            extracted['auto_ip_event'] = m.group(3)
        
        # Arping IP
        m = self.patterns['arping'].search(data_str)
        if m:
            extracted['arping_ip'] = m.group(1)
        
        # Packet MAC
        m = self.patterns['packet_mac'].search(data_str)
        if m:
            extracted['packet_mac_type'] = m.group(1)
            extracted['packet_mac'] = m.group(2)
        
        # ARP details
        m = self.patterns['arp_details'].search(data_str)
        if m:
            extracted['arp_role'] = m.group(1)
            extracted['arp_type'] = m.group(2)
            extracted['arp_value'] = m.group(3)
        
        # SGS message
        m = self.patterns['sgs_msg'].search(data_str)
        if m:
            extracted['sgs_msg_id'] = m.group(1)
            extracted['sgs_msg_type'] = m.group(2)
            extracted['sgs_duration_ms'] = int(m.group(3))
            extracted['sgs_return_code'] = m.group(4)
            extracted['sgs_return_desc'] = m.group(5)
            extracted['sgs_rx_id'] = m.group(6)
        
        # Memory-related extractions
        m = self.patterns['malloc_occupied'].search(data_str)
        if m:
            extracted['malloc_occupied_bytes'] = int(m.group(1))
        
        m = self.patterns['free_chunks'].search(data_str)
        if m:
            extracted['free_chunks_bytes'] = int(m.group(1))
        
        m = self.patterns['topmost_chunk'].search(data_str)
        if m:
            extracted['topmost_chunk_bytes'] = int(m.group(1))
        
        m = self.patterns['freed_bytes'].search(data_str)
        if m:
            extracted['freed_bytes'] = int(m.group(1))
        
        m = self.patterns['used_memory_before'].search(data_str)
        if m:
            extracted['used_memory_before_gc'] = int(m.group(1))
        
        m = self.patterns['used_memory_after'].search(data_str)
        if m:
            extracted['used_memory_after_gc'] = int(m.group(1))
        
        m = self.patterns['allocated_mmap'].search(data_str)
        if m:
            extracted['allocated_mmap_bytes'] = int(m.group(1))
            extracted['allocated_mmap_chunks'] = int(m.group(2))
        
        m = self.patterns['allocated_malloc'].search(data_str)
        if m:
            extracted['allocated_malloc_bytes'] = int(m.group(1))
        
        return extracted
    
    def enrich_log(self, parsed_log: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enrich a parsed log with extracted fields.
        
        Args:
            parsed_log: Previously parsed log dictionary
        
        Returns:
            Enriched log dictionary
        """
        if 'data' in parsed_log:
            extracted_fields = self.extract_fields(parsed_log['data'])
            parsed_log['extracted_fields'] = extracted_fields
        
        return parsed_log
