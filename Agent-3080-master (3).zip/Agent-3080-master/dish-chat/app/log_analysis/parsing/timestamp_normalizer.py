"""
Timestamp normalization module.
Adapted from LOGalyzer patterns.py
"""
import re
from datetime import datetime, timezone
from dateutil import parser as dateparser
from typing import Optional


class TimestampNormalizer:
    """
    Robust timestamp parsing with fuzzy matching and fallback logic.
    """
    
    def __init__(self):
        self.current_year = datetime.now().year
    
    def convert_to_utc(self, timestamp_str: str, 
                       last_valid_timestamp: Optional[datetime] = None) -> Optional[str]:
        """
        Convert timestamp string to UTC ISO format.
        
        Args:
            timestamp_str: Raw timestamp string
            last_valid_timestamp: Fallback timestamp if parsing fails
        
        Returns:
            ISO format UTC timestamp string or None
        """
        timestamp_str = timestamp_str.strip()
        
        # Try fuzzy parsing first
        try:
            dt = dateparser.parse(timestamp_str, fuzzy=True)
        except:
            dt = None
        
        # If fuzzy parsing failed, try adding year
        if not dt:
            if re.match(r'^\d{1,2}/\d{1,2}\b', timestamp_str):
                # Format: MM/DD -> add year
                timestamp_str = f"{self.current_year}/{timestamp_str}"
            elif re.match(r'^[A-Za-z]{3,}\s+\d{1,2}\b', timestamp_str):
                # Format: Month Day -> add year
                parts = timestamp_str.split()
                if len(parts) >= 2:
                    timestamp_str = f"{parts[0]} {parts[1]} {self.current_year} {' '.join(parts[2:])}"
            
            try:
                dt = dateparser.parse(timestamp_str, fuzzy=True)
            except:
                dt = None
        
        # If still no timestamp, use fallback
        if not dt:
            return self.fallback_to_previous(timestamp_str, last_valid_timestamp)
        
        # Ensure timezone awareness
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        
        return dt.astimezone(timezone.utc).isoformat()
    
    def fallback_to_previous(self, timestamp_str: str,
                            last_valid_timestamp: Optional[datetime]) -> Optional[str]:
        """
        Fallback to previous timestamp with time component from current string.
        """
        if not last_valid_timestamp:
            return None
        
        # Try to extract time component (HH:MM:SS)
        time_match = re.search(r'(\d{1,2}):(\d{1,2}):(\d{1,2})', timestamp_str)
        if time_match:
            hours, minutes, seconds = map(int, time_match.groups())
            try:
                fallback = last_valid_timestamp.replace(
                    hour=hours, 
                    minute=minutes, 
                    second=seconds, 
                    microsecond=0
                )
                return fallback.astimezone(timezone.utc).isoformat()
            except ValueError:
                pass
        
        # If time extraction failed, just return the last valid timestamp
        return last_valid_timestamp.astimezone(timezone.utc).isoformat()
