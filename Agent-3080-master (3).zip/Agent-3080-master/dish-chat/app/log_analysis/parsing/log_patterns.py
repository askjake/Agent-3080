"""
Multi-pattern log parser with 9 log format types.
Adapted from LOGalyzer patterns.py
"""
import re
from datetime import datetime
from typing import Dict, List, Optional, Any
from .timestamp_normalizer import TimestampNormalizer
from .field_extractor import FieldExtractor


class LogPattern:
    """Represents a single log pattern with regex and formatter."""
    
    def __init__(self, name: str, pattern: str, formatter: callable):
        self.name = name
        self.pattern = re.compile(pattern)
        self.formatter = formatter
    
    def match(self, line: str) -> Optional[Dict[str, Any]]:
        """Attempt to match the pattern against a log line."""
        m = self.pattern.match(line)
        if m:
            return self.formatter(m)
        return None


class LogPatternLibrary:
    """
    Multi-pattern log parser supporting 9+ log formats.
    Adapted from LOGalyzer patterns.py
    """
    
    def __init__(self):
        self.timestamp_normalizer = TimestampNormalizer()
        self.field_extractor = FieldExtractor()
        self.patterns = self._init_patterns()
    
    def _init_patterns(self) -> List[LogPattern]:
        """Initialize all log patterns."""
        return [
            # Pattern 1: Standard Log Format
            LogPattern(
                name="standard_log",
                pattern=r"^\[(.*?)\]<([\d/:\.\s\-]+)><(.*?)>\s(.*?):\s(.*)$",
                formatter=lambda m: {
                    "category": m.group(1),
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(2)),
                    "file_line": m.group(3),
                    "function": m.group(4),
                    "data": m.group(5)
                }
            ),
            
            # Pattern 2: Qt UI Format
            LogPattern(
                name="qt_ui",
                pattern=r"^\[(.*?)\]<([\d/:\.\s\-]+)>\s(.*?),\s(.*)$",
                formatter=lambda m: {
                    "category": m.group(1),
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(2)),
                    "info": m.group(3),
                    "data": m.group(4)
                }
            ),
            
            # Pattern 3: Qt UI Chunks
            LogPattern(
                name="qt_ui_chunks",
                pattern=r"^\[(.*?)\]<([\d/:\.\s\-]+)>\s(.*)$",
                formatter=lambda m: {
                    "category": m.group(1),
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(2)),
                    "data": m.group(3)
                }
            ),
            
            # Pattern 4: Invidi Debug
            LogPattern(
                name="invidi_debug",
                pattern=r"^([\d/:\s]+):\s(D.*?)\s:\s(.*)$",
                formatter=lambda m: {
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(1)),
                    "component": m.group(2),
                    "data": m.group(3)
                }
            ),
            
            # Pattern 5: WJAP Logs
            LogPattern(
                name="wjap_logs",
                pattern=r"^([A-Za-z]+\s+\d+\s+[\d:]+)\s(.*?)\[(\d+)\]:\s(.*)$",
                formatter=lambda m: {
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(1)),
                    "service": m.group(2),
                    "pid": m.group(3),
                    "data": m.group(4)
                }
            ),
            
            # Pattern 6: SBSDK Logs
            LogPattern(
                name="sbsdk_logs",
                pattern=r"^\[.*?\]<([\d/:\.\s\-]+)>\s(.*?)-(.*?)\s\|\s(.*?)\s\|\s(.*?)\s\|\s(.*?)$",
                formatter=lambda m: {
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(1)),
                    "error_level": m.group(2),
                    "code": m.group(3),
                    "module": m.group(4),
                    "function": m.group(5),
                    "data": m.group(6)
                }
            ),
            
            # Pattern 7: Timestamp with Milliseconds
            LogPattern(
                name="timestamp_colon_ms",
                pattern=r"^([\d/]+\s[\d:]+):(\d+)",
                formatter=lambda m: {
                    "timestamp": self.timestamp_normalizer.convert_to_utc(
                        f"{m.group(1)}.{m.group(2)}"
                    ),
                    "data": m.string.strip()
                }
            ),
            
            # Pattern 8: Pipeline Control
            LogPattern(
                name="pipeline_control",
                pattern=r"^\[(\w+)\]<([\d/:\.\s\-]+)\s([\-\d]+)>\s(\d+):\[(\w+)]<([\w.]+):(\d+)>\s([\w()\[\]:]+)\((.*?)\):\s(.+)$",
                formatter=lambda m: {
                    "category": m.group(1),
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(2)),
                    "timezone_offset": m.group(3).strip(),
                    "pid": m.group(4),
                    "sub_category": m.group(5),
                    "file_line": f"<{m.group(6)}:{m.group(7)}>",
                    "function": m.group(8).strip(),
                    "data": m.group(10)
                }
            ),
            
            # Pattern 9: Generic Timestamp + Data
            LogPattern(
                name="generic",
                pattern=r"^([\d/:\.\s\-]+)\s(.*)$",
                formatter=lambda m: {
                    "timestamp": self.timestamp_normalizer.convert_to_utc(m.group(1)),
                    "data": m.group(2)
                }
            )
        ]
    
    def parse_line(self, line: str, last_valid_timestamp: Optional[datetime] = None,
                   rx_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Parse a single log line using all available patterns.
        
        Args:
            line: Raw log line
            last_valid_timestamp: Last known good timestamp for fallback
            rx_id: Receiver ID to attach to parsed log
        
        Returns:
            Parsed log dictionary or None if no pattern matches
        """
        line = line.strip()
        if not line:
            return None
        
        for pattern in self.patterns:
            result = pattern.match(line)
            if result:
                # Add metadata
                result['pattern_name'] = pattern.name
                result['raw_line'] = line
                if rx_id:
                    result['rx_id'] = rx_id
                
                # Handle missing timestamp with fallback
                if not result.get('timestamp') and last_valid_timestamp:
                    result['timestamp'] = self.timestamp_normalizer.fallback_to_previous(
                        line, last_valid_timestamp
                    )
                
                # Enrich with field extraction
                result = self.field_extractor.enrich_log(result)
                
                return result
        
        return None
    
    def parse_logs(self, lines: List[str], rx_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Parse multiple log lines with timestamp fallback.
        
        Args:
            lines: List of raw log lines
            rx_id: Receiver ID
        
        Returns:
            List of parsed log dictionaries
        """
        parsed_logs = []
        last_timestamp = None
        
        for line in lines:
            result = self.parse_line(line, last_timestamp, rx_id)
            if result:
                parsed_logs.append(result)
                if result.get('timestamp'):
                    # Update last valid timestamp
                    try:
                        last_timestamp = datetime.fromisoformat(result['timestamp'])
                    except (ValueError, TypeError):
                        pass
        
        return parsed_logs
