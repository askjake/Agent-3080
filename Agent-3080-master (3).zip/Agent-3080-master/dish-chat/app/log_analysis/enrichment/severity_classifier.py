"""
Severity classifier for log analysis.
Classifies logs based on keywords, anomaly scores, and patterns.
"""
import re
from typing import Dict, Any, Optional, List
from enum import Enum


class SeverityLevel(Enum):
    """Severity levels for log classification."""
    CRITICAL = "critical"
    WARNING = "warning"
    ANOMALY = "anomaly"
    NORMAL = "normal"
    INFORMATIONAL = "informational"


class SeverityClassifier:
    """
    Classify log severity based on multiple factors:
    - Keyword patterns
    - Anomaly scores
    - Customer-marked flags
    - Field extraction results
    """
    
    def __init__(self):
        # Critical keywords (highest priority)
        self.critical_keywords = [
            r'\b(crash|fatal|panic|segfault|core dump|kernel panic)\b',
            r'\b(critical error|system failure|hardware failure)\b',
            r'\b(out of memory|oom|memory exhausted)\b',
            r'\b(cannot allocate|allocation failed)\b',
            r'\b(disk full|no space left)\b',
            r'\b(database corrupted|data loss)\b',
        ]
        
        # Warning keywords
        self.warning_keywords = [
            r'\b(warning|warn|caution)\b',
            r'\b(error|fail|failure|failed)\b',
            r'\b(timeout|timed out|time out)\b',
            r'\b(retry|retrying|retried)\b',
            r'\b(disconnect|disconnected|connection lost)\b',
            r'\b(degraded|slow|delay|delayed)\b',
            r'\b(exception|stack trace)\b',
            r'\b(unable to|could not|cannot)\b',
        ]
        
        # Informational keywords (positive or neutral)
        self.info_keywords = [
            r'\b(start|started|starting|initialized|init)\b',
            r'\b(success|successful|completed|finished)\b',
            r'\b(connected|connection established)\b',
            r'\b(loaded|loading|ready)\b',
            r'\b(info|information|debug)\b',
        ]
        
        # Compile patterns for performance
        self.critical_patterns = [re.compile(p, re.IGNORECASE) for p in self.critical_keywords]
        self.warning_patterns = [re.compile(p, re.IGNORECASE) for p in self.warning_keywords]
        self.info_patterns = [re.compile(p, re.IGNORECASE) for p in self.info_keywords]
        
        # Anomaly score thresholds
        self.critical_threshold = 0.9
        self.warning_threshold = 0.7
        self.anomaly_threshold = 0.5
    
    def classify(self, 
                 log_data: str,
                 anomaly_score: Optional[float] = None,
                 extracted_fields: Optional[Dict[str, Any]] = None,
                 customer_marked: bool = False) -> SeverityLevel:
        """
        Classify log severity based on multiple factors.
        
        Args:
            log_data: Raw log data string
            anomaly_score: Optional anomaly score from ML model (0-1)
            extracted_fields: Optional extracted fields dictionary
            customer_marked: Whether log is customer-marked
        
        Returns:
            SeverityLevel enum value
        """
        # Customer-marked logs are always at least WARNING
        if customer_marked:
            # Check if critical based on other factors
            if self._matches_keywords(log_data, self.critical_patterns):
                return SeverityLevel.CRITICAL
            return SeverityLevel.WARNING
        
        # Check anomaly score first (if available)
        if anomaly_score is not None:
            if anomaly_score >= self.critical_threshold:
                return SeverityLevel.CRITICAL
            elif anomaly_score >= self.warning_threshold:
                return SeverityLevel.WARNING
            elif anomaly_score >= self.anomaly_threshold:
                return SeverityLevel.ANOMALY
        
        # Check extracted fields for severity indicators
        if extracted_fields:
            if self._check_field_severity(extracted_fields):
                return SeverityLevel.WARNING
        
        # Keyword-based classification
        if self._matches_keywords(log_data, self.critical_patterns):
            return SeverityLevel.CRITICAL
        
        if self._matches_keywords(log_data, self.warning_patterns):
            return SeverityLevel.WARNING
        
        if self._matches_keywords(log_data, self.info_patterns):
            return SeverityLevel.INFORMATIONAL
        
        # Default to normal
        return SeverityLevel.NORMAL
    
    def _matches_keywords(self, text: str, patterns: List[re.Pattern]) -> bool:
        """Check if text matches any of the keyword patterns."""
        for pattern in patterns:
            if pattern.search(text):
                return True
        return False
    
    def _check_field_severity(self, fields: Dict[str, Any]) -> bool:
        """
        Check extracted fields for severity indicators.
        Returns True if fields indicate warning or higher severity.
        """
        # Check connection status
        if 'connection_status' in fields:
            if fields['connection_status'] == 'Not Connected':
                return True
        
        # Check memory issues
        if 'malloc_occupied_bytes' in fields:
            # If malloc occupied is very high (>1GB), flag as warning
            if fields['malloc_occupied_bytes'] > 1_000_000_000:
                return True
        
        # Check SGS message return codes
        if 'sgs_return_code' in fields:
            # Non-zero return codes often indicate errors
            if fields['sgs_return_code'] != '0':
                return True
        
        # Check for customer-marked flag in fields
        if fields.get('customer_marked_flag') == 'YES':
            return True
        
        return False
    
    def classify_with_details(self,
                            log_data: str,
                            anomaly_score: Optional[float] = None,
                            extracted_fields: Optional[Dict[str, Any]] = None,
                            customer_marked: bool = False) -> Dict[str, Any]:
        """
        Classify log and return detailed classification results.
        
        Returns:
            Dictionary with severity, confidence, and reasoning
        """
        severity = self.classify(log_data, anomaly_score, extracted_fields, customer_marked)
        
        # Determine classification reasoning
        reasons = []
        confidence = 0.5  # Default confidence
        
        if customer_marked:
            reasons.append("customer_marked")
            confidence = 0.9
        
        if anomaly_score is not None:
            reasons.append(f"anomaly_score:{anomaly_score:.2f}")
            confidence = max(confidence, anomaly_score)
        
        if self._matches_keywords(log_data, self.critical_patterns):
            reasons.append("critical_keywords")
            confidence = max(confidence, 0.9)
        elif self._matches_keywords(log_data, self.warning_patterns):
            reasons.append("warning_keywords")
            confidence = max(confidence, 0.7)
        elif self._matches_keywords(log_data, self.info_patterns):
            reasons.append("info_keywords")
            confidence = max(confidence, 0.6)
        
        if extracted_fields and self._check_field_severity(extracted_fields):
            reasons.append("field_indicators")
            confidence = max(confidence, 0.8)
        
        return {
            'severity': severity.value,
            'confidence': confidence,
            'reasons': reasons,
            'severity_enum': severity
        }
