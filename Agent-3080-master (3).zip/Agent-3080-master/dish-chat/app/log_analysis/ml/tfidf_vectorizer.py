"""
TF-IDF based log vectorizer for text analysis.
Extracts features from log text for similarity and clustering.
"""
import re
import numpy as np
from typing import List, Dict, Optional, Tuple, Set
from collections import Counter, defaultdict
from sklearn.feature_extraction.text import TfidfVectorizer as SklearnTfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import logging

logger = logging.getLogger(__name__)


class LogTemplateExtractor:
    """
    Extract log templates by replacing variable parts with placeholders.
    """
    
    def __init__(self):
        # Patterns to replace with placeholders
        self.patterns = [
            (r'\b\d+\.\d+\.\d+\.\d+\b', '<IP>'),  # IP addresses
            (r'\b[0-9a-fA-F]{2}(:[0-9a-fA-F]{2}){5}\b', '<MAC>'),  # MAC addresses
            (r'\b\d{4}/\d{2}/\d{2}\b', '<DATE>'),  # Dates
            (r'\b\d{2}:\d{2}:\d{2}\b', '<TIME>'),  # Times
            (r'\b\d+\b', '<NUM>'),  # Numbers
            (r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', '<UUID>'),  # UUIDs
            (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '<EMAIL>'),  # Emails
            (r'/[^\s]*', '<PATH>'),  # File paths
        ]
        
        self.compiled_patterns = [(re.compile(pattern, re.IGNORECASE), placeholder) 
                                 for pattern, placeholder in self.patterns]
    
    def extract_template(self, log_text: str) -> str:
        """
        Extract log template by replacing variable parts.
        
        Args:
            log_text: Raw log text
        
        Returns:
            Log template with variables replaced
        """
        template = log_text
        
        # Apply all patterns
        for pattern, placeholder in self.compiled_patterns:
            template = pattern.sub(placeholder, template)
        
        # Normalize whitespace
        template = ' '.join(template.split())
        
        return template
    
    def extract_templates_batch(self, log_texts: List[str]) -> List[str]:
        """Extract templates for multiple logs."""
        return [self.extract_template(text) for text in log_texts]


class LogTfidfVectorizer:
    """
    TF-IDF vectorizer for log analysis with template extraction.
    """
    
    def __init__(self,
                 max_features: int = 1000,
                 ngram_range: Tuple[int, int] = (1, 2),
                 min_df: int = 2,
                 max_df: float = 0.8,
                 use_templates: bool = True):
        """
        Initialize TF-IDF vectorizer.
        
        Args:
            max_features: Maximum number of features
            ngram_range: Range of n-grams (min, max)
            min_df: Minimum document frequency
            max_df: Maximum document frequency (proportion)
            use_templates: Whether to extract templates before vectorization
        """
        self.max_features = max_features
        self.ngram_range = ngram_range
        self.min_df = min_df
        self.max_df = max_df
        self.use_templates = use_templates
        
        # Initialize components
        self.template_extractor = LogTemplateExtractor() if use_templates else None
        self.vectorizer = SklearnTfidfVectorizer(
            max_features=max_features,
            ngram_range=ngram_range,
            min_df=min_df,
            max_df=max_df,
            token_pattern=r'\b\w+\b',
            lowercase=True,
            stop_words=None  # Don't remove stop words for logs
        )
        
        self.is_fitted = False
        self.template_to_ids: Dict[str, List[int]] = defaultdict(list)
        self.id_to_template: Dict[int, str] = {}
        
        logger.info(f"LogTfidfVectorizer initialized: max_features={max_features}, "
                   f"ngram_range={ngram_range}, use_templates={use_templates}")
    
    def fit(self, log_texts: List[str]) -> 'LogTfidfVectorizer':
        """
        Fit vectorizer on log texts.
        
        Args:
            log_texts: List of log text strings
        
        Returns:
            Self for chaining
        """
        if self.use_templates:
            # Extract templates
            templates = self.template_extractor.extract_templates_batch(log_texts)
            
            # Build template mapping
            for idx, template in enumerate(templates):
                self.template_to_ids[template].append(idx)
                self.id_to_template[idx] = template
            
            # Fit on templates
            self.vectorizer.fit(templates)
        else:
            # Fit on raw texts
            self.vectorizer.fit(log_texts)
        
        self.is_fitted = True
        logger.info(f"Fitted vectorizer on {len(log_texts)} logs")
        
        return self
    
    def transform(self, log_texts: List[str]) -> np.ndarray:
        """
        Transform log texts to TF-IDF vectors.
        
        Args:
            log_texts: List of log text strings
        
        Returns:
            TF-IDF feature matrix (sparse)
        """
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted. Call fit() first.")
        
        if self.use_templates:
            templates = self.template_extractor.extract_templates_batch(log_texts)
            return self.vectorizer.transform(templates)
        else:
            return self.vectorizer.transform(log_texts)
    
    def fit_transform(self, log_texts: List[str]) -> np.ndarray:
        """Fit and transform in one step."""
        return self.fit(log_texts).transform(log_texts)
    
    def get_similar_logs(self,
                        query_text: str,
                        corpus_texts: List[str],
                        top_k: int = 5) -> List[Tuple[int, float]]:
        """
        Find similar logs using cosine similarity.
        
        Args:
            query_text: Query log text
            corpus_texts: Corpus of log texts to search
            top_k: Number of top results to return
        
        Returns:
            List of (index, similarity_score) tuples
        """
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted. Call fit() first.")
        
        # Vectorize query and corpus
        query_vec = self.transform([query_text])
        corpus_vecs = self.transform(corpus_texts)
        
        # Calculate similarities
        similarities = cosine_similarity(query_vec, corpus_vecs)[0]
        
        # Get top-k
        top_indices = np.argsort(similarities)[-top_k:][::-1]
        results = [(int(idx), float(similarities[idx])) for idx in top_indices]
        
        return results
    
    def get_template_clusters(self) -> Dict[str, List[int]]:
        """
        Get clusters of logs by template.
        
        Returns:
            Dictionary mapping template to log indices
        """
        if not self.use_templates:
            raise ValueError("Template clustering only available with use_templates=True")
        
        return dict(self.template_to_ids)
    
    def get_top_terms(self, n: int = 20) -> List[Tuple[str, float]]:
        """
        Get top terms by average TF-IDF score.
        
        Args:
            n: Number of top terms to return
        
        Returns:
            List of (term, avg_score) tuples
        """
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted.")
        
        feature_names = self.vectorizer.get_feature_names_out()
        
        # Get average TF-IDF scores (would need to compute on data)
        # For now, return feature names (placeholder)
        return [(name, 0.0) for name in feature_names[:n]]
    
    def get_feature_names(self) -> List[str]:
        """Get all feature names."""
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted.")
        
        return list(self.vectorizer.get_feature_names_out())
    
    def get_vocabulary(self) -> Dict[str, int]:
        """Get vocabulary mapping term to index."""
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted.")
        
        return self.vectorizer.vocabulary_
    
    def export_state(self) -> Dict:
        """Export vectorizer state for persistence."""
        if not self.is_fitted:
            raise ValueError("Vectorizer not fitted.")
        
        return {
            'max_features': self.max_features,
            'ngram_range': self.ngram_range,
            'min_df': self.min_df,
            'max_df': self.max_df,
            'use_templates': self.use_templates,
            'vocabulary': self.vectorizer.vocabulary_,
            'idf': self.vectorizer.idf_.tolist(),
            'template_to_ids': dict(self.template_to_ids),
            'id_to_template': self.id_to_template
        }
    
    def import_state(self, state: Dict):
        """Import vectorizer state from persistence."""
        self.max_features = state['max_features']
        self.ngram_range = tuple(state['ngram_range'])
        self.min_df = state['min_df']
        self.max_df = state['max_df']
        self.use_templates = state['use_templates']
        
        # Recreate vectorizer with vocabulary
        self.vectorizer = SklearnTfidfVectorizer(
            max_features=self.max_features,
            ngram_range=self.ngram_range,
            vocabulary=state['vocabulary']
        )
        self.vectorizer.idf_ = np.array(state['idf'])
        
        # Restore template mappings
        self.template_to_ids = defaultdict(list, state['template_to_ids'])
        self.id_to_template = state['id_to_template']
        
        self.is_fitted = True
        logger.info("Imported vectorizer state")
