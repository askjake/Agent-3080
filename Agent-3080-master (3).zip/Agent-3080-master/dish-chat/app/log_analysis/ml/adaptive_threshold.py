"""
Adaptive thresholding for anomaly detection.
Calculates per-receiver baselines and dynamically adjusts thresholds.
"""
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import logging

logger = logging.getLogger(__name__)


class AdaptiveThreshold:
    """
    Adaptive threshold calculator for anomaly detection.
    Maintains per-receiver baselines and adjusts thresholds dynamically.
    """
    
    def __init__(self, 
                 initial_threshold: float = 0.5,
                 percentile: float = 95.0,
                 min_samples: int = 100,
                 decay_factor: float = 0.95):
        """
        Initialize adaptive thresholding.
        
        Args:
            initial_threshold: Default threshold before baseline is established
            percentile: Percentile for threshold calculation (e.g., 95th)
            min_samples: Minimum samples needed to establish baseline
            decay_factor: Exponential decay for historical data (0-1)
        """
        self.initial_threshold = initial_threshold
        self.percentile = percentile
        self.min_samples = min_samples
        self.decay_factor = decay_factor
        
        # Per-receiver data
        self.receiver_baselines: Dict[str, Dict] = defaultdict(lambda: {
            'scores': [],
            'threshold': initial_threshold,
            'mean': 0.0,
            'std': 0.0,
            'sample_count': 0,
            'false_positives': 0,
            'true_positives': 0
        })
        
        logger.info(f"AdaptiveThreshold initialized: percentile={percentile}, min_samples={min_samples}")
    
    def update_baseline(self, 
                       receiver_id: str, 
                       anomaly_scores: np.ndarray,
                       is_anomaly: Optional[np.ndarray] = None):
        """
        Update baseline statistics for a receiver.
        
        Args:
            receiver_id: Receiver identifier
            anomaly_scores: Array of anomaly scores
            is_anomaly: Optional array of ground truth labels for feedback
        """
        baseline = self.receiver_baselines[receiver_id]
        
        # Add new scores with decay
        if len(baseline['scores']) > 0:
            # Apply exponential decay to old scores
            baseline['scores'] = [s * self.decay_factor for s in baseline['scores']]
        
        # Add new scores
        baseline['scores'].extend(anomaly_scores.tolist())
        
        # Limit history to prevent unbounded growth
        max_history = self.min_samples * 10
        if len(baseline['scores']) > max_history:
            baseline['scores'] = baseline['scores'][-max_history:]
        
        baseline['sample_count'] += len(anomaly_scores)
        
        # Update statistics if we have enough samples
        if len(baseline['scores']) >= self.min_samples:
            scores_array = np.array(baseline['scores'])
            
            baseline['mean'] = np.mean(scores_array)
            baseline['std'] = np.std(scores_array)
            
            # Calculate threshold at specified percentile
            baseline['threshold'] = np.percentile(scores_array, self.percentile)
            
            # Ensure threshold is at least initial_threshold
            baseline['threshold'] = max(baseline['threshold'], self.initial_threshold)
        
        # Update feedback statistics if provided
        if is_anomaly is not None:
            predicted_anomaly = anomaly_scores > baseline['threshold']
            
            # Count true positives and false positives
            baseline['true_positives'] += np.sum(predicted_anomaly & is_anomaly)
            baseline['false_positives'] += np.sum(predicted_anomaly & ~is_anomaly)
        
        logger.debug(f"Updated baseline for {receiver_id}: "
                    f"samples={baseline['sample_count']}, "
                    f"threshold={baseline['threshold']:.4f}, "
                    f"mean={baseline['mean']:.4f}")
    
    def get_threshold(self, receiver_id: str) -> float:
        """
        Get current threshold for a receiver.
        
        Args:
            receiver_id: Receiver identifier
        
        Returns:
            Current threshold value
        """
        return self.receiver_baselines[receiver_id]['threshold']
    
    def classify_anomalies(self, 
                          receiver_id: str,
                          anomaly_scores: np.ndarray) -> Tuple[np.ndarray, float]:
        """
        Classify anomalies using adaptive threshold.
        
        Args:
            receiver_id: Receiver identifier
            anomaly_scores: Array of anomaly scores
        
        Returns:
            Tuple of (is_anomaly boolean array, threshold used)
        """
        threshold = self.get_threshold(receiver_id)
        is_anomaly = anomaly_scores > threshold
        
        return is_anomaly, threshold
    
    def get_baseline_stats(self, receiver_id: str) -> Dict:
        """
        Get baseline statistics for a receiver.
        
        Args:
            receiver_id: Receiver identifier
        
        Returns:
            Dictionary with baseline statistics
        """
        baseline = self.receiver_baselines[receiver_id]
        
        stats = {
            'threshold': baseline['threshold'],
            'mean': baseline['mean'],
            'std': baseline['std'],
            'sample_count': baseline['sample_count'],
            'has_baseline': baseline['sample_count'] >= self.min_samples
        }
        
        # Add performance metrics if available
        total_predictions = baseline['true_positives'] + baseline['false_positives']
        if total_predictions > 0:
            stats['precision'] = baseline['true_positives'] / total_predictions
            stats['false_positive_rate'] = baseline['false_positives'] / baseline['sample_count']
        else:
            stats['precision'] = None
            stats['false_positive_rate'] = None
        
        return stats
    
    def adjust_threshold_by_feedback(self, 
                                     receiver_id: str,
                                     adjustment_factor: float = 1.1):
        """
        Manually adjust threshold based on feedback.
        
        Args:
            receiver_id: Receiver identifier
            adjustment_factor: Factor to multiply threshold by (>1 increases, <1 decreases)
        """
        baseline = self.receiver_baselines[receiver_id]
        old_threshold = baseline['threshold']
        baseline['threshold'] *= adjustment_factor
        
        # Ensure threshold stays within reasonable bounds
        baseline['threshold'] = max(self.initial_threshold * 0.5, baseline['threshold'])
        baseline['threshold'] = min(self.initial_threshold * 3.0, baseline['threshold'])
        
        logger.info(f"Adjusted threshold for {receiver_id}: "
                   f"{old_threshold:.4f} -> {baseline['threshold']:.4f} "
                   f"(factor={adjustment_factor})")
    
    def get_all_receiver_stats(self) -> Dict[str, Dict]:
        """
        Get statistics for all receivers.
        
        Returns:
            Dictionary mapping receiver_id to stats
        """
        all_stats = {}
        for receiver_id in self.receiver_baselines.keys():
            all_stats[receiver_id] = self.get_baseline_stats(receiver_id)
        
        return all_stats
    
    def reset_receiver(self, receiver_id: str):
        """
        Reset baseline for a receiver.
        
        Args:
            receiver_id: Receiver identifier
        """
        if receiver_id in self.receiver_baselines:
            del self.receiver_baselines[receiver_id]
            logger.info(f"Reset baseline for {receiver_id}")
    
    def export_state(self) -> Dict:
        """Export thresholder state for persistence."""
        return {
            'initial_threshold': self.initial_threshold,
            'percentile': self.percentile,
            'min_samples': self.min_samples,
            'decay_factor': self.decay_factor,
            'receiver_baselines': dict(self.receiver_baselines)
        }
    
    def import_state(self, state: Dict):
        """Import thresholder state from persistence."""
        self.initial_threshold = state['initial_threshold']
        self.percentile = state['percentile']
        self.min_samples = state['min_samples']
        self.decay_factor = state['decay_factor']
        self.receiver_baselines = defaultdict(lambda: {
            'scores': [],
            'threshold': self.initial_threshold,
            'mean': 0.0,
            'std': 0.0,
            'sample_count': 0,
            'false_positives': 0,
            'true_positives': 0
        }, state['receiver_baselines'])
        
        logger.info("Imported thresholder state")
