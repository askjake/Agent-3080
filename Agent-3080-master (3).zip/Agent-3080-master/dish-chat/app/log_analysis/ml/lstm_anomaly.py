"""
LSTM-based Anomaly Detector for log sequences.
Adapted from LOGalyzer for Dish-Chat backend.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
from sklearn.preprocessing import StandardScaler
from typing import List, Dict, Any, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class LogLSTMAnomalyDetector(nn.Module):
    """
    LSTM-based sequence anomaly detector.
    Uses reconstruction error to detect anomalies in log sequences.
    """
    
    def __init__(self, input_size: int, hidden_size: int = 16, num_layers: int = 1):
        """
        Initialize LSTM model.
        
        Args:
            input_size: Dimension of input features
            hidden_size: Number of hidden units in LSTM
            num_layers: Number of LSTM layers
        """
        super(LogLSTMAnomalyDetector, self).__init__()
        
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        
        # LSTM encoder
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.2 if num_layers > 1 else 0
        )
        
        # Decoder to reconstruct input
        self.decoder = nn.Linear(hidden_size, input_size)
        
        logger.info(f"LSTM initialized: input={input_size}, hidden={hidden_size}, layers={num_layers}")
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through LSTM.
        
        Args:
            x: Input tensor of shape (batch, sequence, features)
        
        Returns:
            Reconstructed sequence
        """
        # LSTM forward
        lstm_out, (hidden, cell) = self.lstm(x)
        
        # Decode each time step
        reconstructed = self.decoder(lstm_out)
        
        return reconstructed


class LogSequenceDataset(Dataset):
    """Dataset for log sequences."""
    
    def __init__(self, sequences: np.ndarray):
        """
        Initialize dataset.
        
        Args:
            sequences: Array of shape (num_sequences, seq_len, features)
        """
        self.sequences = torch.FloatTensor(sequences)
    
    def __len__(self) -> int:
        return len(self.sequences)
    
    def __getitem__(self, idx: int) -> torch.Tensor:
        return self.sequences[idx]


class LSTMAnomalyDetectorTrainer:
    """
    Trainer for LSTM anomaly detector.
    Handles training, validation, and inference.
    """
    
    def __init__(self, 
                 input_size: int,
                 hidden_size: int = 16,
                 num_layers: int = 1,
                 seq_len: int = 16,
                 learning_rate: float = 0.001,
                 device: Optional[str] = None):
        """
        Initialize trainer.
        
        Args:
            input_size: Dimension of input features
            hidden_size: LSTM hidden size
            num_layers: Number of LSTM layers
            seq_len: Length of sequences
            learning_rate: Learning rate for optimizer
            device: Device to use (cuda/cpu)
        """
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.seq_len = seq_len
        
        # Device selection
        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device)
        
        # Initialize model
        self.model = LogLSTMAnomalyDetector(input_size, hidden_size, num_layers)
        self.model.to(self.device)
        
        # Optimizer and loss
        self.optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)
        self.criterion = nn.MSELoss()
        
        # Scaler for normalization
        self.scaler = StandardScaler()
        self.is_fitted = False
        
        # Training history
        self.training_history = {
            'train_loss': [],
            'val_loss': []
        }
        
        logger.info(f"Trainer initialized on device: {self.device}")
    
    def prepare_sequences(self, 
                         features: np.ndarray,
                         fit_scaler: bool = False) -> np.ndarray:
        """
        Prepare feature sequences for training/inference.
        
        Args:
            features: Feature array of shape (num_samples, feature_dim)
            fit_scaler: Whether to fit the scaler
        
        Returns:
            Sequences of shape (num_sequences, seq_len, feature_dim)
        """
        # Normalize features
        if fit_scaler:
            features = self.scaler.fit_transform(features)
            self.is_fitted = True
        elif self.is_fitted:
            features = self.scaler.transform(features)
        else:
            raise ValueError("Scaler not fitted. Set fit_scaler=True for training data.")
        
        # Create sliding window sequences
        sequences = []
        for i in range(len(features) - self.seq_len + 1):
            seq = features[i:i + self.seq_len]
            sequences.append(seq)
        
        return np.array(sequences)
    
    def train(self,
              train_features: np.ndarray,
              val_features: Optional[np.ndarray] = None,
              epochs: int = 50,
              batch_size: int = 32) -> Dict[str, List[float]]:
        """
        Train the LSTM model.
        
        Args:
            train_features: Training features (num_samples, feature_dim)
            val_features: Validation features (optional)
            epochs: Number of training epochs
            batch_size: Batch size
        
        Returns:
            Training history dictionary
        """
        logger.info(f"Starting training: epochs={epochs}, batch_size={batch_size}")
        
        # Prepare sequences
        train_sequences = self.prepare_sequences(train_features, fit_scaler=True)
        train_dataset = LogSequenceDataset(train_sequences)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        
        val_loader = None
        if val_features is not None:
            val_sequences = self.prepare_sequences(val_features, fit_scaler=False)
            val_dataset = LogSequenceDataset(val_sequences)
            val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
        
        # Training loop
        self.model.train()
        for epoch in range(epochs):
            train_loss = self._train_epoch(train_loader)
            self.training_history['train_loss'].append(train_loss)
            
            # Validation
            if val_loader is not None:
                val_loss = self._validate_epoch(val_loader)
                self.training_history['val_loss'].append(val_loss)
                logger.info(f"Epoch {epoch+1}/{epochs}: train_loss={train_loss:.6f}, val_loss={val_loss:.6f}")
            else:
                logger.info(f"Epoch {epoch+1}/{epochs}: train_loss={train_loss:.6f}")
        
        logger.info("Training completed")
        return self.training_history
    
    def _train_epoch(self, data_loader: DataLoader) -> float:
        """Train single epoch."""
        self.model.train()
        total_loss = 0.0
        num_batches = 0
        
        for batch in data_loader:
            batch = batch.to(self.device)
            
            # Forward pass
            self.optimizer.zero_grad()
            reconstructed = self.model(batch)
            loss = self.criterion(reconstructed, batch)
            
            # Backward pass
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item()
            num_batches += 1
        
        return total_loss / num_batches
    
    def _validate_epoch(self, data_loader: DataLoader) -> float:
        """Validate single epoch."""
        self.model.eval()
        total_loss = 0.0
        num_batches = 0
        
        with torch.no_grad():
            for batch in data_loader:
                batch = batch.to(self.device)
                reconstructed = self.model(batch)
                loss = self.criterion(reconstructed, batch)
                total_loss += loss.item()
                num_batches += 1
        
        return total_loss / num_batches
    
    def predict_anomaly_scores(self, features: np.ndarray) -> np.ndarray:
        """
        Predict anomaly scores for log sequences.
        
        Args:
            features: Feature array (num_samples, feature_dim)
        
        Returns:
            Anomaly scores (reconstruction errors)
        """
        if not self.is_fitted:
            raise ValueError("Model not trained. Call train() first.")
        
        # Prepare sequences
        sequences = self.prepare_sequences(features, fit_scaler=False)
        dataset = LogSequenceDataset(sequences)
        data_loader = DataLoader(dataset, batch_size=32, shuffle=False)
        
        # Calculate reconstruction errors
        self.model.eval()
        errors = []
        
        with torch.no_grad():
            for batch in data_loader:
                batch = batch.to(self.device)
                reconstructed = self.model(batch)
                
                # MSE per sequence
                mse = torch.mean((batch - reconstructed) ** 2, dim=(1, 2))
                errors.extend(mse.cpu().numpy())
        
        return np.array(errors)
    
    def get_model_state(self) -> Dict[str, Any]:
        """Get model state for persistence."""
        return {
            'model_state_dict': self.model.state_dict(),
            'scaler_mean': self.scaler.mean_.tolist() if self.is_fitted else None,
            'scaler_scale': self.scaler.scale_.tolist() if self.is_fitted else None,
            'input_size': self.input_size,
            'hidden_size': self.hidden_size,
            'num_layers': self.num_layers,
            'seq_len': self.seq_len,
            'is_fitted': self.is_fitted,
            'training_history': self.training_history
        }
    
    def load_model_state(self, state: Dict[str, Any]):
        """Load model state from persistence."""
        self.model.load_state_dict(state['model_state_dict'])
        
        if state['scaler_mean'] is not None:
            self.scaler.mean_ = np.array(state['scaler_mean'])
            self.scaler.scale_ = np.array(state['scaler_scale'])
            self.is_fitted = state['is_fitted']
        
        self.training_history = state.get('training_history', {'train_loss': [], 'val_loss': []})
        
        logger.info("Model state loaded successfully")
