"""
Log Analysis Router
Provides endpoints for log analysis functionality.
"""
from fastapi import APIRouter, HTTPException
from typing import Optional
import logging

from app.log_analysis.api_endpoints import (
    analyze_logs_endpoint,
    get_receiver_stats_endpoint,
    get_recent_anomalies_endpoint,
    AnalyzeLogsRequest,
    AnalyzeLogsResponse,
    ReceiverStatsResponse,
    RecentAnomaliesResponse
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Log Analysis"])


@router.post("/log-analysis/analyze", response_model=AnalyzeLogsResponse)
async def analyze_logs(request: AnalyzeLogsRequest):
    """
    Analyze log lines for a receiver.
    
    Parses logs, classifies severity, and optionally stores results.
    """
    try:
        return analyze_logs_endpoint(request)
    except Exception as e:
        logger.error(f"Error in analyze_logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/log-analysis/receiver/{receiver_id}/stats", response_model=ReceiverStatsResponse)
async def get_receiver_stats(receiver_id: str):
    """
    Get analysis statistics for a receiver.
    
    Returns aggregate statistics including anomaly counts, severity distribution, etc.
    """
    try:
        return get_receiver_stats_endpoint(receiver_id)
    except Exception as e:
        logger.error(f"Error in get_receiver_stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/log-analysis/anomalies/recent", response_model=RecentAnomaliesResponse)
async def get_recent_anomalies(receiver_id: Optional[str] = None, limit: int = 10):
    """
    Get recent anomalies across all receivers or for a specific receiver.
    
    Returns the most recent anomalies detected by the system.
    """
    try:
        return get_recent_anomalies_endpoint(receiver_id, limit)
    except Exception as e:
        logger.error(f"Error in get_recent_anomalies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/log-analysis/health")
async def health_check():
    """
    Check log analysis system health.
    
    Returns system status and database connectivity.
    """
    try:
        from app.log_analysis.pipeline import LogAnalysisPipeline
        
        pipeline = LogAnalysisPipeline()
        # Quick health check - just verify we can instantiate
        return {
            "status": "healthy",
            "service": "log_analysis",
            "components": {
                "pipeline": "initialized",
                "database": "connected"
            }
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return {
            "status": "unhealthy",
            "service": "log_analysis",
            "error": str(e)
        }
