"""
API endpoint templates for log analysis.
STANDALONE - Ready for integration but does not modify existing FastAPI routes.

To integrate: Import these functions in your FastAPI routes file.
"""
from fastapi import HTTPException, Depends
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime
import logging

from app.log_analysis.pipeline import LogAnalysisPipeline

logger = logging.getLogger(__name__)


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

class AnalyzeLogsRequest(BaseModel):
    """Request model for log analysis."""
    receiver_id: str
    log_lines: List[str]
    store_results: bool = True
    
    class Config:
        json_schema_extra = {
            "example": {
                "receiver_id": "RX12345",
                "log_lines": [
                    "[ERROR] Connection timeout",
                    "[INFO] Service started"
                ],
                "store_results": True
            }
        }


class AnalysisResult(BaseModel):
    """Single log analysis result."""
    receiver_id: str
    timestamp: Optional[str]
    severity: str
    is_anomaly: bool
    anomaly_score: Optional[float]
    customer_marked: bool
    parsed_fields: Dict[str, Any]


class AnalyzeLogsResponse(BaseModel):
    """Response model for log analysis."""
    success: bool
    message: str
    results_count: int
    results: List[AnalysisResult]
    processing_time_ms: float


class ReceiverStatsResponse(BaseModel):
    """Response model for receiver statistics."""
    receiver_id: str
    total_logs: int
    anomalies: int
    anomaly_rate: float
    critical: int
    warnings: int
    customer_marked: int
    avg_anomaly_score: Optional[float]
    first_log: Optional[str]
    last_log: Optional[str]


class AnomalyRecord(BaseModel):
    """Model for anomaly record."""
    id: int
    log_identifier: str
    timestamp: str
    severity: str
    anomaly_score: Optional[float]
    threshold: Optional[float]
    customer_marked: bool


class RecentAnomaliesResponse(BaseModel):
    """Response model for recent anomalies."""
    success: bool
    anomalies: List[AnomalyRecord]
    count: int


# ============================================================================
# STANDALONE ENDPOINT FUNCTIONS
# ============================================================================
# These can be imported and used in FastAPI router files

def analyze_logs_endpoint(request: AnalyzeLogsRequest) -> AnalyzeLogsResponse:
    """
    Analyze log lines for a receiver.
    
    STANDALONE FUNCTION - Can be integrated into FastAPI router like:
    
    @router.post("/analyze-logs")
    async def analyze_logs(request: AnalyzeLogsRequest):
        return analyze_logs_endpoint(request)
    
    Args:
        request: Analysis request
    
    Returns:
        Analysis response
    """
    import time
    start_time = time.time()
    
    try:
        # Initialize pipeline
        pipeline = LogAnalysisPipeline(use_ml=False)  # ML optional for now
        
        # Analyze logs
        results = pipeline.analyze_logs(
            log_lines=request.log_lines,
            receiver_id=request.receiver_id,
            store_results=request.store_results
        )
        
        # Convert to response model
        result_models = []
        for r in results:
            result_models.append(AnalysisResult(
                receiver_id=r['receiver_id'],
                timestamp=str(r['timestamp']) if r['timestamp'] else None,
                severity=r['severity'],
                is_anomaly=r['is_anomaly'],
                anomaly_score=r['anomaly_score'],
                customer_marked=r['customer_marked'],
                parsed_fields=r['parsed_fields']
            ))
        
        processing_time = (time.time() - start_time) * 1000
        
        return AnalyzeLogsResponse(
            success=True,
            message=f"Analyzed {len(results)} logs",
            results_count=len(results),
            results=result_models,
            processing_time_ms=processing_time
        )
        
    except Exception as e:
        logger.error(f"Error analyzing logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def get_receiver_stats_endpoint(receiver_id: str) -> ReceiverStatsResponse:
    """
    Get analysis statistics for a receiver.
    
    STANDALONE FUNCTION - Can be integrated into FastAPI router like:
    
    @router.get("/receiver/{receiver_id}/stats")
    async def get_receiver_stats(receiver_id: str):
        return get_receiver_stats_endpoint(receiver_id)
    
    Args:
        receiver_id: Receiver identifier
    
    Returns:
        Statistics response
    """
    try:
        pipeline = LogAnalysisPipeline()
        stats = pipeline.get_receiver_stats(receiver_id)
        
        return ReceiverStatsResponse(
            receiver_id=receiver_id,
            total_logs=stats.get('total_logs', 0),
            anomalies=stats.get('anomalies', 0),
            anomaly_rate=stats.get('anomaly_rate', 0.0),
            critical=stats.get('critical', 0),
            warnings=stats.get('warnings', 0),
            customer_marked=stats.get('customer_marked', 0),
            avg_anomaly_score=stats.get('avg_anomaly_score'),
            first_log=str(stats.get('first_log')) if stats.get('first_log') else None,
            last_log=str(stats.get('last_log')) if stats.get('last_log') else None
        )
        
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


def get_recent_anomalies_endpoint(
    receiver_id: Optional[str] = None,
    limit: int = 10
) -> RecentAnomaliesResponse:
    """
    Get recent anomalies.
    
    STANDALONE FUNCTION - Can be integrated into FastAPI router like:
    
    @router.get("/anomalies/recent")
    async def get_recent_anomalies(receiver_id: Optional[str] = None, limit: int = 10):
        return get_recent_anomalies_endpoint(receiver_id, limit)
    
    Args:
        receiver_id: Optional receiver filter
        limit: Maximum results
    
    Returns:
        Anomalies response
    """
    try:
        pipeline = LogAnalysisPipeline()
        anomalies = pipeline.get_recent_anomalies(receiver_id, limit)
        
        anomaly_models = []
        for a in anomalies:
            anomaly_models.append(AnomalyRecord(
                id=a['id'],
                log_identifier=a['log_identifier'],
                timestamp=str(a['timestamp']),
                severity=a['severity'],
                anomaly_score=a['anomaly_score'],
                threshold=a['threshold'],
                customer_marked=a['customer_marked']
            ))
        
        return RecentAnomaliesResponse(
            success=True,
            anomalies=anomaly_models,
            count=len(anomaly_models)
        )
        
    except Exception as e:
        logger.error(f"Error getting anomalies: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================
"""
TO INTEGRATE THESE ENDPOINTS INTO EXISTING FASTAPI:

1. Create a new router file (e.g., app/routes/log_analysis.py):

    from fastapi import APIRouter
    from app.log_analysis.api_endpoints import (
        analyze_logs_endpoint,
        get_receiver_stats_endpoint,
        get_recent_anomalies_endpoint,
        AnalyzeLogsRequest,
        AnalyzeLogsResponse,
        ReceiverStatsResponse,
        RecentAnomaliesResponse
    )
    
    router = APIRouter(prefix="/api/v1/log-analysis", tags=["Log Analysis"])
    
    @router.post("/analyze", response_model=AnalyzeLogsResponse)
    async def analyze_logs(request: AnalyzeLogsRequest):
        return analyze_logs_endpoint(request)
    
    @router.get("/receiver/{receiver_id}/stats", response_model=ReceiverStatsResponse)
    async def get_receiver_stats(receiver_id: str):
        return get_receiver_stats_endpoint(receiver_id)
    
    @router.get("/anomalies/recent", response_model=RecentAnomaliesResponse)
    async def get_recent_anomalies(receiver_id: Optional[str] = None, limit: int = 10):
        return get_recent_anomalies_endpoint(receiver_id, limit)

2. Add router to main FastAPI app:

    from app.routes import log_analysis
    app.include_router(log_analysis.router)

3. Done! Endpoints are now available at:
   - POST /api/v1/log-analysis/analyze
   - GET /api/v1/log-analysis/receiver/{receiver_id}/stats
   - GET /api/v1/log-analysis/anomalies/recent
"""
