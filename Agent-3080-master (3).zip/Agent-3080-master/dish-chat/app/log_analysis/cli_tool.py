#!/usr/bin/env python3
"""
Command-line tool for testing log analysis components.
STANDALONE - Does not integrate with existing services.
"""
import sys
import argparse
import json

sys.path.insert(0, '/home/montjac/dish-chat')

from app.log_analysis.pipeline import LogAnalysisPipeline
from app.log_analysis.utils.testing_utils import LogGenerator, PerformanceBenchmark


def analyze_command(args):
    print(f"Analyzing logs from: {args.file}")
    with open(args.file, 'r') as f:
        log_lines = [line.strip() for line in f if line.strip()]
    print(f"Read {len(log_lines)} log lines")
    pipeline = LogAnalysisPipeline(use_ml=False)
    results = pipeline.analyze_logs(log_lines, args.receiver, args.store)
    print(f"Analysis complete: {len(results)} results")
    if args.output:
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2, default=str)


def benchmark_command(args):
    print(f"Running benchmark with {args.count} logs...")
    generator = LogGenerator()
    log_lines = generator.generate_batch(count=args.count)
    metrics = PerformanceBenchmark.benchmark_parsing(log_lines)
    print(f"Logs/second: {metrics['logs_per_second']:,.0f}")


def stats_command(args):
    pipeline = LogAnalysisPipeline()
    stats = pipeline.get_receiver_stats(args.receiver)
    print(f"Total logs: {stats.get('total_logs', 0)}")
    print(f"Anomalies: {stats.get('anomalies', 0)}")


def main():
    parser = argparse.ArgumentParser(description='Log Analysis CLI Tool')
    subparsers = parser.add_subparsers(dest='command')
    
    analyze_parser = subparsers.add_parser('analyze')
    analyze_parser.add_argument('--file', required=True)
    analyze_parser.add_argument('--receiver', required=True)
    analyze_parser.add_argument('--store', action='store_true')
    analyze_parser.add_argument('--output')
    
    benchmark_parser = subparsers.add_parser('benchmark')
    benchmark_parser.add_argument('--count', type=int, default=1000)
    
    stats_parser = subparsers.add_parser('stats')
    stats_parser.add_argument('--receiver', required=True)
    
    args = parser.parse_args()
    
    if args.command == 'analyze':
        analyze_command(args)
    elif args.command == 'benchmark':
        benchmark_command(args)
    elif args.command == 'stats':
        stats_command(args)


if __name__ == '__main__':
    main()
