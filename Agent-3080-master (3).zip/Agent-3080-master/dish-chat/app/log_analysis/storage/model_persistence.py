"""
Model persistence layer for storing/loading ML models in database.
Uses the ml_models table with BYTEA storage for model data.
"""
import io
import json
import pickle
from datetime import datetime
from typing import Optional, Dict, Any, List
import logging
import psycopg2
from psycopg2.extras import DictCursor
import torch

logger = logging.getLogger(__name__)


class ModelPersistence:
    """
    Manage ML model persistence in PostgreSQL database.
    Stores models as BYTEA with metadata and training metrics.
    """
    
    def __init__(self, db_config: Optional[Dict[str, Any]] = None):
        """
        Initialize model persistence.
        
        Args:
            db_config: Database configuration dict with keys:
                      host, port, database, user, password
        """
        if db_config is None:
            # Default configuration for Dish-Chat
            self.db_config = {
                'host': '127.0.0.1',
                'port': 5434,
                'database': 'dishchat',
                'user': 'dev_user',
                'password': 'dev123'
            }
        else:
            self.db_config = db_config
        
        logger.info("ModelPersistence initialized")
    
    def _get_connection(self):
        """Get database connection."""
        return psycopg2.connect(**self.db_config)
    
    def save_model(self,
                   model_type: str,
                   model_name: str,
                   model_state: Dict[str, Any],
                   input_dim: int,
                   hidden_size: Optional[int] = None,
                   seq_len: Optional[int] = None,
                   training_metrics: Optional[Dict[str, Any]] = None) -> int:
        """
        Save a model to the database.
        
        Args:
            model_type: Type of model (e.g., 'LSTM', 'RandomForest')
            model_name: Name identifier for the model
            model_state: Model state dictionary
            input_dim: Input dimension
            hidden_size: Hidden size (for LSTM)
            seq_len: Sequence length (for LSTM)
            training_metrics: Training metrics (loss, accuracy, etc.)
        
        Returns:
            model_id of saved model
        """
        # Serialize model state
        buffer = io.BytesIO()
        torch.save(model_state, buffer)
        model_data = buffer.getvalue()
        
        # Prepare metrics
        metrics_json = json.dumps(training_metrics) if training_metrics else None
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Insert or update
            cursor.execute("""
                INSERT INTO ml_models 
                (model_type, model_name, input_dim, hidden_size, seq_len, 
                 model_data, training_metrics, created_at, last_updated)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (model_type, model_name, input_dim, hidden_size, seq_len)
                DO UPDATE SET
                    model_data = EXCLUDED.model_data,
                    training_metrics = EXCLUDED.training_metrics,
                    last_updated = EXCLUDED.last_updated
                RETURNING model_id
            """, (
                model_type,
                model_name,
                input_dim,
                hidden_size,
                seq_len,
                model_data,
                metrics_json,
                datetime.now(),
                datetime.now()
            ))
            
            model_id = cursor.fetchone()[0]
            conn.commit()
            
            logger.info(f"Model saved: id={model_id}, type={model_type}, name={model_name}")
            return model_id
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error saving model: {e}")
            raise
        finally:
            cursor.close()
            conn.close()
    
    def load_model(self,
                   model_type: str,
                   model_name: str,
                   input_dim: int,
                   hidden_size: Optional[int] = None,
                   seq_len: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """
        Load a model from the database.
        
        Args:
            model_type: Type of model
            model_name: Name identifier
            input_dim: Input dimension
            hidden_size: Hidden size (for LSTM)
            seq_len: Sequence length (for LSTM)
        
        Returns:
            Dictionary with model_state, training_metrics, and metadata
        """
        conn = self._get_connection()
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        try:
            cursor.execute("""
                SELECT model_id, model_data, training_metrics, 
                       created_at, last_updated
                FROM ml_models
                WHERE model_type = %s 
                  AND model_name = %s
                  AND input_dim = %s
                  AND hidden_size IS NOT DISTINCT FROM %s
                  AND seq_len IS NOT DISTINCT FROM %s
                ORDER BY last_updated DESC
                LIMIT 1
            """, (model_type, model_name, input_dim, hidden_size, seq_len))
            
            row = cursor.fetchone()
            
            if row is None:
                logger.warning(f"Model not found: {model_type}/{model_name}")
                return None
            
            # Deserialize model state
            buffer = io.BytesIO(row['model_data'])
            model_state = torch.load(buffer)
            
            # Parse metrics
            training_metrics = row["training_metrics"] if row["training_metrics"] else {}
            
            result = {
                'model_id': row['model_id'],
                'model_state': model_state,
                'training_metrics': training_metrics,
                'created_at': row['created_at'],
                'last_updated': row['last_updated']
            }
            
            logger.info(f"Model loaded: id={row['model_id']}, type={model_type}, name={model_name}")
            return result
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise
        finally:
            cursor.close()
            conn.close()
    
    def list_models(self,
                    model_type: Optional[str] = None,
                    limit: int = 10) -> List[Dict[str, Any]]:
        """
        List available models.
        
        Args:
            model_type: Filter by model type (optional)
            limit: Maximum number of models to return
        
        Returns:
            List of model metadata dictionaries
        """
        conn = self._get_connection()
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        try:
            if model_type:
                cursor.execute("""
                    SELECT model_id, model_type, model_name, 
                           input_dim, hidden_size, seq_len,
                           training_metrics, created_at, last_updated
                    FROM ml_models
                    WHERE model_type = %s
                    ORDER BY last_updated DESC
                    LIMIT %s
                """, (model_type, limit))
            else:
                cursor.execute("""
                    SELECT model_id, model_type, model_name, 
                           input_dim, hidden_size, seq_len,
                           training_metrics, created_at, last_updated
                    FROM ml_models
                    ORDER BY last_updated DESC
                    LIMIT %s
                """, (limit,))
            
            models = []
            for row in cursor.fetchall():
                model_info = dict(row)
                if model_info['training_metrics']:
                    pass  # Already parsed by psycopg2
                models.append(model_info)
            
            logger.info(f"Listed {len(models)} models")
            return models
            
        finally:
            cursor.close()
            conn.close()
    
    def delete_model(self, model_id: int) -> bool:
        """
        Delete a model by ID.
        
        Args:
            model_id: ID of model to delete
        
        Returns:
            True if deleted, False if not found
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("DELETE FROM ml_models WHERE model_id = %s", (model_id,))
            deleted = cursor.rowcount > 0
            conn.commit()
            
            if deleted:
                logger.info(f"Model deleted: id={model_id}")
            else:
                logger.warning(f"Model not found for deletion: id={model_id}")
            
            return deleted
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error deleting model: {e}")
            raise
        finally:
            cursor.close()
            conn.close()
    
    def get_latest_model(self, 
                        model_type: str, 
                        model_name: str) -> Optional[Dict[str, Any]]:
        """
        Get the most recently updated model by type and name.
        
        Args:
            model_type: Type of model
            model_name: Name identifier
        
        Returns:
            Model data or None if not found
        """
        conn = self._get_connection()
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        try:
            cursor.execute("""
                SELECT model_id, model_data, training_metrics,
                       input_dim, hidden_size, seq_len,
                       created_at, last_updated
                FROM ml_models
                WHERE model_type = %s AND model_name = %s
                ORDER BY last_updated DESC
                LIMIT 1
            """, (model_type, model_name))
            
            row = cursor.fetchone()
            
            if row is None:
                return None
            
            # Deserialize model state
            buffer = io.BytesIO(row['model_data'])
            model_state = torch.load(buffer)
            
            # Parse metrics
            training_metrics = row["training_metrics"] if row["training_metrics"] else {}
            
            return {
                'model_id': row['model_id'],
                'model_state': model_state,
                'training_metrics': training_metrics,
                'input_dim': row['input_dim'],
                'hidden_size': row['hidden_size'],
                'seq_len': row['seq_len'],
                'created_at': row['created_at'],
                'last_updated': row['last_updated']
            }
            
        finally:
            cursor.close()
            conn.close()
