"""
Testing utilities for log analysis components.
Provides helper functions for testing and validation.
"""
import random
import numpy as np
from typing import List, Dict, Any
from datetime import datetime, timedelta


class LogGenerator:
    """Generate synthetic log lines for testing."""
    
    def __init__(self, seed: int = 42):
        """Initialize log generator with seed."""
        random.seed(seed)
        np.random.seed(seed)
        
        self.categories = ['SYSTEM', 'ERROR', 'NETWORK', 'MEMORY', 'DEBUG', 'INFO', 'WARN']
        self.files = ['main.cpp', 'network.cpp', 'memory.cpp', 'service.cpp']
        self.functions = ['init', 'process', 'handle', 'connect', 'allocate', 'free']
        
        self.error_messages = [
            'Connection timeout',
            'Memory allocation failed',
            'Network unreachable',
            'Service unavailable',
            'Database connection lost'
        ]
        
        self.info_messages = [
            'Service started',
            'Connection established',
            'Processing batch',
            'Task completed',
            'Cache refreshed'
        ]
    
    def generate_standard_log(self, timestamp: datetime = None) -> str:
        """Generate a standard format log line."""
        if timestamp is None:
            timestamp = datetime.now()
        
        category = random.choice(self.categories)
        file = random.choice(self.files)
        line_num = random.randint(10, 500)
        function = random.choice(self.functions)
        
        if category in ['ERROR', 'WARN']:
            message = random.choice(self.error_messages)
        else:
            message = random.choice(self.info_messages)
        
        return f"[{category}]<{timestamp.strftime('%Y/%m/%d %H:%M:%S')}><{file}:{line_num}> {function}: {message}"
    
    def generate_batch(self, count: int = 100, 
                      anomaly_ratio: float = 0.05) -> List[str]:
        """
        Generate a batch of log lines.
        
        Args:
            count: Number of logs to generate
            anomaly_ratio: Ratio of anomalous logs (0-1)
        
        Returns:
            List of log lines
        """
        logs = []
        base_time = datetime.now() - timedelta(hours=1)
        
        for i in range(count):
            timestamp = base_time + timedelta(seconds=i)
            
            # Determine if this should be an anomaly
            if random.random() < anomaly_ratio:
                # Generate anomalous log
                category = random.choice(['ERROR', 'CRITICAL', 'WARN'])
                message = random.choice(self.error_messages)
                log = f"[{category}]<{timestamp.strftime('%Y/%m/%d %H:%M:%S')}> {message}"
            else:
                # Generate normal log
                log = self.generate_standard_log(timestamp)
            
            logs.append(log)
        
        return logs


class PerformanceBenchmark:
    """Benchmark performance of log analysis components."""
    
    @staticmethod
    def benchmark_parsing(log_lines: List[str], iterations: int = 1) -> Dict[str, Any]:
        """
        Benchmark log parsing performance.
        
        Args:
            log_lines: List of log lines
            iterations: Number of iterations
        
        Returns:
            Performance metrics
        """
        from app.log_analysis.parsing.log_patterns import LogPatternLibrary
        import time
        
        parser = LogPatternLibrary()
        
        times = []
        for _ in range(iterations):
            start = time.time()
            results = parser.parse_logs(log_lines)
            elapsed = time.time() - start
            times.append(elapsed)
        
        avg_time = np.mean(times)
        logs_per_sec = len(log_lines) / avg_time
        
        return {
            'total_logs': len(log_lines),
            'iterations': iterations,
            'avg_time_seconds': avg_time,
            'logs_per_second': logs_per_sec,
            'min_time': np.min(times),
            'max_time': np.max(times)
        }
    
    @staticmethod
    def benchmark_pipeline(log_lines: List[str], receiver_id: str = 'BENCH') -> Dict[str, Any]:
        """
        Benchmark full pipeline performance.
        
        Args:
            log_lines: List of log lines
            receiver_id: Receiver identifier
        
        Returns:
            Performance metrics
        """
        from app.log_analysis.pipeline import LogAnalysisPipeline
        import time
        
        pipeline = LogAnalysisPipeline(use_ml=False)
        
        start = time.time()
        results = pipeline.analyze_logs(log_lines, receiver_id, store_results=False)
        elapsed = time.time() - start
        
        return {
            'total_logs': len(log_lines),
            'processed_logs': len(results),
            'total_time_seconds': elapsed,
            'logs_per_second': len(results) / elapsed,
            'avg_time_per_log_ms': (elapsed / len(results)) * 1000
        }


class ValidationHelper:
    """Helper functions for validating analysis results."""
    
    @staticmethod
    def validate_parsed_log(parsed: Dict[str, Any]) -> List[str]:
        """
        Validate a parsed log structure.
        
        Args:
            parsed: Parsed log dictionary
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        required_fields = ['pattern_name', 'rx_id']
        for field in required_fields:
            if field not in parsed:
                errors.append(f"Missing required field: {field}")
        
        if 'timestamp' not in parsed or parsed['timestamp'] is None:
            errors.append("Missing or null timestamp")
        
        return errors
    
    @staticmethod
    def validate_analysis_result(result: Dict[str, Any]) -> List[str]:
        """
        Validate an analysis result.
        
        Args:
            result: Analysis result dictionary
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        required_fields = ['receiver_id', 'severity', 'is_anomaly']
        for field in required_fields:
            if field not in result:
                errors.append(f"Missing required field: {field}")
        
        valid_severities = ['critical', 'warning', 'anomaly', 'normal', 'informational']
        if result.get('severity') not in valid_severities:
            errors.append(f"Invalid severity: {result.get('severity')}")
        
        return errors
    
    @staticmethod
    def calculate_accuracy(predictions: List[bool], 
                         ground_truth: List[bool]) -> Dict[str, float]:
        """
        Calculate classification accuracy metrics.
        
        Args:
            predictions: List of predicted labels
            ground_truth: List of true labels
        
        Returns:
            Dictionary with accuracy metrics
        """
        predictions = np.array(predictions)
        ground_truth = np.array(ground_truth)
        
        tp = np.sum(predictions & ground_truth)
        fp = np.sum(predictions & ~ground_truth)
        tn = np.sum(~predictions & ~ground_truth)
        fn = np.sum(~predictions & ground_truth)
        
        accuracy = (tp + tn) / len(predictions) if len(predictions) > 0 else 0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'true_positives': int(tp),
            'false_positives': int(fp),
            'true_negatives': int(tn),
            'false_negatives': int(fn)
        }


class MockDataGenerator:
    """Generate mock data for testing database operations."""
    
    @staticmethod
    def generate_analysis_results(count: int = 10) -> List[Dict[str, Any]]:
        """Generate mock analysis results."""
        results = []
        base_time = datetime.now()
        
        for i in range(count):
            result = {
                'receiver_id': f'RX{random.randint(1000, 9999)}',
                'timestamp': base_time + timedelta(seconds=i),
                'parsed_fields': {'pattern': 'standard_log', 'data': f'Log {i}'},
                'extracted_fields': {},
                'anomaly_score': random.random(),
                'threshold': 0.5,
                'is_anomaly': random.random() > 0.8,
                'severity': random.choice(['critical', 'warning', 'normal']),
                'customer_marked': random.random() > 0.9
            }
            results.append(result)
        
        return results
