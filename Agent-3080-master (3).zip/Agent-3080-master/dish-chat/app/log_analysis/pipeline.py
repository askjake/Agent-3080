"""
End-to-end log analysis pipeline.
Integrates parsing, ML, and storage components.
STANDALONE - ready for integration but does not modify existing code.
"""
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
import logging
import psycopg2
from psycopg2.extras import DictCursor

from app.log_analysis.parsing.log_patterns import LogPatternLibrary
from app.log_analysis.enrichment.severity_classifier import SeverityClassifier
from app.log_analysis.ml.lstm_anomaly import LSTMAnomalyDetectorTrainer
from app.log_analysis.ml.adaptive_threshold import AdaptiveThreshold
from app.log_analysis.ml.tfidf_vectorizer import LogTfidfVectorizer
from app.log_analysis.storage.model_persistence import ModelPersistence

logger = logging.getLogger(__name__)


class LogAnalysisPipeline:
    """
    End-to-end log analysis pipeline.
    Processes logs through parsing, feature extraction, ML analysis, and storage.
    """
    
    def __init__(self,
                 db_config: Optional[Dict[str, Any]] = None,
                 lstm_model_name: str = 'default_lstm',
                 use_ml: bool = True):
        """
        Initialize pipeline.
        
        Args:
            db_config: Database configuration
            lstm_model_name: Name of LSTM model to load/save
            use_ml: Whether to use ML-based anomaly detection
        """
        # Initialize components
        self.parser = LogPatternLibrary()
        self.classifier = SeverityClassifier()
        self.use_ml = use_ml
        
        # ML components (lazy loaded)
        self.lstm_trainer: Optional[LSTMAnomalyDetectorTrainer] = None
        self.adaptive_threshold: Optional[AdaptiveThreshold] = None
        self.tfidf_vectorizer: Optional[LogTfidfVectorizer] = None
        self.lstm_model_name = lstm_model_name
        
        # Storage
        self.persistence = ModelPersistence(db_config)
        
        # Database config
        if db_config is None:
            self.db_config = {
                'host': '127.0.0.1',
                'port': 5434,
                'database': 'dishchat',
                'user': 'dev_user',
                'password': 'dev123'
            }
        else:
            self.db_config = db_config
        
        logger.info(f"LogAnalysisPipeline initialized (use_ml={use_ml})")
    
    def _ensure_ml_components(self):
        """Lazy load ML components."""
        if not self.use_ml:
            return
        
        if self.adaptive_threshold is None:
            self.adaptive_threshold = AdaptiveThreshold()
            logger.info("Adaptive threshold initialized")
        
        if self.tfidf_vectorizer is None:
            self.tfidf_vectorizer = LogTfidfVectorizer()
            logger.info("TF-IDF vectorizer initialized")
    
    def load_lstm_model(self, 
                       input_dim: int = 5,
                       hidden_size: int = 16,
                       seq_len: int = 16) -> bool:
        """
        Load LSTM model from database.
        
        Args:
            input_dim: Input dimension
            hidden_size: Hidden size
            seq_len: Sequence length
        
        Returns:
            True if loaded, False if not found
        """
        if not self.use_ml:
            return False
        
        # Try to load existing model
        model_data = self.persistence.load_model(
            model_type='LSTM',
            model_name=self.lstm_model_name,
            input_dim=input_dim,
            hidden_size=hidden_size,
            seq_len=seq_len
        )
        
        if model_data:
            # Create trainer and load state
            self.lstm_trainer = LSTMAnomalyDetectorTrainer(
                input_size=input_dim,
                hidden_size=hidden_size,
                seq_len=seq_len,
                device='cpu'
            )
            self.lstm_trainer.load_model_state(model_data['model_state'])
            logger.info(f"Loaded LSTM model: {self.lstm_model_name}")
            return True
        else:
            logger.warning(f"LSTM model not found: {self.lstm_model_name}")
            return False
    
    def analyze_logs(self,
                    log_lines: List[str],
                    receiver_id: str,
                    store_results: bool = True) -> List[Dict[str, Any]]:
        """
        Analyze a batch of log lines.
        
        Args:
            log_lines: List of raw log lines
            receiver_id: Receiver identifier
            store_results: Whether to store results in database
        
        Returns:
            List of analysis result dictionaries
        """
        logger.info(f"Analyzing {len(log_lines)} logs for {receiver_id}")
        
        # Step 1: Parse logs
        parsed_logs = self.parser.parse_logs(log_lines, rx_id=receiver_id)
        logger.debug(f"Parsed {len(parsed_logs)} logs")
        
        results = []
        
        for parsed in parsed_logs:
            result = {
                'receiver_id': receiver_id,
                'timestamp': parsed.get('timestamp'),
                'parsed_fields': parsed,
                'extracted_fields': parsed.get('extracted_fields', {}),
                'anomaly_score': None,
                'threshold': None,
                'is_anomaly': False,
                'severity': None,
                'customer_marked': False
            }
            
            # Step 2: Classify severity
            log_data = parsed.get('data', '')
            extracted_fields = parsed.get('extracted_fields', {})
            customer_marked = extracted_fields.get('customer_marked_flag') == 'YES'
            
            severity_result = self.classifier.classify_with_details(
                log_data,
                extracted_fields=extracted_fields,
                customer_marked=customer_marked
            )
            
            result['severity'] = severity_result['severity']
            result['customer_marked'] = customer_marked
            
            # Step 3: ML-based anomaly detection (if enabled)
            if self.use_ml and self.lstm_trainer and self.lstm_trainer.is_fitted:
                # This would require converting parsed fields to feature vectors
                # For now, we note that ML is available but needs feature engineering
                result['ml_available'] = True
            else:
                result['ml_available'] = False
            
            results.append(result)
        
        # Step 4: Store results (if requested)
        if store_results:
            self._store_results(results)
        
        logger.info(f"Analysis complete: {len(results)} results")
        return results
    
    def _store_results(self, results: List[Dict[str, Any]]):
        """Store analysis results in database."""
        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor()
        
        try:
            for result in results:
                cursor.execute("""
                    INSERT INTO log_analysis_results
                    (log_identifier, timestamp, parsed_fields, extracted_fields,
                     anomaly_score, threshold, is_anomaly, severity, customer_marked,
                     model_version, created_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    result['receiver_id'],
                    result['timestamp'] or datetime.now(),
                    __import__("json").dumps(result["parsed_fields"]),
                    __import__("json").dumps(result["extracted_fields"]),
                    result['anomaly_score'],
                    result['threshold'],
                    result['is_anomaly'],
                    result['severity'],
                    result['customer_marked'],
                    self.lstm_model_name if self.use_ml else None,
                    datetime.now()
                ))
            
            conn.commit()
            logger.info(f"Stored {len(results)} results in database")
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error storing results: {e}")
            raise
        finally:
            cursor.close()
            conn.close()
    
    def get_receiver_stats(self, receiver_id: str) -> Dict[str, Any]:
        """
        Get analysis statistics for a receiver.
        
        Args:
            receiver_id: Receiver identifier
        
        Returns:
            Statistics dictionary
        """
        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        try:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_logs,
                    COUNT(*) FILTER (WHERE is_anomaly = true) as anomalies,
                    COUNT(*) FILTER (WHERE customer_marked = true) as customer_marked,
                    COUNT(*) FILTER (WHERE severity = 'critical') as critical,
                    COUNT(*) FILTER (WHERE severity = 'warning') as warnings,
                    AVG(anomaly_score) as avg_anomaly_score,
                    MIN(timestamp) as first_log,
                    MAX(timestamp) as last_log
                FROM log_analysis_results
                WHERE log_identifier = %s
            """, (receiver_id,))
            
            row = cursor.fetchone()
            
            if row:
                stats = dict(row)
                stats['anomaly_rate'] = (stats['anomalies'] / stats['total_logs'] * 100) if stats['total_logs'] > 0 else 0
                return stats
            else:
                return {'total_logs': 0}
                
        finally:
            cursor.close()
            conn.close()
    
    def get_recent_anomalies(self,
                            receiver_id: Optional[str] = None,
                            limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent anomalies.
        
        Args:
            receiver_id: Optional receiver filter
            limit: Maximum results
        
        Returns:
            List of anomaly records
        """
        conn = psycopg2.connect(**self.db_config)
        cursor = conn.cursor(cursor_factory=DictCursor)
        
        try:
            if receiver_id:
                cursor.execute("""
                    SELECT id, log_identifier, timestamp, severity,
                           anomaly_score, threshold, customer_marked
                    FROM log_analysis_results
                    WHERE is_anomaly = true
                      AND log_identifier = %s
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, (receiver_id, limit))
            else:
                cursor.execute("""
                    SELECT id, log_identifier, timestamp, severity,
                           anomaly_score, threshold, customer_marked
                    FROM log_analysis_results
                    WHERE is_anomaly = true
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, (limit,))
            
            return [dict(row) for row in cursor.fetchall()]
            
        finally:
            cursor.close()
            conn.close()
