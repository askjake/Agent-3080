"""Pydantic schemas for tool management."""
from pydantic import BaseModel, Field
from typing import Optional, List


class ToolInfo(BaseModel):
    """Information about a single tool."""
    name: str = Field(..., description="Tool name")
    description: str = Field(..., description="Tool description")
    group: str = Field(..., description="MCP server name or 'internal'")
    user_selectable: bool = Field(..., description="Whether user can enable/disable this tool")
    enabled: bool = Field(..., description="Global availability (MCP server responsive)")
    user_enabled: Optional[bool] = Field(None, description="User's preference (None = default)")
    
    model_config = {"from_attributes": True}


class ToolGroup(BaseModel):
    """Group of tools from same MCP server."""
    name: str = Field(..., description="Group/server name")
    display_name: str = Field(..., description="Human-readable name")
    user_selectable: bool = Field(..., description="Whether any tools in group are user-selectable")
    enabled: bool = Field(..., description="Whether server is responsive")
    tools: List[ToolInfo] = Field(default_factory=list, description="List of tools in this group")
    
    model_config = {"from_attributes": True}


class UserToolsResponse(BaseModel):
    """Response for GET /tools endpoint."""
    groups: List[ToolGroup] = Field(default_factory=list, description="Tool groups")
    total_tools: int = Field(0, description="Total number of tools")
    total_enabled: int = Field(0, description="Number of enabled tools")
    
    model_config = {"from_attributes": True}


class EnableToolRequest(BaseModel):
    """Request to enable/disable a tool."""
    group: str = Field(..., description="MCP server name or 'internal'")
    tool_name: Optional[str] = Field(None, description="Specific tool name (None = entire group)")
    enabled: bool = Field(..., description="Enable (true) or disable (false)")
    
    model_config = {"from_attributes": True}


class EnableToolResponse(BaseModel):
    """Response for enable/disable tool request."""
    status: str = Field("success", description="Operation status")
    message: str = Field(..., description="Human-readable message")
    group: str = Field(..., description="Affected group")
    tool_name: Optional[str] = Field(None, description="Affected tool")
    
    model_config = {"from_attributes": True}


class EnabledToolsResponse(BaseModel):
    """Response for GET /tools/enabled endpoint."""
    user_email: str = Field(..., description="User email")
    enabled_tools: List[str] = Field(default_factory=list, description="List of enabled tool identifiers")
    count: int = Field(0, description="Number of enabled tools")
    
    model_config = {"from_attributes": True}
