"""
Tool Management Module

Provides hot-plug MCP tool selection capabilities:
- Dynamic tool enable/disable per user
- Tool preference persistence
- Hot-reload support
"""
