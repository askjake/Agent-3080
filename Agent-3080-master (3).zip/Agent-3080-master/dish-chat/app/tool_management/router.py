"""API router for tool management endpoints."""
import logging
from fastapi import APIRouter, Depends
from typing import Annotated

from app.tool_management.service import ToolManagementService
from app.tool_management.schemas import (
    UserToolsResponse,
    EnableToolRequest,
    EnableToolResponse,
    EnabledToolsResponse
)
from app.dependencies import UserEmailDep, DBSessionDep

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/tools", tags=["tool-management"])


async def get_tool_service(session: DBSessionDep) -> ToolManagementService:
    """Dependency to get ToolManagementService instance."""
    return ToolManagementService(session)


@router.get("", response_model=UserToolsResponse)
async def get_available_tools(
    user_email: UserEmailDep,
    service: Annotated[ToolManagementService, Depends(get_tool_service)]
) -> UserToolsResponse:
    """
    Get all available tools with user preferences.
    
    Returns tools grouped by MCP server, with flags indicating:
    - Global availability (MCP server responsive)
    - User's enable/disable preference
    """
    logger.info(f"Fetching available tools for user: {user_email}")
    return await service.get_available_tools(user_email)


@router.post("/enable", response_model=EnableToolResponse)
async def enable_tool(
    request: EnableToolRequest,
    user_email: UserEmailDep,
    service: Annotated[ToolManagementService, Depends(get_tool_service)]
) -> EnableToolResponse:
    """
    Enable or disable a tool for the current user.
    
    Set enabled=true to enable, enabled=false to disable.
    Changes take effect immediately for new conversations.
    """
    logger.info(
        f"User {user_email} {'enabling' if request.enabled else 'disabling'} "
        f"tool: {request.group}.{request.tool_name}"
    )
    return await service.set_tool_enabled(user_email, request)


@router.get("/enabled", response_model=EnabledToolsResponse)
async def get_enabled_tools(
    user_email: UserEmailDep,
    service: Annotated[ToolManagementService, Depends(get_tool_service)]
) -> EnabledToolsResponse:
    """
    Get list of enabled tools for current user.
    
    Returns tool identifiers in format "group.tool_name".
    """
    logger.info(f"Fetching enabled tools for user: {user_email}")
    enabled_tools = await service.get_enabled_tools(user_email)
    return EnabledToolsResponse(
        user_email=user_email,
        enabled_tools=enabled_tools,
        count=len(enabled_tools)
    )
