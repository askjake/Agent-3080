"""Service layer for tool management."""
import logging
from typing import List, Optional, Dict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.tool_management.schemas import (
    ToolInfo,
    ToolGroup,
    UserToolsResponse,
    EnableToolRequest,
    EnableToolResponse
)
from app.tool_management.models import UserEnabledTool

logger = logging.getLogger(__name__)


class ToolManagementService:
    """Service for managing user tool selections."""
    
    def __init__(self, session: AsyncSession):
        self.session = session
    
    async def get_available_tools(self, user_email: str) -> UserToolsResponse:
        """
        Get all available tools with user preferences.
        
        Args:
            user_email: User's email address
            
        Returns:
            UserToolsResponse with all tools grouped by server
        """
        # Get all tools from registry (will implement integration with registry)
        all_tools_metadata = await self._get_all_tools_from_registry()
        
        # Get user preferences
        stmt = select(UserEnabledTool).where(
            UserEnabledTool.user_email == user_email
        )
        result = await self.session.execute(stmt)
        user_prefs = {
            (pref.tool_group, pref.tool_name): pref.enabled
            for pref in result.scalars().all()
        }
        
        # Build response with merged data
        groups = []
        total_tools = 0
        total_enabled = 0
        
        for group_name, group_data in all_tools_metadata.items():
            tool_infos = []
            for tool_data in group_data["tools"]:
                tool_name = tool_data["name"]
                user_enabled = user_prefs.get((group_name, tool_name))
                
                tool_info = ToolInfo(
                    name=tool_name,
                    description=tool_data["description"],
                    group=group_name,
                    user_selectable=group_data["user_selectable"],
                    enabled=group_data["enabled"],
                    user_enabled=user_enabled
                )
                tool_infos.append(tool_info)
                total_tools += 1
                
                # Count as enabled if globally enabled AND user hasn't disabled it
                if tool_info.enabled and (user_enabled is None or user_enabled):
                    total_enabled += 1
            
            if tool_infos:  # Only add groups with tools
                groups.append(ToolGroup(
                    name=group_name,
                    display_name=group_name.replace('_', ' ').replace('-', ' ').title(),
                    user_selectable=group_data["user_selectable"],
                    enabled=group_data["enabled"],
                    tools=tool_infos
                ))
        
        return UserToolsResponse(
            groups=groups,
            total_tools=total_tools,
            total_enabled=total_enabled
        )
    
    async def set_tool_enabled(
        self,
        user_email: str,
        request: EnableToolRequest
    ) -> EnableToolResponse:
        """
        Enable or disable a tool for a user.
        
        Args:
            user_email: User's email address
            request: Enable/disable request
            
        Returns:
            EnableToolResponse with status
        """
        # Check if preference exists
        stmt = select(UserEnabledTool).where(
            UserEnabledTool.user_email == user_email,
            UserEnabledTool.tool_group == request.group,
            UserEnabledTool.tool_name == request.tool_name
        )
        result = await self.session.execute(stmt)
        pref = result.scalar_one_or_none()
        
        if pref:
            pref.enabled = request.enabled
        else:
            pref = UserEnabledTool(
                user_email=user_email,
                tool_group=request.group,
                tool_name=request.tool_name,
                enabled=request.enabled
            )
            self.session.add(pref)
        
        await self.session.commit()
        
        action = "enabled" if request.enabled else "disabled"
        tool_ref = f"{request.group}.{request.tool_name}" if request.tool_name else request.group
        
        return EnableToolResponse(
            status="success",
            message=f"Tool '{tool_ref}' {action} successfully",
            group=request.group,
            tool_name=request.tool_name
        )
    
    async def get_enabled_tools(
        self,
        user_email: str,
        group: Optional[str] = None
    ) -> List[str]:
        """
        Get list of enabled tool names for user.
        
        Args:
            user_email: User's email address
            group: Optional filter by group
            
        Returns:
            List of enabled tool identifiers
        """
        stmt = select(UserEnabledTool).where(
            UserEnabledTool.user_email == user_email,
            UserEnabledTool.enabled == True
        )
        
        if group:
            stmt = stmt.where(UserEnabledTool.tool_group == group)
        
        result = await self.session.execute(stmt)
        prefs = result.scalars().all()
        
        return [
            f"{pref.tool_group}.{pref.tool_name}" if pref.tool_name 
            else pref.tool_group
            for pref in prefs
        ]
    
    async def _get_all_tools_from_registry(self) -> Dict[str, dict]:
        """
        Get all tools from the tool registry.
        
        This is a temporary stub - will be replaced with actual registry integration.
        
        Returns:
            Dict mapping group_name -> metadata dict
        """
        # Import here to avoid circular dependency
        try:
            from app.agent.agents.tools.registry import (
                _ASYNC_TOOL_CACHE,
                _TOOL_FACTORIES,
                _ASYNC_TOOL_FACTORIES
            )
            from app.config import get_settings
            
            settings = get_settings()
            all_tools = {}
            
            # MCP tools from cache
            for name, tools in _ASYNC_TOOL_CACHE.items():
                # Determine user_selectable from mcp_config.yaml
                user_selectable = name in ["jira_mcp", "confluence_mcp", "netra_mcp", "stbhealth", "netdetective"]
                
                all_tools[name] = {
                    "tools": [
                        {
                            "name": tool.name,
                            "description": tool.description or "No description available"
                        }
                        for tool in tools
                    ],
                    "enabled": len(tools) > 0,  # Enabled if tools loaded successfully
                    "user_selectable": user_selectable,
                    "error": None
                }
            
            # Non-MCP internal tools
            for name, factory in _TOOL_FACTORIES.items():
                if name not in all_tools:  # Don't override MCP entries
                    try:
                        tools = factory()
                        all_tools[name] = {
                            "tools": [
                                {
                                    "name": tool.name,
                                    "description": tool.description or "No description available"
                                }
                                for tool in tools
                            ],
                            "enabled": True,
                            "user_selectable": False,  # Internal tools not user-selectable
                            "error": None
                        }
                    except Exception as e:
                        logger.error(f"Failed to load internal tools '{name}': {e}")
            
            return all_tools
            
        except Exception as e:
            logger.error(f"Failed to get tools from registry: {e}")
            return {}
