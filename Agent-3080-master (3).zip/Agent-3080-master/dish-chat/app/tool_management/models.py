"""Database models for tool management."""
from datetime import datetime
from sqlalchemy import String, Boolean, DateTime, Index
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class UserEnabledTool(Base):
    """User tool preference table - tracks which tools each user has enabled."""
    
    __tablename__ = "user_enabled_tools"
    
    id: Mapped[int] = mapped_column(primary_key=True)
    user_email: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    tool_group: Mapped[str] = mapped_column(String(100), nullable=False)  # MCP server name
    tool_name: Mapped[str] = mapped_column(String(100), nullable=True)  # Specific tool (NULL = all)
    enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        Index('idx_user_tools', 'user_email'),
        Index('idx_user_tool_lookup', 'user_email', 'tool_group', 'tool_name', unique=True),
    )
    
    def __repr__(self) -> str:
        return f"<UserEnabledTool(user={self.user_email}, tool={self.tool_group}.{self.tool_name}, enabled={self.enabled})>"
