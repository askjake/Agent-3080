"""Add memory enhancement tables

Revision ID: 20260429_memory_enhancement_phase1
Revises: <PREVIOUS_REVISION>
Create Date: 2026-04-29 13:25:00

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20260429_mem_enhance'
down_revision = "4a599f38a3c4"  # Will be updated to latest revision
branch_labels = None
depends_on = None


def upgrade() -> None:
    """
    Create memory enhancement tables.
    """
    # Enable pgvector extension
    op.execute('CREATE EXTENSION IF NOT EXISTS vector')
    
    # 1. Conversation Summaries
    op.create_table(
        'conversation_summaries',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('chat_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('summary', sa.Text(), nullable=False),
        sa.Column('embedding', postgresql.ARRAY(sa.Float()), nullable=True),  # Will be converted to vector
        sa.Column('message_count', sa.Integer(), server_default='0', nullable=False),
        sa.Column('created_at', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['chat_id'], ['chat.chat_id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Add indexes
    op.create_index('idx_conversation_summaries_chat_id', 'conversation_summaries', ['chat_id'])
    op.create_index('idx_conversation_summaries_created_at', 'conversation_summaries', ['created_at'])
    
    # Convert embedding column to vector type and create HNSW index
    op.execute('ALTER TABLE conversation_summaries ALTER COLUMN embedding TYPE vector(384) USING embedding::vector(384)')
    op.execute('CREATE INDEX idx_conversation_summaries_embedding ON conversation_summaries USING hnsw (embedding vector_cosine_ops)')
    
    # 2. Tool Execution Memory (base table)
    op.create_table(
        'tool_execution_memory',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('chat_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('tool_name', sa.String(100), nullable=False),
        sa.Column('tool_category', sa.String(50), nullable=False),
        sa.Column('execution_timestamp', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('execution_data', postgresql.JSONB(), nullable=False),
        sa.Column('result_summary', sa.Text(), nullable=True),
        sa.Column('embedding', postgresql.ARRAY(sa.Float()), nullable=True),
        sa.Column('scope', sa.String(20), server_default='ephemeral', nullable=False),
        sa.Column('utility_score', sa.Float(), server_default='0.0', nullable=False),
        sa.Column('retrieval_count', sa.Integer(), server_default='0', nullable=False),
        sa.Column('last_retrieved', sa.DateTime(), nullable=True),
        sa.Column('confidence_score', sa.Float(), server_default='1.0', nullable=False),
        sa.Column('deprecated', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('deprecated_reason', sa.String(200), nullable=True),
        sa.Column('deprecated_at', sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(['chat_id'], ['chat.chat_id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Add indexes
    op.create_index('idx_tool_execution_user_id', 'tool_execution_memory', ['user_id'])
    op.create_index('idx_tool_execution_chat_id', 'tool_execution_memory', ['chat_id'])
    op.create_index('idx_tool_execution_tool_category', 'tool_execution_memory', ['tool_category'])
    op.create_index('idx_tool_execution_scope', 'tool_execution_memory', ['scope'])
    op.create_index('idx_tool_execution_deprecated', 'tool_execution_memory', ['deprecated'])
    op.create_index('idx_tool_execution_timestamp', 'tool_execution_memory', ['execution_timestamp'])
    
    # Convert embedding column to vector type and create HNSW index
    op.execute('ALTER TABLE tool_execution_memory ALTER COLUMN embedding TYPE vector(384) USING embedding::vector(384)')
    op.execute('CREATE INDEX idx_tool_execution_memory_embedding ON tool_execution_memory USING hnsw (embedding vector_cosine_ops)')
    
    # 3. Netra Execution Memory (specialized)
    op.create_table(
        'netra_execution_memory',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('memory_id', sa.Integer(), nullable=False),
        sa.Column('receiver_id', sa.String(12), nullable=False),
        sa.Column('analysis_type', sa.String(50), nullable=True),
        sa.Column('error_types_found', postgresql.JSONB(), nullable=True),
        sa.Column('health_score', sa.Float(), nullable=True),
        sa.Column('recommendations', postgresql.JSONB(), nullable=True),
        sa.ForeignKeyConstraint(['memory_id'], ['tool_execution_memory.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    
    op.create_index('idx_netra_memory_receiver_id', 'netra_execution_memory', ['receiver_id'])
    op.create_index('idx_netra_memory_memory_id', 'netra_execution_memory', ['memory_id'])
    
    # 4. Tool Insights (global patterns)
    op.create_table(
        'tool_insights',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('tool_category', sa.String(50), nullable=False),
        sa.Column('pattern_description', sa.Text(), nullable=False),
        sa.Column('pattern_data', postgresql.JSONB(), nullable=True),
        sa.Column('confidence_score', sa.Float(), server_default='0.0', nullable=False),
        sa.Column('occurrence_count', sa.Integer(), server_default='1', nullable=False),
        sa.Column('first_seen', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('last_seen', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('created_by', sa.String(50), server_default='pattern_aggregator', nullable=False),
        sa.Column('deprecated', sa.Boolean(), server_default='false', nullable=False),
        sa.PrimaryKeyConstraint('id')
    )
    
    op.create_index('idx_tool_insights_tool_category', 'tool_insights', ['tool_category'])
    op.create_index('idx_tool_insights_confidence', 'tool_insights', ['confidence_score'])
    op.create_index('idx_tool_insights_deprecated', 'tool_insights', ['deprecated'])
    
    # 5. Memory Corrections
    op.create_table(
        'memory_corrections',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('memory_id', sa.Integer(), nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('correction_type', sa.String(20), nullable=False),
        sa.Column('correction_reason', sa.Text(), nullable=True),
        sa.Column('temporal_constraint', sa.String(200), nullable=True),
        sa.Column('vote_weight', sa.Float(), server_default='1.0', nullable=False),
        sa.Column('vote_count', sa.Integer(), server_default='1', nullable=False),
        sa.Column('auto_deprecated', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('requires_review', sa.Boolean(), server_default='false', nullable=False),
        sa.Column('first_correction_timestamp', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.Column('last_correction_timestamp', sa.DateTime(), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['memory_id'], ['tool_execution_memory.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    
    op.create_index('idx_memory_corrections_memory_id', 'memory_corrections', ['memory_id'])
    op.create_index('idx_memory_corrections_user_id', 'memory_corrections', ['user_id'])
    op.create_index('idx_memory_corrections_auto_deprecated', 'memory_corrections', ['auto_deprecated'])
    
    # 6. User Reputation
    op.create_table(
        'user_reputation',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.Integer(), nullable=False),
        sa.Column('tool_category', sa.String(50), nullable=False),
        sa.Column('reputation_score', sa.Float(), server_default='0.5', nullable=False),
        sa.Column('total_corrections', sa.Integer(), server_default='0', nullable=False),
        sa.Column('validated_corrections', sa.Integer(), server_default='0', nullable=False),
        sa.Column('last_correction_at', sa.DateTime(), nullable=True),
        sa.Column('last_validated_at', sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    
    op.create_index('idx_user_reputation_user_id', 'user_reputation', ['user_id'])
    op.create_index('idx_user_reputation_tool_category', 'user_reputation', ['tool_category'])
    op.create_index('idx_user_reputation_score', 'user_reputation', ['reputation_score'])
    
    # Create unique constraint on (user_id, tool_category)
    op.create_unique_constraint('uq_user_reputation_user_tool', 'user_reputation', ['user_id', 'tool_category'])


def downgrade() -> None:
    """
    Drop memory enhancement tables.
    """
    op.drop_table('user_reputation')
    op.drop_table('memory_corrections')
    op.drop_table('tool_insights')
    op.drop_table('netra_execution_memory')
    op.drop_table('tool_execution_memory')
    op.drop_table('conversation_summaries')
    
    # Note: We don't drop the vector extension as other systems might use it
    # op.execute('DROP EXTENSION IF EXISTS vector')
