"""Add web_searches table for search analytics

Revision ID: 20260326_add_web_searches
Revises: 20260216_fix_usage_tracking_timestamp_default
Create Date: 2026-03-26 11:15:00

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "20260326_add_web_searches"
down_revision: Union[str, None] = "20260216_timestamp_fix"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create web_searches table for tracking web search analytics."""
    
    op.create_table(
        "web_searches",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True, nullable=False),
        sa.Column("chat_id", sa.String(), nullable=True, comment="Associated chat session ID"),
        sa.Column("query", sa.Text(), nullable=False, comment="Search query text"),
        sa.Column("results_json", postgresql.JSONB, nullable=True, comment="Search results and metadata"),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    
    # Indexes for common query patterns
    op.create_index(
        "idx_web_searches_chat_id",
        "web_searches",
        ["chat_id"],
        unique=False,
    )
    
    op.create_index(
        "idx_web_searches_created_at",
        "web_searches",
        ["created_at"],
        unique=False,
    )
    
    # Full-text search index on query (PostgreSQL specific)
    op.execute(
        """
        CREATE INDEX idx_web_searches_query_fulltext 
        ON web_searches USING gin(to_tsvector('english', query))
        """
    )


def downgrade() -> None:
    """Drop web_searches table."""
    op.drop_index("idx_web_searches_query_fulltext", table_name="web_searches")
    op.drop_index("idx_web_searches_created_at", table_name="web_searches")
    op.drop_index("idx_web_searches_chat_id", table_name="web_searches")
    op.drop_table("web_searches")
