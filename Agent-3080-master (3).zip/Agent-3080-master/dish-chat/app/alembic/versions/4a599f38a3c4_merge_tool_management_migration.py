"""merge tool_management migration

Revision ID: 4a599f38a3c4
Revises: merge_heads_001, 20260421_hotplug_tools, 9197c9b549a2, aa1b2c3d4e5f
Create Date: 2026-04-21 14:27:40.512322

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '4a599f38a3c4'
down_revision: Union[str, None] = ('merge_heads_001', '20260421_hotplug_tools', '9197c9b549a2', 'aa1b2c3d4e5f')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
