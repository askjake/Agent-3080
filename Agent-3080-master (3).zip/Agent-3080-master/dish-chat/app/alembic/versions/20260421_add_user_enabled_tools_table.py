"""add user_enabled_tools table for hot-plug tool management

Revision ID: 20260421_hotplug_tools
Revises: 20260326_add_web_searches_table
Create Date: 2026-04-21 14:30:00.000000

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '20260421_hotplug_tools'
down_revision = '20260326_add_web_searches'
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create user_enabled_tools table for hot-plug tool management."""
    op.create_table(
        'user_enabled_tools',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('user_email', sa.String(length=255), nullable=False),
        sa.Column('tool_group', sa.String(length=100), nullable=False),
        sa.Column('tool_name', sa.String(length=100), nullable=True),
        sa.Column('enabled', sa.Boolean(), nullable=False, server_default='true'),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.Column('updated_at', sa.DateTime(), nullable=False, server_default=sa.text('now()')),
        sa.PrimaryKeyConstraint('id')
    )
    
    # Create indexes
    op.create_index('idx_user_tools', 'user_enabled_tools', ['user_email'], unique=False)
    op.create_index(
        'idx_user_tool_lookup',
        'user_enabled_tools',
        ['user_email', 'tool_group', 'tool_name'],
        unique=True
    )


def downgrade() -> None:
    """Drop user_enabled_tools table."""
    op.drop_index('idx_user_tool_lookup', table_name='user_enabled_tools')
    op.drop_index('idx_user_tools', table_name='user_enabled_tools')
    op.drop_table('user_enabled_tools')
