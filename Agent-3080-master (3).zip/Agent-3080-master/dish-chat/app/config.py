from typing import Literal, Optional, ClassVar
from functools import lru_cache, cached_property
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import ConfigDict
from pydantic import computed_field, Field


@lru_cache
def get_settings():
    return Settings()


class Settings(BaseSettings):
    NAME: str = "Dish-Chat"
    VERSION: str = "2.1.0"
    AGENT_THOUGHT_CAPTURE_ENABLED: bool = Field(default=False)
    AGENT_VIZ_SERVER_URL: str = Field(default="http://localhost:8000/rest/api/v1/viz/event")
    API_PREFIX: str = "/rest/api/v1"

    # Runtime settings
    DEBUG: bool = False
    LOCAL: bool = True
    
    # Authentication Settings
    AUTH_DISABLED: bool = False  # Set to True to disable auth requirement (dev/testing only)
    DEFAULT_USER_EMAIL: str = "test.user@dish.com"  # Default email when auth is disabled
    ECHO_SQL: bool = False
    FASTAPI_HOST: str = "0.0.0.0"
    FASTAPI_PORT: int = 8000
    CLEANUP_TIMEOUT: int = 600
    
    # Idle chat checker settings
    IDLE_CHAT_CHECKER_ENABLED: bool = True
    IDLE_CHAT_CHECK_INTERVAL_MINUTES: int = 10  # How often to check for idle chats
    IDLE_CHAT_THRESHOLD_MINUTES: int = 30  # Minutes of inactivity before triggering journal
    IDLE_CHAT_MIN_MESSAGES: int = 5  # Minimum messages required for journal generation
    SPOOLED_MAX_SIZE: int = 2 * 1024 * 1024
    # Default key is for testing only. Prod key is passed in via env var
    MASTER_KEY: str = "SoWTrLlo3xu1ExZIvSNQMpldDmUHc5cxbmrxlPN2RvI="

    # DB
    POSTGRES_HOST: str = "127.0.0.1"
    POSTGRES_PORT: int = 5434
    POSTGRES_DB: str = "dishchat"
    POSTGRES_USER: str = "dev_user"
    POSTGRES_PWD: str = "dev123"

    @computed_field
    @cached_property
    def POSTGRES_URL(self) -> str:
        return f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PWD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

    @computed_field
    @cached_property
    def POSTGRES_SQLALCHEMY_URL(self) -> str:
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PWD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"

    # LLM Models - P for Power and E for Efficient
    PLLM_PROVIDER: Literal["aws-bedrock", "openai", "anthropic"] = "aws-bedrock"
    PLLM_API_BASE: Optional[str] = None
    PLLM_MODEL: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
    PLLM_CTX_LEN: int = 200_000
    ELLM_PROVIDER: Optional[Literal["aws-bedrock", "openai", "anthropic"]] = (
        "aws-bedrock"
    )
    ELLM_API_BASE: Optional[str] = None
    ELLM_MODEL: Optional[str] = "us.anthropic.claude-3-5-haiku-20241022-v1:0"
    ELLM_CTX_LEN: Optional[int] = 200_000
    LLM_TOKENIZER: Optional[str] = None  # HuggingFace Model ID or OpenAI
    DEFAULT_TEMP: float = 0.6
    DEFAULT_REASONING: bool = False
    REASONING_BUDGET: int = 6000

    # Embeddings
    EMBED_PROVIDER: Literal["aws-bedrock", "openai"] = "aws-bedrock"
    EMBED_API_BASE: Optional[str] = None
    EMBED_MODEL: str = "cohere.embed-multilingual-v3"
    EMBED_TOKENIZER: str = "Cohere/Cohere-embed-multilingual-v3.0"
    EMBED_CHUNK_SIZE: int = 300
    EMBED_OVERLAP: int = 0
    EMBED_BATCH_SIZE: int = 96  # Max supported by cohere model
    SUMMARY_LEN: int = 300

    # AWS Settings:
    AWS_REGION: Optional[str] = "us-west-2"
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    AWS_SESSION_TOKEN: Optional[str] = None
    AWS_FILESTORE_BUCKET: str = "dish-chat-attachments"
    
    # Local Storage Configuration (alternative to S3)
    USE_LOCAL_STORAGE_ONLY: str = "false"  # Set to "true" to use local storage instead of S3
    LOCAL_UPLOADS_DIR: str = "/tmp/dish-chat-uploads"  # Base directory for local file storage
    
    # ── AWS Bedrock Application Inference Profile ARNs ──────────────────────
    # These are the authoritative inference-profile ARNs for every model tier.
    # Defaults are set here so the app works out-of-the-box; override via .env
    # or environment variables when deploying to a different account/region.
    #   e.g.  BEDROCK_SONNET_PROFILE_ARN=arn:aws:bedrock:...
    BEDROCK_SONNET_PROFILE_ARN: Optional[str] = (
        "arn:aws:bedrock:us-west-2:233532778289:application-inference-profile/c6y599kzy1u2"
    )
    BEDROCK_HAIKU_PROFILE_ARN: Optional[str] = (
        "arn:aws:bedrock:us-west-2:233532778289:application-inference-profile/wpnvchycfust"
    )
    BEDROCK_OPUS_PROFILE_ARN: Optional[str] = (
        "arn:aws:bedrock:us-west-2:233532778289:application-inference-profile/zkim7rxbcgv0"
    )
    BEDROCK_EMBED_PROFILE_ARN: Optional[str] = (
        "arn:aws:bedrock:us-west-2:233532778289:application-inference-profile/4xgakngy389z"
    )

    # Model-name → profile key mapping.
    # Keys are lowercase substrings matched against the model identifier.
    # Values must correspond to one of the four BEDROCK_*_PROFILE_ARN fields above.
    # Add new entries here when new model variants are introduced; no code changes needed.
    BEDROCK_MODEL_PROFILE_MAP: dict = {
        # ── Sonnet ────────────────────────────────────────────────────────────
        "us.anthropic.claude-sonnet-4-5-20250929-v1:0": "sonnet",
        "anthropic.claude-sonnet-4":                    "sonnet",
        "claude-sonnet-4":                              "sonnet",
        "claude-sonnet-3.5":                            "sonnet",
        "us.anthropic.claude-3-5-sonnet":               "sonnet",
        # ── Haiku ─────────────────────────────────────────────────────────────
        "us.anthropic.claude-3-5-haiku-20241022-v1:0":  "haiku",
        "anthropic.claude-3-5-haiku":                   "haiku",
        "claude-haiku":                                 "haiku",
        "claude-3-5-haiku":                             "haiku",
        # ── Opus ──────────────────────────────────────────────────────────────
        "anthropic.claude-opus":                        "opus",
        "claude-opus":                                  "opus",
        "claude-3-opus":                                "opus",
    }
    
    # Coverity Assist Integration (if using bearer token for external LLM calls)
    COVERITY_ASSIST_URL: Optional[str] = None
    COVERITY_ASSIST_TOKEN: Optional[str] = None
    
    # Sentry Integration (Added 2026-03-02)
    SENTRY_TOKEN: str = Field(default="", description="Sentry auth token")
    SENTRY_API_KEY: str = Field(default="", description="Sentry API key")
    
    # AWS Bedrock Configuration
    BEDROCK_READ_TIMEOUT: int = 300  # 5 minutes for long streaming responses
    BEDROCK_CONNECT_TIMEOUT: int = 10
    BEDROCK_MAX_RETRIES: int = 3

    # Chat Settings:
    MAX_CHAT_COUNT: int = 9999
    MAX_GROUPS_WITH_CHATS_COUNT: int = 20
    MAX_TITLE_LEN: int = 40
    MAX_TITLE_RETRY: int = 5

    # Message Settings:
    MAX_VERSION_COUNT: int = 10
    MAX_IN_CTX_DOC_LEN: int = 4000
    MAX_OUTPUT_COUNT: int = 12_000

    # Enhanced Attachment Settings with Log File Support
    SUPPORTED_DOC_TYPES: list[str] = [
        "application/pdf",
        "text/plain",
    # Markdown files
    "text/markdown",
    "text/x-markdown",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        # Log file MIME types
        "text/x-log",
        "application/x-log",
        "application/log",
        # Generic octet-stream for numbered/unknown extensions
        "application/octet-stream",
    ]
    
    # Log file extensions that should be treated as text/logs
    LOG_FILE_EXTENSIONS: list[str] = [
        ".log",
        ".txt",
        ".001", ".002", ".003", ".004", ".005",
        ".006", ".007", ".008", ".009", ".010",
        # Add more numbered extensions as needed
        ".trace",
        ".dump",
        ".out",
        ".err",
        ".debug",
        ".info",
        ".warn",
        ".error",
        ".syslog",
        ".dmesg",
        ".messages",
    ]
    
    # Enable automatic log analysis
    AUTO_ANALYZE_LOGS: bool = True
    LOG_ANALYZER_TOOL_NAME: str = "logassist_embed_content"
    
    SUPPORTED_IMAGE_TYPES: list[str] = [
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
    ]
    MAX_IMAGE_RES: int = 1092 * 1092

    # Vault Settings:
    VAULT_SESSION_DURATION_SEC: int = 3 * 3600
    ARGON2_TIME: int = 3
    ARGON2_MEM: int = 2**16
    ARGON2_PRL: int = 1

    # Context Manager
    MAX_CONTEXT: int = 8_192  # Max length of core memory + conversation memory
    MAX_CONV_CACHE: float = 0.6  # Max proportion of conversation cache
    SUMMARIZE_WORD_LIMIT: int = 150
    CACHE_EVICT_PROP: float = 0.5  # Amount of conversation cache to evict each time

    # Agent Settings:
    MAX_CACHEPOINT_CNT: int = 4
    # LangGraph recursion limit (for agent tool loops)
    LANGGRAPH_RECURSION_LIMIT: int = 200  # Increased to handle complex agent workflows
    MAX_TOOL_CALLS_PER_TURN: int = 50  # Maximum consecutive tool calls before forcing response
    MAX_CONSECUTIVE_TOOL_ERRORS: int = 1555550  # Maximum tool errors before stopping


    # Beta report agent:
    BETAREPORT_MCP_CONFIG: dict = {
        "beta_report": {
            "transport": "streamable_http",
            "url": "https://7quifnvo576d2m5rhbnguwgvfq0qbivs.lambda-url.us-west-2.on.aws/mcp",
            # "url": "http://127.0.0.1:8001/mcp",
            "headers": {"Authorization": "Bearer yxuRJ1BuBuLRyha57xfmQXUcoWOJ7Tlw"},
        }
    }


    # Individual MCP configurations (loaded separately)
    
    # JIRA MCP - Search JIRA issues
    JIRA_MCP_CONFIG: dict = {
        "jira_mcp": {
            "transport": "streamable_http",
            "url": "https://nxfg5xzy3tqfoiowauaycxlbim0lzrmm.lambda-url.us-west-2.on.aws/mcp",
            "headers": {
                "Authorization": "Bearer ZpX_N8E-i4Hdpgz0l6a743QIDskmfAQyyq2VwhiQodw",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        }
    }
    
    # Confluence MCP - Search Confluence documentation
    CONFLUENCE_MCP_CONFIG: dict = {
        "confluence_mcp": {
            "transport": "streamable_http",
            "url": "https://zkuyopzgcra6gsxceqclqbjtma0gfxlj.lambda-url.us-west-2.on.aws/mcp",
            "headers": {
                "Authorization": "Bearer KaeBTF0GHDDzyTmlg02rnLMutolNntiXF0X_O_4dsrg",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        }
    }
    
    # Netra MCP - Netra service integration
    # DISABLED: Conflicts with Net Detective MCP
    # NETRA_MCP_CONFIG: dict = {
        # "netra_mcp": {
            # "transport": "streamable_http",
            # "url": "https://qzjs7rodqibouzgyymup6jt25u0uqxqx.lambda-url.us-west-2.on.aws/mcp",
            # "headers": {
                # "Authorization": "Bearer WSFwNnXynxCBnTqJ4yks9NZaQ0me7OJLGjCZSuIa6nc",
                # "Content-Type": "application/json",
                # "Accept": "application/json, text/event-stream"
            # }
        # }
    # }


    # Net Detective MCP - ML-powered network diagnostics and error analysis
    # Viewership Measurement MCP:
    VIEWERSHIP_MCP_CONFIG: dict = {
        "viewership_measurement": {
            "transport": "streamable_http",
            "url": "https://cy4h556zxlhqyjju5psohdr6ou0scrxj.lambda-url.us-west-2.on.aws/mcp",
            "headers": {
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        }
    }

    # Coverity Assist / log analysis MCP:
    LOG_ASSIST_MCP_CONFIG: dict = {
        "log_assist": {
            "transport": "streamable_http",
            "url": "http://127.0.0.1:5000/mcp",
        }
    }

    # Internal micro-tools MCP (SSO-protected):
    INTERNAL_TOOLS_MCP_CONFIG: dict = {
        "jira_mcp": {
            "transport": "streamable_http",
            "url": "https://nxfg5xzy3tqfoiowauaycxlbim0lzrmm.lambda-url.us-west-2.on.aws/mcp",
            "headers": {
                "Authorization": "Bearer ZpX_N8E-i4Hdpgz0l6a743QIDskmfAQyyq2VwhiQodw",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        },
        "confluence_mcp": {
            "transport": "streamable_http",
            "url": "https://zkuyopzgcra6gsxceqclqbjtma0gfxlj.lambda-url.us-west-2.on.aws/mcp",
            "headers": {
                "Authorization": "Bearer KaeBTF0GHDDzyTmlg02rnLMutolNntiXF0X_O_4dsrg",
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        },
        # DISABLED DUE TO 502 ERROR - netra_mcp
        # "netra_mcp": {
        # "transport": "streamable_http",
        # "url": "https://qzjs7rodqibouzgyymup6jt25u0uqxqx.lambda-url.us-west-2.on.aws/mcp",
        # "headers": {
        # "Content-Type": "application/json",
        # "Accept": "application/json, text/event-stream"
        # }
        # }
    }
    # Net Detective MCP (ML-powered network analysis):
    NETDETECTIVE_MCP_CONFIG: dict = {
        "netdetective": {
            "transport": "streamable_http",
            "url": "http://localhost:8082/mcp",
            "timeout": 30,  # Analysis can take time
            "headers": {
                "Content-Type": "application/json",
                "Accept": "application/json, text/event-stream"
            }
        }
    }


    # External service endpoints
    COVERITY_GATEWAY_URL: str = "http://127.0.0.1:5001"

    # Sentry Integration (for cluster inspection and monitoring)
    SENTRY_AUTH_TOKEN: Optional[str] = None
    SENTRY_ORG: str = "dishtv.technology"
    SENTRY_URL: str = "https://ds-testing-sentry"
    SENTRY_PROJECT: Optional[str] = None  # Set if needed for specific project
    INTERNAL_SEARCH_URL: str = "https://internal-search.yourdomain/api/search"
    # Internal search mode and timeout
    INTERNAL_SEARCH_MODE: str = "multi"
    INTERNAL_SEARCH_TIMEOUT: float = 10.0
    INTERNAL_SEARCH_SOURCES: str = "confluence,gitlab,jira"

    # Confluence integration settings
    CONFLUENCE_BASE_URL: str = "https://dishtech-dishtv.atlassian.net/wiki"
    CONFLUENCE_USER_EMAIL: Optional[str] = None
    CONFLUENCE_API_TOKEN: Optional[str] = None

    # GitLab integration settings
    GITLAB_BASE_URL: str = "https://gitlab.com"
    GITLAB_TOKEN: Optional[str] = None
    GITLAB_SEARCH_SCOPES: str = "projects,blobs"

    # Jira integration settings
    JIRA_BASE_URL: str = "https://dishtech-dishtv.atlassian.net"
    JIRA_USER_EMAIL: Optional[str] = None
    JIRA_API_TOKEN: Optional[str] = None

    # Confluence integration settings
    # GitLab integration settings

    # Jira integration settings

    # Multi-source search settings



    # Optional overrides for specialized models
    AGENT_MODE_MODEL: Optional[str] = None
    AGENT_MODE_MAX_ITERS: int = 5
    SUMMARY_MODEL_ARN: Optional[str] = None
    REVIEW_MODEL_ARN: Optional[str] = None

    # Read from .env - ALLOW EXTRA FIELDS from environment
    model_config = SettingsConfigDict(
        env_file=(".env", ".env.local"),
        extra="allow",  # FIX: Allow extra fields from .env
    )
    __pydantic_config__ = ConfigDict(extra="allow")

    # Enable / disable MCP tool sets (handy for local dev)
    ENABLE_LOG_ASSIST_MCP: bool = False
    ENABLE_INTERNAL_TOOLS_MCP: bool = True   # Sentry cluster access enabled

    # Memory Enhancement
    ENABLE_MEMORY_INTEGRATION: bool = Field(default=False, description="Enable tool execution memory system")

    # CORS / frontend origins
    CORS_ALLOWED_ORIGINS: list[str] = [
        "http://localhost:3000",
        "http://localhost:3001",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://10.79.83.40:3000",
        "http://10.79.83.40:3001",
        "http://10.79.85.47:3000",
        "http://10.79.85.47:3001",
        "http://10.79.85.47:8000",
        "http://10.79.85.47:8001",
        "http://10.79.85.35:3000",
        "http://10.79.85.35:3001",
        "http://dsgpu3090-lambda-vector:3000",
        "http://dsgpu3090-lambda-vector:3001",
        "https://chat-agent.dishtv.technology",
        "http://chat-agent.dishtv.technology"]
