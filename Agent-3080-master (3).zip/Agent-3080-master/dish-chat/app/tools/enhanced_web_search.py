"""
Enhanced Web Search Integration
Combines advanced caching, sanitization, and result processing
"""
import json
import logging
from typing import Optional, Any
from langchain_core.tools import InjectedToolArg
from langchain_core.runnables import RunnableConfig
from langchain.tools import tool
from typing_extensions import Annotated

from app.config import get_settings
from app.analytics.service import save_web_search
from app.agent_mode.thought_interceptor import interceptor
from app.tools.enhanced_query_sanitizer import sanitize_query_enhanced
from app.tools.enhanced_web_search_tool import enhanced_web_search, maintain_cache
import httpx

logger = logging.getLogger(__name__)
settings = get_settings()

COVERITY_GATEWAY_URL = settings.COVERITY_GATEWAY_URL


@tool("public_web_search_enhanced")
async def public_web_search_enhanced(
    query: str,
    max_results: int = 6,
    use_cache: bool = True,
    enhance_diversity: bool = True,
    config: Annotated[RunnableConfig, InjectedToolArg] = None,
) -> str:
    """
    Enhanced privacy-friendly web search with advanced features:
    - Automatic query sanitization and security checks
    - Result caching to improve performance
    - Intelligent deduplication and diversity scoring
    - Relevance filtering and ranking
    - Retry logic and rate limit handling
    - Enhanced markdown formatting
    
    ⚠️ SECURITY WARNING: This tool sends queries to external public services.
    NEVER include proprietary company information, internal system names,
    employee data, or any confidential information in your queries.
    
    Use this tool when you need current information about:
    - News, weather, prices, stock quotes
    - Recent events or developments
    - Current statistics or data
    - Any information that changes frequently
    
    For company-specific information, use confluence_search or jira_search instead.
    
    Args:
        query: Search query string
        max_results: Maximum number of results (default: 6)
        use_cache: Whether to use cached results (default: True)
        enhance_diversity: Promote source diversity (default: True)
        config: Runtime configuration (auto-injected)
    
    Returns:
        JSON string with search results or enhanced markdown format
    """
    interceptor.tool_call("public_web_search_enhanced", 
                         params={"query": query[:100], "max_results": max_results})
    interceptor.thought(f"Enhanced search for: {query[:50]}", "tool")
    
    # Extract chat_id from config
    chat_id = None
    if config and "configurable" in config:
        chat_id = config["configurable"].get("thread_id")
    
    # Enhanced sanitization
    sanitization_result = sanitize_query_enhanced(query)
    
    # Check if query should be blocked
    if sanitization_result.should_block:
        logger.error(
            f"BLOCKED sensitive query in chat {chat_id}: {query[:50]}... "
            f"Reason: {sanitization_result.block_reason}"
        )
        
        error_response = {
            "error": "Query blocked for security reasons",
            "reason": sanitization_result.block_reason,
            "violations": sanitization_result.violations,
            "confidence_scores": sanitization_result.confidence_scores,
            "suggestions": sanitization_result.suggestions,
            "recommendation": "Please rephrase using generic terms, or use internal_search for company info."
        }
        
        interceptor.tool_call("public_web_search_enhanced", 
                            result=f"BLOCKED: {sanitization_result.block_reason}")
        
        return json.dumps(error_response, indent=2)
    
    # Log if query was modified
    if sanitization_result.was_modified:
        logger.warning(
            f"Sanitized query in chat {chat_id}: "
            f"Original: '{query[:50]}...' "
            f"Violations: {sanitization_result.violations} "
            f"Confidence: {sanitization_result.confidence_scores}"
        )
        
        # Optionally notify user of sanitization
        if sanitization_result.suggestions:
            logger.info(f"Sanitization suggestions: {sanitization_result.suggestions}")
    
    # Use sanitized query
    search_query = sanitization_result.sanitized_query
    
    logger.info(f"Enhanced web search: query='{search_query}' chat_id={chat_id}")
    
    try:
        # Use enhanced search function
        result = await enhanced_web_search(
            query=search_query,
            max_results=max_results,
            use_cache=use_cache,
            enhance_diversity=enhance_diversity,
            filter_relevance=True,
            min_relevance_score=0.0
        )
        
        # Log to analytics (use original query for tracking)
        try:
            # Create analytics data
            analytics_data = {
                "response": {
                    "results": [],  # Would need to parse markdown to extract
                    "metadata": {
                        "sanitized": sanitization_result.was_modified,
                        "violations": sanitization_result.violations,
                        "cached": use_cache
                    }
                }
            }
            await save_web_search(chat_id, query, analytics_data)
        except Exception as e:
            logger.warning(f"Failed to log web search analytics: {e}")
        
        # Log success
        interceptor.tool_call("public_web_search_enhanced", 
                            result=f"Found results (cached={use_cache})")
        
        # Add sanitization notice if query was modified
        if sanitization_result.was_modified:
            notice = (
                "\n\n---\n"
                "**🔒 Security Notice:** Your query was automatically sanitized to remove "
                "potentially sensitive information before searching. "
            )
            if sanitization_result.suggestions:
                notice += "\n**Suggestions:**\n" + "\n".join(f"- {s}" for s in sanitization_result.suggestions)
            result = notice + "\n\n" + result
        
        return result
        
    except Exception as e:
        logger.error(f"Enhanced web search failed: {e}", exc_info=True)
        error_response = {
            "error": "Search failed",
            "message": str(e),
            "query": search_query
        }
        return json.dumps(error_response, indent=2)


# Background task for cache maintenance
async def periodic_cache_maintenance():
    """
    Periodic task to maintain search cache
    Should be called by a scheduler (e.g., every hour)
    """
    try:
        await maintain_cache()
        logger.info("Cache maintenance completed")
    except Exception as e:
        logger.error(f"Cache maintenance failed: {e}")
