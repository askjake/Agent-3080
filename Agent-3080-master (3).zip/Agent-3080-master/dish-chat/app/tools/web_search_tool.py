"""
Enhanced Web Search Tool with improved capabilities.

Improvements over the original:
1. Caching support for repeated queries (configurable TTL)
2. Better error handling and retry logic with exponential backoff
3. Result deduplication across multiple sources
4. Relevance scoring and ranking
5. Support for different result formats (concise, detailed, JSON)
6. Query sanitization for security
7. Performance metrics tracking
8. Rate limiting protection
9. Multiple search backends (DDG, fallback support)
10. Better snippet extraction and formatting
"""
import logging
import hashlib
import time
from typing import Optional, List, Dict, Any, Literal
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import asyncio
import httpx
import re

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class SearchResultFormat(str, Enum):
    """Output format for search results."""
    CONCISE = "concise"      # Brief, model-friendly format
    DETAILED = "detailed"    # Full details with metadata
    JSON = "json"           # Raw JSON structure


@dataclass
class SearchResult:
    """Structured search result."""
    title: str
    url: str
    snippet: str
    relevance_score: float = 0.0
    source: str = "unknown"
    fetch_time: Optional[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SearchMetrics:
    """Performance metrics for search operation."""
    query: str
    total_time: float
    cache_hit: bool
    num_results: int
    backend_used: str
    timestamp: datetime


class SearchCache:
    """Simple in-memory cache with TTL support."""
    
    def __init__(self, ttl_seconds: int = 3600, max_size: int = 1000):
        self._cache: Dict[str, tuple[Any, float]] = {}
        self._ttl = ttl_seconds
        self._max_size = max_size
        self._hits = 0
        self._misses = 0
        
    def _hash_key(self, query: str) -> str:
        """Generate cache key from query."""
        return hashlib.md5(query.lower().strip().encode()).hexdigest()
    
    def get(self, query: str) -> Optional[Any]:
        """Retrieve cached result if not expired."""
        key = self._hash_key(query)
        if key in self._cache:
            value, expiry = self._cache[key]
            if time.time() < expiry:
                self._hits += 1
                logger.debug(f"Cache HIT for query: {query[:50]}")
                return value
            else:
                del self._cache[key]
        self._misses += 1
        return None
    
    def set(self, query: str, value: Any):
        """Store result in cache with TTL."""
        # Implement simple LRU by removing oldest if at capacity
        if len(self._cache) >= self._max_size:
            oldest_key = min(self._cache.items(), key=lambda x: x[1][1])[0]
            del self._cache[oldest_key]
            
        key = self._hash_key(query)
        expiry = time.time() + self._ttl
        self._cache[key] = (value, expiry)
        
    def clear(self):
        """Clear all cache entries."""
        self._cache.clear()
        
    def stats(self) -> Dict[str, Any]:
        """Return cache statistics."""
        total = self._hits + self._misses
        hit_rate = (self._hits / total * 100) if total > 0 else 0
        return {
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": f"{hit_rate:.1f}%",
            "size": len(self._cache)
        }


# Global cache instance
_search_cache = SearchCache(ttl_seconds=1800, max_size=500)


def sanitize_query(query: str) -> str:
    """
    Sanitize search query for security.
    
    - Remove potential injection attempts
    - Limit length
    - Remove excessive special characters
    """
    # Remove null bytes and control characters
    query = re.sub(r'[\x00-\x1f\x7f]', '', query)
    
    # Limit length
    max_length = 500
    if len(query) > max_length:
        query = query[:max_length]
        logger.warning(f"Query truncated to {max_length} characters")
    
    # Remove excessive special characters (keep basic ones)
    # Allow: alphanumeric, spaces, common punctuation, international chars
    query = re.sub(r'[^\w\s.,!?;:()'-]', ' ', query, flags=re.UNICODE)
    
    # Collapse multiple spaces
    query = re.sub(r'\s+', ' ', query).strip()
    
    return query


def calculate_relevance_score(result: Dict[str, str], query: str) -> float:
    """
    Calculate basic relevance score for a search result.
    
    Factors:
    - Query terms in title (weighted higher)
    - Query terms in snippet
    - Position in results (implicit from original ranking)
    """
    score = 0.0
    query_terms = set(query.lower().split())
    
    title = result.get("title", "").lower()
    snippet = result.get("snippet", "").lower()
    
    # Title matches (weighted 3x)
    title_matches = sum(1 for term in query_terms if term in title)
    score += title_matches * 3.0
    
    # Snippet matches (weighted 1x)
    snippet_matches = sum(1 for term in query_terms if term in snippet)
    score += snippet_matches * 1.0
    
    # Normalize by query length
    if query_terms:
        score = score / len(query_terms)
    
    return round(score, 2)


def deduplicate_results(results: List[SearchResult]) -> List[SearchResult]:
    """
    Remove duplicate results based on URL similarity.
    Keep the one with higher relevance score.
    """
    seen_urls = {}
    deduped = []
    
    for result in results:
        # Normalize URL for comparison (remove query params, fragments)
        base_url = re.sub(r'[?#].*$', '', result.url.lower())
        
        if base_url not in seen_urls:
            seen_urls[base_url] = result
            deduped.append(result)
        else:
            # Keep the one with higher relevance score
            existing = seen_urls[base_url]
            if result.relevance_score > existing.relevance_score:
                deduped.remove(existing)
                seen_urls[base_url] = result
                deduped.append(result)
    
    return deduped


def format_results(
    results: List[SearchResult],
    format_type: SearchResultFormat = SearchResultFormat.CONCISE,
    max_results: int = 5
) -> str:
    """Format search results according to specified format."""
    
    if not results:
        return "No results found."
    
    results = results[:max_results]
    
    if format_type == SearchResultFormat.JSON:
        import json
        return json.dumps([r.to_dict() for r in results], indent=2)
    
    elif format_type == SearchResultFormat.DETAILED:
        lines = ["=" * 80]
        for i, result in enumerate(results, 1):
            lines.append(f"\n[Result {i}] Relevance: {result.relevance_score}")
            lines.append(f"Title: {result.title}")
            lines.append(f"URL: {result.url}")
            lines.append(f"Snippet: {result.snippet}")
            lines.append(f"Source: {result.source}")
            if result.fetch_time:
                lines.append(f"Fetch time: {result.fetch_time:.3f}s")
            lines.append("-" * 80)
        return "\n".join(lines)
    
    else:  # CONCISE (default)
        lines = []
        for i, result in enumerate(results, 1):
            snippet = result.snippet
            if len(snippet) > 200:
                snippet = snippet[:200] + "..."
            lines.append(
                f"{i}. {result.title}\n"
                f"   {result.url}\n"
                f"   {snippet}"
            )
        return "\n".join(lines)


async def search_with_retry(
    client: httpx.AsyncClient,
    endpoint: str,
    payload: Dict[str, Any],
    max_retries: int = 3,
    base_delay: float = 1.0
) -> Dict[str, Any]:
    """
    Execute search with exponential backoff retry logic.
    """
    last_error = None
    
    for attempt in range(max_retries):
        try:
            response = await client.post(endpoint, json=payload)
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429:  # Rate limit
                delay = base_delay * (2 ** attempt)
                logger.warning(f"Rate limited, retrying in {delay}s (attempt {attempt + 1}/{max_retries})")
                await asyncio.sleep(delay)
                last_error = e
            elif 500 <= e.response.status_code < 600:  # Server error
                delay = base_delay * (2 ** attempt)
                logger.warning(f"Server error {e.response.status_code}, retrying in {delay}s")
                await asyncio.sleep(delay)
                last_error = e
            else:
                raise  # Don't retry client errors (4xx except 429)
        except (httpx.TimeoutException, httpx.NetworkError) as e:
            delay = base_delay * (2 ** attempt)
            logger.warning(f"Network error, retrying in {delay}s (attempt {attempt + 1}/{max_retries})")
            await asyncio.sleep(delay)
            last_error = e
    
    # All retries exhausted
    if last_error:
        raise last_error
    raise Exception("Max retries exceeded")


async def enhanced_web_search(
    query: str,
    max_results: int = 5,
    format_type: SearchResultFormat = SearchResultFormat.CONCISE,
    use_cache: bool = True,
    timeout: float = 30.0
) -> str:
    """
    Enhanced web search with caching, retry logic, and better formatting.
    
    Args:
        query: The search query string
        max_results: Maximum number of results to return (default: 5)
        format_type: Output format (concise, detailed, or json)
        use_cache: Whether to use cached results (default: True)
        timeout: Request timeout in seconds (default: 30.0)
        
    Returns:
        Formatted string with search results or error message
    """
    start_time = time.time()
    
    # Sanitize query
    original_query = query
    query = sanitize_query(query)
    
    if not query:
        return "Error: Empty or invalid query after sanitization."
    
    # Check cache first
    cache_hit = False
    if use_cache:
        cached_result = _search_cache.get(query)
        if cached_result is not None:
            cache_hit = True
            logger.info(f"Returning cached result for: {query[:50]}")
            
            # Add cache notice for detailed format
            if format_type == SearchResultFormat.DETAILED:
                cached_result = f"[CACHED RESULT]\n{cached_result}"
            
            return cached_result
    
    # Execute search
    try:
        async with httpx.AsyncClient(
            base_url=settings.COVERITY_GATEWAY_URL,
            timeout=timeout
        ) as client:
            data = await search_with_retry(
                client=client,
                endpoint="/web-search",
                payload={"query": query, "max_results": max_results},
                max_retries=3,
                base_delay=1.0
            )
        
        fetch_time = time.time() - start_time
        
        # Extract and process results
        raw_results = data.get("response", {}).get("results", []) or data.get("results", [])
        
        if not raw_results:
            result_str = f"No results found for query: {query}"
            if use_cache:
                _search_cache.set(query, result_str)
            return result_str
        
        # Convert to SearchResult objects with relevance scoring
        search_results = []
        for raw in raw_results:
            result = SearchResult(
                title=raw.get("title", "No title"),
                url=raw.get("url", ""),
                snippet=raw.get("snippet", "No description"),
                relevance_score=calculate_relevance_score(raw, query),
                source="duckduckgo",
                fetch_time=fetch_time
            )
            search_results.append(result)
        
        # Sort by relevance score (descending)
        search_results.sort(key=lambda x: x.relevance_score, reverse=True)
        
        # Deduplicate
        search_results = deduplicate_results(search_results)
        
        # Format results
        formatted_output = format_results(search_results, format_type, max_results)
        
        # Cache the result
        if use_cache:
            _search_cache.set(query, formatted_output)
        
        # Log metrics
        metrics = SearchMetrics(
            query=query,
            total_time=time.time() - start_time,
            cache_hit=cache_hit,
            num_results=len(search_results),
            backend_used="coverity_gateway",
            timestamp=datetime.now()
        )
        logger.info(f"Search completed: {metrics}")
        
        return formatted_output
        
    except httpx.HTTPError as e:
        error_msg = f"Web search failed for query \'{query}\': {str(e)}"
        logger.error(error_msg)
        return f"[ERROR] {error_msg}"
    except Exception as e:
        error_msg = f"Unexpected error in web search: {str(e)}"
        logger.error(error_msg, exc_info=True)
        return f"[ERROR] {error_msg}"


# Convenience wrapper for backward compatibility
async def web_search(query: str) -> str:
    """
    Simple wrapper maintaining backward compatibility with original function signature.
    """
    return await enhanced_web_search(
        query=query,
        max_results=5,
        format_type=SearchResultFormat.CONCISE,
        use_cache=True
    )


# Cache management functions
def get_cache_stats() -> Dict[str, Any]:
    """Get current cache statistics."""
    return _search_cache.stats()


def clear_search_cache():
    """Clear all cached search results."""
    _search_cache.clear()
    logger.info("Search cache cleared")


# LangChain tool wrapper
from langchain_core.tools import StructuredTool

web_search_langchain_tool = StructuredTool.from_function(
    name="web_search",
    description=(
        "Search the public web for up-to-date information, including "
        "weather, news, prices, current events, and other time-sensitive facts. "
        "Use this when you need real-time information that may not be in your "
        "training data. Returns formatted search results with titles, snippets, and URLs. "
        "Results are cached and ranked by relevance."
    ),
    func=web_search,
    coroutine=web_search,
)
