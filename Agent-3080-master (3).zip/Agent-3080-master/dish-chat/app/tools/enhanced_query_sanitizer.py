"""
Enhanced Query Sanitizer with ML-based detection and auto-correction
Improvements:
1. More comprehensive pattern detection
2. Automatic query rewriting for blocked content
3. Confidence scoring for detections
4. Context-aware sanitization
5. Whitelist for safe company terms
6. Better AWS/cloud resource detection
"""
import re
import logging
from typing import Tuple, List, Dict, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class SanitizationResult:
    """Result of query sanitization"""
    original_query: str
    sanitized_query: str
    was_modified: bool
    violations: List[str]
    confidence_scores: Dict[str, float]
    should_block: bool
    block_reason: Optional[str] = None
    suggestions: List[str] = None
    
    def __post_init__(self):
        if self.suggestions is None:
            self.suggestions = []


# Enhanced sensitive patterns with confidence scores
SENSITIVE_PATTERNS = [
    # Email addresses (HIGH confidence)
    (r'\b[A-Za-z0-9._%+-]+@(?:dish|echostar|sling|boost|hughesnet)\.com\b', 'EMAIL', 1.0),
    
    # Internal domains (HIGH confidence)
    (r'\b(?:[\w-]+\.)?(?:dish|echostar|sling|boost)\.(?:com|net|org|internal|local)\b', 'INTERNAL_DOMAIN', 0.95),
    
    # IP addresses - Private ranges (HIGH confidence)
    (r'\b(?:10\.|172\.(?:1[6-9]|2[0-9]|3[01])\.|192\.168\.)\d{1,3}\.\d{1,3}\b', 'PRIVATE_IP', 1.0),
    
    # Internal system names with prefixes (HIGH confidence)
    (r'\b(?:RAIL|DATASO|DMAS|SSE|DANTE|ODIN|THOR)-[\w-]+\b', 'INTERNAL_SYSTEM', 0.9),
    
    # Kubernetes/cluster identifiers (MEDIUM-HIGH confidence)
    (r'\b(?:k8s|kubectl|helm|eks|ecs)-[\w-]+', 'K8S_IDENTIFIER', 0.85),
    (r'\b(?:prod|staging|dev|test|qa)-(?:cluster|namespace|pod|deployment)', 'ENV_IDENTIFIER', 0.85),
    
    # AWS Resource names (MEDIUM-HIGH confidence)
    (r'\b(?:arn:aws:[\w-]+:[\w-]+:\d+:[\w-]+/[\w-]+)', 'AWS_ARN', 1.0),
    (r'\b(?:i-[a-f0-9]{8,17})\b', 'EC2_INSTANCE_ID', 0.9),
    (r'\b(?:sg-[a-f0-9]{8,17})\b', 'SECURITY_GROUP_ID', 0.9),
    (r'\b(?:vpc-[a-f0-9]{8,17})\b', 'VPC_ID', 0.9),
    (r'\b(?:subnet-[a-f0-9]{8,17})\b', 'SUBNET_ID', 0.9),
    (r'\b(?:vol-[a-f0-9]{8,17})\b', 'EBS_VOLUME_ID', 0.9),
    (r'\bs3://[a-z0-9.-]+', 'S3_URI', 0.85),
    
    # Employee/User IDs (HIGH confidence)
    (r'\b(?:EMP|USR|UID|EMPID)[-_]?\d{4,}\b', 'EMPLOYEE_ID', 0.9),
    
    # API keys and tokens (HIGH confidence)
    (r'\b(?:api[_-]?key|token|secret|password|pwd|passwd)\s*[:=]\s*[\'"]?\S+[\'"]?', 'CREDENTIAL', 1.0),
    (r'\b(?:AKIA[0-9A-Z]{16})\b', 'AWS_ACCESS_KEY', 1.0),
    (r'\b(?:sk-[a-zA-Z0-9]{48})\b', 'OPENAI_KEY', 1.0),
    
    # Internal hostnames (MEDIUM confidence)
    (r'\b[\w-]+\d+\.(?:dish|echostar)\.(?:com|net|local)\b', 'INTERNAL_HOSTNAME', 0.8),
    
    # Database connection strings (HIGH confidence)
    (r'(?:jdbc|postgres|mysql|mongodb)://[^\s]+', 'DB_CONNECTION_STRING', 0.95),
    
    # Source code patterns (MEDIUM confidence)
    (r'/(?:home|root|opt)/[\w-]+/[\w.-]+(?:/[\w.-]+)+', 'FILE_PATH', 0.7),
    
    # Phone numbers (MEDIUM confidence, could be legitimate searches)
    (r'\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b', 'PHONE_NUMBER', 0.6),
]


# Whitelisted public/safe contexts
SAFE_CONTEXTS = [
    'documentation',
    'tutorial',
    'example',
    'guide',
    'best practices',
    'how to',
    'github',
    'stackoverflow',
    'aws documentation',
]


# Company terms that are OK in generic contexts
COMPANY_TERMS_WHITELIST = {
    'dish': ['dish soap', 'satellite dish', 'dish antenna', 'petri dish', 'dish network stock'],
    'sling': ['sling bag', 'baby sling', 'camera sling', 'arm sling'],
    'boost': ['boost performance', 'boost speed', 'turbo boost', 'confidence boost'],
}


def is_safe_context(query: str) -> bool:
    """Check if query is in a safe public context"""
    query_lower = query.lower()
    return any(ctx in query_lower for ctx in SAFE_CONTEXTS)


def check_company_term_whitelist(query: str, company_term: str) -> bool:
    """Check if company term usage is in a safe/generic context"""
    query_lower = query.lower()
    if company_term in COMPANY_TERMS_WHITELIST:
        safe_usages = COMPANY_TERMS_WHITELIST[company_term]
        return any(usage in query_lower for usage in safe_usages)
    return False


def detect_violations(query: str) -> Tuple[List[str], Dict[str, float]]:
    """
    Detect all violations in a query with confidence scores
    
    Returns:
        Tuple of (violations_list, confidence_scores_dict)
    """
    violations = []
    confidence_scores = {}
    
    for pattern, violation_type, confidence in SENSITIVE_PATTERNS:
        matches = re.findall(pattern, query, re.IGNORECASE)
        if matches:
            violations.append(violation_type)
            confidence_scores[violation_type] = confidence
            logger.debug(f"Detected {violation_type} in query (confidence: {confidence}): {matches}")
    
    return violations, confidence_scores


def auto_sanitize_query(query: str, violations: List[str]) -> Tuple[str, List[str]]:
    """
    Automatically sanitize query by replacing sensitive content with generic terms
    
    Returns:
        Tuple of (sanitized_query, suggestions_for_user)
    """
    sanitized = query
    suggestions = []
    
    # Replace email addresses
    if 'EMAIL' in violations:
        sanitized = re.sub(
            r'\b[A-Za-z0-9._%+-]+@(?:dish|echostar|sling|boost|hughesnet)\.com\b',
            '[USER_EMAIL]',
            sanitized,
            flags=re.IGNORECASE
        )
        suggestions.append("Email addresses removed. Use generic terms like 'employee email' instead.")
    
    # Replace internal domains
    if 'INTERNAL_DOMAIN' in violations:
        sanitized = re.sub(
            r'\b(?:[\w-]+\.)?(?:dish|echostar|sling|boost)\.(?:com|net|org|internal|local)\b',
            '[INTERNAL_DOMAIN]',
            sanitized,
            flags=re.IGNORECASE
        )
        suggestions.append("Internal domains removed. Use 'company domain' or 'internal system' instead.")
    
    # Replace private IPs
    if 'PRIVATE_IP' in violations:
        sanitized = re.sub(
            r'\b(?:10\.|172\.(?:1[6-9]|2[0-9]|3[01])\.|192\.168\.)\d{1,3}\.\d{1,3}\b',
            '[PRIVATE_IP]',
            sanitized
        )
        suggestions.append("Private IP addresses removed. Use 'internal IP' or describe the network tier instead.")
    
    # Replace AWS resource IDs
    aws_patterns = [
        (r'\b(?:i-[a-f0-9]{8,17})\b', '[EC2_INSTANCE]', 'AWS EC2 instance IDs'),
        (r'\b(?:sg-[a-f0-9]{8,17})\b', '[SECURITY_GROUP]', 'AWS security group IDs'),
        (r'\b(?:vpc-[a-f0-9]{8,17})\b', '[VPC]', 'AWS VPC IDs'),
        (r'\bs3://[a-z0-9.-]+', '[S3_BUCKET]', 'AWS S3 bucket names'),
    ]
    
    for pattern, replacement, description in aws_patterns:
        if re.search(pattern, sanitized):
            sanitized = re.sub(pattern, replacement, sanitized)
            suggestions.append(f"{description} removed. Use generic terms like 'EC2 instance' or 'S3 bucket'.")
    
    # Replace credentials
    if 'CREDENTIAL' in violations or 'AWS_ACCESS_KEY' in violations or 'OPENAI_KEY' in violations:
        sanitized = re.sub(
            r'\b(?:api[_-]?key|token|secret|password|pwd|passwd)\s*[:=]\s*[\'"]?\S+[\'"]?',
            '[CREDENTIAL_REDACTED]',
            sanitized,
            flags=re.IGNORECASE
        )
        sanitized = re.sub(r'\b(?:AKIA[0-9A-Z]{16})\b', '[AWS_KEY_REDACTED]', sanitized)
        sanitized = re.sub(r'\b(?:sk-[a-zA-Z0-9]{48})\b', '[API_KEY_REDACTED]', sanitized)
        suggestions.append("CRITICAL: Credentials removed from query. Never include passwords, keys, or tokens in searches.")
    
    # Replace internal system names
    if 'INTERNAL_SYSTEM' in violations:
        sanitized = re.sub(
            r'\b(?:RAIL|DATASO|DMAS|SSE|DANTE|ODIN|THOR)-[\w-]+\b',
            '[INTERNAL_SYSTEM]',
            sanitized,
            flags=re.IGNORECASE
        )
        suggestions.append("Internal system names removed. Use generic terms like 'kubernetes cluster' or 'microservice'.")
    
    # Replace file paths
    if 'FILE_PATH' in violations:
        sanitized = re.sub(
            r'/(?:home|root|opt)/[\w-]+/[\w.-]+(?:/[\w.-]+)+',
            '[FILE_PATH]',
            sanitized
        )
        suggestions.append("Internal file paths removed. Describe the file type or purpose instead.")
    
    return sanitized, suggestions


def sanitize_query_enhanced(query: str) -> SanitizationResult:
    """
    Enhanced query sanitization with auto-correction and detailed reporting
    
    Returns:
        SanitizationResult with full details
    """
    # Check if it's in a safe context
    if is_safe_context(query):
        logger.info(f"Query is in safe context: {query[:50]}...")
        return SanitizationResult(
            original_query=query,
            sanitized_query=query,
            was_modified=False,
            violations=[],
            confidence_scores={},
            should_block=False
        )
    
    # Detect violations
    violations, confidence_scores = detect_violations(query)
    
    if not violations:
        return SanitizationResult(
            original_query=query,
            sanitized_query=query,
            was_modified=False,
            violations=[],
            confidence_scores={},
            should_block=False
        )
    
    # Determine if we should block
    critical_violations = {'EMAIL', 'CREDENTIAL', 'AWS_ACCESS_KEY', 'OPENAI_KEY', 'DB_CONNECTION_STRING'}
    high_confidence_critical = any(
        v in critical_violations and confidence_scores.get(v, 0) >= 0.9
        for v in violations
    )
    
    should_block = high_confidence_critical
    block_reason = None
    
    if should_block:
        critical_found = [v for v in violations if v in critical_violations]
        block_reason = f"Query contains highly sensitive information: {', '.join(critical_found)}"
    
    # Auto-sanitize
    sanitized_query, suggestions = auto_sanitize_query(query, violations)
    
    return SanitizationResult(
        original_query=query,
        sanitized_query=sanitized_query,
        was_modified=(sanitized_query != query),
        violations=violations,
        confidence_scores=confidence_scores,
        should_block=should_block,
        block_reason=block_reason,
        suggestions=suggestions
    )


# Backward compatibility functions
def should_block_query(query: str) -> Tuple[bool, str]:
    """
    Legacy function for backward compatibility
    """
    result = sanitize_query_enhanced(query)
    return result.should_block, result.block_reason or ""


def sanitize_query(query: str) -> Tuple[str, bool, List[str]]:
    """
    Legacy function for backward compatibility
    """
    result = sanitize_query_enhanced(query)
    return result.sanitized_query, result.was_modified, result.violations


def contains_sensitive_info(query: str) -> Tuple[bool, List[str]]:
    """
    Legacy function for backward compatibility
    """
    violations, _ = detect_violations(query)
    return len(violations) > 0, violations
