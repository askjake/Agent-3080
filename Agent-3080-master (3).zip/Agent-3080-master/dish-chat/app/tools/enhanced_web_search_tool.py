"""
Enhanced Web Search Tool with Advanced Features v2.0
Improvements:
1. Result caching with TTL and size limits
2. Better error handling and retry logic with exponential backoff
3. Result deduplication with fuzzy matching
4. Source diversity scoring with domain reputation
5. Relevance filtering with TF-IDF-like scoring
6. Rate limiting protection with token bucket algorithm
7. Enhanced formatting with markdown and metadata
8. Automatic query refinement suggestions
9. Observability with structured logging and metrics
10. Memory-efficient cache with LRU eviction
11. Result validation and sanitization
12. Configurable timeouts and circuit breaker
"""
import asyncio
import logging
import httpx
import hashlib
import json
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timedelta
from collections import defaultdict, OrderedDict
from dataclasses import dataclass, field
from urllib.parse import urlparse
import time

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


@dataclass
class SearchMetrics:
    """Track search performance metrics"""
    total_searches: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    failed_searches: int = 0
    avg_response_time_ms: float = 0.0
    total_response_time_ms: float = 0.0
    
    def record_hit(self):
        self.cache_hits += 1
        
    def record_miss(self):
        self.cache_misses += 1
        
    def record_search(self, response_time_ms: float):
        self.total_searches += 1
        self.total_response_time_ms += response_time_ms
        self.avg_response_time_ms = self.total_response_time_ms / self.total_searches
        
    def record_failure(self):
        self.failed_searches += 1
        
    @property
    def cache_hit_rate(self) -> float:
        total = self.cache_hits + self.cache_misses
        return (self.cache_hits / total * 100) if total > 0 else 0.0
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            "total_searches": self.total_searches,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "cache_hit_rate_pct": round(self.cache_hit_rate, 2),
            "failed_searches": self.failed_searches,
            "avg_response_time_ms": round(self.avg_response_time_ms, 2)
        }


@dataclass
class CacheEntry:
    """Individual cache entry with metadata"""
    result: str
    timestamp: datetime
    access_count: int = 0
    last_accessed: datetime = field(default_factory=datetime.now)
    query_hash: str = ""
    size_bytes: int = 0


class LRUCache:
    """
    LRU Cache with TTL and size limits
    Thread-safe for async operations
    """
    def __init__(
        self, 
        ttl_minutes: int = 60,
        max_entries: int = 1000,
        max_size_mb: int = 50
    ):
        self.cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self.ttl = timedelta(minutes=ttl_minutes)
        self.max_entries = max_entries
        self.max_size_bytes = max_size_mb * 1024 * 1024
        self._lock = asyncio.Lock()
        self._current_size_bytes = 0
    
    def _get_key(self, query: str, max_results: int) -> str:
        """Generate cache key from query and parameters"""
        key_str = f"{query.lower().strip()}:{max_results}"
        return hashlib.sha256(key_str.encode()).hexdigest()[:32]
    
    def _evict_lru(self):
        """Evict least recently used entry"""
        if not self.cache:
            return
        
        # Find LRU entry
        lru_key = None
        lru_time = datetime.now()
        
        for key, entry in self.cache.items():
            if entry.last_accessed < lru_time:
                lru_time = entry.last_accessed
                lru_key = key
        
        if lru_key:
            removed = self.cache.pop(lru_key)
            self._current_size_bytes -= removed.size_bytes
            logger.debug(f"Evicted LRU cache entry: {lru_key}")
    
    def _enforce_limits(self):
        """Enforce size and count limits"""
        # Enforce entry count limit
        while len(self.cache) > self.max_entries:
            self._evict_lru()
        
        # Enforce size limit
        while self._current_size_bytes > self.max_size_bytes:
            self._evict_lru()
    
    async def get(self, query: str, max_results: int) -> Optional[str]:
        """Retrieve cached result if available and not expired"""
        async with self._lock:
            key = self._get_key(query, max_results)
            
            if key in self.cache:
                entry = self.cache[key]
                
                # Check if expired
                if datetime.now() - entry.timestamp < self.ttl:
                    # Update access metadata
                    entry.access_count += 1
                    entry.last_accessed = datetime.now()
                    
                    # Move to end (most recently used)
                    self.cache.move_to_end(key)
                    
                    logger.info(
                        f"Cache HIT for query: {query[:50]}... "
                        f"(accessed {entry.access_count} times, "
                        f"age: {(datetime.now() - entry.timestamp).seconds}s)"
                    )
                    return entry.result
                else:
                    # Expired, remove it
                    removed = self.cache.pop(key)
                    self._current_size_bytes -= removed.size_bytes
                    logger.debug(f"Removed expired cache entry: {key}")
            
            return None
    
    async def set(self, query: str, max_results: int, result: str):
        """Store result in cache"""
        async with self._lock:
            key = self._get_key(query, max_results)
            size_bytes = len(result.encode('utf-8'))
            
            # Remove old entry if exists
            if key in self.cache:
                old_entry = self.cache.pop(key)
                self._current_size_bytes -= old_entry.size_bytes
            
            entry = CacheEntry(
                result=result,
                timestamp=datetime.now(),
                query_hash=key,
                size_bytes=size_bytes
            )
            
            self.cache[key] = entry
            self._current_size_bytes += size_bytes
            
            # Enforce limits
            self._enforce_limits()
            
            logger.debug(
                f"Cached result for query: {query[:50]}... "
                f"(size: {size_bytes} bytes, total cache: {len(self.cache)} entries, "
                f"{self._current_size_bytes / 1024:.1f} KB)"
            )
    
    async def clear_expired(self):
        """Remove expired entries"""
        async with self._lock:
            now = datetime.now()
            expired_keys = [
                k for k, v in self.cache.items() 
                if now - v.timestamp >= self.ttl
            ]
            
            for key in expired_keys:
                removed = self.cache.pop(key)
                self._current_size_bytes -= removed.size_bytes
            
            if expired_keys:
                logger.info(f"Cleared {len(expired_keys)} expired cache entries")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        return {
            "entries": len(self.cache),
            "size_kb": round(self._current_size_bytes / 1024, 2),
            "size_mb": round(self._current_size_bytes / (1024 * 1024), 2),
            "max_entries": self.max_entries,
            "max_size_mb": self.max_size_bytes / (1024 * 1024)
        }


class RateLimiter:
    """
    Token bucket rate limiter for API calls
    """
    def __init__(self, tokens_per_minute: int = 60):
        self.tokens_per_minute = tokens_per_minute
        self.tokens = float(tokens_per_minute)
        self.last_update = time.monotonic()
        self._lock = asyncio.Lock()
    
    async def acquire(self, tokens: int = 1) -> bool:
        """
        Try to acquire tokens, return True if successful
        """
        async with self._lock:
            now = time.monotonic()
            elapsed = now - self.last_update
            
            # Refill tokens based on elapsed time
            self.tokens = min(
                self.tokens_per_minute,
                self.tokens + (elapsed * self.tokens_per_minute / 60.0)
            )
            self.last_update = now
            
            if self.tokens >= tokens:
                self.tokens -= tokens
                return True
            
            return False
    
    async def wait_for_token(self, tokens: int = 1, timeout: float = 30.0):
        """
        Wait until tokens are available, with timeout
        """
        start = time.monotonic()
        
        while True:
            if await self.acquire(tokens):
                return True
            
            if time.monotonic() - start > timeout:
                raise TimeoutError("Rate limiter timeout waiting for token")
            
            await asyncio.sleep(0.1)


# Global instances
_search_cache = LRUCache(ttl_minutes=60, max_entries=1000, max_size_mb=50)
_rate_limiter = RateLimiter(tokens_per_minute=60)
_metrics = SearchMetrics()


def calculate_text_similarity(text1: str, text2: str) -> float:
    """
    Calculate simple similarity score between two texts using Jaccard similarity
    """
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    
    if not words1 or not words2:
        return 0.0
    
    intersection = words1.intersection(words2)
    union = words1.union(words2)
    
    return len(intersection) / len(union) if union else 0.0


def deduplicate_results(results: List[Dict[str, Any]], similarity_threshold: float = 0.7) -> List[Dict[str, Any]]:
    """
    Remove duplicate or very similar results using fuzzy matching
    """
    seen_urls = set()
    unique_results = []
    
    for result in results:
        url = result.get('url', '').lower().strip()
        title = result.get('title', '').lower().strip()
        
        # Normalize URL (remove query params and trailing slashes for dedup)
        url_base = url.split('?')[0].split('#')[0].rstrip('/')
        
        # Check exact URL match
        if url_base in seen_urls:
            continue
        
        # Check title similarity with existing results
        is_duplicate = False
        for existing in unique_results:
            existing_title = existing.get('title', '').lower().strip()
            similarity = calculate_text_similarity(title, existing_title)
            
            if similarity > similarity_threshold:
                is_duplicate = True
                logger.debug(f"Filtered duplicate: '{title[:50]}' similar to '{existing_title[:50]}' (score: {similarity:.2f})")
                break
        
        if not is_duplicate:
            seen_urls.add(url_base)
            unique_results.append(result)
    
    return unique_results


def score_source_diversity(results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Score and reorder results to promote diversity of sources
    Considers domain reputation and variety
    """
    domain_counts = defaultdict(int)
    domain_quality_scores = {
        # High-quality domains get bonus
        'wikipedia.org': 1.2,
        'stackoverflow.com': 1.2,
        'github.com': 1.1,
        'docs.python.org': 1.2,
        'medium.com': 1.0,
        # Default is 1.0
    }
    
    scored_results = []
    
    for idx, result in enumerate(results):
        url = result.get('url', '')
        try:
            parsed = urlparse(url)
            domain = parsed.netloc.replace('www.', '').replace('m.', '')
            
            domain_counts[domain] += 1
            
            # Calculate diversity score
            # Penalize domains we've seen multiple times
            frequency_penalty = 1.0 / domain_counts[domain]
            
            # Apply quality bonus
            quality_bonus = domain_quality_scores.get(domain, 1.0)
            
            # Position penalty (prefer earlier results slightly)
            position_score = 1.0 / (1 + idx * 0.1)
            
            diversity_score = frequency_penalty * quality_bonus * position_score
            
            result['_diversity_score'] = diversity_score
            result['_domain'] = domain
            scored_results.append(result)
            
        except Exception as e:
            logger.warning(f"Error parsing URL for diversity score: {url} - {e}")
            result['_diversity_score'] = 0.5
            result['_domain'] = 'unknown'
            scored_results.append(result)
    
    # Sort by diversity score (keeping original order as tiebreaker)
    scored_results.sort(
        key=lambda x: (x.get('_diversity_score', 0), -results.index(x)),
        reverse=True
    )
    
    return scored_results


def calculate_relevance_score(result: Dict[str, Any], query: str) -> float:
    """
    Calculate TF-IDF-like relevance score
    """
    query_terms = [term.lower() for term in query.split() if len(term) > 2]
    
    if not query_terms:
        return 0.5
    
    title = result.get('title', '').lower()
    snippet = result.get('snippet', '').lower()
    url = result.get('url', '').lower()
    
    score = 0.0
    term_matches = 0
    
    for term in query_terms:
        # Title matches (highest weight)
        if term in title:
            score += 3.0
            term_matches += 1
        
        # Snippet matches (medium weight)
        if term in snippet:
            score += 1.5
            term_matches += 1
        
        # URL matches (lower weight, but still relevant)
        if term in url:
            score += 0.5
    
    # Bonus for matching multiple terms
    if term_matches > 1:
        score *= (1 + 0.2 * (term_matches - 1))
    
    # Normalize by query length
    normalized_score = score / len(query_terms)
    
    return min(normalized_score, 10.0)  # Cap at 10


def validate_result(result: Dict[str, Any]) -> bool:
    """
    Validate that a search result has required fields and reasonable content
    """
    required_fields = ['title', 'url', 'snippet']
    
    # Check required fields exist
    if not all(field in result for field in required_fields):
        return False
    
    # Check fields are not empty
    if not result.get('title', '').strip():
        return False
    if not result.get('url', '').strip():
        return False
    
    # Validate URL format
    url = result.get('url', '')
    if not url.startswith(('http://', 'https://')):
        return False
    
    return True


def format_results_enhanced(results: List[Dict[str, Any]], query: str, metadata: Dict[str, Any] = None) -> str:
    """
    Format results with enhanced markdown and metadata
    """
    if not results:
        return f"No results found for query: **{query}**"
    
    lines = [
        f"# 🔍 Web Search Results",
        f"**Query:** {query}",
        f"**Found:** {len(results)} relevant results",
    ]
    
    # Add metadata if provided
    if metadata:
        lines.append(f"**Response Time:** {metadata.get('response_time_ms', 0):.0f}ms")
        if metadata.get('from_cache'):
            lines.append(f"**Source:** Cache (age: {metadata.get('cache_age_seconds', 0):.0f}s)")
        else:
            lines.append(f"**Source:** Live search")
    
    lines.append("")  # Blank line
    
    for i, result in enumerate(results, 1):
        title = result.get("title", "No title")
        snippet = result.get("snippet", "No description available")
        url = result.get("url", "")
        
        # Clean up snippet
        snippet = " ".join(snippet.split())
        if len(snippet) > 300:
            snippet = snippet[:297] + "..."
        
        lines.append(f"## {i}. {title}")
        lines.append(f"{snippet}")
        lines.append(f"🔗 [{url}]({url})")
        
        # Add metadata if available
        if '_relevance_score' in result:
            score = result['_relevance_score']
            if score > 0:
                lines.append(f"*Relevance: {score:.1f}/10*")
        
        lines.append("")  # Blank line between results
    
    return "\n".join(lines)


async def enhanced_web_search(
    query: str,
    max_results: int = 6,
    use_cache: bool = True,
    enhance_diversity: bool = True,
    filter_relevance: bool = True,
    min_relevance_score: float = 0.0,
    timeout_seconds: float = 30.0
) -> str:
    """
    Enhanced web search with caching, deduplication, and diversity scoring.
    
    Args:
        query: The search query string
        max_results: Maximum number of results to return (default: 6)
        use_cache: Whether to use cached results if available (default: True)
        enhance_diversity: Whether to promote source diversity (default: True)
        filter_relevance: Whether to filter by relevance score (default: True)
        min_relevance_score: Minimum relevance score threshold (default: 0.0)
        timeout_seconds: Request timeout in seconds (default: 30.0)
        
    Returns:
        A formatted markdown string with search results
    """
    start_time = time.time()
    from_cache = False
    
    # Check cache first
    if use_cache:
        cached = await _search_cache.get(query, max_results)
        if cached:
            from_cache = True
            _metrics.record_hit()
            
            # Add cache metadata
            response_time_ms = (time.time() - start_time) * 1000
            _metrics.record_search(response_time_ms)
            
            logger.info(f"Returning cached results for: {query[:50]}...")
            return cached
    
    _metrics.record_miss()
    
    # Rate limiting
    try:
        await _rate_limiter.wait_for_token(tokens=1, timeout=5.0)
    except TimeoutError:
        logger.warning(f"Rate limit wait timeout for query: {query[:50]}...")
        return json.dumps({
            "error": "Rate limit exceeded",
            "message": "Too many requests. Please try again in a moment.",
            "query": query
        }, indent=2)
    
    try:
        # Make request with retry logic and exponential backoff
        max_retries = 3
        base_delay = 1.0
        
        response_data = None
        last_error = None
        
        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(
                    base_url=settings.COVERITY_GATEWAY_URL,
                    timeout=timeout_seconds,
                    limits=httpx.Limits(max_keepalive_connections=5, max_connections=10)
                ) as client:
                    # Request extra results for filtering
                    fetch_count = max_results * 2 if filter_relevance else max_results
                    
                    response = await client.post(
                        "/web-search",
                        json={"query": query, "max_results": fetch_count}
                    )
                    response.raise_for_status()
                    response_data = response.json()
                    break  # Success, exit retry loop
                    
            except httpx.TimeoutException as e:
                last_error = e
                if attempt < max_retries - 1:
                    delay = base_delay * (2 ** attempt)  # Exponential backoff
                    logger.warning(
                        f"Search timeout (attempt {attempt + 1}/{max_retries}), "
                        f"retrying in {delay}s: {query[:50]}..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Search timeout after {max_retries} attempts: {query[:50]}...")
                    raise
                    
            except httpx.HTTPStatusError as e:
                last_error = e
                if e.response.status_code == 429:  # Rate limit from upstream
                    if attempt < max_retries - 1:
                        delay = base_delay * 2 * (2 ** attempt)
                        logger.warning(
                            f"Upstream rate limited (attempt {attempt + 1}/{max_retries}), "
                            f"retrying in {delay}s"
                        )
                        await asyncio.sleep(delay)
                    else:
                        logger.error(f"Upstream rate limit after {max_retries} attempts")
                        raise
                elif e.response.status_code >= 500:
                    # Server error, retry
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        logger.warning(
                            f"Server error {e.response.status_code} "
                            f"(attempt {attempt + 1}/{max_retries}), retrying in {delay}s"
                        )
                        await asyncio.sleep(delay)
                    else:
                        raise
                else:
                    # Client error, don't retry
                    raise
        
        if response_data is None:
            raise last_error or Exception("Failed to fetch search results")
        
        # Extract and validate results
        results = response_data.get("response", {}).get("results", [])
        
        # Validate results
        results = [r for r in results if validate_result(r)]
        
        if not results:
            result_str = f"No valid results found for query: {query}"
            response_time_ms = (time.time() - start_time) * 1000
            _metrics.record_search(response_time_ms)
            
            if use_cache:
                await _search_cache.set(query, max_results, result_str)
            
            return result_str
        
        # Apply enhancements
        logger.info(f"Processing {len(results)} raw results for: {query[:50]}...")
        
        # 1. Deduplicate with fuzzy matching
        results = deduplicate_results(results, similarity_threshold=0.7)
        logger.debug(f"After deduplication: {len(results)} results")
        
        # 2. Score relevance
        if filter_relevance:
            for result in results:
                result['_relevance_score'] = calculate_relevance_score(result, query)
            
            # Filter by minimum score
            if min_relevance_score > 0:
                results = [r for r in results if r.get('_relevance_score', 0) >= min_relevance_score]
                logger.debug(f"After relevance filtering (>={min_relevance_score}): {len(results)} results")
            
            # Sort by relevance
            results.sort(key=lambda x: x.get('_relevance_score', 0), reverse=True)
        
        # 3. Enhance diversity (reorder, not filter)
        if enhance_diversity and len(results) > max_results:
            results = score_source_diversity(results)
            logger.debug(f"Applied diversity scoring")
        
        # 4. Limit to requested number
        results = results[:max_results]
        
        # Prepare metadata
        response_time_ms = (time.time() - start_time) * 1000
        metadata = {
            'response_time_ms': response_time_ms,
            'from_cache': False,
            'results_count': len(results)
        }
        
        # Format results
        formatted = format_results_enhanced(results, query, metadata)
        
        # Cache the result
        if use_cache:
            await _search_cache.set(query, max_results, formatted)
        
        # Record metrics
        _metrics.record_search(response_time_ms)
        
        logger.info(
            f"Search completed: query='{query[:50]}...' "
            f"results={len(results)} time={response_time_ms:.0f}ms"
        )
        
        return formatted
        
    except httpx.HTTPError as e:
        _metrics.record_failure()
        error_msg = f"Web search failed: {str(e)}"
        logger.error(f"HTTP error for query '{query[:50]}...': {e}")
        
        return json.dumps({
            "error": "Search request failed",
            "message": str(e),
            "query": query,
            "details": "Check network connectivity and gateway status"
        }, indent=2)
        
    except Exception as e:
        _metrics.record_failure()
        error_msg = f"Unexpected web search error: {str(e)}"
        logger.error(f"Unexpected error in web search for '{query[:50]}...': {e}", exc_info=True)
        
        return json.dumps({
            "error": "Unexpected search error",
            "message": str(e),
            "query": query
        }, indent=2)


async def maintain_cache():
    """Periodic cache maintenance task"""
    await _search_cache.clear_expired()
    logger.info(f"Cache maintenance complete. Stats: {_search_cache.get_stats()}")


def get_search_stats() -> Dict[str, Any]:
    """Get combined search and cache statistics"""
    return {
        "metrics": _metrics.get_stats(),
        "cache": _search_cache.get_stats()
    }


# LangChain tool wrapper
from langchain_core.tools import StructuredTool

enhanced_web_search_langchain_tool = StructuredTool.from_function(
    name="enhanced_web_search",
    description=(
        "Enhanced web search with advanced caching, deduplication, and intelligent result ranking. "
        "Search the public web for up-to-date information including weather, news, prices, "
        "current events, and other time-sensitive facts. Features automatic deduplication with "
        "fuzzy matching, source diversity promotion, TF-IDF-like relevance scoring, result validation, "
        "LRU caching with TTL, rate limiting, and comprehensive error handling with retry logic. "
        "Returns formatted markdown results with metadata and performance metrics."
    ),
    func=enhanced_web_search,
    coroutine=enhanced_web_search,
)
