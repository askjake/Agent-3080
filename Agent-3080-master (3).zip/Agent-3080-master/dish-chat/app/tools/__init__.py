"""Tool management module for hot-plug MCP tool selection."""
