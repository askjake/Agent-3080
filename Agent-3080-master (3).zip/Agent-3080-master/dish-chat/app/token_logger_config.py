from token_logger import create_token_logger
import os

# Use registered agent name from hub
token_logger = create_token_logger(
    agent_name=os.getenv("AGENT_NAME", "agent_10.79.85.47_8000"),
    hub_url=os.getenv("MULTI_AGENT_HUB_URL", "http://localhost:5002"),
    enabled=os.getenv("TOKEN_LOGGING_ENABLED", "true").lower() == "true"
)
