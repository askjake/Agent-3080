
# Dish-Chat Agent Backend: Versioning & Restoration System

## Overview

This system provides comprehensive version control and disaster recovery capabilities
for the Dish-Chat agent backend, addressing the critical need for:

1. **State Management**: Track all system states with metadata
2. **Quick Recovery**: Rollback to any previous working state
3. **Health Monitoring**: Continuous verification of system health
4. **Dependency Tracking**: Ensure all Python packages are correct
5. **Change Tracking**: Git-integrated version control

## Architecture

### Components

1. **Snapshot System**
   - Full backup of app/ directory
   - Environment configuration (.env files)
   - Python dependency list (pip freeze)
   - Database schema state
   - Git commit state
   - Service logs
   - Metadata and manifest

2. **Restoration Engine**
   - Pre-restore auto-backup
   - Selective file restoration
   - Dependency reinstallation
   - Health verification

3. **Health Monitor**
   - Service status check
   - Database connectivity
   - Critical package verification
   - Log error analysis

4. **Quick Fix Tool**
   - Auto-install missing packages
   - Fix requirements.txt
   - Common issue resolution

## Usage Guide

### Creating Snapshots

**Before any major change:**
```bash
cd ~/dish-chat
./dish_chat_version_manager.sh create "pre_memory_integration" "Before adding memory system"
```

**Daily snapshots:**
```bash
./dish_chat_version_manager.sh create "daily_$(date +%Y%m%d)" "Daily backup"
```

### Listing Snapshots

```bash
./dish_chat_version_manager.sh list
```

Output shows:
- Timestamp
- Version tag
- Description
- Git state

### Restoring from Snapshot

```bash
# List available snapshots first
./dish_chat_version_manager.sh list

# Restore specific snapshot
./dish_chat_version_manager.sh restore snapshot_20260429_150000_working_state
```

**Safety features:**
- Creates auto-backup before restore
- Prompts for confirmation
- Validates snapshot integrity

### Health Verification

```bash
./dish_chat_version_manager.sh verify
```

Checks:
- Service running status
- Health endpoint response
- Database connectivity
- Critical Python packages (pgvector, asyncpg)
- Recent error logs

### Quick Fix

For common issues like missing dependencies:
```bash
./dish_chat_version_manager.sh fix
```

Automatically:
- Installs pgvector if missing
- Updates requirements.txt
- Verifies configuration

## Integration with Git

The system works alongside Git:

1. **Snapshots capture Git state:**
   - Current branch
   - Current commit hash
   - Uncommitted changes (git diff)
   - Recent history

2. **Restore preserves Git history:**
   - Doesn't modify .git/
   - Allows manual git operations after restore

3. **Recommended workflow:**
   ```bash
   # Before making changes
   git checkout -b feature/my-feature
   ./dish_chat_version_manager.sh create "pre_feature" "Before my feature"
   
   # Make changes
   # ...
   
   # If something breaks
   ./dish_chat_version_manager.sh restore snapshot_xxx_pre_feature
   
   # Or use git
   git reset --hard HEAD
   ```

## Automated Scheduling

### Daily Snapshots (Cron)

Add to crontab:
```bash
0 2 * * * cd /home/montjac/dish-chat && ./dish_chat_version_manager.sh create "auto_daily_$(date +\%Y\%m\%d)" "Automated daily backup" >> /tmp/dish_chat_backup.log 2>&1
```

### Pre-Deployment Hook

Add to deployment script:
```bash
#!/bin/bash
# Before deploying new version
cd /home/montjac/dish-chat
./dish_chat_version_manager.sh create "pre_deploy_$(date +%Y%m%d_%H%M%S)" "Before deployment"

# Deploy
# ...

# Verify
if ! ./dish_chat_version_manager.sh verify; then
    echo "Deployment verification failed! Rolling back..."
    # Restore last snapshot
fi
```

## Troubleshooting

### Common Issues

**Issue: "Snapshot not found"**
```bash
# Check available snapshots
./dish_chat_version_manager.sh list

# Verify backup directory exists
ls -la ~/dish-chat/backups/versioned/
```

**Issue: "Service won't start after restore"**
```bash
# Check dependencies
cd ~/dish-chat
source .venv/bin/activate
pip install -r requirements.txt

# Check database
PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -c '\dt'

# Check logs
tail -100 logs/backend.log
```

**Issue: "pgvector errors persist"**
```bash
# Run quick fix
./dish_chat_version_manager.sh fix

# Manually install
source .venv/bin/activate
pip install pgvector==0.3.6
pip install 'sqlalchemy[asyncio]'
```

## Best Practices

1. **Snapshot Before Changes**
   - Always create snapshot before modifying code
   - Use descriptive tags and descriptions

2. **Regular Health Checks**
   - Run verification daily
   - Monitor for dependency drift

3. **Clean Up Old Snapshots**
   ```bash
   # Keep last 30 days
   find ~/dish-chat/backups/versioned -type d -name 'snapshot_*' -mtime +30 -exec rm -rf {} \;
   ```

4. **Test Restoration Periodically**
   - Verify backups are valid
   - Practice recovery procedures

5. **Document Changes**
   - Use meaningful version tags
   - Include change descriptions
   - Note breaking changes

## Recovery Procedures

### Scenario: Complete System Failure

```bash
# 1. List available snapshots
./dish_chat_version_manager.sh list

# 2. Choose last known good state
./dish_chat_version_manager.sh restore snapshot_20260429_120000_working

# 3. Verify restoration
./dish_chat_version_manager.sh verify

# 4. Restart service
cd ~/dish-chat
source .venv/bin/activate
nohup python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 > logs/backend.log 2>&1 &

# 5. Monitor logs
tail -f logs/backend.log
```

### Scenario: Partial Failure (Only Dependencies)

```bash
# Quick fix approach
./dish_chat_version_manager.sh fix

# Or manual approach
cd ~/dish-chat
source .venv/bin/activate
pip install -r requirements.txt
pip install pgvector==0.3.6
```

### Scenario: Configuration Issue

```bash
# Restore only .env
snapshot_dir=~/dish-chat/backups/versioned/snapshot_xxx
cp "$snapshot_dir/.env" ~/dish-chat/.env

# Restart service
pkill -f 'uvicorn.*8001'
cd ~/dish-chat && source .venv/bin/activate
nohup python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 > logs/backend.log 2>&1 &
```

## Monitoring and Alerts

### Health Check Monitoring

Create monitoring script:
```bash
#!/bin/bash
# /home/montjac/dish-chat/monitor_health.sh

cd /home/montjac/dish-chat

if ! ./dish_chat_version_manager.sh verify > /tmp/health_check.log 2>&1; then
    # Send alert (email, Slack, etc.)
    echo "ALERT: Dish-Chat health check failed" | mail -s "Dish-Chat Alert" admin@example.com
fi
```

Schedule in cron:
```bash
*/15 * * * * /home/montjac/dish-chat/monitor_health.sh
```

## Future Enhancements

Planned features:
- [ ] Database dump/restore integration
- [ ] Remote backup storage (S3)
- [ ] Slack/email notifications
- [ ] Web UI for snapshot management
- [ ] Automated rollback on deployment failure
- [ ] Snapshot compression for storage efficiency
- [ ] Migration verification before restore

## Support

For issues or questions:
1. Check logs: `~/dish-chat/logs/backend.log`
2. Run health check: `./dish_chat_version_manager.sh verify`
3. Review recent snapshots: `./dish_chat_version_manager.sh list`
4. Consult investigation report in `/tmp/`

