"""
Net Detective MCP HTTP Server

HTTP wrapper for the Net Detective MCP server to work with dish-chat's
streamable_http transport.

Runs on port 8082 and forwards MCP protocol messages to the underlying
Net Detective API on port 8080.
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
import httpx
import uvicorn

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Net Detective API configuration
NET_DETECTIVE_BASE_URL = "http://localhost:8080/api/v1"
NET_DETECTIVE_TIMEOUT = 30.0

app = FastAPI(title="Net Detective MCP Server", version="1.0.0")


async def call_net_detective_api(
    method: str,
    path: str,
    params: Optional[Dict[str, Any]] = None,
    json_data: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Call the Net Detective API."""
    url = f"{NET_DETECTIVE_BASE_URL}{path}"
    logger.info(f"Calling Net Detective API: {method} {url}")
    
    try:
        async with httpx.AsyncClient(timeout=NET_DETECTIVE_TIMEOUT) as client:
            if method == "GET":
                response = await client.get(url, params=params)
            elif method == "POST":
                response = await client.post(url, params=params, json=json_data)
            elif method == "DELETE":
                response = await client.delete(url, params=params)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
            
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code} - {e.response.text}")
        return {
            "error": f"HTTP {e.response.status_code}",
            "message": e.response.text[:200]
        }
    except Exception as e:
        logger.error(f"API call failed: {str(e)}")
        return {
            "error": "api_error",
            "message": str(e)
        }


@app.post("/mcp")
async def mcp_endpoint(request: Request) -> Response:
    """Handle MCP protocol messages."""
    try:
        message = await request.json()
        logger.info(f"Received MCP message: {message.get('method', 'unknown')}")
        
        method = message.get("method")
        params = message.get("params", {})
        msg_id = message.get("id")
        
        if method == "initialize":
            return JSONResponse({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "protocolVersion": "1.0",
                    "capabilities": {
                        "tools": {}
                    },
                    "serverInfo": {
                        "name": "netdetective",
                        "version": "1.0.0"
                    }
                }
            })
            
        elif method == "tools/list":
            return JSONResponse({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "tools": [
                        {
                            "name": "analyze_receiver",
                            "description": "Analyze network health and errors for a DISH receiver using ML",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "rid": {
                                        "type": "string",
                                        "description": "Receiver ID (10 digits)",
                                        "pattern": "^R?\d{10}$"
                                    },
                                    "use_ml": {
                                        "type": "boolean",
                                        "description": "Use ML models (default: true)",
                                        "default": True
                                    },
                                    "force_refresh": {
                                        "type": "boolean",
                                        "description": "Force fresh analysis (default: false)",
                                        "default": False
                                    }
                                },
                                "required": ["rid"]
                            }
                        },
                        {
                            "name": "get_job_status",
                            "description": "Check status of an async analysis job",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "job_id": {
                                        "type": "string",
                                        "description": "Job ID from analyze_receiver"
                                    }
                                },
                                "required": ["job_id"]
                            }
                        },
                        {
                            "name": "get_analysis_result",
                            "description": "Retrieve completed analysis results",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "job_id": {
                                        "type": "string",
                                        "description": "Job ID from analyze_receiver"
                                    }
                                },
                                "required": ["job_id"]
                            }
                        },
                        {
                            "name": "get_cached_analysis",
                            "description": "Get previously cached analysis for a receiver",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "rid": {
                                        "type": "string",
                                        "description": "Receiver ID",
                                        "pattern": "^R?\d{10}$"
                                    }
                                },
                                "required": ["rid"]
                            }
                        },
                        {
                            "name": "list_models",
                            "description": "Get info about available ML models",
                            "inputSchema": {
                                "type": "object",
                                "properties": {
                                    "error_num": {
                                        "type": "integer",
                                        "description": "Specific error number (optional)",
                                        "enum": [1, 8, 10, 13, 19, 21, 23, 25]
                                    },
                                    "detailed": {
                                        "type": "boolean",
                                        "description": "Return detailed info",
                                        "default": False
                                    }
                                }
                            }
                        },
                        {
                            "name": "get_health",
                            "description": "Check Net Detective service health",
                            "inputSchema": {
                                "type": "object",
                                "properties": {}
                            }
                        }
                    ]
                }
            })
            
        elif method == "tools/call":
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            
            logger.info(f"Calling tool: {tool_name}")
            
            result = None
            
            if tool_name == "analyze_receiver":
                rid = arguments["rid"]
                options = {
                    "use_ml": arguments.get("use_ml", True),
                    "force_refresh": arguments.get("force_refresh", False),
                    "include_plots": arguments.get("include_plots", False),
                    "include_llm_report": arguments.get("include_llm_report", False)
                }
                result = await call_net_detective_api("POST", "/analysis/", params={"rid": rid}, json_data=options)
                
            elif tool_name == "get_job_status":
                job_id = arguments["job_id"]
                result = await call_net_detective_api("GET", f"/jobs/{job_id}")
                
            elif tool_name == "get_analysis_result":
                job_id = arguments["job_id"]
                result = await call_net_detective_api("GET", f"/jobs/{job_id}/result")
                
            elif tool_name == "get_cached_analysis":
                rid = arguments["rid"]
                result = await call_net_detective_api("GET", f"/analysis/{rid}")
                
            elif tool_name == "list_models":
                error_num = arguments.get("error_num")
                detailed = arguments.get("detailed", False)
                params_dict = {"detailed": detailed}
                if error_num:
                    params_dict["error_num"] = error_num
                result = await call_net_detective_api("GET", "/models", params=params_dict)
                
            elif tool_name == "get_health":
                result = await call_net_detective_api("GET", "/health")
                
            else:
                raise ValueError(f"Unknown tool: {tool_name}")
            
            return JSONResponse({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [
                        {
                            "type": "text",
                            "text": json.dumps(result, indent=2)
                        }
                    ]
                }
            })
            
        else:
            raise ValueError(f"Unknown method: {method}")
            
    except Exception as e:
        logger.error(f"Error handling MCP message: {str(e)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "jsonrpc": "2.0",
                "id": message.get("id") if 'message' in locals() else None,
                "error": {
                    "code": -32603,
                    "message": str(e)
                }
            }
        )


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "netdetective-mcp"}


if __name__ == "__main__":
    logger.info("Starting Net Detective MCP HTTP Server on port 8082...")
    uvicorn.run(app, host="0.0.0.0", port=8082, log_level="info")
