#!/bin/bash
#
# Fix for Dish-Chat 'Thinking' Message Issue
# Filters out reasoning content so only text is shown to users
#

set -e

cd ~/dish-chat

echo "========================================================================"
echo "FIXING: Messages showing 'thinking' instead of actual content"
echo "========================================================================"
echo ""

# Backup original file
echo "[1/4] Creating backup..."
cp app/core/constants.py app/core/constants.py.backup-thinking-fix-$(date +%Y%m%d_%H%M%S)
echo "✓ Backup created"
echo ""

# Apply fix - comment out reasoning_content mapping
echo "[2/4] Applying fix to app/core/constants.py..."
cat > app/core/constants.py << 'EOFIX'
from pydantic import BaseModel, ConfigDict, Field


CONTENT_TYPE_MAPPING = {
    "text": "text",
    # "reasoning_content": "reasoning"  # DISABLED: Hides thinking/reasoning content from users
}


class NSProperty(BaseModel):
    model_config = ConfigDict(frozen=True)

    chat_agent: str = Field(..., description="Agent to use for this namespace")
    is_singleton: bool = Field(
        ..., description="Whether this namespace allows only one chat instance"
    )
    agent_params: dict[str, str] | None = Field(
        None, description="Agent parameters for chat agent"
    )


CHAT_NS_MAP = {
    "generic": NSProperty(chat_agent="chat", is_singleton=False),
    "beta_report/androidtv": NSProperty(
        chat_agent="beta_report",
        is_singleton=True,
        agent_params={"platform": "AndroidTV"},
    ),
    "beta_report/dishtv": NSProperty(
        chat_agent="beta_report",
        is_singleton=True,
        agent_params={"platform": "DishTV"},
    ),
}
EOFIX
echo "✓ Fix applied"
echo ""

# Verify the change
echo "[3/4] Verifying fix..."
if grep -q '# "reasoning_content": "reasoning"' app/core/constants.py; then
    echo "✓ Verification passed - reasoning_content mapping is commented out"
else
    echo "✗ Verification failed - fix may not have applied correctly"
    exit 1
fi
echo ""

# Show what changed
echo "[4/4] Changes made:"
echo "----------------------------------------------------------------------"
echo "BEFORE:"
echo '  CONTENT_TYPE_MAPPING = {
      "text": "text",
      "reasoning_content": "reasoning"  # <-- Was mapping reasoning content
  }'
echo ""
echo "AFTER:"
echo '  CONTENT_TYPE_MAPPING = {
      "text": "text",
      # "reasoning_content": "reasoning"  # <-- Now commented out
  }'
echo "----------------------------------------------------------------------"
echo ""

echo "========================================================================"
echo "FIX APPLIED SUCCESSFULLY"
echo "========================================================================"
echo ""
echo "EFFECT:"
echo "  • Reasoning/thinking content will be ignored by backend"
echo "  • Only text content will be returned to frontend"
echo "  • Users will see actual answers instead of 'thinking' process"
echo ""
echo "NEXT STEP:"
echo "  Service needs restart to load the change:"
echo "  "
echo "  cd ~/dish-chat"
echo "  pkill -f 'uvicorn.*8001'"
echo "  source .venv/bin/activate"
echo "  nohup python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 \\"
echo "    > logs/backend.log 2>&1 &"
echo ""
echo "VERIFICATION:"
echo "  1. Send a test message"
echo "  2. Verify response shows actual content (not 'thinking')"
echo "  3. Check logs: tail -f ~/dish-chat/logs/backend.log"
echo ""
echo "ROLLBACK (if needed):"
echo "  cp app/core/constants.py.backup-thinking-fix-* app/core/constants.py"
echo ""
