#!/bin/bash
# Auto-patch CORS configuration for 10.79.85.47

CONFIG_FILE="$HOME/dish-chat/app/config.py"

echo "Updating CORS configuration in $CONFIG_FILE..."

# Backup original
cp "$CONFIG_FILE" "$CONFIG_FILE.backup.$(date +%Y%m%d_%H%M%S)"

# Add the new CORS entries before the closing bracket
sed -i '/http:\/\/10.79.83.40:3001/a\        "http://10.79.85.47:3000",\n        "http://10.79.85.47:3001",\n        "http://10.79.85.47:8000",\n        "http://10.79.85.47:8001",' "$CONFIG_FILE"

echo "✅ CORS configuration updated!"
echo "✅ Backup saved to: $CONFIG_FILE.backup.*"
echo ""
echo "New entries added:"
echo "  - http://10.79.85.47:3000"
echo "  - http://10.79.85.47:3001"
echo "  - http://10.79.85.47:8000"
echo "  - http://10.79.85.47:8001"
echo ""
echo "Restart the backend for changes to take effect."
