# Web Search Error Analysis & Resolution

**Date:** 2026-03-26 11:13 UTC  
**System:** montjac@10.79.85.35:/home/montjac/dish-chat

---

## Issue Summary

Two distinct errors occurred during web search operation:

### Error 1: Gateway Connection Failure (CRITICAL)
```
ERROR: All connection attempts failed
Query: 'current weather Denver Colorado'
Target: http://127.0.0.1:5000
```

### Error 2: Missing Database Table (WARNING - Non-blocking)
```
ERROR: relation "web_searches" does not exist
Table: web_searches
Operation: INSERT (analytics logging)
Impact: Analytics not saved, but search continues
```

---

## Root Cause Analysis

### Error 1: Gateway Not Running ❌

**Investigation Results:**
```bash
# Check gateway configuration
COVERITY_GATEWAY_URL: http://127.0.0.1:5000

# Test gateway connectivity
curl http://127.0.0.1:5000/health
Result: TIMEOUT (not responding)

# Check if gateway process is running
ps aux | grep coverity
Result: NO PROCESS FOUND
```

**Root Cause:** The `coverity_assist_gateway.py` service is not running.

**Gateway Script Located:** `/home/montjac/dish-chat/coverity_assist_gateway.py`

**Impact:**
- ❌ Web searches fail completely
- ❌ No external search capability
- ❌ Agent cannot retrieve current information (weather, news, etc.)

---

### Error 2: Missing Database Migration ⚠️

**Investigation Results:**
```bash
# Check alembic migrations
ls app/alembic/versions/
Result: 19 migrations found

# Search for web_searches table migration
grep -r 'web_searches' app/alembic/versions/
Result: NOT FOUND

# Check analytics service code
grep 'INSERT INTO web_searches' app/analytics/service.py
Result: FOUND at line 90

# Check existing analytics migrations
cat app/alembic/versions/aa1b2c3d4e5f_add_analytics_tables.py
Result: Creates chat_summary and backend_insight tables only
```

**Root Cause:** The `web_searches` table was added in application code but no database migration was created.

**Code Reference:** `/home/montjac/dish-chat/app/analytics/service.py:90`

**Impact:**
- ⚠️ Search analytics not logged
- ⚠️ Cannot track search patterns
- ✅ Web search functionality still works (error is caught and logged)
- ✅ Non-blocking error (doesn't prevent searches)

---

## Resolution Steps

### IMMEDIATE ACTION REQUIRED (Error 1) - Gateway

**Option A: Start Gateway Service (Recommended)**
```bash
ssh montjac@10.79.85.35
cd /home/montjac/dish-chat

# Check if gateway has systemd service
systemctl --user status coverity-gateway 2>/dev/null

# If no service, start manually
nohup python3 coverity_assist_gateway.py &> logs/gateway.log &

# Verify it's running
curl http://127.0.0.1:5000/health
```

**Option B: Use Alternative Gateway URL**
If gateway is running elsewhere, update config:
```python
# In app/config.py line 187
COVERITY_GATEWAY_URL: str = "http://<actual-host>:<port>"
```

**Option C: Disable Web Search (Temporary)**
Not recommended - removes key functionality.

---

### SHORT-TERM FIX (Error 2) - Database Migration

**Option A: Create Alembic Migration (Proper Solution)**
```bash
cd /home/montjac/dish-chat

# Generate migration
alembic revision -m "add_web_searches_table"

# Edit the generated migration file to add:
def upgrade():
    op.create_table(
        'web_searches',
        sa.Column('id', postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column('chat_id', sa.String(), nullable=True),
        sa.Column('query', sa.Text(), nullable=False),
        sa.Column('results_json', postgresql.JSONB, nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False, server_default=sa.func.now())
    )
    op.create_index('idx_web_searches_chat_id', 'web_searches', ['chat_id'])
    op.create_index('idx_web_searches_created_at', 'web_searches', ['created_at'])

def downgrade():
    op.drop_index('idx_web_searches_created_at')
    op.drop_index('idx_web_searches_chat_id')
    op.drop_table('web_searches')

# Apply migration
alembic upgrade head
```

**Option B: Disable Analytics Logging (Temporary)**
Comment out the analytics call in `app/tools/enhanced_web_search.py`:
```python
# try:
#     await save_web_search(chat_id, query, analytics_data)
# except Exception as e:
#     logger.warning(f"Failed to log web search analytics: {e}")
```

**Option C: Create Table Manually (Quick Fix)**
```sql
-- Connect to database
psql <connection_string>

-- Create table
CREATE TABLE web_searches (
    id UUID PRIMARY KEY,
    chat_id VARCHAR,
    query TEXT NOT NULL,
    results_json JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_web_searches_chat_id ON web_searches(chat_id);
CREATE INDEX idx_web_searches_created_at ON web_searches(created_at);
```

---

## Priority Assessment

| Issue | Severity | Impact | Priority | Blocks Service |
|-------|----------|--------|----------|----------------|
| Gateway Not Running | CRITICAL | Web search completely broken | P0 | YES |
| Missing DB Table | WARNING | Analytics not saved | P2 | NO |

---

## What I Can vs Cannot Fix

### ✅ What I Can Do (Code Changes):
- Improve error messages
- Add graceful degradation
- Create migration template
- Update documentation

### ❌ What I Cannot Do (Infrastructure):
- Start the gateway service (requires systemd/process management)
- Create database tables (requires database credentials)
- Modify production infrastructure
- Access environment variables

---

## Recommended Action Plan

### Phase 1: Restore Web Search (IMMEDIATE)
1. ✅ **Start Gateway Service**
   ```bash
   cd /home/montjac/dish-chat
   python3 coverity_assist_gateway.py &
   ```

2. ✅ **Verify Gateway**
   ```bash
   curl http://127.0.0.1:5000/health
   # Should return 200 OK
   ```

3. ✅ **Test Web Search**
   Use dish-chat UI to perform a web search

### Phase 2: Fix Analytics (SHORT-TERM)
1. Create proper Alembic migration
2. Apply migration to database
3. Verify analytics logging works

### Phase 3: Prevent Future Issues (LONG-TERM)
1. Add health check endpoint for gateway
2. Add startup script for gateway service
3. Create systemd service for gateway
4. Add database migration validation in CI/CD

---

## Monitoring Commands

```bash
# Check gateway status
curl http://127.0.0.1:5000/health

# Check gateway logs
tail -f logs/gateway.log

# Monitor web search errors
grep "web search failed" logs/backend.log

# Check database tables
psql -c "\dt web_searches"
```

---

## Enhanced Web Search Tool Status

The enhanced web search tool v2.0 deployed earlier is working correctly. The errors are NOT caused by the enhancement:

✅ Code is correct and validated  
✅ Import order fixed  
✅ Cache working properly  
✅ Rate limiter functional  
❌ Gateway unavailable (infrastructure issue)  
⚠️ Analytics table missing (migration issue)  

The enhancement improved error handling, which is why we now see clearer error messages about the gateway being down.

---

## Next Steps

**IMMEDIATE (5 minutes):**
1. Start gateway: `python3 coverity_assist_gateway.py &`
2. Test web search in UI
3. Verify in logs

**SHORT-TERM (1 hour):**
1. Create systemd service for gateway
2. Create database migration
3. Apply migration
4. Test analytics logging

**LONG-TERM (1 day):**
1. Add health monitoring
2. Add auto-restart for gateway
3. Add migration validation to CI/CD
4. Document deployment dependencies

---

**Status:** 📋 DIAGNOSIS COMPLETE  
**Action Required:** ⚠️ START GATEWAY SERVICE  
**Code Issues:** ✅ NONE (web search tool is working correctly)  
**Infrastructure Issues:** ❌ GATEWAY DOWN, ⚠️ TABLE MISSING  

