#!/bin/bash
# Dish-Chat Comprehensive Startup Script
# Updated: 2026-04-28
# Location: ~/dish-chat/start-dish-chat-comprehensive.sh

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ROOT="$HOME/dish-chat"
BACKEND_PORT="${BACKEND_PORT:-8000}"
FRONTEND_PORT="${FRONTEND_PORT:-3000}"
LOG_DIR="$HOME/dish-chat-logs"

echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║              DISH-CHAT COMPREHENSIVE STARTUP v2.0                        ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""

# Step 1: Stop existing services
echo "${BLUE}▶ Step 1: Stopping existing services...${NC}"
echo ""

# Kill backend on port 8000 and 8001
for PORT in 8000 8001; do
    PIDS=$(lsof -ti:$PORT 2>/dev/null || true)
    if [ -n "$PIDS" ]; then
        echo "▶ Killing backend on port $PORT (PIDs: $PIDS)"
        kill -9 $PIDS 2>/dev/null || true
        sleep 1
        echo "${GREEN}✅ Stopped backend on port $PORT${NC}"
    else
        echo "▶ No backend running on port $PORT"
    fi
done

# Kill frontend on port 3000 and 3001
for PORT in 3000 3001; do
    PIDS=$(lsof -ti:$PORT 2>/dev/null || true)
    if [ -n "$PIDS" ]; then
        echo "▶ Killing frontend on port $PORT (PIDs: $PIDS)"
        kill -9 $PIDS 2>/dev/null || true
        sleep 1
        echo "${GREEN}✅ Stopped frontend on port $PORT${NC}"
    else
        echo "▶ No frontend running on port $PORT"
    fi
done

echo "${GREEN}✅ Cleanup complete${NC}"
echo ""

# Step 2: Verify ports are free
echo "${BLUE}▶ Step 2: Verifying ports are free...${NC}"
echo ""

for PORT in $BACKEND_PORT $FRONTEND_PORT; do
    if lsof -ti:$PORT >/dev/null 2>&1; then
        echo "${RED}❌ Port $PORT is still in use!${NC}"
        exit 1
    else
        echo "${GREEN}✅ Port $PORT is free${NC}"
    fi
done

echo ""

# Step 3: Create log directory
echo "${BLUE}▶ Step 3: Setting up logging...${NC}"
mkdir -p "$LOG_DIR"
echo "${GREEN}✅ Log directory: $LOG_DIR${NC}"
echo ""

# Step 4: Refresh AWS tokens
echo "${BLUE}▶ Step 4: Refreshing AWS tokens...${NC}"
if [ -f "$HOME/secgateway/bin/secgateway.py" ]; then
    python3 "$HOME/secgateway/bin/secgateway.py" >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo "${GREEN}✅ AWS tokens refreshed${NC}"
    else
        echo "${YELLOW}⚠ AWS token refresh failed (continuing anyway)${NC}"
    fi
else
    echo "${YELLOW}⚠ secgateway not found, skipping token refresh${NC}"
fi
echo ""

# Step 5: Start Backend
echo "${BLUE}▶ Step 5: Starting Backend...${NC}"
echo ""

cd "$PROJECT_ROOT"

# Check virtual environment
if [ ! -d ".venv" ]; then
    echo "${RED}❌ Virtual environment not found at $PROJECT_ROOT/.venv${NC}"
    exit 1
fi

# Load environment variables
if [ -f ".env" ]; then
    set -a
    source .env
    set +a
    echo "${GREEN}✅ Loaded environment variables from .env${NC}"
fi

# Start backend with bytecode disabled
echo "▶ Starting uvicorn on port $BACKEND_PORT..."
PYTHONDONTWRITEBYTECODE=1 nohup .venv/bin/python -B -m uvicorn app.main:app \
    --host 0.0.0.0 \
    --port $BACKEND_PORT \
    --reload \
    > "$LOG_DIR/backend.log" 2>&1 &

BACKEND_PID=$!
echo "▶ Backend started with PID: $BACKEND_PID"

# Wait for backend to start
sleep 3

# Verify backend is running
if ! ps -p $BACKEND_PID > /dev/null 2>&1; then
    echo "${RED}❌ Backend process died immediately!${NC}"
    echo "${RED}❌ Check $LOG_DIR/backend.log for errors${NC}"
    tail -50 "$LOG_DIR/backend.log"
    exit 1
fi

# Test backend health
for i in {1..10}; do
    if curl -s http://localhost:$BACKEND_PORT/rest/api/v1/health > /dev/null 2>&1; then
        echo "${GREEN}✅ Backend is responding on port $BACKEND_PORT${NC}"
        break
    fi
    if [ $i -eq 10 ]; then
        echo "${RED}❌ Backend not responding after 10 seconds${NC}"
        exit 1
    fi
    sleep 1
done

echo ""

# Step 6: Start Frontend
echo "${BLUE}▶ Step 6: Starting Frontend...${NC}"
echo ""

cd "$PROJECT_ROOT"

# Check if pnpm is available
if ! command -v pnpm &> /dev/null; then
    echo "${RED}❌ pnpm not found. Install with: npm install -g pnpm${NC}"
    exit 1
fi

# Start frontend
echo "▶ Starting Next.js on port $FRONTEND_PORT..."
cd "$PROJECT_ROOT"
NEXT_PUBLIC_API_URL="http://10.79.85.47:$BACKEND_PORT" \
nohup pnpm -C apps/chats exec next dev --hostname 0.0.0.0 --port $FRONTEND_PORT \
    > "$LOG_DIR/frontend.log" 2>&1 &

FRONTEND_PID=$!
echo "▶ Frontend started with PID: $FRONTEND_PID"

# Wait for frontend to start
sleep 5

# Verify frontend is running
if ! ps -p $FRONTEND_PID > /dev/null 2>&1; then
    echo "${YELLOW}⚠ Frontend process may have failed. Check $LOG_DIR/frontend.log${NC}"
else
    echo "${GREEN}✅ Frontend is running on port $FRONTEND_PORT${NC}"
fi

echo ""

# Step 7: Summary
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║                         STARTUP COMPLETE                                 ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "${GREEN}✅ Backend:${NC}  http://10.79.85.47:$BACKEND_PORT/rest/api/v1/health"
echo "${GREEN}✅ Frontend:${NC} http://10.79.85.47:$FRONTEND_PORT"
echo "${GREEN}✅ Logs:${NC}     $LOG_DIR/"
echo ""
echo "${BLUE}Backend PID:${NC}  $BACKEND_PID"
echo "${BLUE}Frontend PID:${NC} $FRONTEND_PID"
echo ""
echo "${YELLOW}To stop:${NC}"
echo "  kill -9 $BACKEND_PID $FRONTEND_PID"
echo ""
echo "${YELLOW}To view logs:${NC}"
echo "  tail -f $LOG_DIR/backend.log"
echo "  tail -f $LOG_DIR/frontend.log"
echo ""
