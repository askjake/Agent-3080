#!/bin/bash
# Start Coverity Assist Gateway
# Location: /home/montjac/dish-chat/start_gateway.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

GATEWAY_PID_FILE="$SCRIPT_DIR/gateway.pid"
GATEWAY_LOG="$SCRIPT_DIR/logs/gateway.log"
GATEWAY_SCRIPT="$SCRIPT_DIR/coverity_assist_gateway.py"

# Ensure logs directory exists
mkdir -p "$SCRIPT_DIR/logs"

# Check if gateway is already running
if [ -f "$GATEWAY_PID_FILE" ]; then
    OLD_PID=$(cat "$GATEWAY_PID_FILE")
    if ps -p "$OLD_PID" > /dev/null 2>&1; then
        echo "Gateway is already running (PID: $OLD_PID)"
        exit 0
    else
        echo "Removing stale PID file"
        rm -f "$GATEWAY_PID_FILE"
    fi
fi

# Start the gateway
echo "Starting Coverity Assist Gateway..."
nohup python3 "$GATEWAY_SCRIPT" >> "$GATEWAY_LOG" 2>&1 &
GATEWAY_PID=$!

# Save PID
echo "$GATEWAY_PID" > "$GATEWAY_PID_FILE"

# Wait a moment and check if it started successfully
sleep 2

if ps -p "$GATEWAY_PID" > /dev/null 2>&1; then
    echo "Gateway started successfully (PID: $GATEWAY_PID)"
    echo "Logs: $GATEWAY_LOG"
    
    # Test the health endpoint
    sleep 1
    if curl -s -f http://127.0.0.1:5000/health > /dev/null 2>&1; then
        echo "✅ Gateway health check passed"
    else
        echo "⚠️  Gateway started but health check failed (may still be initializing)"
    fi
else
    echo "❌ Gateway failed to start"
    rm -f "$GATEWAY_PID_FILE"
    exit 1
fi
