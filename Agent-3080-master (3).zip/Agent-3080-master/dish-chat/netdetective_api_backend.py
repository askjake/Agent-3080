#!/usr/bin/env python3
"""
Mock Net Detective API Backend
Provides realistic mock responses for testing the MCP integration
"""
import uvicorn
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import random
import time
from datetime import datetime

app = FastAPI(title="Net Detective API (Mock)", version="1.0.0")

# Mock ML models database
MOCK_MODELS = {
    1: {"name": "Error 1 Predictor", "accuracy": 0.89, "trained": True},
    8: {"name": "Error 8 Predictor", "accuracy": 0.92, "trained": True},
    10: {"name": "Error 10 Predictor", "accuracy": 0.87, "trained": True},
    13: {"name": "Error 13 Predictor", "accuracy": 0.91, "trained": True},
    19: {"name": "Error 19 Predictor", "accuracy": 0.88, "trained": True},
    21: {"name": "Error 21 Predictor", "accuracy": 0.90, "trained": True},
    23: {"name": "Error 23 Predictor", "accuracy": 0.85, "trained": True},
    25: {"name": "Error 25 Predictor", "accuracy": 0.93, "trained": True},
}

# Mock job storage
jobs_db = {}

class AnalysisOptions(BaseModel):
    force_refresh: bool = False
    include_plots: bool = False
    include_llm_report: bool = True

@app.get("/api/v1/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "net-detective-api",
        "version": "1.0.0-mock",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.post("/api/v1/analysis/")
async def analyze_receiver(
    rid: str = Query(..., description="Receiver ID"),
    options: AnalysisOptions = None
):
    """
    Analyze receiver network and predict errors
    Returns a mock analysis result with ML predictions
    """
    if options is None:
        options = AnalysisOptions()
    
    # Validate RID format
    clean_rid = rid.replace("R", "").strip()
    if not clean_rid.isdigit() or len(clean_rid) != 10:
        raise HTTPException(status_code=400, detail=f"Invalid RID format: {rid}")
    
    # Create mock analysis result
    analysis_result = {
        "rid": f"R{clean_rid}",
        "analysis_id": f"ANALYSIS_{int(time.time())}",
        "timestamp": datetime.utcnow().isoformat(),
        "network_health": {
            "overall_score": round(random.uniform(0.70, 0.95), 2),
            "latency_ms": random.randint(20, 150),
            "packet_loss_pct": round(random.uniform(0, 5), 2),
            "connection_stability": random.choice(["Excellent", "Good", "Fair", "Poor"])
        },
        "error_predictions": [
            {
                "error_num": err_num,
                "probability": round(random.uniform(0.05, 0.35), 3),
                "confidence": round(random.uniform(0.75, 0.95), 2),
                "severity": random.choice(["Low", "Medium", "High"])
            }
            for err_num in random.sample(list(MOCK_MODELS.keys()), 3)
        ],
        "anomalies_detected": random.randint(0, 3),
        "recommendations": [
            "Check signal strength on satellite dish alignment",
            "Monitor network latency during peak hours",
            "Verify cable connections and grounding"
        ][:random.randint(1, 3)],
        "ml_insights": {
            "models_used": len(MOCK_MODELS),
            "features_analyzed": 47,
            "data_points": random.randint(500, 2000)
        }
    }
    
    if options.include_llm_report:
        analysis_result["llm_report"] = f"""
Network Analysis Report for Receiver {clean_rid}

Overall Health Score: {analysis_result['network_health']['overall_score']}/1.0

The receiver is showing {analysis_result['network_health']['connection_stability'].lower()} connectivity 
with {analysis_result['network_health']['latency_ms']}ms average latency. 

{analysis_result['anomalies_detected']} anomalies were detected in recent network patterns.

Predicted Error Risks:
{chr(10).join([f"  - Error {p['error_num']}: {int(p['probability']*100)}% probability ({p['severity']} severity)" 
              for p in analysis_result['error_predictions']])}

Recommendations:
{chr(10).join([f"  • {rec}" for rec in analysis_result['recommendations']])}
"""
    
    return analysis_result

@app.get("/api/v1/analysis/{rid}")
async def get_cached_analysis(rid: str):
    """
    Get cached analysis result for a receiver
    """
    clean_rid = rid.replace("R", "").strip()
    
    # Simulate 50% cache hit rate
    if random.random() < 0.5:
        return {
            "rid": f"R{clean_rid}",
            "cached": True,
            "cache_age_minutes": random.randint(5, 120),
            "network_health": {
                "overall_score": round(random.uniform(0.70, 0.95), 2),
                "connection_stability": random.choice(["Excellent", "Good", "Fair"])
            },
            "last_updated": datetime.utcnow().isoformat()
        }
    else:
        raise HTTPException(
            status_code=404,
            detail={
                "error": 404,
                "message": "No analysis result found for this RID",
                "details": None
            }
        )

@app.get("/api/v1/jobs/{job_id}")
async def get_job_status(job_id: str):
    """
    Get status of an asynchronous analysis job
    """
    if job_id in jobs_db:
        return jobs_db[job_id]
    
    # Simulate job status
    statuses = ["pending", "running", "completed", "failed"]
    status = random.choice(statuses)
    
    job_info = {
        "job_id": job_id,
        "status": status,
        "progress": random.randint(0, 100) if status in ["pending", "running"] else 100,
        "created_at": datetime.utcnow().isoformat(),
        "updated_at": datetime.utcnow().isoformat()
    }
    
    if status == "completed":
        job_info["result_url"] = f"/api/v1/jobs/{job_id}/result"
    
    jobs_db[job_id] = job_info
    return job_info

@app.get("/api/v1/jobs/{job_id}/result")
async def get_job_result(job_id: str):
    """
    Get the result of a completed job
    """
    if job_id in jobs_db and jobs_db[job_id]["status"] == "completed":
        return {
            "job_id": job_id,
            "status": "completed",
            "result": {
                "analysis_summary": "Analysis completed successfully",
                "receivers_analyzed": random.randint(1, 5),
                "total_insights": random.randint(10, 50)
            }
        }
    
    raise HTTPException(status_code=404, detail="Job not found or not completed")

@app.get("/api/v1/models")
async def list_models(detailed: bool = False):
    """
    List available ML models
    """
    if detailed:
        return {
            "models": [
                {
                    "error_num": err_num,
                    **details,
                    "version": "1.0.0",
                    "last_trained": datetime.utcnow().isoformat(),
                    "features": 47,
                    "training_samples": random.randint(5000, 20000)
                }
                for err_num, details in MOCK_MODELS.items()
            ],
            "total_models": len(MOCK_MODELS)
        }
    else:
        return {
            "models": [
                {"error_num": err_num, "trained": details["trained"]}
                for err_num, details in MOCK_MODELS.items()
            ],
            "total_models": len(MOCK_MODELS)
        }

@app.get("/api/v1/models/{error_num}")
async def get_model_details(error_num: int):
    """
    Get detailed information about a specific model
    """
    if error_num not in MOCK_MODELS:
        raise HTTPException(
            status_code=404,
            detail=f"Model for error {error_num} not found"
        )
    
    model = MOCK_MODELS[error_num]
    return {
        "error_num": error_num,
        **model,
        "version": "1.0.0",
        "architecture": "XGBoost",
        "features": [f"feature_{i}" for i in range(1, 48)],
        "hyperparameters": {
            "max_depth": 6,
            "learning_rate": 0.1,
            "n_estimators": 100
        },
        "performance_metrics": {
            "precision": round(random.uniform(0.80, 0.95), 2),
            "recall": round(random.uniform(0.80, 0.95), 2),
            "f1_score": round(random.uniform(0.80, 0.95), 2),
            "roc_auc": model["accuracy"]
        },
        "training_info": {
            "samples": random.randint(5000, 20000),
            "last_trained": datetime.utcnow().isoformat(),
            "training_duration_minutes": random.randint(10, 60)
        }
    }

if __name__ == "__main__":
    print("🚀 Starting Mock Net Detective API Backend on port 8080...")
    print("📡 Health endpoint: http://localhost:8080/api/v1/health")
    print("📊 Available endpoints:")
    print("   - POST /api/v1/analysis/?rid=<RID>")
    print("   - GET  /api/v1/analysis/<RID>")
    print("   - GET  /api/v1/jobs/<job_id>")
    print("   - GET  /api/v1/jobs/<job_id>/result")
    print("   - GET  /api/v1/models")
    print("   - GET  /api/v1/models/<error_num>")
    print("   - GET  /api/v1/health")
    
    uvicorn.run(app, host="127.0.0.1", port=8080, log_level="info")
