#!/bin/bash
# Startup script for Net Detective MCP Server

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LOG_FILE="$SCRIPT_DIR/netdetective_mcp.log"
PID_FILE="$SCRIPT_DIR/netdetective_mcp.pid"

# Check if already running
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null 2>&1; then
        echo "❌ Net Detective MCP server is already running with PID $PID"
        exit 1
    else
        echo "⚠️  Stale PID file found, removing..."
        rm -f "$PID_FILE"
    fi
fi

# Check if Net Detective API is running on port 8080
if ! curl -s http://localhost:8080/api/v1/health > /dev/null; then
    echo "❌ Net Detective API is not running on port 8080"
    echo "Please start the Net Detective API first"
    exit 1
fi

# Start the server
echo "🚀 Starting Net Detective MCP Server on port 8082..."
cd "$SCRIPT_DIR"
nohup $SCRIPT_DIR/.venv/bin/python netdetective_mcp_server.py > "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

sleep 2

# Check if it started successfully
if ps -p $(cat "$PID_FILE") > /dev/null 2>&1; then
    echo "✅ Net Detective MCP server started successfully with PID $(cat $PID_FILE)"
    echo "📝 Log file: $LOG_FILE"
    echo ""
    echo "To check status: curl http://localhost:8082/health"
    echo "To view logs: tail -f $LOG_FILE"
    echo "To stop: $SCRIPT_DIR/stop_netdetective_mcp.sh"
else
    echo "❌ Failed to start MCP server"
    echo "📝 Check log file: $LOG_FILE"
    rm -f "$PID_FILE"
    exit 1
fi
