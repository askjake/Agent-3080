#!/usr/bin/env python3
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from app.db.base import Base
from app.config import get_settings

# Import models that actually exist
try:
    from app.chat.models import Chat
except: pass
try:
    from app.message.models import MessageMD
except: pass
try:
    from app.vault.models import VaultCred, VaultSession
except: pass
try:
    from app.user.models import UserState
except: pass
try:
    from app.journal.models import UserJournal
except: pass
try:
    from app.attachment.models import Attachment
except: pass
try:
    from app.chat_group.models import ChatGroup
except: pass
try:
    from app.usage_tracking.models import UsageTracking
except: pass
try:
    from app.analytics.models import ChatSummary, BackendInsight
except: pass
try:
    from app.background_mgr.models import BgTask
except: pass
try:
    from app.releases.models import Release
except: pass
try:
    from app.logs.models import LogIngestionJob
except: pass
try:
    from app.agent_mode.models import AgentModeRun
except: pass

async def init_db():
    settings = get_settings()
    print(fConnecting
