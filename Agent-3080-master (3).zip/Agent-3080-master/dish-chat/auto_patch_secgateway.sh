#!/bin/bash
set -euo pipefail

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo "========================================================================"
echo "🔧 AUTOMATED SECGATEWAY TOKEN REFRESH PATCH"
echo "========================================================================"

cd ~/dish-chat

# Backup
BACKUP="app/core/llm/chat_models.py.backup.$(date +%Y%m%d_%H%M%S)"
cp app/core/llm/chat_models.py "$BACKUP"
echo -e "${GREEN}✅ Backed up to: $BACKUP${NC}"

# Apply patch with Python
python3 << 'PYEND'
import re

file_path = "app/core/llm/chat_models.py"
with open(file_path, 'r') as f:
    content = f.read()

if '_refresh_aws_credentials_via_secgateway' in content:
    print("Already patched!")
    exit(0)

# Add imports
if 'import subprocess' not in content:
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if line.startswith('import '):
            lines.insert(i+1, 'import subprocess')
            lines.insert(i+2, 'from pathlib import Path')
            content = '\n'.join(lines)
            print("✅ Added imports")
            break

# Add function
func = """

def _refresh_aws_credentials_via_secgateway():
    from pathlib import Path
    import subprocess
    script = Path.home() / "secgateway" / "bin" / "secgateway.py"
    if not script.exists():
        logger.error(f"Secgateway not found: {script}")
        return False
    try:
        logger.info("Calling secgateway...")
        result = subprocess.run(["/usr/bin/python3", str(script)], 
                              capture_output=True, text=True, timeout=30)
        if result.returncode == 0:
            logger.info("✅ Credentials refreshed")
            import time; time.sleep(1)
            return True
        else:
            logger.error(f"Failed: {result.stderr}")
            return False
    except Exception as e:
        logger.error(f"Error: {e}")
        return False
"""

match = re.search(r'(def _read_aws_credentials_metadata.*?return.*?\n)', content, re.DOTALL)
if match:
    content = content[:match.end()] + func + content[match.end():]
    print("✅ Added function")

# Modify refresh task
old = 'logger.info("Proactively refreshing AWS tokens for all models")'
new = '''logger.info("Refreshing credentials via secgateway")
            success = await asyncio.to_thread(_refresh_aws_credentials_via_secgateway)
            if not success:
                await asyncio.sleep(300)
                continue
            logger.info("Refreshing models")'''
                
content = content.replace(old, new)
print("✅ Modified refresh task")

with open(file_path, 'w') as f:
    f.write(content)
PYEND

# Validate
python3 -m py_compile app/core/llm/chat_models.py || { echo "Syntax error!"; cp "$BACKUP" app/core/llm/chat_models.py; exit 1; }
echo -e "${GREEN}✅ Syntax valid${NC}"

# Restart
./montjac-manager.sh stop || true
sleep 2
./montjac-manager.sh start
echo -e "${GREEN}✅ Restarted${NC}"

echo ""
echo "🎉 COMPLETE! Monitor with: tail -f logs/backend.log | grep token"
