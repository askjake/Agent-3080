#!/bin/bash

echo "=== TESTING MEMORY STORAGE VIA API ==="
echo

# Get current count
BEFORE=$(PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -t -c "SELECT COUNT(*) FROM tool_executions;")
echo "Executions before: $BEFORE"
echo

# You need to use the actual chat interface or create a chat first
echo "To test properly, you need to:"
echo "1. Open the Dish-Chat web interface"
echo "2. Send a message like: \"Search for Docker container best practices\""
echo "3. Wait for response"
echo "4. Run this script again to see the count increase"
echo
echo "OR use curl with a valid chat_id (UUID format):"
echo
echo "First, list existing chats:"
curl -s http://localhost:8001/rest/api/v1/chats?namespace=generic | python3 -m json.tool | grep -E "chat_id|title" | head -20

echo
echo "Then send a message to one of those chats:"
echo "curl -X POST http://localhost:8001/rest/api/v1/chats/YOUR-CHAT-ID/messages \\"
echo "  -H \"Content-Type: application/json\" \\"
echo "  -d '{"content": "Search for Docker best practices", "namespace": "generic"}'"
echo
echo "After sending, run: bash ~/dish-chat/check_memory.sh"
