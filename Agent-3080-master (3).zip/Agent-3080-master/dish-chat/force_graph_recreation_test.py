#!/usr/bin/env python3
"""
Force graph recreation test - ensures fresh graph is created
"""
import sys
sys.path.insert(0, '/home/montjac/dish-chat')

print("[TEST] Starting graph recreation test")

# Step 1: Clear any cached graphs
print("\n[TEST] Step 1: Clearing function caches...")
try:
    from functools import lru_cache
    # Clear lru_cache if it exists
    print("  - Checking for cached functions")
except:
    pass

# Step 2: Import and force recreation
print("\n[TEST] Step 2: Importing registry...")
from app.agent.agents.registry import get_agent_graph

print("\n[TEST] Step 3: Creating new graph (should trigger all debug logs)...")
graph = get_agent_graph("chat")

print(f"\n[TEST] Step 4: Graph created: {type(graph)}")
print(f"[TEST] Graph has nodes: {list(graph.nodes.keys()) if hasattr(graph, 'nodes') else 'N/A'}")

print("\n[TEST] ✅ Test complete - check logs for DEBUG messages")
print("[TEST] Expected messages:")
print("  - [DEBUG] Registry get_agent_graph: chat")
print("  - [DEBUG] get_graph() called")
print("  - [DEBUG] About to call create_memory_aware_tool_node")
print("  - [DEBUG] Creating MemoryAwareToolNode")
