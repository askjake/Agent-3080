#!/bin/bash

##############################################################################
# KUBECTL SAFETY WARNING - HIGH
##############################################################################
# This script contains kubectl commands that can MODIFY or DELETE resources
# 
# DANGEROUS OPERATIONS DETECTED:
# - This script can affect live Kubernetes clusters
# - Changes may be irreversible
# - Always review commands before execution
#
# SAFETY CHECKLIST:
# [ ] Verified correct cluster context (kubectl config current-context)
# [ ] Reviewed all kubectl commands in this script
# [ ] Have backups of affected resources
# [ ] Tested in non-production environment first
# [ ] Notified team of planned changes
#
# To bypass this warning, set: KUBECTL_SAFETY_BYPASS=yes
#
# Tagged by: kubectl-safety-audit on 2026-02-24 15:38:15
##############################################################################

if [ "" != "yes" ]; then
    echo ""
    echo -e "\033[0;31m WARNING: This script contains kubectl commands! \033[0m"
    echo -e "\033[1;33m Risk Level: HIGH \033[0m"
    echo ""
    echo "Current cluster: sentry"
    echo ""
    echo -ne "Are you sure you want to continue? (yes/no): "
    read -r response
    if [ "" != "yes" ]; then
        echo "Aborted by user."
        exit 1
    fi
    echo ""
fi

set -e

# Dish-Chat Deployment Script
# This script builds and deploys the fixed version with:
# - Increased recursion limit (100 -> 200)
# - Production CORS enabled for chat-agent.dishtv.technology

echo "=========================================="
echo "Dish-Chat Deployment Script"
echo "=========================================="

# Configuration
ECR_REGISTRY="233532778289.dkr.ecr.us-west-2.amazonaws.com"
ECR_REPO="dish-dash-chat"
IMAGE_TAG="${1:-$(git rev-parse --short HEAD)}"
NAMESPACE="${2:-chatbot-prod}"

echo "Configuration:"
echo "  ECR Registry: $ECR_REGISTRY"
echo "  ECR Repo: $ECR_REPO"
echo "  Image Tag: $IMAGE_TAG"
echo "  Namespace: $NAMESPACE"
echo ""

# Step 1: Login to ECR
echo "Step 1: Logging in to ECR..."
aws ecr get-login-password --region us-west-2 | docker login --username AWS --password-stdin $ECR_REGISTRY
echo "✓ Logged in to ECR"
echo ""

# Step 2: Build Docker image
echo "Step 2: Building Docker image..."
cd ~/dish-chat
docker build -t $ECR_REPO:$IMAGE_TAG .
echo "✓ Docker image built"
echo ""

# Step 3: Tag and push to ECR
echo "Step 3: Tagging and pushing to ECR..."
docker tag $ECR_REPO:$IMAGE_TAG $ECR_REGISTRY/$ECR_REPO:$IMAGE_TAG
docker push $ECR_REGISTRY/$ECR_REPO:$IMAGE_TAG
echo "✓ Image pushed to ECR: $ECR_REGISTRY/$ECR_REPO:$IMAGE_TAG"
echo ""

# Step 4: Update Kubernetes deployment
echo "Step 4: Updating Kubernetes deployment..."
echo "Note: This assumes you have a deployment named 'dish-chat' in namespace '$NAMESPACE'"
echo ""
echo "You can update the deployment with:"
echo "  kubectl set image deployment/dish-chat dish-chat=$ECR_REGISTRY/$ECR_REPO:$IMAGE_TAG -n $NAMESPACE"
echo ""
echo "Or if using Kustomize/GitOps, update the image tag in your kustomization.yaml"
echo ""

# Step 5: Verification
echo "Step 5: Verification commands:"
echo "  kubectl get pods -n $NAMESPACE -l app=dish-chat"
echo "  kubectl logs -n $NAMESPACE -l app=dish-chat --tail=100 -f"
echo "  curl -I https://chat-agent.dishtv.technology/rest/api/v1/health"
echo ""

echo "=========================================="
echo "Deployment script completed!"
echo "=========================================="
echo ""
echo "IMPORTANT: Test the following after deployment:"
echo "1. No more 'Recursion limit of 100 reached' errors"
echo "2. CORS requests from https://chat-agent.dishtv.technology work"
echo "3. Application health check passes"
echo ""
