# LOGalyzer Integration Database Setup

## Tables Created

### 1. ml_models
Stores PyTorch ML models (LSTM, Random Forest, etc.)
- Model versioning with unique constraints
- BYTEA storage for serialized models
- JSONB for training metrics

### 2. log_analysis_results
Stores log analysis results
- Parsed log fields (JSONB)
- Extracted fields from 16+ regex patterns (JSONB)
- Anomaly detection scores and classifications
- Severity levels and customer-marked flags

## How to Apply Migration

**Option 1: Manual execution (recommended for first run)**
```bash
cd /home/montjac/dish-chat
psql -h <db_host> -U <db_user> -d <db_name> -f log_analysis_schema.sql
```

**Option 2: Using Python (if database config available)**
```python
import psycopg2
conn = psycopg2.connect("postgresql://user:pass@host/dbname")
with open('log_analysis_schema.sql', 'r') as f:
    conn.cursor().execute(f.read())
conn.commit()
```

## Verification

After running migration:
```sql
-- Check tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_name IN ('ml_models', 'log_analysis_results');

-- Check indexes
SELECT indexname FROM pg_indexes 
WHERE tablename IN ('ml_models', 'log_analysis_results');
```

## Rollback

To remove tables:
```sql
DROP TABLE IF EXISTS log_analysis_results CASCADE;
DROP TABLE IF EXISTS ml_models CASCADE;
```

## Safety Notes

- Uses CREATE TABLE IF NOT EXISTS (safe to re-run)
- Uses CREATE INDEX IF NOT EXISTS (idempotent)
- No data loss on re-execution
- Includes proper constraints and indexes for performance
