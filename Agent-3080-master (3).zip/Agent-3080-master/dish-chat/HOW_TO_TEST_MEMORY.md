# Memory Enhancement - Testing Guide

## 🎯 Quick Start (3 Prompts)

Use these prompts **in order** in the agent chat interface:

### 1. First Query (Cold Start)

**Expected:** Normal search response, execution stored in database

### 2. Second Query (Warm - Uses Memory)

**Expected:** Agent references the previous Docker search!
*Look for phrases like: "I see you were looking at Docker..."*

### 3. Third Query (Hot - Maximum Learning)

**Expected:** Agent connects ALL previous Docker knowledge!
*Look for: "Based on your exploration of Docker best practices and security..."*

---

## 📊 Verify It's Working

After each query, run this to see executions growing:



You'll see the execution count increase and recent queries stored!

---

## 🚀 Full Test Sequence (12 Prompts)

### Phase 1: Docker Cluster
1. 
2. 
3. 

### Phase 2: Kubernetes Cluster  
4. 
5. 
6. 

### Phase 3: Cross-Tool Memory
7. 
8. 

### Phase 4: The Big Reveal 🎯
9. 

**This query will retrieve context from BOTH Docker AND Kubernetes searches!**
The agent will demonstrate it remembers your entire learning journey!

### Phase 5: Verification
10. 
11. 
12. 

---

## ✅ What You'll See

### Query 1 (Cold Start)
- **Response:** Normal search results
- **Memory Used:** None (first query)
- **Database:** +1 execution

### Query 2 (Warm)
- **Response:** References previous Docker search
- **Memory Used:** Finds Query 1 (similarity ~0.85)
- **Database:** +1 execution
- **Phrases to look for:**
  - I see you were looking at Docker...
  - Building on your previous search...
  - You recently searched for...

### Query 3 (Hot)
- **Response:** Synthesizes multiple past searches
- **Memory Used:** Finds Queries 1 & 2 (similarity ~0.80-0.90)
- **Database:** +1 execution
- **Phrases to look for:**
  - Based on your exploration of Docker best practices, security, and...
  - Combining your research...
  - From your previous searches about...

### Query 9 (Maximum Context) 🎯
- **Response:** Comprehensive synthesis of Docker + Kubernetes
- **Memory Used:** Retrieves 6-8 related executions
- **Database:** +1 execution
- **THE MAGIC:**
  - Agent references BOTH Docker (queries 1-3) AND Kubernetes (queries 4-8)
  - Demonstrates understanding of your learning path
  - Connects Docker → Kubernetes logically
  - Shows getting smarter effect!

---

## 🔍 Advanced: Semantic Filtering Test

After completing the sequence, try a completely different topic:



**Expected:** No Docker/K8s context retrieved (different topic)

This demonstrates the memory system is **intelligent** about what context to inject!

---

## 📈 Expected Database Growth

| After Prompt | Total Executions | Topics in Memory |
|--------------|------------------|------------------|
| 1            | 6                | Docker (1)       |
| 2            | 7                | Docker (2)       |
| 3            | 8                | Docker (3)       |
| 4            | 9                | Docker (3), K8s (1) |
| 5            | 10               | Docker (3), K8s (2) |
| 9            | 14               | Docker (3), K8s (6) |

---

## 🎓 Understanding the Learning Effect

### Zero-Shot → Few-Shot Automatically

**Without Memory (Traditional):**
- Query 1: Agent has no context
- Query 2: Agent has no context
- Query 3: Agent has no context
- Each query is independent

**With Memory (Enhanced):**
- Query 1: Creates first memory (zero-shot)
- Query 2: Uses Query 1 as context (one-shot)
- Query 3: Uses Queries 1 & 2 as context (few-shot)
- Agent builds knowledge over time!

### Cross-Tool Intelligence

The system connects executions across different tools:
- **Searches** about Kubernetes
- **Cluster inspections** of namespaces
- **Both** contribute to understanding your goals

This is semantic memory at work!

---

## 🛠️ Troubleshooting

### Not seeing memory effects?

1. **Check memory is enabled:**
   
   Should show: 

2. **Check executions are being stored:**
   
   Count should increase after each query

3. **Check backend logs:**
   
   Should show no errors

### Database queries for debugging

**Count executions:**


**See latest with embeddings:**


---

## 📝 Files

- **Test Prompts:** 
- **Check Status:** 
- **This Guide:** 
- **Integration Summary:** 

---

## 🎉 Success Indicators

You'll know memory is working when:

- ✅ Agent references previous searches in responses
- ✅ Agent connects topics from different queries
- ✅ Response quality improves for related topics
- ✅ Database execution count increases
- ✅ Agent demonstrates learning across conversation
- ✅ Cross-tool connections are made (search + inspect)

**The more you use it, the smarter it gets!**

---

## 💡 Pro Tips

1. **Use similar but different queries** to see semantic matching
2. **Mix topics** to see memory clustering
3. **Ask meta-questions** (like what have I been learning?)
4. **Try cross-tool scenarios** (search + inspect same topic)
5. **Check database between queries** to see storage happening

Happy testing! 🚀
