#!/bin/bash
#
# Dish-Chat Message Content Diagnostic
# Investigates why messages show as 'thinking' instead of real content
#

set -e

cd ~/dish-chat

echo "========================================================================"
echo "DISH-CHAT MESSAGE CONTENT DIAGNOSTIC"
echo "========================================================================"
echo ""

# Check 1: CONTENT_TYPE_MAPPING configuration
echo "[1] Checking CONTENT_TYPE_MAPPING..."
echo "----------------------------------------------------------------------"
grep -A 5 "CONTENT_TYPE_MAPPING" app/core/constants.py
echo ""

# Check 2: Check if reasoning/thinking is enabled
echo "[2] Checking DEFAULT_REASONING configuration..."
echo "----------------------------------------------------------------------"
grep "DEFAULT_REASONING\|REASONING_BUDGET" app/config.py
echo ""

# Check 3: Check recent AI message content structure
echo "[3] Analyzing recent AI messages from database..."
echo "----------------------------------------------------------------------"
PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat << 'EOSQL'
SELECT 
    mm.checkpoint_id,
    mm.role,
    mm.message_config::text as config
FROM message_metadata mm
WHERE mm.role = 'AI'
ORDER BY mm.checkpoint_id DESC
LIMIT 5;
EOSQL
echo ""

# Check 4: Look for any hardcoded "thinking" strings
echo "[4] Searching for hardcoded 'thinking' strings..."
echo "----------------------------------------------------------------------"
grep -r '"thinking"\|"Thinking"\|'''thinking'''' app/message/ app/core/ --include='*.py' | grep -v '.pyc' | head -10
echo ""

# Check 5: Check extract_lc_msg_content function logic
echo "[5] Checking message content extraction logic..."
echo "----------------------------------------------------------------------"
echo "CONTENT_TYPE_MAPPING only includes:"
grep "CONTENT_TYPE_MAPPING" app/core/constants.py -A 5
echo ""
echo "Logic in extract_lc_msg_content:"
echo "  - Maps content types using CONTENT_TYPE_MAPPING"
echo "  - Ignores unmapped types with 'continue'"
echo "  - Special handling for 'reasoning_content' type"
echo ""

# Check 6: Test what content types Bedrock returns
echo "[6] Checking Bedrock extended thinking documentation..."
echo "----------------------------------------------------------------------"
echo "From langchain_aws documentation:"
echo "  Extended thinking returns content as:"
echo "  [{"
echo "      '''type''': '''reasoning_content''',"
echo "      '''reasoning_content''': {'''type''': '''text''', '''text''': '''...''', '''signature''': '''...'''}"
echo "  },"
echo "  {"
echo "      '''type''': '''text''',"
echo "      '''text''': '''The answer is...'''  "
echo "  }]"
echo ""

# Check 7: Check if messages have ONLY reasoning_content (no text)
echo "[7] Hypothesis: Messages have ONLY reasoning_content, no text block..."
echo "----------------------------------------------------------------------"
echo "If a message has:"
echo "  - reasoning_content: Mapped to 'reasoning' (shown)"
echo "  - NO text content: Nothing else to show"
echo "Result: User only sees reasoning/thinking, not the actual answer"
echo ""

# Check 8: Look for filtering logic
echo "[8] Checking if reasoning content is being filtered..."
echo "----------------------------------------------------------------------"
grep -B 3 -A 3 "reasoning\|mapped_type.*==" app/message/utils.py app/core/utils.py | head -30
echo ""

# Check 9: Proposed fix
echo "=========================================="
echo "DIAGNOSIS SUMMARY"
echo "=========================================="
echo ""
echo "LIKELY ISSUE:"
echo "  Bedrock is returning messages with extended thinking content,"
echo "  but the system is either:"
echo "    A) Showing ONLY reasoning/thinking blocks (not text)"
echo "    B) Filtering out text blocks incorrectly"
echo "    C) Frontend not rendering 'reasoning' type content properly"
echo ""
echo "VERIFICATION NEEDED:"
echo "  1. Check frontend - does it handle content type 'reasoning'?"
echo "  2. Check actual message content in checkpoint blobs"
echo "  3. Verify if reasoning mode is accidentally enabled"
echo ""
echo "QUICK CHECK - Is reasoning enabled?"
source .venv/bin/activate
python3 << 'EOPY'
import sys
sys.path.insert(0, ".")
from app.config import get_settings
settings = get_settings()
print(f"DEFAULT_REASONING: {settings.DEFAULT_REASONING}")
print(f"REASONING_BUDGET: {settings.REASONING_BUDGET}")
EOPY
deactivate
echo ""

echo "=========================================="
echo "NEXT STEPS"
echo "=========================================="
echo ""
echo "1. If DEFAULT_REASONING=True, that\'s the issue - reasoning content is enabled"
echo "2. Check frontend to see if it renders 'reasoning' type content"
echo "3. Check if messages have both reasoning_content AND text content"
echo "4. If reasoning should be hidden, filter it in extract_lc_msg_content()"
echo ""
