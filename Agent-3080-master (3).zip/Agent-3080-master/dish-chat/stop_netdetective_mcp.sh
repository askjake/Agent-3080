#!/bin/bash
# Stop script for Net Detective MCP Server

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PID_FILE="$SCRIPT_DIR/netdetective_mcp.pid"

if [ ! -f "$PID_FILE" ]; then
    echo "❌ PID file not found. Server may not be running."
    exit 1
fi

PID=$(cat "$PID_FILE")

if ps -p $PID > /dev/null 2>&1; then
    echo "🛑 Stopping Net Detective MCP Server (PID: $PID)..."
    kill $PID
    sleep 2
    
    if ps -p $PID > /dev/null 2>&1; then
        echo "⚠️  Process still running, forcing kill..."
        kill -9 $PID
    fi
    
    rm -f "$PID_FILE"
    echo "✅ Net Detective MCP server stopped"
else
    echo "❌ Process $PID is not running"
    rm -f "$PID_FILE"
fi
