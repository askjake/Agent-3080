#!/bin/bash
# Dish-Chat Fix Verification Script
# Run this after restarting the backend

echo "╔════════════════════════════════════════════════════════════════╗"
echo "║       DISH-CHAT MESSAGE CUTOFF FIX - VERIFICATION              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

cd ~/dish-chat

# Check 1: Backend running
echo "✓ Checking backend status..."
if ps aux | grep -q "[u]vicorn.*main:app.*8001"; then
    echo "  ✅ Backend is running on port 8001"
    PID=$(ps aux | grep "[u]vicorn.*main:app.*8001" | awk '{print $2}' | head -1)
    echo "  Process ID: $PID"
else
    echo "  ❌ Backend not running on port 8001!"
    exit 1
fi

echo ""

# Check 2: No "No user message found" errors since restart
echo "✓ Checking for message truncation errors..."
ERROR_COUNT=$(tail -500 logs/backend.log | grep -c "No user message found" || echo "0")
if [ "$ERROR_COUNT" -eq "0" ]; then
    echo "  ✅ No message truncation errors detected"
else
    echo "  ⚠️  WARNING: Found $ERROR_COUNT occurrences of 'No user message found'"
    echo "  Last occurrence:"
    tail -500 logs/backend.log | grep "No user message found" | tail -1
fi

echo ""

# Check 3: Human message preservation logic active
echo "✓ Checking human message preservation logic..."
PRESERVE_COUNT=$(grep -c "Preserving it +" logs/backend.log || echo "0")
if [ "$PRESERVE_COUNT" -gt "0" ]; then
    echo "  ✅ Preservation logic has activated $PRESERVE_COUNT times"
    echo "  Most recent:"
    grep "Preserving it +" logs/backend.log | tail -1
else
    echo "  ℹ️  Preservation logic not yet triggered (expected in long conversations)"
fi

echo ""

# Check 4: Memory integration status
echo "✓ Checking memory integration..."
if grep -q "MemoryAwareToolNode initialized" logs/backend.log; then
    echo "  ✅ Memory integration is enabled"
    grep "MemoryAwareToolNode" logs/backend.log | tail -2
else
    echo "  ⚠️  Memory integration not detected in logs"
fi

echo ""

# Check 5: Recent errors or exceptions
echo "✓ Checking for recent errors..."
RECENT_ERRORS=$(tail -200 logs/backend.log | grep -i "error\|exception\|critical" | grep -v "404" | wc -l)
if [ "$RECENT_ERRORS" -eq "0" ]; then
    echo "  ✅ No recent errors detected"
else
    echo "  ⚠️  Found $RECENT_ERRORS error/exception log entries"
    echo "  Last 3 errors:"
    tail -200 logs/backend.log | grep -i "error\|exception\|critical" | grep -v "404" | tail -3
fi

echo ""

# Check 6: Backend health endpoint
echo "✓ Checking backend health endpoint..."
if curl -s -f http://localhost:8001/rest/api/v1/health > /dev/null 2>&1; then
    echo "  ✅ Health endpoint responding"
else
    echo "  ❌ Health endpoint not responding!"
fi

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                    VERIFICATION COMPLETE                       ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""
echo "Next steps:"
echo "1. Test with a long conversation (100+ messages)"
echo "2. Monitor logs: tail -f ~/dish-chat/logs/backend.log"
echo "3. Watch for 'Preserving it +' messages in long conversations"
echo ""
echo "If issues persist, rollback with:"
echo "  cd ~/dish-chat"
echo "  cp app/agent/agents/agentic_rag.py.backup-20260504-073620 app/agent/agents/agentic_rag.py"
echo "  # Restart backend"
