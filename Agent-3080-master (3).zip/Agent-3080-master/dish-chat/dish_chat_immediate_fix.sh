#!/bin/bash
#
# Immediate Fix for Dish-Chat Agent Backend
# Addresses: Missing pgvector dependency
#

set -e

PROJECT_DIR="$HOME/dish-chat"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}  Dish-Chat Agent Backend - Quick Fix${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

cd "$PROJECT_DIR"

# Step 1: Install pgvector
echo -e "${GREEN}[1/4]${NC} Installing pgvector package..."
source .venv/bin/activate
pip install pgvector==0.3.6 --quiet
echo -e "${GREEN}✓${NC} pgvector installed"

# Step 2: Update requirements.txt
echo -e "${GREEN}[2/4]${NC} Updating requirements.txt..."
if ! grep -q "pgvector" requirements.txt; then
    echo "pgvector==0.3.6" >> requirements.txt
    echo -e "${GREEN}✓${NC} requirements.txt updated"
else
    echo -e "${YELLOW}✓${NC} pgvector already in requirements.txt"
fi

# Step 3: Verify .env format
echo -e "${GREEN}[3/4]${NC} Verifying environment configuration..."
if head -1 .env | grep -q "^export"; then
    echo -e "${YELLOW}⚠${NC} .env has 'export' prefix, this is OK for bash but not needed for Python"
else
    echo -e "${GREEN}✓${NC} .env format OK"
fi

# Step 4: Verify database connection
echo -e "${GREEN}[4/4]${NC} Testing database connection..."
if PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -c "SELECT COUNT(*) FROM tool_execution_memory" > /dev/null 2>&1; then
    echo -e "${GREEN}✓${NC} Database connection OK"
else
    echo -e "${RED}✗${NC} Database connection failed (service may still work)"
fi

deactivate

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  Fix Applied Successfully!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "NEXT STEPS:"
echo "  1. Restart the service (if running)"
echo "  2. Monitor logs for any vector-related errors"
echo "  3. Test memory system functionality"
echo ""
echo "To restart service:"
echo "  pkill -f 'uvicorn.*8001'"
echo "  cd $PROJECT_DIR && source .venv/bin/activate"
echo "  nohup python -m uvicorn app.main:app --host 0.0.0.0 --port 8001 > logs/backend.log 2>&1 &"
echo ""
