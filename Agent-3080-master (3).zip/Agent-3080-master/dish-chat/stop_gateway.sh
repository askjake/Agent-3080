#!/bin/bash
# Stop Coverity Assist Gateway
# Location: /home/montjac/dish-chat/stop_gateway.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GATEWAY_PID_FILE="$SCRIPT_DIR/gateway.pid"

if [ ! -f "$GATEWAY_PID_FILE" ]; then
    echo "Gateway PID file not found. Gateway may not be running."
    exit 0
fi

GATEWAY_PID=$(cat "$GATEWAY_PID_FILE")

if ps -p "$GATEWAY_PID" > /dev/null 2>&1; then
    echo "Stopping gateway (PID: $GATEWAY_PID)..."
    kill "$GATEWAY_PID"
    
    # Wait for graceful shutdown
    for i in {1..10}; do
        if ! ps -p "$GATEWAY_PID" > /dev/null 2>&1; then
            echo "✅ Gateway stopped successfully"
            rm -f "$GATEWAY_PID_FILE"
            exit 0
        fi
        sleep 1
    done
    
    # Force kill if still running
    echo "Gateway didn't stop gracefully, forcing..."
    kill -9 "$GATEWAY_PID" 2>/dev/null
    rm -f "$GATEWAY_PID_FILE"
    echo "✅ Gateway force-stopped"
else
    echo "Gateway process (PID: $GATEWAY_PID) not found"
    rm -f "$GATEWAY_PID_FILE"
fi
