#!/usr/bin/env python3
"""
Comprehensive Memory System Debug Script
Tests each component individually to isolate the issue
"""
import sys
import os
import asyncio
from pathlib import Path

# Add dish-chat to path
sys.path.insert(0, str(Path(__file__).parent))

print("="*80)
print("MEMORY SYSTEM COMPREHENSIVE DEBUG")
print("="*80)
print()

# Test 1: Import context_injection
print("[TEST 1] Importing context_injection module...")
try:
    from app.agent.context_injection import create_memory_aware_tool_node, MemoryAwareToolNode
    print("✅ PASS: context_injection imported successfully")
    print(f"   - create_memory_aware_tool_node: {create_memory_aware_tool_node}")
    print(f"   - MemoryAwareToolNode: {MemoryAwareToolNode}")
except Exception as e:
    print(f"❌ FAIL: {e}")
    sys.exit(1)
print()

# Test 2: Check memory system configuration
print("[TEST 2] Checking memory system configuration...")
try:
    from app.config import get_settings
    settings = get_settings()
    print(f"✅ PASS: Settings loaded")
    print(f"   - ENABLE_MEMORY_INTEGRATION: {settings.ENABLE_MEMORY_INTEGRATION}")
except Exception as e:
    print(f"❌ FAIL: {e}")
print()

# Test 3: Get memory service
print("[TEST 3] Importing memory service...")
try:
    from app.core.memory.tool_memory_service import get_tool_memory_service
    service = get_tool_memory_service()
    print(f"✅ PASS: Memory service obtained")
    print(f"   - Enabled: {service.enabled}")
    print(f"   - Health: {service.get_health()}")
except Exception as e:
    print(f"❌ FAIL: {e}")
print()

# Test 4: Create a mock tool and MemoryAwareToolNode
print("[TEST 4] Creating MemoryAwareToolNode with mock tools...")
try:
    from langchain_core.tools import tool
    
    @tool
    def test_tool(query: str) -> str:
        """A test tool"""
        return f"Test result for: {query}"
    
    node = create_memory_aware_tool_node([test_tool])
    print(f"✅ PASS: MemoryAwareToolNode created")
    print(f"   - Type: {type(node)}")
    print(f"   - Is MemoryAwareToolNode: {isinstance(node, MemoryAwareToolNode)}")
    print(f"   - Has memory_integration: {hasattr(node, 'memory_integration')}")
except Exception as e:
    print(f"❌ FAIL: {e}")
    import traceback
    traceback.print_exc()
print()

# Test 5: Check if agentic_rag imports correctly
print("[TEST 5] Importing agentic_rag module...")
try:
    from app.agent.agents import agentic_rag
    print(f"✅ PASS: agentic_rag imported")
    print(f"   - Has get_graph: {hasattr(agentic_rag, 'get_graph')}")
    print(f"   - Has create_memory_aware_tool_node import: {'create_memory_aware_tool_node' in dir(agentic_rag)}")
except Exception as e:
    print(f"❌ FAIL: {e}")
    import traceback
    traceback.print_exc()
print()

# Test 6: Check the actual source code
print("[TEST 6] Verifying source code integration...")
try:
    import inspect
    source = inspect.getsource(agentic_rag.get_graph)
    
    has_import = "create_memory_aware_tool_node" in source
    has_usage = "create_memory_aware_tool_node(tools)" in source
    
    print(f"✅ Code inspection complete")
    print(f"   - Has create_memory_aware_tool_node in source: {has_import}")
    print(f"   - Has create_memory_aware_tool_node(tools) call: {has_usage}")
    
    if has_usage:
        # Find the line
        for i, line in enumerate(source.split(n), 1):
            if "create_memory_aware_tool_node" in line:
                print(f"   - Line {i}: {line.strip()}")
except Exception as e:
    print(f"❌ FAIL: {e}")
print()

# Test 7: Test manual storage
print("[TEST 7] Testing manual storage...")
async def test_storage():
    try:
        from app.core.memory.tool_memory_service import get_tool_memory_service
        service = get_tool_memory_service()
        
        # Enable if not enabled
        if not service.enabled:
            service.enable()
            print(f"   - Enabled memory service")
        
        # Try to store
        exec_id = await service.store_execution(
            tool_name="debug_test_tool",
            tool_parameters={"query": "debug test"},
            tool_output="Debug test output",
            user_query="Debug test query",
            success=True
        )
        
        print(f"✅ PASS: Storage successful")
        print(f"   - Execution ID: {exec_id}")
        
        # Get stats
        stats = await service.get_statistics()
        print(f"   - Total executions: {stats.get('total_executions', 'N/A')}")
        
        return exec_id
    except Exception as e:
        print(f"❌ FAIL: {e}")
        import traceback
        traceback.print_exc()
        return None

exec_id = asyncio.run(test_storage())
print()

# Test 8: Database check
print("[TEST 8] Checking database directly...")
try:
    import asyncpg
    import os
    
    # Get database URL from settings
    from app.config import get_settings
    settings = get_settings()
    
    async def check_db():
        try:
            # Parse connection info
            conn = await asyncpg.connect(
                host="127.0.0.1",
                port=5434,
                database="dishchat",
                user="dev_user",
                password="dev123"
            )
            
            # Count executions
            count = await conn.fetchval("SELECT COUNT(*) FROM tool_executions")
            print(f"✅ PASS: Database accessible")
            print(f"   - Total executions in DB: {count}")
            
            # Get latest
            latest = await conn.fetchrow(
                "SELECT id, tool_name, created_at FROM tool_executions ORDER BY id DESC LIMIT 1"
            )
            if latest:
                print(f"   - Latest execution: ID={latest['id']}, tool={latest['tool_name']}, time={latest['created_at']}")
            
            await conn.close()
            return count
        except Exception as e:
            print(f"❌ FAIL: {e}")
            return None
    
    count = asyncio.run(check_db())
except Exception as e:
    print(f"❌ FAIL: {e}")
    import traceback
    traceback.print_exc()
print()

# Test 9: Try to create graph and inspect it
print("[TEST 9] Creating graph and inspecting node...")
try:
    # This might fail due to checkpointer, but let's try
    print("   - Attempting to create graph...")
    print("   - (This may fail due to checkpointer issues, that's OK)")
    
    # We can't easily test this without the full environment
    # So let's just verify the function exists
    from app.agent.agents.agentic_rag import get_graph
    print(f"✅ PASS: get_graph function exists")
    print(f"   - Note: Cannot test graph creation without full environment")
    
except Exception as e:
    print(f"⚠️  INFO: {e}")
print()

# Final Summary
print("="*80)
print("SUMMARY")
print("="*80)
print()
print("If all tests passed, the integration is correct.")
print("If storage test passed, memory system works.")
print()
print("If memory count in database increased, the system is functional.")
print("If it didn't increase during actual tool execution, there's a runtime issue.")
print()
print("Next steps:")
print("1. Check if backend is using the updated code")
print("2. Verify graph is being recreated (not cached)")
print("3. Test with actual agent execution")
print("="*80)
