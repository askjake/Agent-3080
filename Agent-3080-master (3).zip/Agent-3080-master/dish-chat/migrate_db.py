#!/usr/bin/env python3
"""
Database migration script for Memory Enhancement.
Creates necessary tables with pgvector support.
"""
import asyncio
import sys
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker


async def migrate_database(database_url: str) -> bool:
    """
    Run database migration to create memory tables.
    
    Args:
        database_url: PostgreSQL connection string
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Create async engine
        engine = create_async_engine(database_url, echo=True)
        
        async with engine.begin() as conn:
            # Enable pgvector extension
            print("\n=== Enabling pgvector extension ===")
            await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
            print("✅ pgvector extension enabled")
            
            # Create tool_executions table
            print("\n=== Creating tool_executions table ===")
            create_table_sql = """
            CREATE TABLE IF NOT EXISTS tool_executions (
                id SERIAL PRIMARY KEY,
                tool_name VARCHAR(255) NOT NULL,
                tool_parameters JSONB NOT NULL,
                tool_output TEXT NOT NULL,
                embedding vector(384),
                metadata_ JSONB,
                user_query TEXT,
                success BOOLEAN DEFAULT true,
                execution_time FLOAT,
                error_message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """
            await conn.execute(text(create_table_sql))
            print("✅ tool_executions table created")
            
            # Create indexes
            print("\n=== Creating indexes ===")
            
            # Index on tool_name for faster filtering
            await conn.execute(text(
                "CREATE INDEX IF NOT EXISTS idx_tool_executions_tool_name "
                "ON tool_executions(tool_name);"
            ))
            print("✅ Index on tool_name created")
            
            # Index on created_at for time-based queries
            await conn.execute(text(
                "CREATE INDEX IF NOT EXISTS idx_tool_executions_created_at "
                "ON tool_executions(created_at DESC);"
            ))
            print("✅ Index on created_at created")
            
            # Index on success for filtering
            await conn.execute(text(
                "CREATE INDEX IF NOT EXISTS idx_tool_executions_success "
                "ON tool_executions(success);"
            ))
            print("✅ Index on success created")
            
            # Vector similarity index (using HNSW for fast similarity search)
            await conn.execute(text(
                "CREATE INDEX IF NOT EXISTS idx_tool_executions_embedding "
                "ON tool_executions USING hnsw (embedding vector_cosine_ops);"
            ))
            print("✅ Vector similarity index created")
            
            print("\n=== Migration completed successfully ===")
            return True
            
    except Exception as e:
        print(f"\n❌ Migration failed: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return False
    finally:
        await engine.dispose()


async def verify_migration(database_url: str) -> bool:
    """
    Verify that migration was successful.
    
    Args:
        database_url: PostgreSQL connection string
        
    Returns:
        True if verification passed, False otherwise
    """
    try:
        engine = create_async_engine(database_url, echo=False)
        
        async with engine.begin() as conn:
            # Check if table exists
            result = await conn.execute(text("""
                SELECT EXISTS (
                    SELECT FROM information_schema.tables 
                    WHERE table_name = 'tool_executions'
                );
            """))
            table_exists = result.scalar()
            
            if not table_exists:
                print("❌ Verification failed: tool_executions table not found")
                return False
            
            # Check if pgvector extension is enabled
            result = await conn.execute(text("""
                SELECT EXISTS (
                    SELECT FROM pg_extension 
                    WHERE extname = 'vector'
                );
            """))
            vector_enabled = result.scalar()
            
            if not vector_enabled:
                print("❌ Verification failed: pgvector extension not enabled")
                return False
            
            # Check indexes
            result = await conn.execute(text("""
                SELECT indexname FROM pg_indexes 
                WHERE tablename = 'tool_executions';
            """))
            indexes = [row[0] for row in result.fetchall()]
            
            expected_indexes = [
                'idx_tool_executions_tool_name',
                'idx_tool_executions_created_at',
                'idx_tool_executions_success',
                'idx_tool_executions_embedding'
            ]
            
            for idx in expected_indexes:
                if idx not in indexes:
                    print(f"⚠️  Warning: Index {idx} not found")
            
            print("\n✅ Migration verification passed")
            print(f"   - Table: tool_executions ✓")
            print(f"   - Extension: pgvector ✓")
            print(f"   - Indexes: {len(indexes)} found")
            
            return True
            
    except Exception as e:
        print(f"\n❌ Verification failed: {e}", file=sys.stderr)
        return False
    finally:
        await engine.dispose()


async def main():
    """Main migration function."""
    import os
    
    # Get database URL from environment or use default
    database_url = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://postgres:postgres@localhost:5432/dish_chat"
    )
    
    print("=== Memory Enhancement Database Migration ===")
    print(f"Database: {database_url.split('@')[1] if '@' in database_url else 'localhost'}")
    print()
    
    # Run migration
    success = await migrate_database(database_url)
    
    if not success:
        print("\n❌ Migration failed")
        sys.exit(1)
    
    # Verify migration
    print("\n=== Verifying migration ===")
    verified = await verify_migration(database_url)
    
    if not verified:
        print("\n⚠️  Migration completed but verification failed")
        sys.exit(1)
    
    print("\n✅ Migration and verification completed successfully")
    print("\nNext steps:")
    print("  1. Restart the backend: systemctl restart dish-chat-backend")
    print("  2. Enable memory: export ENABLE_MEMORY_INTEGRATION=true")
    print("  3. Test: curl http://localhost:8000/health")


if __name__ == "__main__":
    asyncio.run(main())
