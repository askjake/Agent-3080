#!/bin/bash
# Quick script to check memory system status

echo "========================================"
echo "MEMORY SYSTEM STATUS"
echo "========================================"
echo

# Check total executions
echo "Total Executions Stored:"
PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat -t -c \
  "SELECT COUNT(*) FROM tool_executions;"
echo

# Show recent executions
echo "Recent Executions (Last 10):"
PGPASSWORD=dev123 psql -h 127.0.0.1 -p 5434 -U dev_user -d dishchat << SQL
SELECT 
  id, 
  tool_name,
  LEFT(COALESCE(tool_parameters->>'query', 'N/A'), 50) as query_preview,
  success,
  TO_CHAR(created_at, 'HH24:MI:SS') as time
FROM tool_executions 
ORDER BY id DESC 
LIMIT 10;
SQL

echo
echo "========================================"
echo "Use: bash ~/dish-chat/check_memory.sh"
echo "========================================"
