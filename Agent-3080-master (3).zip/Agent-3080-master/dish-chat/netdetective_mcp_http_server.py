#!/usr/bin/env python3
"""
MCP HTTP Server wrapper for Net Detective API
Exposes Net Detective functionality through the Model Context Protocol over HTTP
"""
import asyncio
import httpx
import json
import logging
from fastapi import FastAPI, Request, Response
from fastapi.responses import StreamingResponse, JSONResponse
from typing import Any, AsyncGenerator
import uvicorn

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("netdetective-mcp-http")

# Net Detective API base URL
NET_DETECTIVE_BASE_URL = "http://localhost:8080/api/v1"

app = FastAPI(title="Net Detective MCP Server")

# MCP Protocol Implementation
MCP_TOOLS = [
    {
        "name": "analyze_receiver_network",
        "description": "Analyze network health and predict errors for a receiver ID (RID). "
                      "Returns ML-powered insights including multi-error analysis, anomaly detection, "
                      "and network diagnostic recommendations. "
                      "Requires a 10-digit receiver ID (with or without 'R' prefix).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "rid": {
                    "type": "string",
                    "description": "Receiver ID (10 digits, optionally prefixed with 'R')",
                    "pattern": "^R?\\d{10}$"
                },
                "force_refresh": {
                    "type": "boolean",
                    "description": "Force new analysis instead of using cached results",
                    "default": False
                },
                "include_plots": {
                    "type": "boolean",
                    "description": "Include visualization plots in results",
                    "default": False
                },
                "include_llm_report": {
                    "type": "boolean",
                    "description": "Include LLM-generated summary report",
                    "default": True
                }
            },
            "required": ["rid"]
        }
    },
    {
        "name": "get_cached_analysis",
        "description": "Retrieve previously cached analysis results for a receiver ID. "
                      "Much faster than running a new analysis. Returns 404 if no cache exists.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "rid": {
                    "type": "string",
                    "description": "Receiver ID (10 digits, optionally prefixed with 'R')",
                    "pattern": "^R?\\d{10}$"
                }
            },
            "required": ["rid"]
        }
    },
    {
        "name": "get_job_status",
        "description": "Check the status of an asynchronous analysis job. "
                      "Use this to poll for completion after starting an analysis.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Job ID returned from analyze_receiver_network"
                }
            },
            "required": ["job_id"]
        }
    },
    {
        "name": "get_job_result",
        "description": "Retrieve the full result of a completed analysis job. "
                      "Only works when job status is 'completed'.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "job_id": {
                    "type": "string",
                    "description": "Job ID of completed analysis"
                }
            },
            "required": ["job_id"]
        }
    },
    {
        "name": "list_ml_models",
        "description": "List available ML models and their status. "
                      "Shows which error types have trained models available. "
                      "Error types: 1, 8, 10, 13, 19, 21, 23, 25",
        "inputSchema": {
            "type": "object",
            "properties": {
                "detailed": {
                    "type": "boolean",
                    "description": "Include detailed metrics and training info",
                    "default": False
                }
            }
        }
    },
    {
        "name": "get_model_details",
        "description": "Get detailed information about a specific error prediction model, "
                      "including training metrics, feature importance, and performance stats.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "error_num": {
                    "type": "integer",
                    "description": "Error number (1, 8, 10, 13, 19, 21, 23, or 25)",
                    "enum": [1, 8, 10, 13, 19, 21, 23, 25]
                }
            },
            "required": ["error_num"]
        }
    },
    {
        "name": "health_check",
        "description": "Check if Net Detective service is healthy and get version information.",
        "inputSchema": {
            "type": "object",
            "properties": {}
        }
    }
]

async def call_api(method: str, endpoint: str, **kwargs) -> dict:
    """Make an HTTP request to the Net Detective API."""
    url = f"{NET_DETECTIVE_BASE_URL}{endpoint}"
    async with httpx.AsyncClient(timeout=60.0) as client:
        try:
            if method == "GET":
                response = await client.get(url, **kwargs)
            elif method == "POST":
                response = await client.post(url, **kwargs)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error {e.response.status_code}: {e.response.text}")
            return {
                "error": f"API returned {e.response.status_code}",
                "detail": e.response.text
            }
        except Exception as e:
            logger.error(f"Request failed: {e}")
            return {"error": str(e)}

async def handle_tool_call(tool_name: str, arguments: dict) -> dict:
    """Execute a tool call and return the result."""
    try:
        if tool_name == "analyze_receiver_network":
            rid = arguments["rid"]
            options = {
                "force_refresh": arguments.get("force_refresh", False),
                "include_plots": arguments.get("include_plots", False),
                "include_llm_report": arguments.get("include_llm_report", True)
            }
            
            result = await call_api(
                "POST",
                "/analysis/",
                params={"rid": rid},
                json=options
            )
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "get_cached_analysis":
            rid = arguments["rid"]
            result = await call_api("GET", f"/analysis/{rid}")
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "get_job_status":
            job_id = arguments["job_id"]
            result = await call_api("GET", f"/jobs/{job_id}")
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "get_job_result":
            job_id = arguments["job_id"]
            result = await call_api("GET", f"/jobs/{job_id}/result")
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "list_ml_models":
            detailed = arguments.get("detailed", False)
            result = await call_api("GET", "/models", params={"detailed": detailed})
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "get_model_details":
            error_num = arguments["error_num"]
            result = await call_api("GET", "/models", params={"error_num": error_num, "detailed": True})
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "health_check":
            result = await call_api("GET", "/health")
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        else:
            return {"content": [{"type": "text", "text": json.dumps({"error": f"Unknown tool: {tool_name}"})}]}
    
    except Exception as e:
        logger.error(f"Tool execution failed: {e}", exc_info=True)
        return {"content": [{"type": "text", "text": json.dumps({"error": str(e)})}]}

async def generate_sse_messages(messages: list[dict]) -> AsyncGenerator[str, None]:
    """Generate Server-Sent Events from messages."""
    for message in messages:
        data = json.dumps(message)
        yield f"data: {data}\n\n"

@app.post("/mcp")
async def mcp_endpoint(request: Request):
    """Handle MCP protocol requests."""
    try:
        body = await request.json()
        method = body.get("method")
        
        logger.info(f"Received MCP request: {method}")
        
        if method == "initialize":
            response = {
                "jsonrpc": "2.0",
                "id": body.get("id"),
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {
                        "tools": {}
                    },
                    "serverInfo": {
                        "name": "netdetective",
                        "version": "1.0.0"
                    }
                }
            }
            
        elif method == "tools/list":
            response = {
                "jsonrpc": "2.0",
                "id": body.get("id"),
                "result": {
                    "tools": MCP_TOOLS
                }
            }
        
        elif method == "tools/call":
            params = body.get("params", {})
            tool_name = params.get("name")
            arguments = params.get("arguments", {})
            
            result = await handle_tool_call(tool_name, arguments)
            
            response = {
                "jsonrpc": "2.0",
                "id": body.get("id"),
                "result": result
            }
        
        else:
            response = {
                "jsonrpc": "2.0",
                "id": body.get("id"),
                "error": {
                    "code": -32601,
                    "message": f"Method not found: {method}"
                }
            }
        
        # Check if streaming is requested
        accept_header = request.headers.get("accept", "")
        if "text/event-stream" in accept_header:
            messages = [response]
            return StreamingResponse(
                generate_sse_messages(messages),
                media_type="text/event-stream"
            )
        else:
            return JSONResponse(response)
    
    except Exception as e:
        logger.error(f"Error handling request: {e}", exc_info=True)
        return JSONResponse({
            "jsonrpc": "2.0",
            "id": body.get("id") if "body" in locals() else None,
            "error": {
                "code": -32603,
                "message": str(e)
            }
        }, status_code=500)

@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "service": "netdetective-mcp"}

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8082, log_level="info")
