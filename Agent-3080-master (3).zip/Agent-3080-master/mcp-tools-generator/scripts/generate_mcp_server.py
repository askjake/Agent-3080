#!/usr/bin/env python3
"""
MCP Server Generator

Generates a complete MCP server from a configuration file or interactive prompts.

Usage:
    python generate_mcp_server.py --config myservice.yaml
    python generate_mcp_server.py --interactive
"""

import os
import sys
import argparse
import yaml
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List

class MCPServerGenerator:
    """Generate MCP server from configuration."""
    
    def __init__(self, output_dir: str = "."):
        self.output_dir = Path(output_dir)
        self.templates_dir = Path(__file__).parent.parent / "templates"
        
    def generate_from_config(self, config_path: str):
        """Generate MCP server from YAML config file."""
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        self._generate_server(config)
    
    def generate_interactive(self):
        """Generate MCP server from interactive prompts."""
        print("╔═══════════════════════════════════════════════════════════╗")
        print("║       MCP Server Generator - Interactive Mode             ║")
        print("╚═══════════════════════════════════════════════════════════╝")
        print()
        
        config = {}
        
        # Basic info
        config['service_name'] = input("Service name (e.g., 'GitHub'): ").strip()
        config['service_name_lower'] = config['service_name'].lower().replace(' ', '_')
        config['service_description'] = input("Description: ").strip()
        
        # Authentication
        print("\nAuthentication type:")
        print("  1. None")
        print("  2. API Key (Bearer token)")
        print("  3. Basic Auth (username + password)")
        print("  4. OAuth")
        auth_choice = input("Choose (1-4): ").strip()
        
        auth_types = {
            '1': 'none',
            '2': 'bearer',
            '3': 'basic',
            '4': 'oauth'
        }
        config['auth_type'] = auth_types.get(auth_choice, 'none')
        
        # API endpoint
        config['api_base_url'] = input("\nAPI base URL: ").strip()
        
        # Tools
        print("\nHow many tools to create?")
        num_tools = int(input("Number of tools: ").strip() or "1")
        
        config['tools'] = []
        for i in range(num_tools):
            print(f"\n--- Tool {i+1} ---")
            tool = {
                'name': input("  Tool name (e.g., 'search_items'): ").strip(),
                'description': input("  Short description: ").strip(),
                'endpoint': input("  API endpoint path: ").strip(),
                'method': input("  HTTP method (GET/POST): ").strip().upper() or "GET",
            }
            
            # Parameters
            print("  Parameters (one per line, empty to finish):")
            tool['parameters'] = []
            while True:
                param_name = input("    Parameter name: ").strip()
                if not param_name:
                    break
                param_type = input("    Type (str/int/bool): ").strip() or "str"
                param_required = input("    Required? (y/n): ").strip().lower() == 'y'
                param_default = input("    Default value (or empty): ").strip() or None
                
                tool['parameters'].append({
                    'name': param_name,
                    'type': param_type,
                    'required': param_required,
                    'default': param_default
                })
            
            config['tools'].append(tool)
        
        self._generate_server(config)
    
    def _generate_server(self, config: Dict[str, Any]):
        """Generate all files for the MCP server."""
        service_name = config['service_name']
        service_name_lower = config.get('service_name_lower', service_name.lower().replace(' ', '_'))
        
        # Create output directory
        output_dir = self.output_dir / f"{service_name_lower}-mcp-server"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        print(f"\n📁 Generating in: {output_dir}")
        
        # Generate server.py
        self._generate_server_py(output_dir, config)
        
        # Generate Dockerfile
        self._generate_dockerfile(output_dir, config)
        
        # Generate requirements.txt
        self._generate_requirements(output_dir, config)
        
        # Generate .env.example
        self._generate_env_example(output_dir, config)
        
        # Generate deploy_direct.sh
        self._generate_deploy_script(output_dir, config)
        
        # Generate README.md
        self._generate_readme(output_dir, config)
        
        # Generate test.sh
        self._generate_test_script(output_dir, config)
        
        print(f"\n✅ MCP server generated successfully!")
        print(f"\n📂 Next steps:")
        print(f"   cd {output_dir}")
        print(f"   # Edit server.py to customize")
        print(f"   ./deploy_direct.sh")
    
    def _generate_server_py(self, output_dir: Path, config: Dict[str, Any]):
        """Generate server.py file."""
        service_name = config['service_name']
        
        # Generate environment variables section
        env_vars = self._generate_env_vars(config)
        
        # Generate authentication section
        auth_section = self._generate_auth_section(config)
        
        # Generate tools section
        tools_section = self._generate_tools_section(config)
        
        # Load template
        template_path = self.templates_dir / "server.py.template"
        with open(template_path, 'r') as f:
            template = f.read()
        
        # Replace placeholders
        content = template.replace('{{SERVICE_NAME}}', service_name)
        content = content.replace('{{service_description}}', config.get('service_description', ''))
        content = content.replace('{{generation_date}}', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        content = content.replace('{{env_var_section}}', env_vars)
        content = content.replace('{{auth_section}}', auth_section)
        content = content.replace('{{tools_section}}', tools_section)
        content = content.replace('{{use_case_1}}', config.get('use_cases', ['Find information'])[0] if config.get('use_cases') else 'Find information')
        content = content.replace('{{use_case_2}}', config.get('use_cases', ['', 'Search data'])[1] if len(config.get('use_cases', [])) > 1 else 'Search data')
        content = content.replace('{{use_case_3}}', config.get('use_cases', ['', '', 'Query resources'])[2] if len(config.get('use_cases', [])) > 2 else 'Query resources')
        content = content.replace('{{tip_1}}', 'Start with broad queries')
        content = content.replace('{{tip_2}}', 'Refine based on results')
        content = content.replace('{{tip_3}}', 'Check returned URLs for details')
        content = content.replace('{{access_note}}', 'This provides read-only access')
        
        # Write file
        output_path = output_dir / "server.py"
        with open(output_path, 'w') as f:
            f.write(content)
        
        print(f"  ✓ server.py")
    
    def _generate_env_vars(self, config: Dict[str, Any]) -> str:
        """Generate environment variables section."""
        service_name_upper = config['service_name'].upper().replace(' ', '_')
        
        lines = []
        
        # Base URL
        if config.get('api_base_url'):
            lines.append(f'{service_name_upper}_BASE_URL = os.getenv("{service_name_upper}_BASE_URL", "{config["api_base_url"]}")')
        
        # Auth variables
        auth_type = config.get('auth_type', 'none')
        if auth_type == 'bearer':
            lines.append(f'{service_name_upper}_API_KEY = os.getenv("{service_name_upper}_API_KEY")')
        elif auth_type == 'basic':
            lines.append(f'{service_name_upper}_USER = os.getenv("{service_name_upper}_USER")')
            lines.append(f'{service_name_upper}_PASSWORD = os.getenv("{service_name_upper}_PASSWORD")')
        
        return '\n'.join(lines)
    
    def _generate_auth_section(self, config: Dict[str, Any]) -> str:
        """Generate authentication helper function."""
        auth_type = config.get('auth_type', 'none')
        service_name_upper = config['service_name'].upper().replace(' ', '_')
        
        if auth_type == 'none':
            return """if True:
        return None, None"""
        
        elif auth_type == 'bearer':
            return f"""api_key = {service_name_upper}_API_KEY
    if not api_key:
        return None, None
    return 'bearer', api_key"""
        
        elif auth_type == 'basic':
            return f"""user = {service_name_upper}_USER
    password = {service_name_upper}_PASSWORD
    if not (user and password):
        return None, None
    return 'basic', httpx.BasicAuth(user, password)"""
        
        return "return None, None"
    
    def _generate_tools_section(self, config: Dict[str, Any]) -> str:
        """Generate tools section."""
        tools = config.get('tools', [])
        if not tools:
            # Generate a default search tool
            tools = [{
                'name': 'search',
                'description': 'Search the service',
                'endpoint': '/search',
                'method': 'GET',
                'parameters': [
                    {'name': 'query', 'type': 'str', 'required': True},
                    {'name': 'limit', 'type': 'int', 'required': False, 'default': 5}
                ]
            }]
        
        tool_codes = []
        for tool in tools:
            tool_codes.append(self._generate_single_tool(tool, config))
        
        return '\n\n'.join(tool_codes)
    
    def _generate_single_tool(self, tool: Dict[str, Any], config: Dict[str, Any]) -> str:
        """Generate code for a single tool."""
        service_name_upper = config['service_name'].upper().replace(' ', '_')
        
        # Parameters
        params = []
        for p in tool.get('parameters', []):
            param_str = f"{p['name']}: {p['type']}"
            if not p.get('required', True) and p.get('default') is not None:
                if p['type'] == 'str':
                    param_str += f' = "{p["default"]}"'
                else:
                    param_str += f' = {p["default"]}'
            params.append(param_str)
        
        params_str = ', '.join(params)
        
        # Build tool code
        code = f'''@mcp.tool()
async def {tool['name']}({params_str}) -> str:
    """
    {tool.get('description', 'Tool description')}
    
    Args:'''
        
        for p in tool.get('parameters', []):
            code += f'\n        {p["name"]}: {p.get("description", f"{p["name"]} parameter")}'
        
        code += '''
    
    Returns:
        Formatted string with results
    """'''
        
        code += f'''
    logger.info(f"{tool['name']} called")
    
    # Get authentication
    auth_type, auth_value = get_auth()
    
    try:
        async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
            # Prepare request
            url = f"{{{service_name_upper}_BASE_URL}}{tool['endpoint']}"
            '''
        
        # Add method-specific code
        if tool.get('method', 'GET') == 'GET':
            code += f'''
            params = {{{', '.join([f'"{p["name"]}": {p["name"]}' for p in tool.get('parameters', [])])}}}
            
            # Make request
            if auth_type == 'bearer':
                headers = {{"Authorization": f"Bearer {{auth_value}}"}}
                resp = await client.get(url, params=params, headers=headers)
            elif auth_type == 'basic':
                resp = await client.get(url, params=params, auth=auth_value)
            else:
                resp = await client.get(url, params=params)'''
        else:  # POST
            code += f'''
            data = {{{', '.join([f'"{p["name"]}": {p["name"]}' for p in tool.get('parameters', [])])}}}
            
            # Make request
            if auth_type == 'bearer':
                headers = {{"Authorization": f"Bearer {{auth_value}}"}}
                resp = await client.post(url, json=data, headers=headers)
            elif auth_type == 'basic':
                resp = await client.post(url, json=data, auth=auth_value)
            else:
                resp = await client.post(url, json=data)'''
        
        code += '''
            
            resp.raise_for_status()
            data = resp.json()
        
        # Format response
        # TODO: Customize this based on your API response structure
        results = data.get('results', []) or data.get('items', []) or []
        
        if not results:
            return "No results found"
        
        output_lines = [f"Found {len(results)} result(s):\\n"]
        for i, item in enumerate(results[:10], 1):
            title = item.get('title') or item.get('name') or item.get('id', 'Item')
            output_lines.append(f"{i}. {title}")
            if 'url' in item:
                output_lines.append(f"   URL: {item['url']}")
            output_lines.append("")
        
        return "\\n".join(output_lines)
    
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code}")
        if e.response.status_code == 401:
            return "Error: Authentication failed"
        elif e.response.status_code == 403:
            return "Error: Access forbidden"
        return f"Error: Request failed with status {e.response.status_code}"
    
    except httpx.TimeoutException:
        return f"Error: Request timed out after {DEFAULT_TIMEOUT} seconds"
    
    except Exception as e:
        logger.error(f"Error: {e}")
        return f"Error: {str(e)}"'''
        
        return code
    
    def _generate_dockerfile(self, output_dir: Path, config: Dict[str, Any]):
        """Generate Dockerfile."""
        template_path = self.templates_dir / "Dockerfile.template"
        with open(template_path, 'r') as f:
            content = f.read()
        
        output_path = output_dir / "Dockerfile"
        with open(output_path, 'w') as f:
            f.write(content)
        
        print(f"  ✓ Dockerfile")
    
    def _generate_requirements(self, output_dir: Path, config: Dict[str, Any]):
        """Generate requirements.txt."""
        additional = config.get('additional_requirements', [])
        additional_str = '\n'.join(additional) if additional else ''
        
        template_path = self.templates_dir / "requirements.txt.template"
        with open(template_path, 'r') as f:
            content = f.read()
        
        content = content.replace('{{additional_requirements}}', additional_str)
        
        output_path = output_dir / "requirements.txt"
        with open(output_path, 'w') as f:
            f.write(content)
        
        print(f"  ✓ requirements.txt")
    
    def _generate_env_example(self, output_dir: Path, config: Dict[str, Any]):
        """Generate .env.example."""
        service_name_upper = config['service_name'].upper().replace(' ', '_')
        
        lines = [f"# {config['service_name']} MCP Server Configuration\n"]
        
        if config.get('api_base_url'):
            lines.append(f"{service_name_upper}_BASE_URL={config['api_base_url']}")
        
        auth_type = config.get('auth_type', 'none')
        if auth_type == 'bearer':
            lines.append(f"{service_name_upper}_API_KEY=your_api_key_here")
        elif auth_type == 'basic':
            lines.append(f"{service_name_upper}_USER=your_username")
            lines.append(f"{service_name_upper}_PASSWORD=your_password")
        
        lines.append("SEARCH_TIMEOUT=10.0")
        
        output_path = output_dir / ".env.example"
        with open(output_path, 'w') as f:
            f.write('\n'.join(lines))
        
        print(f"  ✓ .env.example")
    
    def _generate_deploy_script(self, output_dir: Path, config: Dict[str, Any]):
        """Generate deploy_direct.sh script."""
        service_name_lower = config.get('service_name_lower', config['service_name'].lower().replace(' ', '_'))
        
        script = f'''#!/bin/bash

# {config['service_name']} MCP Server - Direct Deployment
# Generated: {datetime.now().strftime('%Y-%m-%d')}

FUNCTION_NAME="{service_name_lower}-mcp-function"
REGION="us-west-2"
ECR_REPO="{service_name_lower}-mcp-server"

# Colors
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
NC='\\033[0m'

echo -e "${{BLUE}}╔════════════════════════════════════════════════╗${{NC}}"
echo -e "${{BLUE}}║   {config['service_name']} MCP Server - Deployment      ║${{NC}}"
echo -e "${{BLUE}}╚════════════════════════════════════════════════╝${{NC}}"

# Check AWS credentials
echo -e "\\n${{BLUE}}[1/7] Checking AWS credentials...${{NC}}"
if ! aws sts get-caller-identity > /dev/null 2>&1; then
    echo -e "${{RED}}✗ AWS credentials not configured${{NC}}"
    exit 1
fi
echo -e "${{GREEN}}✓ AWS credentials valid${{NC}}"

# Get account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_URI="${{ACCOUNT_ID}}.dkr.ecr.${{REGION}}.amazonaws.com/${{ECR_REPO}}"

# Create ECR repository
echo -e "\\n${{BLUE}}[2/7] Creating ECR repository...${{NC}}"
aws ecr create-repository --repository-name ${{ECR_REPO}} --region ${{REGION}} 2>/dev/null || true
echo -e "${{GREEN}}✓ ECR repository ready${{NC}}"

# Build Docker image
echo -e "\\n${{BLUE}}[3/7] Building Docker image...${{NC}}"
docker build -t ${{ECR_REPO}}:latest .
if [ $? -ne 0 ]; then
    echo -e "${{RED}}✗ Docker build failed${{NC}}"
    exit 1
fi
echo -e "${{GREEN}}✓ Docker image built${{NC}}"

# Push to ECR
echo -e "\\n${{BLUE}}[4/7] Pushing to ECR...${{NC}}"
aws ecr get-login-password --region ${{REGION}} | docker login --username AWS --password-stdin ${{ACCOUNT_ID}}.dkr.ecr.${{REGION}}.amazonaws.com
docker tag ${{ECR_REPO}}:latest ${{ECR_URI}}:latest
docker push ${{ECR_URI}}:latest
echo -e "${{GREEN}}✓ Image pushed to ECR${{NC}}"

# Create/Update Lambda function
echo -e "\\n${{BLUE}}[5/7] Creating/Updating Lambda function...${{NC}}"
if aws lambda get-function --function-name ${{FUNCTION_NAME}} --region ${{REGION}} > /dev/null 2>&1; then
    aws lambda update-function-code \\
        --function-name ${{FUNCTION_NAME}} \\
        --image-uri ${{ECR_URI}}:latest \\
        --region ${{REGION}}
    echo -e "${{GREEN}}✓ Lambda function updated${{NC}}"
else
    aws lambda create-function \\
        --function-name ${{FUNCTION_NAME}} \\
        --package-type Image \\
        --code ImageUri=${{ECR_URI}}:latest \\
        --role arn:aws:iam::${{ACCOUNT_ID}}:role/lambda-execution-role \\
        --timeout 30 \\
        --memory-size 512 \\
        --region ${{REGION}}
    echo -e "${{GREEN}}✓ Lambda function created${{NC}}"
fi

# Create Function URL
echo -e "\\n${{BLUE}}[6/7] Configuring Function URL...${{NC}}"
FUNCTION_URL=$(aws lambda create-function-url-config \\
    --function-name ${{FUNCTION_NAME}} \\
    --auth-type NONE \\
    --region ${{REGION}} \\
    --query FunctionUrl --output text 2>/dev/null || \\
    aws lambda get-function-url-config \\
    --function-name ${{FUNCTION_NAME}} \\
    --region ${{REGION}} \\
    --query FunctionUrl --output text)
echo -e "${{GREEN}}✓ Function URL configured${{NC}}"

# Set environment variables
echo -e "\\n${{BLUE}}[7/7] Setting environment variables...${{NC}}"
'''
        
        # Add environment variable prompts based on auth type
        auth_type = config.get('auth_type', 'none')
        service_name_upper = config['service_name'].upper().replace(' ', '_')
        
        if auth_type == 'bearer':
            script += f'''read -p "Enter {service_name_upper}_API_KEY: " API_KEY
aws lambda update-function-configuration \\
    --function-name ${{FUNCTION_NAME}} \\
    --environment "Variables={{{service_name_upper}_BASE_URL={config.get('api_base_url', 'https://api.example.com')},{service_name_upper}_API_KEY=${{API_KEY}},SEARCH_TIMEOUT=10.0}}" \\
    --region ${{REGION}}
'''
        elif auth_type == 'basic':
            script += f'''read -p "Enter {service_name_upper}_USER: " USER
read -sp "Enter {service_name_upper}_PASSWORD: " PASSWORD
echo
aws lambda update-function-configuration \\
    --function-name ${{FUNCTION_NAME}} \\
    --environment "Variables={{{service_name_upper}_BASE_URL={config.get('api_base_url', 'https://api.example.com')},{service_name_upper}_USER=${{USER}},{service_name_upper}_PASSWORD=${{PASSWORD}},SEARCH_TIMEOUT=10.0}}" \\
    --region ${{REGION}}
'''
        else:
            script += f'''aws lambda update-function-configuration \\
    --function-name ${{FUNCTION_NAME}} \\
    --environment "Variables={{{service_name_upper}_BASE_URL={config.get('api_base_url', 'https://api.example.com')},SEARCH_TIMEOUT=10.0}}" \\
    --region ${{REGION}}
'''
        
        script += f'''
echo -e "${{GREEN}}✓ Environment variables set${{NC}}"

# Success
echo -e "\\n${{GREEN}}╔════════════════════════════════════════════════╗${{NC}}"
echo -e "${{GREEN}}║          ✓ DEPLOYMENT SUCCESSFUL               ║${{NC}}"
echo -e "${{GREEN}}╚════════════════════════════════════════════════╝${{NC}}"
echo -e "\\n📍 ${{YELLOW}}Function URL:${{NC}}"
echo -e "   ${{FUNCTION_URL}}"
echo -e "\\n📝 ${{YELLOW}}Next Steps:${{NC}}"
echo -e "   1. Add this URL to dish-chat mcp_config.yaml"
echo -e "   2. Restart dish-chat backend"
echo -e "   3. Test the MCP tools"
'''
        
        output_path = output_dir / "deploy_direct.sh"
        with open(output_path, 'w') as f:
            f.write(script)
        
        os.chmod(output_path, 0o755)
        print(f"  ✓ deploy_direct.sh")
    
    def _generate_readme(self, output_dir: Path, config: Dict[str, Any]):
        """Generate README.md."""
        service_name = config['service_name']
        service_name_lower = config.get('service_name_lower', service_name.lower().replace(' ', '_'))
        
        readme = f'''# {service_name} MCP Server

MCP server for {service_name} integration with dish-chat.

**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Overview

This MCP server exposes {service_name} functionality to the dish-chat agent via the Model Context Protocol.

## Tools

'''
        
        for tool in config.get('tools', []):
            readme += f"- **{tool['name']}**: {tool.get('description', 'No description')}\n"
        
        readme += f'''
## Deployment

### Quick Start

```bash
./deploy_direct.sh
```

### Configuration

Environment variables:
'''
        
        service_name_upper = service_name.upper().replace(' ', '_')
        if config.get('api_base_url'):
            readme += f"- `{service_name_upper}_BASE_URL`: API base URL\n"
        
        auth_type = config.get('auth_type', 'none')
        if auth_type == 'bearer':
            readme += f"- `{service_name_upper}_API_KEY`: Authentication key\n"
        elif auth_type == 'basic':
            readme += f"- `{service_name_upper}_USER`: Username\n"
            readme += f"- `{service_name_upper}_PASSWORD`: Password\n"
        
        readme += '''- `SEARCH_TIMEOUT`: Request timeout (default: 10.0)

## Testing

```bash
curl -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp
```

## Integration with Dish-Chat

Add to `mcp_config.yaml`:

```yaml
---
name: '''
        
        readme += service_name_lower + '''_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://your-function-url.lambda-url.us-west-2.on.aws/mcp
```

## Development

This MCP server was generated using the MCP Tools Generator.

To modify:
1. Edit `server.py` to customize tools
2. Update `requirements.txt` if adding dependencies
3. Rebuild and redeploy with `./deploy_direct.sh`

## Support

- Slack: #dish-chat-support
- Email: data-solutions-team@dish.com
'''
        
        output_path = output_dir / "README.md"
        with open(output_path, 'w') as f:
            f.write(readme)
        
        print(f"  ✓ README.md")
    
    def _generate_test_script(self, output_dir: Path, config: Dict[str, Any]):
        """Generate test.sh script."""
        script = '''#!/bin/bash

# Test script for MCP server

echo "Testing Lambda Function URL..."
echo

# Test 1: Health check
echo "Test 1: Health check (/)..."
curl -s https://your-function-url.lambda-url.us-west-2.on.aws/ | head -n 5
echo
echo

# Test 2: List tools
echo "Test 2: List tools..."
curl -s -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp | jq .
echo

# Test 3: Call first tool
echo "Test 3: Call tool..."
# TODO: Customize this with your actual tool name and parameters
curl -s -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/call", "params": {"name": "search", "arguments": {"query": "test"}}, "id": 2}' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp | jq .
echo
'''
        
        output_path = output_dir / "test.sh"
        with open(output_path, 'w') as f:
            f.write(script)
        
        os.chmod(output_path, 0o755)
        print(f"  ✓ test.sh")


def main():
    parser = argparse.ArgumentParser(description='Generate MCP server from configuration')
    parser.add_argument('--config', help='Path to YAML configuration file')
    parser.add_argument('--interactive', '-i', action='store_true', help='Interactive mode')
    parser.add_argument('--output', '-o', default='.', help='Output directory')
    
    args = parser.parse_args()
    
    generator = MCPServerGenerator(output_dir=args.output)
    
    if args.config:
        generator.generate_from_config(args.config)
    elif args.interactive:
        generator.generate_interactive()
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
