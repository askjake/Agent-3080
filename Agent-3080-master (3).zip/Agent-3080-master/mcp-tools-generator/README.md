# MCP Tools Generator

**Rapidly scaffold new MCP servers for Dish-Chat integration**

Generate complete, production-ready MCP servers in minutes instead of hours.

---

## 🚀 Quick Start

### Method 1: Interactive Mode (Recommended)

```bash
cd /home/montjac/Jakes-agent/mcp-tools-generator
python scripts/generate_mcp_server.py --interactive
```

Answer the prompts, and a complete MCP server will be generated!

### Method 2: From Configuration File

```bash
# Use an example
python scripts/generate_mcp_server.py --config examples/github_example.yaml

# Or create your own config
python scripts/generate_mcp_server.py --config my_service.yaml
```

---

## 📦 What Gets Generated

The generator creates a complete MCP server directory with all files production-ready.

## 📝 Configuration Format

Create a YAML file describing your service with authentication, tools, and API details.

## 🚀 Deployment Workflow

After generation, review, deploy to AWS Lambda, integrate with Dish-Chat, and test.

## 📞 Support

- **Slack:** #dish-chat-support
- **Email:** data-solutions-team@dish.com
- **Documentation:** /home/montjac/Jakes-agent/mcp-documentation/

---

**Version:** 1.0  
**Last Updated:** 2026-04-17  
**Maintained By:** Data Solutions Team
