# MCP Tool Integration Protocol for Dish-Chat Backend

**Version:** 2.0  
**Last Updated:** 2026-04-17  
**Author:** Data Solutions Team  
**Status:** PRODUCTION STANDARD

---

## 📋 Table of Contents

1. [Executive Summary](#executive-summary)
2. [Architecture Overview](#architecture-overview)
3. [MCP Server Components](#mcp-server-components)
4. [Infrastructure Requirements](#infrastructure-requirements)
5. [Implementation Checklist](#implementation-checklist)
6. [Integration with Dish-Chat](#integration-with-dish-chat)
7. [Testing & Validation](#testing--validation)
8. [Deployment Process](#deployment-process)
9. [Troubleshooting Guide](#troubleshooting-guide)
10. [Reference Implementations](#reference-implementations)

---

## 🎯 Executive Summary

This protocol documents the exact process for adding new MCP (Model Context Protocol) tools to the Dish-Chat backend based on the successful implementation of three MCP servers:

- **JIRA MCP** - Search DISH JIRA issues
- **Confluence MCP** - Search DISH Confluence documentation  
- **Netra MCP** - Search DISH Netra internal records

### Key Learnings

✅ **FastMCP Framework** - Use FastMCP for rapid MCP server development  
✅ **AWS Lambda Deployment** - Deploy as containerized Lambda functions with Function URLs  
✅ **ArgoCD Integration** - Track Lambda metadata in Kubernetes via GitOps  
✅ **YAML Configuration** - Configure MCP connections via mcp_config.yaml  
✅ **Dual Config Support** - Support both YAML and Python config formats  
✅ **Bearer Token Auth** - Optional Bearer token authentication for Lambda URLs

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                         DISH-CHAT FRONTEND                          │
│                        (React/TypeScript)                           │
└────────────────────────────────┬────────────────────────────────────┘
                                 │ HTTP/WebSocket
                                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    DISH-CHAT BACKEND (FastAPI)                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                   MCP Client Manager                         │  │
│  │  - Loads mcp_config.yaml                                     │  │
│  │  - Creates HTTP clients for each MCP server                 │  │
│  │  - Manages tool discovery & invocation                      │  │
│  └──────────────────────────────────────────────────────────────┘  │
└────────┬─────────┬─────────┬─────────────────────────────────┬──────┘
         │         │         │                                 │
         │ MCP     │ MCP     │ MCP                            │ MCP
         │ Proto   │ Proto   │ Proto                          │ Proto
         ▼         ▼         ▼                                 ▼
┌─────────────┐ ┌────────────────┐ ┌───────────────┐ ┌─────────────────┐
│  JIRA MCP   │ │ Confluence MCP │ │  Netra MCP    │ │  Your New MCP   │
│   Lambda    │ │     Lambda     │ │    Lambda     │ │     Lambda      │
│             │ │                │ │               │ │                 │
│ Function    │ │   Function     │ │   Function    │ │    Function     │
│   URL       │ │      URL       │ │      URL      │ │       URL       │
└─────┬───────┘ └────────┬───────┘ └───────┬───────┘ └────────┬────────┘
      │                  │                 │                    │
      │ REST API         │ REST API        │ Internal API      │ API
      ▼                  ▼                 ▼                    ▼
┌─────────────┐ ┌────────────────┐ ┌───────────────┐ ┌─────────────────┐
│JIRA Cloud   │ │Confluence Cloud│ │ Netra Service │ │   External      │
│  (Atlassian)│ │  (Atlassian)   │ │  (Internal)   │ │   Service       │
└─────────────┘ └────────────────┘ └───────────────┘ └─────────────────┘
```

### Component Responsibilities

**Dish-Chat Backend**
- Loads MCP configurations from mcp_config.yaml
- Discovers available tools from each MCP server
- Routes tool invocations to appropriate MCP servers
- Handles responses and streams results to frontend

**MCP Lambda Functions**
- Implement MCP protocol (tools/list, tools/call, prompts/list)
- Handle authentication with external services
- Transform API responses to LLM-friendly formats
- Provide error handling and timeout management

**External Services**
- JIRA, Confluence, Netra, etc.
- Provide data via REST APIs
- Handle authentication and authorization

---

## 🔧 MCP Server Components

Each MCP server consists of these files:

### 1. server.py - Core MCP Server

```python
"""
{Service Name} MCP Server for DISH

Exposes {service} functionality to dish-chat via MCP protocol.
Designed to be deployed on AWS Lambda with Lambda Web Adapter.
"""

import os
import logging
from typing import Optional

import httpx
from mcp.server.fastmcp import FastMCP

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastMCP server
mcp = FastMCP("{Service Name}")

# Configuration from environment variables
SERVICE_BASE_URL = os.getenv("SERVICE_BASE_URL", "https://default.example.com")
SERVICE_API_KEY = os.getenv("SERVICE_API_KEY")
DEFAULT_TIMEOUT = float(os.getenv("SEARCH_TIMEOUT", "10.0"))

# Tool definitions using @mcp.tool() decorator
@mcp.tool()
async def tool_name(param1: str, param2: int = 5) -> str:
    """
    Tool description for the LLM.
    
    Detailed explanation of what this tool does.
    
    Args:
        param1: Description of param1
        param2: Description of param2 (default: 5)
    
    Returns:
        Formatted string with results
    
    Examples:
        - Example 1: tool_name("query")
        - Example 2: tool_name("query", max=10)
    
    Use this tool when users:
        - Ask about X
        - Need to find Y
        - Want to know Z
    """
    logger.info(f"Tool invocation: param1={param1}")
    
    # Validate inputs
    if not SERVICE_API_KEY:
        return "Error: API key not configured"
    
    # Make API call
    try:
        async with httpx.AsyncClient(timeout=DEFAULT_TIMEOUT) as client:
            resp = await client.get(
                f"{SERVICE_BASE_URL}/endpoint",
                params={"query": param1},
                headers={"Authorization": f"Bearer {SERVICE_API_KEY}"}
            )
            resp.raise_for_status()
            data = resp.json()
        
        # Format response
        results = data.get("results", [])
        if not results:
            return f"No results found for: {param1}"
        
        output_lines = [f"Found {len(results)} result(s):\\n"]
        for i, item in enumerate(results, 1):
            output_lines.append(f"{i}. {item.get('title')}")
            output_lines.append(f"   {item.get('url')}")
            output_lines.append("")
        
        return "\\n".join(output_lines)
    
    except httpx.HTTPStatusError as e:
        logger.error(f"HTTP error: {e.response.status_code}")
        if e.response.status_code == 401:
            return "Error: Authentication failed"
        elif e.response.status_code == 403:
            return "Error: Access forbidden"
        return f"Error: Request failed with status {e.response.status_code}"
    
    except httpx.TimeoutException:
        logger.error("Request timeout")
        return f"Error: Request timed out after {DEFAULT_TIMEOUT} seconds"
    
    except Exception as e:
        logger.error(f"Tool error: {e}")
        return f"Error: {str(e)}"

# Optional: Provide context to the LLM
@mcp.prompt()
def task_instruction() -> str:
    """
    Provide domain context about this service to the LLM.
    """
    return """You have access to {Service Name}.

You can help users:
- Find X
- Search for Y
- Look up Z

When using {tool_name}:
- Start broad, then refine
- Look for keywords or patterns
- Provide URLs for users to investigate further

Note: This is read-only access."""

# Server initialization
if __name__ == "__main__":
    mcp.run()
```

### 2. Dockerfile - Container Definition

```dockerfile
FROM public.ecr.aws/lambda/python:3.12

# Copy requirements and install dependencies
COPY requirements.txt ${LAMBDA_TASK_ROOT}
RUN pip install --no-cache-dir -r requirements.txt

# Copy server code
COPY server.py ${LAMBDA_TASK_ROOT}

# Set the CMD to your handler
CMD ["server.mcp.run"]
```

### 3. requirements.txt - Dependencies

```
httpx
mcp
```

### 4. .env.example - Environment Template

```bash
# Service Configuration
SERVICE_BASE_URL=https://api.example.com
SERVICE_API_KEY=your_api_key_here
SERVICE_USER_EMAIL=your.email@dish.com
SEARCH_TIMEOUT=10.0
```

### 5. template.yaml - SAM Template (Optional)

```yaml
AWSTemplateFormatVersion: '2010-09-09'
Transform: AWS::Serverless-2016-10-31
Description: {Service} MCP Server for dish-chat

Resources:
  ServiceMCPFunction:
    Type: AWS::Serverless::Function
    Properties:
      FunctionName: {service}-mcp-server
      PackageType: Image
      Timeout: 30
      MemorySize: 512
      Environment:
        Variables:
          SERVICE_BASE_URL: !Ref ServiceBaseURL
          SERVICE_API_KEY: !Ref ServiceAPIKey
      FunctionUrlConfig:
        AuthType: NONE

    Metadata:
      DockerTag: python3.12-v1
      DockerContext: .
      Dockerfile: Dockerfile

Parameters:
  ServiceBaseURL:
    Type: String
    Default: https://api.example.com
  ServiceAPIKey:
    Type: String
    NoEcho: true

Outputs:
  FunctionUrl:
    Description: {Service} MCP Server URL
    Value: !GetAtt ServiceMCPFunctionUrl.FunctionUrl
```

### 6. deploy_direct.sh - Deployment Script

```bash
#!/bin/bash

# Configuration
FUNCTION_NAME="{service}-mcp-function"
REGION="us-west-2"
ECR_REPO="{service}-mcp-server"

# Colors
RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
BLUE='\\033[0;34m'
NC='\\033[0m'

echo -e "${BLUE}╔════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   {Service} MCP Server - Direct Deployment    ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════╝${NC}"

# Check AWS credentials
echo -e "\\n${BLUE}[1/7] Checking AWS credentials...${NC}"
if ! aws sts get-caller-identity > /dev/null 2>&1; then
    echo -e "${RED}✗ AWS credentials not configured${NC}"
    exit 1
fi
echo -e "${GREEN}✓ AWS credentials valid${NC}"

# Get account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_URI="${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com/${ECR_REPO}"

# Create ECR repository
echo -e "\\n${BLUE}[2/7] Creating ECR repository...${NC}"
aws ecr create-repository --repository-name ${ECR_REPO} --region ${REGION} 2>/dev/null || true
echo -e "${GREEN}✓ ECR repository ready${NC}"

# Build Docker image
echo -e "\\n${BLUE}[3/7] Building Docker image...${NC}"
docker build -t ${ECR_REPO}:latest .
if [ $? -ne 0 ]; then
    echo -e "${RED}✗ Docker build failed${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Docker image built${NC}"

# Push to ECR
echo -e "\\n${BLUE}[4/7] Pushing to ECR...${NC}"
aws ecr get-login-password --region ${REGION} | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr.${REGION}.amazonaws.com
docker tag ${ECR_REPO}:latest ${ECR_URI}:latest
docker push ${ECR_URI}:latest
echo -e "${GREEN}✓ Image pushed to ECR${NC}"

# Create/Update Lambda function
echo -e "\\n${BLUE}[5/7] Creating/Updating Lambda function...${NC}"
if aws lambda get-function --function-name ${FUNCTION_NAME} --region ${REGION} > /dev/null 2>&1; then
    aws lambda update-function-code \\
        --function-name ${FUNCTION_NAME} \\
        --image-uri ${ECR_URI}:latest \\
        --region ${REGION}
    echo -e "${GREEN}✓ Lambda function updated${NC}"
else
    aws lambda create-function \\
        --function-name ${FUNCTION_NAME} \\
        --package-type Image \\
        --code ImageUri=${ECR_URI}:latest \\
        --role arn:aws:iam::${ACCOUNT_ID}:role/lambda-execution-role \\
        --timeout 30 \\
        --memory-size 512 \\
        --region ${REGION}
    echo -e "${GREEN}✓ Lambda function created${NC}"
fi

# Create Function URL
echo -e "\\n${BLUE}[6/7] Configuring Function URL...${NC}"
FUNCTION_URL=$(aws lambda create-function-url-config \\
    --function-name ${FUNCTION_NAME} \\
    --auth-type NONE \\
    --region ${REGION} \\
    --query FunctionUrl --output text 2>/dev/null || \\
    aws lambda get-function-url-config \\
    --function-name ${FUNCTION_NAME} \\
    --region ${REGION} \\
    --query FunctionUrl --output text)
echo -e "${GREEN}✓ Function URL configured${NC}"

# Set environment variables
echo -e "\\n${BLUE}[7/7] Setting environment variables...${NC}"
read -p "Enter SERVICE_API_KEY: " API_KEY
aws lambda update-function-configuration \\
    --function-name ${FUNCTION_NAME} \\
    --environment "Variables={SERVICE_BASE_URL=https://api.example.com,SERVICE_API_KEY=${API_KEY},SEARCH_TIMEOUT=10.0}" \\
    --region ${REGION}
echo -e "${GREEN}✓ Environment variables set${NC}"

# Success
echo -e "\\n${GREEN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║          ✓ DEPLOYMENT SUCCESSFUL               ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════╝${NC}"
echo -e "\\n📍 ${YELLOW}Function URL:${NC}"
echo -e "   ${FUNCTION_URL}"
echo -e "\\n📝 ${YELLOW}Next Steps:${NC}"
echo -e "   1. Add this URL to dish-chat mcp_config.yaml"
echo -e "   2. Restart dish-chat backend"
echo -e "   3. Test the MCP tools"
```

### 7. README.md - Documentation

```markdown
# {Service} MCP Server

MCP server for {Service} integration with dish-chat.

## Overview

This MCP server exposes {Service} functionality to the dish-chat agent via the Model Context Protocol.

## Tools

- **tool_name**: Description of what this tool does

## Deployment

### Quick Start

\`\`\`bash
./deploy_direct.sh
\`\`\`

### Manual Deployment

1. Build Docker image
2. Push to ECR
3. Deploy Lambda function
4. Configure Function URL
5. Set environment variables

See DEPLOYMENT.md for detailed instructions.

## Configuration

Environment variables:
- \`SERVICE_BASE_URL\`: API base URL
- \`SERVICE_API_KEY\`: Authentication key
- \`SEARCH_TIMEOUT\`: Request timeout (default: 10.0)

## Testing

\`\`\`bash
curl -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp
\`\`\`

## Integration

Add to dish-chat \`mcp_config.yaml\`:

\`\`\`yaml
---
name: {service}_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://your-function-url.lambda-url.us-west-2.on.aws/mcp
  headers:
    Content-Type: application/json
    Accept: application/json, text/event-stream
\`\`\`
```

---

## 🏗️ Infrastructure Requirements

### AWS Resources

| Resource | Purpose | Configuration |
|----------|---------|---------------|
| **Lambda Function** | Run MCP server code | Memory: 512MB, Timeout: 30s |
| **ECR Repository** | Store Docker images | Name: {service}-mcp-server |
| **Function URL** | Public HTTPS endpoint | Auth: NONE or IAM |
| **IAM Role** | Lambda execution role | Permissions: Logs, ECR |
| **CloudWatch Logs** | Function logging | Retention: 7-30 days |

### Optional Resources

| Resource | Purpose | When to Use |
|----------|---------|-------------|
| **API Gateway** | Custom domain, rate limiting | Production deployments |
| **Secrets Manager** | Secure credential storage | Sensitive API keys |
| **VPC** | Private network access | Internal services only |
| **X-Ray** | Distributed tracing | Performance debugging |

### Kubernetes Resources (ArgoCD Tracking)

| Resource | Purpose | Namespace |
|----------|---------|-----------|
| **Namespace** | Resource grouping | mcp-tools |
| **ConfigMap** | Lambda metadata | mcp-tools |
| **Service (ExternalName)** | Service discovery | mcp-tools |
| **ArgoCD Application** | GitOps management | argocd |

---

## ✅ Implementation Checklist

### Phase 1: Development

- [ ] Create project directory structure
- [ ] Write server.py with tool definitions
- [ ] Create Dockerfile
- [ ] Write requirements.txt
- [ ] Test locally with FastMCP
- [ ] Create .env.example
- [ ] Write README.md
- [ ] Create test suite

### Phase 2: AWS Deployment

- [ ] Configure AWS credentials
- [ ] Create ECR repository
- [ ] Build Docker image
- [ ] Push image to ECR
- [ ] Create Lambda function
- [ ] Configure Function URL
- [ ] Set environment variables
- [ ] Test Lambda endpoint

### Phase 3: Kubernetes Integration

- [ ] Create namespace.yaml
- [ ] Create configmap.yaml
- [ ] Create service.yaml (ExternalName)
- [ ] Create kustomization.yaml
- [ ] Create ArgoCD config.json
- [ ] Commit to Git repository
- [ ] Verify ArgoCD auto-discovery

### Phase 4: Dish-Chat Integration

- [ ] Add MCP config to mcp_config.yaml
- [ ] (Optional) Add config to config.py
- [ ] Restart dish-chat backend
- [ ] Verify tool discovery
- [ ] Test tool invocation
- [ ] Document usage examples

### Phase 5: Testing & Documentation

- [ ] Write integration tests
- [ ] Create user guide
- [ ] Document API endpoints
- [ ] Create troubleshooting guide
- [ ] Update team documentation

---

## 🔌 Integration with Dish-Chat

### Method 1: YAML Configuration (Recommended)

Edit \`/home/montjac/dish-chat/app/mcp_config.yaml\`:

\`\`\`yaml
---
name: {service}_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://your-function-url.lambda-url.us-west-2.on.aws/mcp
  headers:
    Content-Type: application/json
    Accept: application/json, text/event-stream
\`\`\`

**With Authentication:**

\`\`\`yaml
---
name: {service}_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://your-function-url.lambda-url.us-west-2.on.aws/mcp
  headers:
    Authorization: Bearer YOUR_BEARER_TOKEN_HERE
    Content-Type: application/json
    Accept: application/json, text/event-stream
\`\`\`

### Method 2: Python Configuration (Legacy)

Edit \`/home/montjac/dish-chat/app/config.py\`:

\`\`\`python
# {Service} MCP - {Description}
{SERVICE}_MCP_CONFIG: dict = {
    "{service}_mcp": {
        "transport": "streamable_http",
        "url": "https://your-function-url.lambda-url.us-west-2.on.aws/mcp",
        "headers": {
            "Authorization": "Bearer YOUR_BEARER_TOKEN",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream"
        }
    }
}
\`\`\`

### Configuration Options

| Option | Description | Example |
|--------|-------------|---------|
| **name** | MCP server identifier | \`jira_mcp\` |
| **user_selectable** | User can enable/disable | \`true\` or \`false\` |
| **transport** | Connection type | \`streamable_http\` |
| **url** | Lambda Function URL | \`https://xxx.lambda-url.us-west-2.on.aws/mcp\` |
| **headers.Authorization** | Bearer token (optional) | \`Bearer abc123\` |
| **headers.Content-Type** | Request content type | \`application/json\` |
| **headers.Accept** | Response formats | \`application/json, text/event-stream\` |

### Restart Dish-Chat

\`\`\`bash
# Method 1: If running as systemd service
sudo systemctl restart dish-chat

# Method 2: If running manually
pkill -f "uvicorn"
cd /home/montjac/dish-chat
./start-backend.sh

# Method 3: Using process manager
pm2 restart dish-chat
\`\`\`

---

## 🧪 Testing & Validation

### Test 1: Lambda Function Health

\`\`\`bash
curl https://your-function-url.lambda-url.us-west-2.on.aws/
\`\`\`

Expected: HTTP 200 or 404 (endpoint exists)

### Test 2: MCP Protocol - List Tools

\`\`\`bash
curl -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{
    "jsonrpc": "2.0",
    "method": "tools/list",
    "id": 1
  }' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp
\`\`\`

Expected:
\`\`\`json
{
  "jsonrpc": "2.0",
  "result": {
    "tools": [
      {
        "name": "tool_name",
        "description": "Tool description",
        "inputSchema": {
          "type": "object",
          "properties": {...}
        }
      }
    ]
  },
  "id": 1
}
\`\`\`

### Test 3: MCP Protocol - Call Tool

\`\`\`bash
curl -X POST \\
  -H 'Content-Type: application/json' \\
  -d '{
    "jsonrpc": "2.0",
    "method": "tools/call",
    "params": {
      "name": "tool_name",
      "arguments": {
        "param1": "test query"
      }
    },
    "id": 2
  }' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp
\`\`\`

Expected:
\`\`\`json
{
  "jsonrpc": "2.0",
  "result": {
    "content": [
      {
        "type": "text",
        "text": "Tool execution results..."
      }
    ]
  },
  "id": 2
}
\`\`\`

### Test 4: Dish-Chat Integration

In dish-chat UI:

\`\`\`
User: "Test {service} integration"
Expected: Agent recognizes and can use {service}_mcp tools
\`\`\`

### Test 5: ArgoCD Sync Status

\`\`\`bash
kubectl get application apps-{service}-mcp -n argocd
\`\`\`

Expected: STATUS = Synced, HEALTH = Healthy

### Test 6: Kubernetes Resources

\`\`\`bash
kubectl get configmap {service}-mcp-function -n mcp-tools
kubectl get service {service}-mcp-function -n mcp-tools
\`\`\`

Expected: Resources exist and contain correct metadata

---

## 🚀 Deployment Process

### Standard Deployment (Using Scripts)

\`\`\`bash
# 1. Clone/navigate to project
cd {service}-mcp-server

# 2. Deploy to AWS Lambda
./deploy_direct.sh

# 3. Copy Function URL from output
# Example: https://abc123xyz.lambda-url.us-west-2.on.aws

# 4. Add to dish-chat configuration
nano /home/montjac/dish-chat/app/mcp_config.yaml

# 5. Restart dish-chat
sudo systemctl restart dish-chat

# 6. Verify in dish-chat UI
# Ask: "What tools do you have access to?"
\`\`\`

### GitOps Deployment (ArgoCD)

\`\`\`bash
# 1. Create Kubernetes manifests
mkdir -p {service}-mcp-server/k8s
cd {service}-mcp-server/k8s

# 2. Create namespace.yaml
cat > namespace.yaml << 'EOF'
apiVersion: v1
kind: Namespace
metadata:
  name: mcp-tools
  labels:
    app.kubernetes.io/name: mcp-tools
EOF

# 3. Create configmap.yaml
cat > configmap.yaml << 'EOF'
apiVersion: v1
kind: ConfigMap
metadata:
  name: {service}-mcp-function
  namespace: mcp-tools
  labels:
    app.kubernetes.io/name: {service}-mcp
data:
  LAMBDA_URL: "https://your-function-url.lambda-url.us-west-2.on.aws"
  MCP_ENDPOINT: "/mcp"
  ECR_REPOSITORY: "{service}-mcp-server"
  REGION: "us-west-2"
EOF

# 4. Create service.yaml
cat > service.yaml << 'EOF'
apiVersion: v1
kind: Service
metadata:
  name: {service}-mcp-function
  namespace: mcp-tools
  labels:
    app.kubernetes.io/name: {service}-mcp
spec:
  type: ExternalName
  externalName: your-function-url.lambda-url.us-west-2.on.aws
EOF

# 5. Create kustomization.yaml
cat > kustomization.yaml << 'EOF'
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - namespace.yaml
  - configmap.yaml
  - service.yaml
EOF

# 6. Commit to Git
git add k8s/
git commit -m "feat: Add Kubernetes manifests for {service} MCP"
git push origin main

# 7. Create ArgoCD config
mkdir -p ../argocd
cat > ../argocd/config.json << 'EOF'
{
  "appName": "{service}-mcp",
  "userGivenName": "{service}-mcp",
  "destNamespace": "mcp-tools",
  "destServer": "https://kubernetes.default.svc",
  "srcPath": "{service}-mcp-server/k8s",
  "srcRepoURL": "https://gitlab.com/dish-cloud/dt/sse/datasolutions/internal-tools-mcp-server.git",
  "srcTargetRevision": "main",
  "CreateNamespace": true,
  "labels": null
}
EOF

# 8. Commit ArgoCD config
git add argocd/
git commit -m "feat: Add ArgoCD application for {service} MCP"
git push origin main

# 9. Verify ArgoCD auto-discovery (~20 seconds)
kubectl get application apps-{service}-mcp -n argocd
\`\`\`

---

## 🔧 Troubleshooting Guide

### Problem: Lambda function not responding

**Symptoms:**
- Curl to Function URL returns 500/502/503
- dish-chat shows "MCP tool unavailable"

**Solutions:**
\`\`\`bash
# Check Lambda logs
aws logs tail /aws/lambda/{service}-mcp-function --follow

# Check function configuration
aws lambda get-function-configuration --function-name {service}-mcp-function

# Test locally
docker run -p 8080:8080 {service}-mcp-server:latest

# Verify environment variables are set
aws lambda get-function-configuration --function-name {service}-mcp-function --query Environment
\`\`\`

### Problem: "Authentication failed" errors

**Symptoms:**
- Tool returns "Error: Authentication failed"
- Logs show 401/403 errors

**Solutions:**
\`\`\`bash
# Verify API credentials are set
aws lambda get-function-configuration --function-name {service}-mcp-function --query Environment.Variables

# Update credentials
aws lambda update-function-configuration \\
  --function-name {service}-mcp-function \\
  --environment "Variables={SERVICE_API_KEY=new_key_here}"

# Test credentials manually
curl -H "Authorization: Bearer YOUR_API_KEY" https://api.example.com/test
\`\`\`

### Problem: Dish-chat not discovering MCP tools

**Symptoms:**
- Agent doesn't mention having {service} tools
- \`tools/list\` returns empty array

**Solutions:**
\`\`\`bash
# Check mcp_config.yaml syntax
cat /home/montjac/dish-chat/app/mcp_config.yaml

# Verify YAML is valid
python3 -c "import yaml; yaml.safe_load(open('/home/montjac/dish-chat/app/mcp_config.yaml'))"

# Check dish-chat logs
tail -f /home/montjac/dish-chat/backend.log

# Restart dish-chat
sudo systemctl restart dish-chat

# Test MCP endpoint directly
curl -X POST -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \\
  https://your-function-url.lambda-url.us-west-2.on.aws/mcp
\`\`\`

### Problem: ArgoCD application not syncing

**Symptoms:**
- Application shows "OutOfSync" status
- Resources not created in Kubernetes

**Solutions:**
\`\`\`bash
# Check ArgoCD application status
argocd app get apps-{service}-mcp

# View sync errors
argocd app get apps-{service}-mcp --show-operation

# Manually sync
argocd app sync apps-{service}-mcp

# Check manifest syntax
kubectl apply --dry-run=client -f {service}-mcp-server/k8s/

# Verify Git repository accessible
git ls-remote https://gitlab.com/.../internal-tools-mcp-server.git
\`\`\`

### Problem: Timeout errors

**Symptoms:**
- "Request timed out after 10 seconds"
- Lambda function taking too long

**Solutions:**
\`\`\`bash
# Increase Lambda timeout
aws lambda update-function-configuration \\
  --function-name {service}-mcp-function \\
  --timeout 60

# Increase MCP timeout in environment
aws lambda update-function-configuration \\
  --function-name {service}-mcp-function \\
  --environment "Variables={...,SEARCH_TIMEOUT=30.0}"

# Check external API performance
time curl https://api.example.com/endpoint

# Enable X-Ray tracing for debugging
aws lambda update-function-configuration \\
  --function-name {service}-mcp-function \\
  --tracing-config Mode=Active
\`\`\`

### Problem: Docker build fails

**Symptoms:**
- \`docker build\` returns errors
- Dependencies not installing

**Solutions:**
\`\`\`bash
# Clean Docker cache
docker system prune -af

# Build with no cache
docker build --no-cache -t {service}-mcp-server:latest .

# Check Dockerfile syntax
docker build --dry-run -t test .

# Verify Python version compatibility
docker run --rm public.ecr.aws/lambda/python:3.12 python --version

# Test requirements.txt
pip install -r requirements.txt --dry-run
\`\`\`

---

## 📚 Reference Implementations

### JIRA MCP

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/jira-mcp-server.git  
**Function URL:** https://nxfg5xzy3tqfoiowauaycxlbim0lzrmm.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD:** https://ds-argocd-latest.dishtv.technology/applications/argocd/apps-jira-mcp  
**MR:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/dish-chat/-/merge_requests/99

**Key Features:**
- Basic text search with JQL queries
- HTTP Basic Auth (email + API token)
- API fallback (v3 → v2)
- ADF description parsing

### Confluence MCP

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/confluence-mcp-server.git  
**Function URL:** https://zkuyopzgcra6gsxceqclqbjtma0gfxlj.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD:** https://ds-argocd-latest.dishtv.technology/applications/argocd/apps-confluence-mcp  
**MR:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/dish-chat/-/merge_requests/98

**Key Features:**
- CQL text search
- HTTP Basic Auth
- HTML tag cleaning
- Excerpt formatting

### Netra MCP

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/netra-mcp-server  
**Function URL:** https://qzjs7rodqibouzgyymup6jt25u0uqxqx.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD:** https://ds-argocd-latest.dishtv.technology/applications/argocd/apps-netra-mcp  
**MR:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/dish-chat/-/merge_requests/100

**Key Features:**
- Record ID + date search
- Internal service (no auth)
- HTML response handling
- Required parameter validation

---

## 🔐 Security Best Practices

### 1. API Credentials

❌ **DON'T:**
- Hardcode API keys in source code
- Commit credentials to Git
- Use plain text in Dockerfile

✅ **DO:**
- Use Lambda environment variables
- Store sensitive data in AWS Secrets Manager
- Rotate credentials regularly

\`\`\`bash
# Store in Secrets Manager
aws secretsmanager create-secret \\
  --name {service}-mcp-credentials \\
  --secret-string '{"api_key":"xxx","email":"user@dish.com"}'

# Update Lambda to use Secrets Manager
# (Requires Lambda IAM role update)
\`\`\`

### 2. Function URL Authentication

**Public (Current):**
\`\`\`yaml
FunctionUrlConfig:
  AuthType: NONE
\`\`\`

**With IAM Authentication (Recommended for sensitive services):**
\`\`\`yaml
FunctionUrlConfig:
  AuthType: AWS_IAM
\`\`\`

**With Custom Bearer Token:**
\`\`\`python
# In server.py
BEARER_TOKEN = os.getenv("BEARER_TOKEN")

# Middleware to validate token
if request.headers.get("Authorization") != f"Bearer {BEARER_TOKEN}":
    return {"error": "Unauthorized"}, 401
\`\`\`

### 3. Network Security

**Internal Services Only:**
\`\`\`yaml
# Deploy Lambda in VPC
VpcConfig:
  SecurityGroupIds:
    - sg-xxxxx
  SubnetIds:
    - subnet-xxxxx
    - subnet-yyyyy
\`\`\`

**Outbound Traffic Control:**
- Use VPC endpoints for AWS services
- Whitelist external API endpoints
- Enable VPC Flow Logs

### 4. Logging & Monitoring

\`\`\`python
# Sanitize logs - don't log sensitive data
logger.info(f"Search query: {query[:50]}")  # Truncate
# NOT: logger.info(f"API key: {api_key}")  # Never log credentials
\`\`\`

---

## 📊 Performance Optimization

### 1. Lambda Configuration

| Setting | Development | Production |
|---------|-------------|------------|
| **Memory** | 512 MB | 1024 MB |
| **Timeout** | 30 seconds | 60 seconds |
| **Reserved Concurrency** | None | 10-50 |
| **Provisioned Concurrency** | 0 | 1-5 (for low latency) |

### 2. Caching Strategies

\`\`\`python
# Simple in-memory cache (single Lambda instance)
from functools import lru_cache

@lru_cache(maxsize=128)
def cached_api_call(query: str) -> dict:
    return fetch_from_api(query)
\`\`\`

\`\`\`python
# Distributed cache (ElastiCache Redis)
import redis

redis_client = redis.Redis(host='cache.example.com', port=6379)

def get_cached(key: str) -> Optional[str]:
    return redis_client.get(key)

def set_cached(key: str, value: str, ttl: int = 300):
    redis_client.setex(key, ttl, value)
\`\`\`

### 3. Async Best Practices

\`\`\`python
# Parallel API calls
async def search_multiple(queries: list[str]) -> list[dict]:
    async with httpx.AsyncClient() as client:
        tasks = [client.get(url, params={"q": q}) for q in queries]
        responses = await asyncio.gather(*tasks, return_exceptions=True)
    return responses
\`\`\`

### 4. Connection Pooling

\`\`\`python
# Reuse HTTP client across invocations
from mcp.server.fastmcp import FastMCP

# Global client (persists across Lambda warm starts)
http_client = None

def get_client() -> httpx.AsyncClient:
    global http_client
    if http_client is None or http_client.is_closed:
        http_client = httpx.AsyncClient(timeout=10.0)
    return http_client
\`\`\`

---

## 🗂️ Project Structure Template

\`\`\`
{service}-mcp-server/
├── .git/
├── .gitignore
├── README.md
├── DEPLOYMENT.md
├── LICENSE
├── .env.example
├── requirements.txt
├── Dockerfile
├── template.yaml
├── deploy.sh
├── deploy_direct.sh
├── test.sh
├── server.py                    # Main MCP server
├── tests/
│   ├── __init__.py
│   ├── test_server.py
│   └── test_integration.py
├── k8s/                         # Kubernetes manifests
│   ├── namespace.yaml
│   ├── configmap.yaml
│   ├── service.yaml
│   └── kustomization.yaml
├── argocd/                      # ArgoCD config
│   └── config.json
└── docs/
    ├── API.md
    ├── EXAMPLES.md
    └── TROUBLESHOOTING.md
\`\`\`

---

## 📝 Changelog & Versioning

### Version 2.0 (Current)

**New Features:**
- YAML-based MCP configuration support
- Bearer token authentication
- ArgoCD GitOps integration
- Kubernetes service discovery
- Comprehensive deployment scripts

**Reference Implementations:**
- JIRA MCP (MR #99)
- Confluence MCP (MR #98)
- Netra MCP (MR #100)

### Version 1.0 (Legacy)

**Features:**
- Python-based configuration only
- Direct Lambda invocation
- Manual infrastructure management

---

## 🤝 Contributing

### Adding a New MCP Server

1. **Fork template repository**
2. **Implement server.py** with your tools
3. **Test locally** with FastMCP
4. **Deploy to AWS Lambda**
5. **Create Kubernetes manifests**
6. **Submit merge request** to dish-chat

### Code Review Checklist

- [ ] Server implements MCP protocol correctly
- [ ] Tools have comprehensive docstrings
- [ ] Error handling for all failure modes
- [ ] Logging doesn't expose sensitive data
- [ ] Dockerfile builds successfully
- [ ] README.md is complete
- [ ] Tests cover main functionality
- [ ] Deployment script works end-to-end

---

## 📞 Support & Resources

### Documentation

- **MCP Protocol Spec:** https://modelcontextprotocol.io/
- **FastMCP Docs:** https://github.com/jlowin/fastmcp
- **AWS Lambda Docs:** https://docs.aws.amazon.com/lambda/
- **ArgoCD Docs:** https://argo-cd.readthedocs.io/

### Internal Resources

- **GitLab Group:** https://gitlab.com/dish-cloud/dt/sse/datasolutions
- **ArgoCD UI:** https://ds-argocd-latest.dishtv.technology
- **Dish-Chat Source:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/dish-chat

### Contact

- **Slack:** #dish-chat-support
- **Email:** data-solutions-team@dish.com
- **On-Call:** PagerDuty escalation

---

## 📜 License

Internal DISH Wireless documentation. Not for external distribution.

---

**Document Version:** 2.0  
**Last Updated:** 2026-04-17  
**Next Review:** 2026-07-17  
**Owner:** Data Solutions Team

