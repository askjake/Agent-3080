# MCP Server Infrastructure Investigation - Summary Report

**Date:** 2026-04-17  
**Investigator:** Dish-Chat Agent  
**Location:** montjac@10.79.85.47:/tmp/  
**Status:** ✅ COMPLETE

---

## 🎯 Executive Summary

Comprehensive investigation of three newly implemented MCP (Model Context Protocol) servers for Dish-Chat:

1. **JIRA MCP** - Search DISH JIRA issues via text queries
2. **Confluence MCP** - Search DISH Confluence documentation  
3. **Netra MCP** - Search DISH Netra internal log/record system

All three servers follow identical architecture patterns and deployment strategies, enabling rapid development of future MCP integrations.

---

## 📊 Infrastructure Analysis

### Technology Stack

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **MCP Framework** | FastMCP (Python) | Rapid MCP server development |
| **Runtime** | AWS Lambda (Docker) | Serverless execution |
| **Container Registry** | Amazon ECR | Docker image storage |
| **API Gateway** | Lambda Function URL | Public HTTPS endpoints |
| **GitOps** | ArgoCD | Kubernetes resource tracking |
| **Configuration** | YAML + Python | Dish-Chat MCP client config |
| **Authentication** | Bearer Token (optional) | Lambda URL security |

### Architecture Pattern

```
┌───────────────┐
│  Dish-Chat    │  ← User Interface
│   Frontend    │
└───────┬───────┘
        │ HTTP/WebSocket
        ▼
┌───────────────┐
│  Dish-Chat    │  ← MCP Client Manager
│   Backend     │     - Loads mcp_config.yaml
│  (FastAPI)    │     - Discovers tools
└───────┬───────┘     - Invokes tools
        │
        │ MCP Protocol (HTTP+JSON-RPC)
        ▼
┌───────────────┐
│ MCP Lambda    │  ← FastMCP Server
│   Function    │     - @mcp.tool() decorators
│ (Container)   │     - Async HTTP calls
└───────┬───────┘     - Error handling
        │
        │ REST API
        ▼
┌───────────────┐
│  External     │  ← JIRA, Confluence, etc.
│   Service     │
└───────────────┘
```

---

## 🔍 Detailed Investigation Results

### 1. JIRA MCP Server

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/jira-mcp-server.git  
**Lambda URL:** https://nxfg5xzy3tqfoiowauaycxlbim0lzrmm.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD App:** apps-jira-mcp  
**Merge Request:** #99

**Key Features:**
- Single tool: `jira_search(query, max_results)`
- JQL (JIRA Query Language) text search
- HTTP Basic Authentication (email + API token)
- API version fallback (v3 → v2)
- ADF (Atlassian Document Format) description parsing

**Environment Variables:**
- `JIRA_BASE_URL`: https://dishtech-dishtv.atlassian.net
- `JIRA_USER_EMAIL`: Service account email
- `JIRA_API_TOKEN`: Atlassian API token
- `SEARCH_TIMEOUT`: 10.0 seconds

**Configuration in Dish-Chat:**
```yaml
---
name: jira_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://nxfg5xzy3tqfoiowauaycxlbim0lzrmm.lambda-url.us-west-2.on.aws/mcp
```

### 2. Confluence MCP Server

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/confluence-mcp-server.git  
**Lambda URL:** https://zkuyopzgcra6gsxceqclqbjtma0gfxlj.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD App:** apps-confluence-mcp  
**Merge Request:** #98

**Key Features:**
- Single tool: `confluence_search(query, max_results)`
- CQL (Confluence Query Language) text search
- HTTP Basic Authentication
- HTML tag cleaning for better readability
- Excerpt formatting with truncation

**Environment Variables:**
- `CONFLUENCE_BASE_URL`: https://dishtech-dishtv.atlassian.net/wiki
- `CONFLUENCE_USER_EMAIL`: Service account email
- `CONFLUENCE_API_TOKEN`: Atlassian API token
- `SEARCH_TIMEOUT`: 10.0 seconds

**Configuration in Dish-Chat:**
```yaml
---
name: confluence_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://zkuyopzgcra6gsxceqclqbjtma0gfxlj.lambda-url.us-west-2.on.aws/mcp
```

### 3. Netra MCP Server

**Repository:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/netra-mcp-server  
**Lambda URL:** https://qzjs7rodqibouzgyymup6jt25u0uqxqx.lambda-url.us-west-2.on.aws/mcp  
**ArgoCD App:** apps-netra-mcp  
**Merge Request:** #100

**Key Features:**
- Single tool: `netra_search(rec_id, search_date, query)`
- Record ID + date-based search (both REQUIRED)
- Date format validation (YYYYMMDD)
- HTML response handling
- Internal service (no authentication required)

**Environment Variables:**
- `NETRA_HOST`: netra.dish.com
- `SEARCH_TIMEOUT`: 10.0 seconds

**Configuration in Dish-Chat:**
```yaml
---
name: netra_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://qzjs7rodqibouzgyymup6jt25u0uqxqx.lambda-url.us-west-2.on.aws/mcp
```

---

## 📦 Standard Components

Each MCP server repository contains these files:

### Core Files (Required)

1. **server.py** - FastMCP server implementation
   - Tool definitions with `@mcp.tool()` decorator
   - Async HTTP client logic
   - Error handling
   - Optional `@mcp.prompt()` for LLM context

2. **Dockerfile** - Lambda container definition
   ```dockerfile
   FROM public.ecr.aws/lambda/python:3.12
   COPY requirements.txt ${LAMBDA_TASK_ROOT}
   RUN pip install --no-cache-dir -r requirements.txt
   COPY server.py ${LAMBDA_TASK_ROOT}
   CMD ["server.mcp.run"]
   ```

3. **requirements.txt** - Python dependencies
   ```
   httpx
   mcp
   ```

4. **.env.example** - Environment variable template
   ```bash
   SERVICE_BASE_URL=https://api.example.com
   SERVICE_API_KEY=your_key_here
   ```

### Deployment Files (Required)

5. **deploy_direct.sh** - AWS deployment script
   - Creates ECR repository
   - Builds Docker image
   - Pushes to ECR
   - Creates/updates Lambda function
   - Configures Function URL
   - Sets environment variables

6. **template.yaml** - AWS SAM template (optional)
   - CloudFormation template
   - Alternative to deploy_direct.sh

### Documentation Files (Required)

7. **README.md** - Project overview
8. **DEPLOYMENT.md** - Deployment guide

### Testing Files (Optional)

9. **test.sh** - Integration test script
10. **tests/** - Unit test directory

### Kubernetes Files (For GitOps)

11. **k8s/namespace.yaml** - Namespace definition
12. **k8s/configmap.yaml** - Lambda metadata
13. **k8s/service.yaml** - ExternalName service for discovery
14. **k8s/kustomization.yaml** - Resource bundling

### ArgoCD Files (For GitOps)

15. **argocd/config.json** - ArgoCD Application config
    ```json
    {
      "appName": "service-mcp",
      "userGivenName": "service-mcp",
      "destNamespace": "mcp-tools",
      "destServer": "https://kubernetes.default.svc",
      "srcPath": "service-mcp-server/k8s",
      "srcRepoURL": "https://gitlab.com/.../internal-tools-mcp-server.git",
      "srcTargetRevision": "main",
      "CreateNamespace": true
    }
    ```

---

## 🔑 Key Learnings & Best Practices

### 1. FastMCP Framework

✅ **Use FastMCP** for rapid development
- Simple `@mcp.tool()` decorator
- Automatic schema generation
- Built-in MCP protocol handling
- Async/await support

```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ServiceName")

@mcp.tool()
async def tool_name(param: str) -> str:
    """Tool description for LLM"""
    return "result"

if __name__ == "__main__":
    mcp.run()
```

### 2. AWS Lambda Deployment

✅ **Use containerized Lambda functions**
- Consistent environment across dev/prod
- Easy to include system dependencies
- Supports large applications (up to 10GB)
- Standard Docker workflow

✅ **Use Lambda Function URLs**
- No API Gateway needed for simple cases
- Direct HTTPS endpoint
- Optional IAM authentication
- Lower latency

### 3. Configuration Management

✅ **Support both YAML and Python configs**
- `mcp_config.yaml` - primary configuration
- `config.py` variables - fallback/override

✅ **YAML format** (preferred):
```yaml
---
name: service_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://xxx.lambda-url.us-west-2.on.aws/mcp
  headers:
    Authorization: Bearer TOKEN  # Optional
    Content-Type: application/json
    Accept: application/json, text/event-stream
```

### 4. Error Handling

✅ **Comprehensive error handling**
```python
try:
    resp = await client.get(url)
    resp.raise_for_status()
    return process_response(resp)
except httpx.HTTPStatusError as e:
    if e.response.status_code == 401:
        return "Error: Authentication failed"
    elif e.response.status_code == 403:
        return "Error: Access forbidden"
    return f"Error: {e.response.status_code}"
except httpx.TimeoutException:
    return f"Error: Timed out after {timeout}s"
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    return f"Error: {str(e)}"
```

### 5. Kubernetes Integration (Optional)

✅ **Track Lambda metadata in K8s via ArgoCD**
- Centralized visibility
- GitOps workflow
- Service discovery
- Documentation

⚠️ **Important:** K8s resources are for TRACKING only
- Lambda functions continue running in AWS
- No pods/deployments/containers in K8s
- Lambda updates happen via deploy scripts, NOT ArgoCD

### 6. Security

✅ **Use environment variables for secrets**
```bash
aws lambda update-function-configuration \
  --function-name service-mcp \
  --environment "Variables={API_KEY=xxx,EMAIL=user@dish.com}"
```

✅ **Consider AWS Secrets Manager for production**
```python
import boto3

secrets_client = boto3.client('secretsmanager')
response = secrets_client.get_secret_value(SecretId='service-mcp-credentials')
credentials = json.loads(response['SecretString'])
```

✅ **Optional Bearer Token authentication**
- Add to Lambda Function URL config
- Include in mcp_config.yaml headers

### 7. Testing

✅ **Test Lambda directly with curl**
```bash
curl -X POST -H 'Content-Type: application/json' \
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \
  https://xxx.lambda-url.us-west-2.on.aws/mcp
```

✅ **Test in Dish-Chat UI**
- "What tools do you have access to?"
- "Search [service] for [query]"

---

## 🚀 Deployment Workflow

### Standard Deployment Process

```
1. DEVELOP
   ├── Write server.py
   ├── Create Dockerfile
   ├── Test locally
   └── Create documentation

2. DEPLOY TO AWS
   ├── Run deploy_direct.sh
   ├── Build Docker image
   ├── Push to ECR
   ├── Create/update Lambda
   ├── Configure Function URL
   └── Set environment variables

3. INTEGRATE WITH DISH-CHAT
   ├── Add to mcp_config.yaml
   ├── Restart backend
   └── Verify tool discovery

4. GITOPS (Optional)
   ├── Create k8s/ manifests
   ├── Create argocd/config.json
   ├── Commit to Git
   └── ArgoCD auto-discovers
```

### Deployment Time Estimates

| Phase | Duration | Notes |
|-------|----------|-------|
| Development | 2-4 hours | Server code, Dockerfile, docs |
| AWS Deployment | 10-15 min | ECR + Lambda setup |
| Dish-Chat Integration | 5 min | Config update + restart |
| GitOps Setup | 15-20 min | K8s manifests + ArgoCD config |
| Testing | 10-15 min | End-to-end validation |
| **Total** | **3-5 hours** | First MCP server |
| **Subsequent** | **1-2 hours** | Following template |

---

## 📊 Comparison Matrix

| Feature | JIRA MCP | Confluence MCP | Netra MCP |
|---------|----------|----------------|-----------|
| **Tools** | 1 | 1 | 1 |
| **Authentication** | HTTP Basic Auth | HTTP Basic Auth | None (internal) |
| **Query Language** | JQL | CQL | Record ID + Date |
| **Response Format** | Text with URLs | Text with URLs | JSON |
| **API Fallback** | v3 → v2 | No | No |
| **Special Handling** | ADF parsing | HTML cleaning | Date validation |
| **External Service** | Atlassian JIRA | Atlassian Confluence | DISH Netra |
| **Network Access** | Public internet | Public internet | Internal only |

---

## 🎓 Enhancement Opportunities

### Short-term (Already Documented)

1. **JIRA MCP Enhanced** (/tmp/jira_enhancement_summary.txt)
   - 12 tools (vs 1 original)
   - Advanced JQL queries
   - Issue details, comments, changelog
   - Project management
   - Status: Code complete, awaiting deployment

2. **Confluence MCP Enhanced** (/tmp/confluence_enhancement_summary.txt)
   - 10 tools (vs 1 original)
   - Advanced CQL queries
   - Full page content retrieval
   - Space discovery
   - Status: Code complete, awaiting deployment

### Long-term

3. **Multi-tool MCP Servers**
   - Combine related services
   - Reduce Lambda function count
   - Shared authentication logic

4. **Caching Layer**
   - ElastiCache Redis
   - Reduce API calls
   - Improve response time

5. **Monitoring & Analytics**
   - CloudWatch dashboards
   - Usage metrics
   - Performance tracking

6. **Advanced Security**
   - VPC integration for internal services
   - AWS Secrets Manager
   - IAM authentication for Function URLs

---

## 📁 Files Created During Investigation

### Summary Documents

- `/tmp/MCP_TOOL_PROTOCOL.md` - Comprehensive protocol documentation
- `/tmp/MCP_QUICK_START.md` - Fast-track guide for new MCP tools
- `/tmp/MCP_INVESTIGATION_SUMMARY.md` - This document

### Previous Work

- `/tmp/jira_enhancement_summary.txt` - JIRA MCP v2.0 completion report
- `/tmp/confluence_enhancement_summary.txt` - Confluence MCP v2.0 completion report
- `/tmp/jira_api_research.txt` - JIRA API capabilities
- `/tmp/confluence_api_research.txt` - Confluence API capabilities
- `/tmp/confluence_jira_mcp_yaml.txt` - YAML config examples
- `/tmp/mcp_argocd_setup/ARGOCD_SETUP_REPORT.txt` - ArgoCD integration details

### Repository Clones

- `/tmp/jira-mcp-server-test/` - JIRA MCP server code
- `/tmp/confluence-mcp-server-test/` - Confluence MCP server code
- `/tmp/netra-mcp-server-test/` - Netra MCP server code

---

## 🎯 Next Steps for New MCP Tools

### Using This Investigation

1. **Read Protocol:** `/tmp/MCP_TOOL_PROTOCOL.md`
2. **Copy Template:** Use JIRA/Confluence/Netra as reference
3. **Follow Checklist:** Implementation checklist in protocol doc
4. **Deploy:** Use `deploy_direct.sh` script pattern
5. **Integrate:** Add to `mcp_config.yaml`
6. **Test:** Verify with curl and Dish-Chat UI

### Template Repository

Consider creating a template repo:
```
mcp-server-template/
├── server.py.template
├── Dockerfile
├── requirements.txt
├── .env.example
├── deploy_direct.sh
├── README.md
└── DEPLOYMENT.md
```

---

## 📞 Resources & Support

### Documentation

- **MCP Protocol:** https://modelcontextprotocol.io/
- **FastMCP:** https://github.com/jlowin/fastmcp
- **AWS Lambda:** https://docs.aws.amazon.com/lambda/

### Internal

- **GitLab:** https://gitlab.com/dish-cloud/dt/sse/datasolutions
- **ArgoCD:** https://ds-argocd-latest.dishtv.technology
- **Slack:** #dish-chat-support

### Support

- Email: data-solutions-team@dish.com
- PagerDuty: On-call escalation

---

## ✅ Verification Summary

### Files Investigated

✅ Examined 3 MCP server repositories  
✅ Analyzed deployment configurations  
✅ Reviewed ArgoCD integration  
✅ Inspected Dish-Chat integration  
✅ Documented enhancement summaries  
✅ Extracted common patterns

### Documents Created

✅ MCP Tool Protocol (comprehensive)  
✅ Quick Start Guide (fast-track)  
✅ Investigation Summary (this document)

### Location for Jakes-agent

All documents will be copied to:
```
/home/montjac/Jakes-agent/mcp-documentation/
```

---

## 🎉 Conclusion

The investigation of JIRA, Confluence, and Netra MCP servers has revealed a robust, repeatable pattern for integrating external services with Dish-Chat via the Model Context Protocol.

**Key Success Factors:**
1. FastMCP framework for rapid development
2. AWS Lambda for serverless deployment
3. YAML configuration for flexibility
4. ArgoCD for GitOps tracking
5. Comprehensive error handling
6. Clear documentation

**Outcome:**
A well-documented protocol that enables the Data Solutions team to add new MCP tools in 1-2 hours vs the 3-5 hours required for the first implementation.

---

**Report Version:** 1.0  
**Generated:** 2026-04-17  
**Investigator:** Dish-Chat Agent  
**Status:** COMPLETE ✅

