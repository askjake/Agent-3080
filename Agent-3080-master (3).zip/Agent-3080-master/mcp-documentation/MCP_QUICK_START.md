# MCP Tool Quick Start Guide

**🚀 Ultra-fast guide to adding a new MCP tool to Dish-Chat**

## Step-by-Step (30 minutes)

### 1. Create Server Code (10 min)

\`\`\`python
# server.py
import os
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MyService")

@mcp.tool()
async def search_service(query: str, limit: int = 5) -> str:
    """Search MyService for information."""
    api_key = os.getenv("SERVICE_API_KEY")
    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            "https://api.myservice.com/search",
            params={"q": query, "limit": limit},
            headers={"Authorization": f"Bearer {api_key}"}
        )
        resp.raise_for_status()
        return resp.text

if __name__ == "__main__":
    mcp.run()
\`\`\`

\`\`\`dockerfile
# Dockerfile
FROM public.ecr.aws/lambda/python:3.12
COPY requirements.txt ${LAMBDA_TASK_ROOT}
RUN pip install --no-cache-dir -r requirements.txt
COPY server.py ${LAMBDA_TASK_ROOT}
CMD ["server.mcp.run"]
\`\`\`

\`\`\`
# requirements.txt
httpx
mcp
\`\`\`

### 2. Deploy to AWS (10 min)

\`\`\`bash
# Build & push
docker build -t myservice-mcp .
aws ecr create-repository --repository-name myservice-mcp
aws ecr get-login-password | docker login ...
docker tag myservice-mcp:latest ACCOUNT.dkr.ecr.us-west-2.amazonaws.com/myservice-mcp:latest
docker push ...

# Create Lambda
aws lambda create-function \\
  --function-name myservice-mcp \\
  --package-type Image \\
  --code ImageUri=ACCOUNT.dkr.ecr.us-west-2.amazonaws.com/myservice-mcp:latest \\
  --role arn:aws:iam::ACCOUNT:role/lambda-execution-role \\
  --timeout 30 \\
  --memory-size 512

# Get Function URL
aws lambda create-function-url-config \\
  --function-name myservice-mcp \\
  --auth-type NONE
# Output: https://abc123.lambda-url.us-west-2.on.aws
\`\`\`

### 3. Add to Dish-Chat (5 min)

\`\`\`bash
# Edit config
nano /home/montjac/dish-chat/app/mcp_config.yaml
\`\`\`

\`\`\`yaml
# Add this block:
---
name: myservice_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://abc123.lambda-url.us-west-2.on.aws/mcp
\`\`\`

\`\`\`bash
# Restart
sudo systemctl restart dish-chat
\`\`\`

### 4. Test (5 min)

\`\`\`bash
# Test Lambda
curl -X POST -H 'Content-Type: application/json' \\
  -d '{"jsonrpc": "2.0", "method": "tools/list", "id": 1}' \\
  https://abc123.lambda-url.us-west-2.on.aws/mcp

# Test in Dish-Chat
# Ask: "What tools do you have?"
# Ask: "Search myservice for X"
\`\`\`

## Done! ✅

Your new MCP tool is now integrated with Dish-Chat.

## Common Patterns

### With Authentication

\`\`\`python
SERVICE_API_KEY = os.getenv("SERVICE_API_KEY")
auth = httpx.BasicAuth(username, password)  # or
headers = {"Authorization": f"Bearer {SERVICE_API_KEY}"}
\`\`\`

### Error Handling

\`\`\`python
try:
    resp = await client.get(url)
    resp.raise_for_status()
    return resp.text
except httpx.HTTPStatusError as e:
    if e.response.status_code == 401:
        return "Error: Authentication failed"
    return f"Error: {e.response.status_code}"
except httpx.TimeoutException:
    return "Error: Request timed out"
except Exception as e:
    return f"Error: {str(e)}"
\`\`\`

### Multiple Tools

\`\`\`python
@mcp.tool()
async def search_items(query: str) -> str:
    """Search for items"""
    pass

@mcp.tool()
async def get_item_details(item_id: str) -> str:
    """Get item details"""
    pass

@mcp.tool()
async def list_categories() -> str:
    """List all categories"""
    pass
\`\`\`

## Reference URLs

- **JIRA MCP:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/jira-mcp-server.git
- **Confluence MCP:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/confluence-mcp-server.git
- **Netra MCP:** https://gitlab.com/dish-cloud/dt/sse/datasolutions/netra-mcp-server
- **Full Protocol:** /tmp/MCP_TOOL_PROTOCOL.md

## Troubleshooting

| Problem | Solution |
|---------|----------|
| "Authentication failed" | Set SERVICE_API_KEY in Lambda environment |
| "Tool not found" | Check mcp_config.yaml syntax, restart dish-chat |
| "Timeout" | Increase timeout in server.py or Lambda config |
| "Docker build fails" | Check Python version, requirements.txt |

## Need Help?

- Slack: #dish-chat-support
- Full docs: /tmp/MCP_TOOL_PROTOCOL.md
- Examples: /tmp/jira-mcp-server-test/, /tmp/confluence-mcp-server-test/

