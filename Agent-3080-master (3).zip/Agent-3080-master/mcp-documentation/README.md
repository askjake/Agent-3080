# MCP Tool Documentation

**Last Updated:** 2026-04-17  
**Status:** Production Ready ✅

---

## 📚 Documentation Index

This directory contains comprehensive documentation for adding new MCP (Model Context Protocol) tools to the Dish-Chat backend.

### Quick Access

| Document | Purpose | Read Time |
|----------|---------|-----------|
| **[MCP_QUICK_START.md](./MCP_QUICK_START.md)** | Get started in 30 minutes | 5 min |
| **[MCP_TOOL_PROTOCOL.md](./MCP_TOOL_PROTOCOL.md)** | Complete reference guide | 30 min |
| **[MCP_INVESTIGATION_SUMMARY.md](./MCP_INVESTIGATION_SUMMARY.md)** | Investigation findings | 15 min |

### Supporting Documents

| Document | Purpose |
|----------|---------|
| **[jira_enhancement_summary.txt](./jira_enhancement_summary.txt)** | JIRA MCP v2.0 details |
| **[confluence_enhancement_summary.txt](./confluence_enhancement_summary.txt)** | Confluence MCP v2.0 details |
| **[confluence_jira_mcp_yaml.txt](./confluence_jira_mcp_yaml.txt)** | YAML configuration examples |

---

## 🚀 Getting Started

### I want to add a new MCP tool quickly
→ Read **MCP_QUICK_START.md** (30 minutes to deployment)

### I want to understand the complete process
→ Read **MCP_TOOL_PROTOCOL.md** (comprehensive guide)

### I want to see what was learned from previous work
→ Read **MCP_INVESTIGATION_SUMMARY.md** (investigation findings)

---

## 📖 What is MCP?

**Model Context Protocol (MCP)** is a standard for connecting LLMs (Large Language Models) to external data sources and tools.

In Dish-Chat:
- **MCP Servers** = Lambda functions that expose tools (search JIRA, query Confluence, etc.)
- **MCP Client** = Dish-Chat backend that invokes these tools
- **Protocol** = JSON-RPC over HTTP for tool discovery and invocation

---

## 🏗️ Current MCP Servers

| MCP Server | Purpose | Status |
|------------|---------|--------|
| **JIRA MCP** | Search DISH JIRA issues | ✅ Production |
| **Confluence MCP** | Search DISH Confluence docs | ✅ Production |
| **Netra MCP** | Search DISH Netra records | ✅ Production |
| **STB Health MCP** | STB health monitoring | ✅ Production |
| **Beta Report MCP** | Beta testing reports | ✅ Production |

---

## 🎯 Architecture Overview

```
┌─────────────┐
│ Dish-Chat   │ ← Users interact with chat UI
│  Frontend   │
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ Dish-Chat   │ ← MCP Client Manager
│  Backend    │   - Loads mcp_config.yaml
└──────┬──────┘   - Discovers tools from MCP servers
       │           - Routes tool invocations
       │
       │ MCP Protocol (HTTP + JSON-RPC 2.0)
       │
       ├─────────┬─────────┬─────────┬─────────┐
       ▼         ▼         ▼         ▼         ▼
   ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
   │ JIRA   │ │Conflue │ │ Netra  │ │  STB   │ │ Beta   │
   │  MCP   │ │nce MCP │ │  MCP   │ │ Health │ │ Report │
   │ Lambda │ │ Lambda │ │ Lambda │ │  MCP   │ │  MCP   │
   └────┬───┘ └────┬───┘ └────┬───┘ └────┬───┘ └────┬───┘
        │          │          │          │          │
        ▼          ▼          ▼          ▼          ▼
   External APIs (JIRA, Confluence, Netra, STB Health, etc.)
```

---

## 🔑 Key Technologies

- **FastMCP** - Python framework for rapid MCP server development
- **AWS Lambda** - Serverless execution (Docker containers)
- **Lambda Function URLs** - Public HTTPS endpoints
- **Amazon ECR** - Docker image storage
- **ArgoCD** - GitOps tracking (optional)
- **YAML Configuration** - Flexible MCP client config

---

## 📝 Quick Example

### Minimal MCP Server

```python
# server.py
import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MyService")

@mcp.tool()
async def search_items(query: str) -> str:
    """Search for items in MyService."""
    async with httpx.AsyncClient() as client:
        resp = await client.get(f"https://api.myservice.com/search?q={query}")
        return resp.text

if __name__ == "__main__":
    mcp.run()
```

### Deploy to Lambda

```bash
docker build -t myservice-mcp .
aws ecr create-repository --repository-name myservice-mcp
# ... push to ECR ...
aws lambda create-function --function-name myservice-mcp --package-type Image --code ImageUri=...
aws lambda create-function-url-config --function-name myservice-mcp --auth-type NONE
```

### Configure in Dish-Chat

```yaml
# /home/montjac/dish-chat/app/mcp_config.yaml
---
name: myservice_mcp
user_selectable: true
connection:
  transport: streamable_http
  url: https://abc123.lambda-url.us-west-2.on.aws/mcp
```

**Done!** ✅ Your new tool is now available in Dish-Chat.

---

## 📊 Documentation Statistics

| Metric | Value |
|--------|-------|
| Total Documents | 6 |
| Total Pages | ~85 (estimated) |
| MCP Servers Documented | 3 (JIRA, Confluence, Netra) |
| Code Examples | 50+ |
| Deployment Scripts | 3 |
| Configuration Examples | 10+ |

---

## 🔄 Updates & Maintenance

### Last Major Update
**Date:** 2026-04-17  
**Changes:**
- Initial comprehensive documentation
- Documented JIRA, Confluence, Netra MCP servers
- Created protocol, quick start, and summary docs

### Next Review
**Date:** 2026-07-17 (3 months)  
**Focus:**
- Update with new MCP servers
- Add lessons learned from production use
- Enhance troubleshooting section

---

## 📞 Support

### Questions About MCP Tools?
- **Slack:** #dish-chat-support
- **Email:** data-solutions-team@dish.com
- **GitLab:** https://gitlab.com/dish-cloud/dt/sse/datasolutions

### Want to Add a New MCP Tool?
1. Read MCP_QUICK_START.md
2. Clone a reference implementation (JIRA/Confluence/Netra)
3. Follow the checklist in MCP_TOOL_PROTOCOL.md
4. Reach out on Slack if you get stuck

### Found an Issue in Documentation?
- Create GitLab issue
- Tag: @data-solutions-team
- Include document name and section

---

## 🎓 Learning Path

### Beginner (New to MCP)
1. Read "What is MCP?" section in this README
2. Review Quick Example above
3. Read MCP_QUICK_START.md
4. Try deploying JIRA MCP from reference

### Intermediate (Familiar with MCP)
1. Read MCP_TOOL_PROTOCOL.md
2. Review reference implementations (JIRA, Confluence, Netra)
3. Deploy a custom MCP server
4. Document your learnings

### Advanced (Building Complex MCP Servers)
1. Study enhancement summaries (jira_enhancement_summary.txt)
2. Review ArgoCD GitOps integration
3. Implement multi-tool MCP servers
4. Add caching and optimization

---

## 🏆 Best Practices

### Development
✅ Use FastMCP framework  
✅ Write comprehensive docstrings  
✅ Handle all error cases  
✅ Test locally before deploying  
✅ Follow existing patterns

### Deployment
✅ Use deploy_direct.sh script pattern  
✅ Store secrets in environment variables  
✅ Test Lambda endpoint after deploy  
✅ Document Function URL in README  
✅ Verify in Dish-Chat UI

### Documentation
✅ Create README.md with examples  
✅ Document all environment variables  
✅ Provide troubleshooting section  
✅ Include curl test commands  
✅ Update this documentation directory

---

## 📦 File Organization

```
mcp-documentation/
├── README.md                              ← You are here
├── MCP_QUICK_START.md                     ← 30-min guide
├── MCP_TOOL_PROTOCOL.md                   ← Comprehensive protocol
├── MCP_INVESTIGATION_SUMMARY.md           ← Investigation findings
├── jira_enhancement_summary.txt           ← JIRA MCP v2.0 details
├── confluence_enhancement_summary.txt     ← Confluence MCP v2.0 details
└── confluence_jira_mcp_yaml.txt           ← Config examples
```

---

## 🎯 Success Criteria

You'll know you've successfully added an MCP tool when:

- [ ] Lambda function responds to curl test
- [ ] `tools/list` returns your tool definition
- [ ] Tool appears in Dish-Chat UI
- [ ] Agent can successfully invoke your tool
- [ ] Error cases return helpful messages
- [ ] Documentation is complete
- [ ] Team members can use it

---

## 🚀 Ready to Start?

Choose your path:

**Fast Track (30 minutes):**  
→ Open [MCP_QUICK_START.md](./MCP_QUICK_START.md)

**Comprehensive (1 hour):**  
→ Open [MCP_TOOL_PROTOCOL.md](./MCP_TOOL_PROTOCOL.md)

**Understanding (15 minutes):**  
→ Open [MCP_INVESTIGATION_SUMMARY.md](./MCP_INVESTIGATION_SUMMARY.md)

---

**Documentation Version:** 1.0  
**Maintained By:** Data Solutions Team  
**Contact:** #dish-chat-support on Slack

