#!/bin/bash
# Dish-Chat 3080 Agent Startup Script - Refactored
# Updated: 2026-04-28
# Prevents Python bytecode caching to avoid stale code issues

set -euo pipefail  # Exit on error, undefined vars, pipe failures

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() { echo -e "${BLUE}▶${NC} $1"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warn() { echo -e "${YELLOW}⚠${NC} $1"; }
log_error() { echo -e "${RED}✗${NC} $1"; }

# Configuration
DISH_CHAT_DIR="${DISH_CHAT_DIR:-$HOME/dish-chat}"
JAKES_AGENT_DIR="${JAKES_AGENT_DIR:-$HOME/Jakes-agent/dish-chat}"
LOG_DIR="$HOME/dish-chat-logs"
BACKEND_HOST="${FASTAPI_HOST:-0.0.0.0}"
BACKEND_PORT="${FASTAPI_PORT:-8000}"

# Create log directory
mkdir -p "$LOG_DIR"

echo "========================================"
echo "  Dish-Chat Startup - 3080 Agent"
echo "========================================"
log_info "Config: $DISH_CHAT_DIR"
log_info "Logs: $LOG_DIR"
echo ""

# Step 1: Refresh AWS tokens
echo "[1/4] AWS Token Refresh"
log_info "Running secgateway..."
if python3 ~/secgateway/bin/secgateway.py; then
    log_success "AWS tokens refreshed"
else
    log_error "AWS token refresh failed!"
    exit 1
fi
echo ""

# Step 2: Clean up stale processes
echo "[2/4] Process Cleanup"
EXISTING_PID=$(pgrep -f "uvicorn app.main:app" | head -1 || echo "")
if [ -n "$EXISTING_PID" ]; then
    log_warn "Found existing uvicorn process (PID: $EXISTING_PID)"
    log_info "Stopping existing process..."
    kill "$EXISTING_PID" 2>/dev/null || true
    sleep 2
    log_success "Process stopped"
else
    log_info "No existing processes found"
fi

# Clean up PID files
rm -f "$DISH_CHAT_DIR/backend.pid" 2>/dev/null || true
rm -f "$JAKES_AGENT_DIR/backend.pid" 2>/dev/null || true
echo ""

# Step 3: Clear Python bytecode cache
echo "[3/4] Cache Cleanup"
log_info "Clearing Python bytecode cache..."
find "$DISH_CHAT_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$DISH_CHAT_DIR" -type f -name "*.pyc" -delete 2>/dev/null || true
find "$JAKES_AGENT_DIR" -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
find "$JAKES_AGENT_DIR" -type f -name "*.pyc" -delete 2>/dev/null || true
log_success "Cache cleared"
echo ""

# Step 4: Start backend
echo "[4/4] Starting Backend"
cd "$DISH_CHAT_DIR" || exit 1

# Activate virtual environment
if [ -f ".venv/bin/activate" ]; then
    source .venv/bin/activate
    log_success "Virtual environment activated"
else
    log_error "Virtual environment not found at $DISH_CHAT_DIR/.venv"
    exit 1
fi

# Set environment variables to prevent bytecode caching
export PYTHONDONTWRITEBYTECODE=1
export PYTHONUNBUFFERED=1

log_info "Starting uvicorn on $BACKEND_HOST:$BACKEND_PORT..."
log_info "Command: python -B -m uvicorn app.main:app --host $BACKEND_HOST --port $BACKEND_PORT --reload"

# Start uvicorn in background with bytecode prevention
nohup python -B -m uvicorn app.main:app \
    --host "$BACKEND_HOST" \
    --port "$BACKEND_PORT" \
    --reload \
    >> "$LOG_DIR/backend.log" 2>&1 &

BACKEND_PID=$!
echo $BACKEND_PID > backend.pid

log_info "Backend started (PID: $BACKEND_PID)"
sleep 3

# Verify backend is running
if ! ps -p $BACKEND_PID > /dev/null; then
    log_error "Backend failed to start. Check logs:"
    log_error "  tail -f $LOG_DIR/backend.log"
    tail -20 "$LOG_DIR/backend.log"
    exit 1
fi

# Test HTTP endpoint
log_info "Testing HTTP endpoint..."
sleep 2
if curl -s --max-time 5 http://localhost:$BACKEND_PORT/docs > /dev/null 2>&1; then
    log_success "Backend is responding"
else
    log_warn "Backend not responding yet (may still be loading)"
fi

echo ""
echo "========================================"
log_success "Startup complete!"
echo "  Backend PID: $BACKEND_PID"
echo "  Endpoint: http://localhost:$BACKEND_PORT"
echo "  Logs: tail -f $LOG_DIR/backend.log"
echo "  Stop: kill $BACKEND_PID"
echo "========================================"
