from functools import cache
from typing import Optional
import logging
import asyncio
import os
import configparser
import boto3
from datetime import datetime, timedelta, timezone

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.runnables import ConfigurableField
from langchain_aws import ChatBedrockConverse
from botocore.exceptions import ClientError

from app.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

# Store model instances with token expiry tracking
_model_cache = {
    "efficient": {"model": None, "expires_at": None},
    "primary": {"model": None, "expires_at": None}
}

_AWS_CREDENTIALS_PATH = os.environ.get("AWS_SHARED_CREDENTIALS_FILE", os.path.expanduser("~/.aws/credentials"))

# Background task for token refresh
_refresh_task = None
_refresh_lock = asyncio.Lock()
_task_started = False  # Flag to prevent multiple task starts

def _clear_boto3_credential_cache():
    """
    Force boto3 to clear its internal credential cache.
    
    This is CRITICAL when credentials are refreshed externally (like by secgateway.py).
    Without this, boto3 will continue using expired credentials cached in memory
    even after the ~/.aws/credentials file has been updated.
    """
    try:
        # Clear the default session (this is where boto3 caches credentials)
        if hasattr(boto3, 'DEFAULT_SESSION') and boto3.DEFAULT_SESSION is not None:
            logger.debug("Clearing boto3 DEFAULT_SESSION credential cache")
            boto3.DEFAULT_SESSION = None
        
        # Force creation of new session with fresh credentials
        session = boto3.Session()
        credentials = session.get_credentials()
        if credentials:
            # Force credential refresh by invalidating the cache
            if hasattr(credentials, '_refresh'):
                logger.debug("Forcing boto3 credential refresh")
                # Call refresh to reload from file
                credentials._refresh()
            
        logger.info("Cleared boto3 credential cache - will reload from credentials file")
        
    except Exception as e:
        logger.warning(f"Error clearing boto3 credential cache: {e}")

def _read_aws_credentials_expiration() -> Optional[datetime]:
    """
    Read AWS credential expiration from ~/.aws/credentials file.
    Many credential providers (like secgateway.py) write an 'expiration' field.
    
    Returns:
        datetime of when credentials expire, or None if not available
    """
    try:
        if not os.path.exists(_AWS_CREDENTIALS_PATH):
            logger.debug(f"Credentials file not found: {_AWS_CREDENTIALS_PATH}")
            return None

        parser = configparser.RawConfigParser()
        parser.read(_AWS_CREDENTIALS_PATH)

        if not parser.has_section("default"):
            logger.debug("No [default] section in credentials file")
            return None

        expiration_raw = parser.get("default", "expiration", fallback=None)
        if not expiration_raw:
            logger.debug("No 'expiration' field in credentials file")
            return None

        # Parse ISO 8601 format (e.g., "2026-03-26T17:27:37Z")
        exp = expiration_raw.strip()
        if exp.endswith("Z"):
            exp = exp[:-1] + "+00:00"
            
        expiration_dt = datetime.fromisoformat(exp)
        if expiration_dt.tzinfo is not None:
            expiration_dt = expiration_dt.astimezone(timezone.utc).replace(tzinfo=None)
            
        logger.debug(f"Read expiration from credentials file: {expiration_dt} UTC")
        return expiration_dt
        
    except Exception as e:
        logger.warning(f"Could not read expiration from credentials file: {e}")
        return None


def _get_aws_token_expiry_from_session() -> Optional[datetime]:
    """
    Try to get AWS token expiration from boto3 session (works for STS temporary credentials).
    
    Returns:
        datetime of when credentials expire, or None if not available
    """
    try:
        session = boto3.Session()
        credentials = session.get_credentials()
        
        if credentials is None:
            logger.warning("No AWS credentials found in boto3 session")
            return None
            
        # Try to get expiration from the session (works for STS credentials)
        if hasattr(session, '_session'):
            botocore_session = session._session
            if botocore_session and hasattr(botocore_session, '_credentials'):
                creds = botocore_session._credentials
                if hasattr(creds, '_expiry_time'):
                    expiry = creds._expiry_time
                    logger.debug(f"Found AWS token expiry from boto3 session: {expiry}")
                    return expiry
        
        logger.debug("No _expiry_time attribute in boto3 session")
        return None
        
    except Exception as e:
        logger.warning(f"Error getting AWS token expiry from session: {e}")
        return None


def _get_next_token_expiry() -> datetime:
    """
    Get token expiration time with improved fallback logic.
    
    Priority order:
    1. Read 'expiration' field from ~/.aws/credentials (written by secgateway.py or similar)
    2. Query boto3 session for STS credential expiry
    3. Assume 1 hour from now (last resort)
    
    Refresh 5 minutes before actual expiration.
    """
    # Priority 1: Try reading from credentials file
    expiry_from_file = _read_aws_credentials_expiration()
    if expiry_from_file:
        refresh_time = expiry_from_file - timedelta(minutes=5)
        now = datetime.utcnow()
        
        if refresh_time <= now:
            logger.warning(f"Token expires at {expiry_from_file} (very soon or past). Refreshing immediately.")
            return now
        
        logger.info(f"AWS token expires at {expiry_from_file} UTC (from credentials file), will refresh at {refresh_time} UTC")
        return refresh_time
    
    # Priority 2: Try boto3 session (for STS credentials)
    expiry_from_session = _get_aws_token_expiry_from_session()
    if expiry_from_session:
        refresh_time = expiry_from_session - timedelta(minutes=5)
        now = datetime.utcnow()
        
        if refresh_time <= now:
            logger.warning(f"Token expires at {expiry_from_session} (very soon or past). Refreshing immediately.")
            return now
        
        logger.info(f"AWS token expires at {expiry_from_session} UTC (from boto3 session), will refresh at {refresh_time} UTC")
        return refresh_time
    
    # Priority 3: Last resort - assume 1-hour token lifetime
    logger.warning("No expiration info available from file or session, assuming 1-hour token lifetime")
    return datetime.utcnow() + timedelta(minutes=50)


def _create_bedrock_model(model_name: str, max_tokens: int) -> ChatBedrockConverse:
    """
    Create a new ChatBedrockConverse instance with fresh credentials.
    
    CRITICAL: This function now clears boto3's credential cache first to ensure
    we pick up any externally-refreshed credentials from ~/.aws/credentials
    
    Args:
        model_name: The Bedrock model identifier
        max_tokens: Maximum tokens for the model
        
    Returns:
        A new ChatBedrockConverse instance with fresh AWS credentials
    """
    logger.info(f"Creating new Bedrock model instance for {model_name}")
    
    # CRITICAL FIX: Clear boto3 credential cache to force reload from file
    _clear_boto3_credential_cache()
    
    return ChatBedrockConverse(
        model=model_name,
        max_tokens=max_tokens,
        region_name=settings.AWS_REGION,
        disable_streaming=False
    )

async def _refresh_models_periodically():
    """Background task to refresh models before token expiry."""
    while True:
        try:
            # Calculate sleep time until next refresh
            refresh_time = _get_next_token_expiry()
            now = datetime.utcnow()
            sleep_seconds = (refresh_time - now).total_seconds()
            
            # Ensure minimum delay to prevent infinite loops
            if sleep_seconds > 0:
                logger.info(f"Next token refresh scheduled in {sleep_seconds/60:.1f} minutes (at {refresh_time} UTC)")
                await asyncio.sleep(sleep_seconds)
            else:
                # Token already expired or expires very soon, refresh immediately
                logger.warning(f"Token expired or expiring soon (sleep_seconds={sleep_seconds:.1f}), refreshing now")
            
            # CRITICAL FIX: Clear credential cache before refreshing models
            _clear_boto3_credential_cache()
            
            # Refresh all cached models WITHOUT triggering task restart
            logger.info("Proactively refreshing AWS tokens for all models")
            for cache_key in ["efficient", "primary"]:
                if _model_cache[cache_key]["model"] is not None:
                    # Direct model refresh without calling get_model to avoid loop
                    efficient = (cache_key == "efficient")
                    if efficient and settings.ELLM_MODEL:
                        if settings.ELLM_PROVIDER == "aws-bedrock":
                            model = _create_bedrock_model(settings.ELLM_MODEL, 4096)
                        else:
                            continue
                    else:
                        if settings.PLLM_PROVIDER == "aws-bedrock":
                            model = _create_bedrock_model(settings.PLLM_MODEL, settings.MAX_OUTPUT_COUNT)
                        else:
                            continue
                    
                    # Update cache directly
                    _model_cache[cache_key] = {
                        "model": model,
                        "expires_at": _get_next_token_expiry()
                    }
                    logger.info(f"Refreshed {cache_key} model with new AWS tokens")
                        
        except Exception as e:
            logger.error(f"Error in token refresh background task: {e}", exc_info=True)
            # On error, wait 5 minutes and try again
            await asyncio.sleep(300)

def start_token_refresh_task():
    """Start the background token refresh task (only once)."""
    global _refresh_task, _task_started
    
    # Check if task already started
    if _task_started:
        return
        
    if _refresh_task is None or _refresh_task.done():
        _refresh_task = asyncio.create_task(_refresh_models_periodically())
        _task_started = True
        logger.info("Started AWS token refresh background task")

def get_model(efficient: bool = False, force_refresh: bool = False) -> BaseChatModel:
    """
    Get chat model objects with automatic credential refresh on expiry.
    
    Args:
        efficient: use smaller and more cost friendly model
        force_refresh: force creation of new model instance (useful after token expiry)

    Returns:
        A Langchain chat model object.
    """
    cache_key = "efficient" if efficient else "primary"
    
    # Check if model exists and token hasn't expired
    cache_entry = _model_cache[cache_key]
    if not force_refresh and cache_entry["model"] is not None:
        # Check if token is still valid
        if cache_entry["expires_at"] and datetime.utcnow() < cache_entry["expires_at"]:
            return cache_entry["model"]
        else:
            logger.warning(f"{cache_key.capitalize()} model token expired, refreshing")
    
    # When force_refresh is True, clear boto3 cache first
    if force_refresh:
        logger.info("Force refresh requested - clearing boto3 credential cache")
        _clear_boto3_credential_cache()
    
    # Create new model instance
    if efficient and settings.ELLM_MODEL:
        if settings.ELLM_PROVIDER == "aws-bedrock":
            model = _create_bedrock_model(settings.ELLM_MODEL, 4096)
        else:
            raise NotImplementedError(f"Provider {settings.ELLM_PROVIDER} not implemented yet")
    else:
        if settings.PLLM_PROVIDER == "aws-bedrock":
            model = _create_bedrock_model(settings.PLLM_MODEL, settings.MAX_OUTPUT_COUNT)
        else:
            raise NotImplementedError(f"Provider {settings.PLLM_PROVIDER} not implemented yet")
    
    # Cache the new model with expiry time
    _model_cache[cache_key] = {
        "model": model,
        "expires_at": _get_next_token_expiry()
    }
    
    logger.debug(f"Created new {cache_key} model instance, expires at {_model_cache[cache_key]['expires_at']}")
    
    # Ensure background refresh task is running (but only start once)
    try:
        start_token_refresh_task()
    except RuntimeError:
        # Event loop not running yet, will start on first async call
        pass
    
    return model

async def invoke_with_retry(
    model: BaseChatModel,
    messages,
    efficient: bool = False,
    max_retries: int = 2
) -> any:
    """
    Invoke model with automatic retry on ExpiredTokenException.
    
    Args:
        model: The model to invoke
        messages: The messages to send (list of Message objects or compatible format)
        efficient: Whether this is an efficient model (for refresh)
        max_retries: Maximum number of retries on token expiry
        
    Returns:
        Model response
        
    Raises:
        Exception: If all retries fail
    """
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            return await model.ainvoke(messages)
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            last_exception = e
            
            if error_code == 'ExpiredTokenException':
                if attempt < max_retries:
                    logger.warning(
                        f"AWS token expired during invocation, "
                        f"refreshing and retrying (attempt {attempt + 1}/{max_retries + 1})"
                    )
                    # Get fresh model with new credentials
                    model = get_model(efficient=efficient, force_refresh=True)
                    # Small delay before retry
                    await asyncio.sleep(1)
                    continue
                else:
                    logger.error(
                        f"AWS token expired and max retries ({max_retries}) reached. "
                        "This should not happen with proactive refresh. Check token refresh task."
                    )
                    raise
            else:
                # Re-raise non-token-expiry errors immediately
                logger.error(f"AWS Bedrock error (non-token): {error_code} - {str(e)}")
                raise
                
        except Exception as e:
            # Handle other exceptions
            logger.error(f"Unexpected error during model invocation: {type(e).__name__} - {str(e)}")
            raise
    
    # Should never reach here
    if last_exception:
        raise last_exception
    raise Exception("Unexpected error in invoke_with_retry")

async def stream_with_retry(
    model: BaseChatModel,
    messages,
    efficient: bool = False,
    max_retries: int = 2
):
    """
    Stream model response with automatic retry on ExpiredTokenException.
    
    Args:
        model: The model to invoke
        messages: The messages to send
        efficient: Whether this is an efficient model
        max_retries: Maximum number of retries on token expiry
        
    Yields:
        Streaming response chunks
        
    Raises:
        Exception: If all retries fail
    """
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            async for chunk in model.astream(messages):
                yield chunk
            return  # Success, exit
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', '')
            last_exception = e
            
            if error_code == 'ExpiredTokenException':
                if attempt < max_retries:
                    logger.warning(
                        f"AWS token expired during streaming, "
                        f"refreshing and retrying (attempt {attempt + 1}/{max_retries + 1})"
                    )
                    # Get fresh model with new credentials
                    model = get_model(efficient=efficient, force_refresh=True)
                    await asyncio.sleep(1)
                    continue
                else:
                    logger.error(f"AWS token expired and max retries ({max_retries}) reached")
                    raise
            else:
                logger.error(f"AWS Bedrock error during streaming: {error_code} - {str(e)}")
                raise
                
        except Exception as e:
            logger.error(f"Unexpected error during model streaming: {type(e).__name__} - {str(e)}")
            raise
    
    if last_exception:
        raise last_exception
    raise Exception("Unexpected error in stream_with_retry")
