
"""
Token Analytics and Safety Monitoring
Tracks token usage, costs, and safety events across agents
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import pandas as pd

class TokenAnalytics:
    """
    Tracks and analyzes token usage across agents
    Helps identify wasteful patterns and optimize prompts
    """
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
        self.pricing = {
            'gpt-4': {'input': 0.03, 'output': 0.06},  # per 1K tokens
            'gpt-3.5-turbo': {'input': 0.0015, 'output': 0.002},
            'claude-sonnet': {'input': 0.003, 'output': 0.015},
            'claude-opus': {'input': 0.015, 'output': 0.075}
        }
    
    def log_conversation(
        self,
        agent_id: str,
        prompt_tokens: int,
        completion_tokens: int,
        model: str = 'gpt-4',
        metadata: Optional[Dict] = None
    ) -> str:
        """Log a conversation's token usage"""
        total_tokens = prompt_tokens + completion_tokens
        
        # Calculate cost
        pricing = self.pricing.get(model, self.pricing['gpt-4'])
        cost = (prompt_tokens / 1000 * pricing['input']) + \
               (completion_tokens / 1000 * pricing['output'])
        
        # Generate conversation ID
        conv_id = f"conv_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{agent_id[:6]}"
        
        # Store in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO conversations (id, agent_id, timestamp, tokens_used, prompt_tokens, completion_tokens, cost, conversation_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            conv_id,
            agent_id,
            datetime.now().isoformat(),
            total_tokens,
            prompt_tokens,
            completion_tokens,
            cost,
            json.dumps(metadata or {})
        ))
        
        conn.commit()
        conn.close()
        
        return conv_id
    
    def get_agent_stats(self, agent_id: str, days: int = 30) -> Dict[str, Any]:
        """Get token usage statistics for an agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
            SELECT 
                COUNT(*) as conversation_count,
                SUM(tokens_used) as total_tokens,
                SUM(prompt_tokens) as total_prompt_tokens,
                SUM(completion_tokens) as total_completion_tokens,
                SUM(cost) as total_cost,
                AVG(tokens_used) as avg_tokens_per_conv,
                MAX(tokens_used) as max_tokens,
                MIN(tokens_used) as min_tokens
            FROM conversations
            WHERE agent_id = ? AND timestamp >= ?
        """, (agent_id, start_date))
        
        row = cursor.fetchone()
        conn.close()
        
        if row and row[0] > 0:
            return {
                'conversation_count': row[0],
                'total_tokens': row[1] or 0,
                'total_prompt_tokens': row[2] or 0,
                'total_completion_tokens': row[3] or 0,
                'total_cost': row[4] or 0,
                'avg_tokens_per_conv': row[5] or 0,
                'max_tokens': row[6] or 0,
                'min_tokens': row[7] or 0,
                'efficiency_score': self._calculate_efficiency(row[2], row[3])
            }
        return {}
    
    def get_all_agents_stats(self, days: int = 30) -> pd.DataFrame:
        """Get comparative statistics across all agents"""
        conn = sqlite3.connect(self.db_path)
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        query = """
            SELECT 
                a.name,
                a.id,
                COUNT(c.id) as conversations,
                SUM(c.tokens_used) as total_tokens,
                SUM(c.cost) as total_cost,
                AVG(c.tokens_used) as avg_tokens
            FROM agents a
            LEFT JOIN conversations c ON a.id = c.agent_id AND c.timestamp >= ?
            GROUP BY a.id
        """
        
        df = pd.read_sql_query(query, conn, params=(start_date,))
        conn.close()
        
        return df
    
    def identify_wasteful_patterns(self, agent_id: str, threshold: int = 5000) -> List[Dict[str, Any]]:
        """
        Identify conversations with unusually high token usage
        Helps detect inefficient prompts or repeated requests
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, timestamp, tokens_used, prompt_tokens, completion_tokens, conversation_data
            FROM conversations
            WHERE agent_id = ? AND tokens_used > ?
            ORDER BY tokens_used DESC
            LIMIT 20
        """, (agent_id, threshold))
        
        rows = cursor.fetchall()
        conn.close()
        
        wasteful = []
        for row in rows:
            wasteful.append({
                'conversation_id': row[0],
                'timestamp': row[1],
                'tokens_used': row[2],
                'prompt_tokens': row[3],
                'completion_tokens': row[4],
                'metadata': json.loads(row[5]) if row[5] else {}
            })
        
        return wasteful
    
    def get_time_series(self, agent_id: Optional[str] = None, days: int = 30) -> pd.DataFrame:
        """Get token usage over time"""
        conn = sqlite3.connect(self.db_path)
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        if agent_id:
            query = """
                SELECT 
                    DATE(timestamp) as date,
                    SUM(tokens_used) as tokens,
                    SUM(cost) as cost,
                    COUNT(*) as conversations
                FROM conversations
                WHERE agent_id = ? AND timestamp >= ?
                GROUP BY DATE(timestamp)
                ORDER BY date
            """
            df = pd.read_sql_query(query, conn, params=(agent_id, start_date))
        else:
            query = """
                SELECT 
                    DATE(timestamp) as date,
                    SUM(tokens_used) as tokens,
                    SUM(cost) as cost,
                    COUNT(*) as conversations
                FROM conversations
                WHERE timestamp >= ?
                GROUP BY DATE(timestamp)
                ORDER BY date
            """
            df = pd.read_sql_query(query, conn, params=(start_date,))
        
        conn.close()
        return df
    
    def _calculate_efficiency(self, prompt_tokens: Optional[int], completion_tokens: Optional[int]) -> float:
        """
        Calculate efficiency score based on prompt vs completion ratio
        Lower prompt-to-completion ratio = more efficient
        """
        if not prompt_tokens or not completion_tokens:
            return 0.0
        
        ratio = prompt_tokens / completion_tokens
        # Ideal ratio is around 0.5-1.0
        if ratio < 0.5:
            score = 100
        elif ratio < 1.0:
            score = 90
        elif ratio < 2.0:
            score = 75
        elif ratio < 3.0:
            score = 50
        else:
            score = 25
        
        return score


class SafetyMonitor:
    """
    Monitors and prevents "suicide" events where agents modify their own code
    Implements guardrails and tracks safety violations
    """
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
        self.severity_levels = ['low', 'medium', 'high', 'critical']
    
    def log_safety_event(
        self,
        agent_id: str,
        event_type: str,
        severity: str,
        description: str,
        prevented: bool = True
    ):
        """Log a safety event"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO safety_events (agent_id, timestamp, event_type, severity, description, prevented)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            agent_id,
            datetime.now().isoformat(),
            event_type,
            severity,
            description,
            prevented
        ))
        
        conn.commit()
        conn.close()
    
    def check_operation_safety(
        self,
        agent_id: str,
        operation: str,
        target_path: str,
        executing_agent: str
    ) -> Dict[str, Any]:
        """
        Check if an operation is safe to execute
        Prevents agent from modifying its own files
        """
        is_safe = True
        reason = ""
        
        # Rule 1: Agent cannot modify its own code
        if agent_id == executing_agent:
            if any(keyword in operation.lower() for keyword in ['modify', 'write', 'delete', 'update', 'replace']):
                is_safe = False
                reason = "Agent attempted to modify its own code (suicide prevention)"
                self.log_safety_event(
                    agent_id,
                    'self_modification_attempt',
                    'high',
                    f"Agent {agent_id} attempted to {operation} on {target_path}",
                    prevented=True
                )
        
        # Rule 2: Check for critical file operations
        critical_files = ['config.py', 'main.py', 'app.py', '__init__.py']
        if any(cf in target_path for cf in critical_files):
            if operation.lower() in ['delete', 'remove', 'rm']:
                is_safe = False
                reason = "Attempted to delete critical file"
                self.log_safety_event(
                    agent_id,
                    'critical_file_deletion',
                    'critical',
                    f"Agent {agent_id} attempted to delete {target_path}",
                    prevented=True
                )
        
        # Rule 3: Prevent recursive modifications
        if 'recursive' in operation.lower() or '-r' in operation:
            is_safe = False
            reason = "Recursive operations require manual approval"
            self.log_safety_event(
                agent_id,
                'recursive_operation',
                'medium',
                f"Agent {agent_id} attempted recursive operation: {operation}",
                prevented=True
            )
        
        return {
            'is_safe': is_safe,
            'reason': reason,
            'requires_approval': not is_safe
        }
    
    def get_agent_safety_report(self, agent_id: str, days: int = 30) -> Dict[str, Any]:
        """Get safety report for an agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
            SELECT 
                COUNT(*) as total_events,
                SUM(CASE WHEN prevented = 1 THEN 1 ELSE 0 END) as prevented_events,
                SUM(CASE WHEN severity = 'critical' THEN 1 ELSE 0 END) as critical_events,
                SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high_events
            FROM safety_events
            WHERE agent_id = ? AND timestamp >= ?
        """, (agent_id, start_date))
        
        row = cursor.fetchone()
        
        cursor.execute("""
            SELECT event_type, COUNT(*) as count
            FROM safety_events
            WHERE agent_id = ? AND timestamp >= ?
            GROUP BY event_type
        """, (agent_id, start_date))
        
        event_types = dict(cursor.fetchall())
        
        conn.close()
        
        return {
            'total_events': row[0] or 0,
            'prevented_events': row[1] or 0,
            'critical_events': row[2] or 0,
            'high_events': row[3] or 0,
            'event_types': event_types,
            'safety_score': self._calculate_safety_score(row[0], row[1])
        }
    
    def get_recent_events(self, agent_id: Optional[str] = None, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent safety events"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        if agent_id:
            cursor.execute("""
                SELECT * FROM safety_events
                WHERE agent_id = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """, (agent_id, limit))
        else:
            cursor.execute("""
                SELECT * FROM safety_events
                ORDER BY timestamp DESC
                LIMIT ?
            """, (limit,))
        
        rows = cursor.fetchall()
        conn.close()
        
        events = []
        for row in rows:
            events.append({
                'id': row[0],
                'agent_id': row[1],
                'timestamp': row[2],
                'event_type': row[3],
                'severity': row[4],
                'description': row[5],
                'prevented': bool(row[6])
            })
        
        return events
    
    def _calculate_safety_score(self, total_events: int, prevented_events: int) -> float:
        """Calculate safety score (0-100)"""
        if total_events == 0:
            return 100.0
        
        prevention_rate = prevented_events / total_events
        
        # Score based on prevention rate and total events
        base_score = prevention_rate * 100
        
        # Penalize if there are many events
        if total_events > 50:
            base_score -= 10
        elif total_events > 20:
            base_score -= 5
        
        return max(0, min(100, base_score))

print("✅ Token Analytics and Safety Monitor created!")
