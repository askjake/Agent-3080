
import os
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
from collections import defaultdict

class PromptArchitect:
    """Analyzes projects and generates comprehensive explanatory prompts."""
    
    def __init__(self, project_path: str):
        self.project_path = Path(project_path)
        self.analysis = {
            'project_name': self.project_path.name,
            'analyzed_at': datetime.now().isoformat(),
            'structure': {},
            'key_files': [],
            'technologies': set(),
            'entry_points': [],
            'documentation': [],
            'dependencies': [],
            'architecture': {},
        }
    
    def analyze_project(self):
        """Comprehensive project analysis."""
        print(f"🔍 Analyzing project: {self.project_path}")
        
        self._analyze_structure()
        self._identify_key_files()
        self._extract_technologies()
        self._find_entry_points()
        self._parse_documentation()
        self._detect_dependencies()
        self._infer_architecture()
        
        print("✅ Analysis complete!")
        return self.analysis
    
    def _analyze_structure(self):
        """Analyze directory structure."""
        structure = {}
        for root, dirs, files in os.walk(self.project_path):
            dirs[:] = [d for d in dirs if d not in ['.git', '__pycache__', 'node_modules', 'venv', '.venv']]
            rel_path = Path(root).relative_to(self.project_path)
            structure[str(rel_path)] = {'dirs': dirs, 'files': files, 'file_count': len(files)}
        
        self.analysis['structure'] = structure
        print(f"   📁 Found {len(structure)} directories")
    
    def _identify_key_files(self):
        """Identify important files."""
        key_patterns = {
            'entry': ['main.py', 'app.py', 'index.py', 'quickstart.sh', 'start*.sh'],
            'config': ['config.py', 'settings.py', 'config.json'],
            'readme': ['README.md', 'QUICK_REFERENCE.md', 'INDEX.md'],
            'setup': ['requirements.txt', 'setup.py'],
        }
        
        for category, patterns in key_patterns.items():
            for pattern in patterns:
                matches = list(self.project_path.rglob(pattern))
                for match in matches:
                    if match.is_file():
                        self.analysis['key_files'].append({
                            'category': category,
                            'path': str(match.relative_to(self.project_path)),
                            'size': match.stat().st_size
                        })
        
        print(f"   🔑 Found {len(self.analysis['key_files'])} key files")
    
    def _extract_technologies(self):
        """Detect technologies used."""
        techs = set()
        
        # Check for Python
        if list(self.project_path.rglob('*.py')):
            techs.add('Python')
        
        # Check dependencies
        req_file = self.project_path / 'requirements.txt'
        if req_file.exists():
            content = req_file.read_text()
            if 'streamlit' in content: techs.add('Streamlit')
            if 'flask' in content: techs.add('Flask')
            if 'pandas' in content: techs.add('Pandas')
            if 'plotly' in content: techs.add('Plotly')
        
        # Check for databases
        if list(self.project_path.rglob('*.db')):
            techs.add('SQLite')
        
        self.analysis['technologies'] = list(techs)
        print(f"   🛠️  Detected {len(techs)} technologies")
    
    def _find_entry_points(self):
        """Find application entry points."""
        entry_files = ['quickstart*.sh', 'start*.sh', '*app*.py', 'main.py']
        
        for pattern in entry_files:
            matches = list(self.project_path.rglob(pattern))
            for match in matches:
                if match.is_file() and match.stat().st_size > 100:  # Skip tiny files
                    self.analysis['entry_points'].append({
                        'file': str(match.relative_to(self.project_path)),
                        'type': 'script' if match.suffix in ['.sh'] else 'python',
                        'executable': os.access(match, os.X_OK)
                    })
        
        print(f"   🚀 Found {len(self.analysis['entry_points'])} entry points")
    
    def _parse_documentation(self):
        """Parse documentation files."""
        for doc_file in self.project_path.rglob('*.md'):
            if doc_file.is_file():
                try:
                    content = doc_file.read_text(encoding='utf-8', errors='ignore')
                    self.analysis['documentation'].append({
                        'file': str(doc_file.relative_to(self.project_path)),
                        'size': len(content),
                        'lines': content.count('\n'),
                    })
                except:
                    pass
        
        print(f"   📚 Found {len(self.analysis['documentation'])} documentation files")
    
    def _detect_dependencies(self):
        """Detect project dependencies."""
        req_file = self.project_path / 'requirements.txt'
        if req_file.exists():
            content = req_file.read_text()
            deps = [line.strip() for line in content.splitlines() if line.strip() and not line.startswith('#')]
            self.analysis['dependencies'] = deps
        
        print(f"   📦 Found {len(self.analysis['dependencies'])} dependencies")
    
    def _infer_architecture(self):
        """Infer architectural patterns."""
        arch = {'pattern': 'unknown', 'components': []}
        
        if any('agent' in str(f).lower() for f in self.project_path.rglob('*.py')):
            arch['components'].append('Multi-Agent System')
            arch['pattern'] = 'Multi-Agent'
        
        if self.project_path.rglob('*.db'):
            arch['components'].append('Database (SQLite)')
        
        if 'Streamlit' in self.analysis['technologies']:
            arch['components'].append('Web UI (Streamlit)')
            arch['pattern'] = 'Web Application'
        
        self.analysis['architecture'] = arch
        print(f"   🏗️  Architecture: {arch['pattern']}")


# Run analysis on multi-agent-hub
project_path = '/home/montjac/multi-agent-hub'
architect = PromptArchitect(project_path)
analysis = architect.analyze_project()

# Save analysis
output_file = Path('/tmp/dish_chat_agent/montjac-prompt-architect/project_analysis.json')
with open(output_file, 'w') as f:
    # Convert set to list for JSON serialization
    json.dump(analysis, f, indent=2, default=str)

print(f"\n💾 Analysis saved to: {output_file}")
print(f"\n📊 Summary:")
print(f"   - Technologies: {', '.join(analysis['technologies'])}")
print(f"   - Entry points: {len(analysis['entry_points'])}")
print(f"   - Documentation files: {len(analysis['documentation'])}")
print(f"   - Dependencies: {len(analysis['dependencies'])}")
