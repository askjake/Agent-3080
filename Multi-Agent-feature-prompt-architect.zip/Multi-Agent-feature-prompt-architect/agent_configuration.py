import re
import requests
import sqlite3
import streamlit as st
import pandas as pd
import time
from datetime import datetime



# Database path
DB_PATH = "/home/montjac/multi-agent-hub/agent_hub.db"



# ============================================================================
# AGENT CONFIGURATION PAGE
# ============================================================================

def check_agent_health(backend_url: str) -> dict:
    """
    Check health status of an agent
    
    Args:
        backend_url: Agent's backend URL
        
    Returns:
        Dict with status, response_time, and error info
    """
    try:
        start_time = time.time()
        response = requests.get(f"{backend_url.rstrip('/')}/health", timeout=5)
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            return {
                'status': 'online',
                'response_time': response_time,
                'status_code': response.status_code
            }
        elif 400 <= response.status_code < 500:
            return {
                'status': 'degraded',
                'response_time': response_time,
                'status_code': response.status_code,
                'error': f'HTTP {response.status_code}'
            }
        else:
            return {
                'status': 'offline',
                'response_time': response_time,
                'status_code': response.status_code,
                'error': f'HTTP {response.status_code}'
            }
    except requests.exceptions.Timeout:
        return {
            'status': 'offline',
            'error': 'Timeout (>5s)',
            'response_time': 5.0
        }
    except requests.exceptions.ConnectionError:
        return {
            'status': 'offline',
            'error': 'Connection refused',
            'response_time': None
        }
    except Exception as e:
        return {
            'status': 'offline',
            'error': str(e)[:50],
            'response_time': None
        }

def render_agent_configuration_page():
    """Agent Configuration Page - Add, Edit, Delete agents"""
    st.title("⚙️ Agent Configuration")
    st.markdown("Manage your AI agents - configure backend and frontend URLs")
    
    # Action buttons
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        if st.button("➕ Add New Agent", use_container_width=True, type="primary"):
            st.session_state['show_add_form'] = True
            st.session_state['editing_agent'] = None
            st.rerun()
    
    with col2:
        if st.button("🔄 Refresh", use_container_width=True):
            st.rerun()
    
    with col3:
        if st.button("🧪 Test All", use_container_width=True):
            st.session_state['test_all_agents'] = True
            st.rerun()
    
    st.markdown("---")
    
    # Show add/edit form if requested
    if st.session_state.get('show_add_form', False):
        render_agent_form()
        st.markdown("---")
    
    # Get all agents
    conn = sqlite3.connect(DB_PATH)
    agents_df = pd.read_sql_query("""
        SELECT id, name, backend_url, frontend_url, status, added_timestamp, description, capabilities, metadata
        FROM agents
        ORDER BY added_timestamp DESC
    """, conn)
    conn.close()
    
    if agents_df.empty:
        st.info("👻 No agents registered yet. Click 'Add New Agent' to get started!")
        return
    
    # Test all agents if requested
    if st.session_state.pop('test_all_agents', False):
        with st.spinner("🧪 Testing all agents..."):
            for _, agent in agents_df.iterrows():
                test_agent_connection(agent['id'], agent['backend_url'])
            time.sleep(0.5)
            st.rerun()
    
    # Display each agent as a card
    for idx, agent in agents_df.iterrows():
        render_agent_card(agent)
        st.markdown("<br>", unsafe_allow_html=True)


def render_agent_form(agent_data=None):
    """Render add/edit agent form"""
    is_editing = agent_data is not None
    
    st.subheader("✏️ Edit Agent" if is_editing else "➕ Add New Agent")
    
    with st.form(f"agent_form_{agent_data['id'] if agent_data is not None else 'new'}"):
        col1, col2 = st.columns(2)
        
        with col1:
            agent_id = st.text_input(
                "Agent ID *", 
                value=agent_data['id'] if is_editing else "",
                help="Unique identifier (alphanumeric, hyphens, underscores)",
                disabled=is_editing,
                key=f"form_agent_id_{agent_data['id'] if agent_data is not None else 'new'}"
            )
            
            agent_name = st.text_input(
                "Agent Name *",
                value=agent_data['name'] if is_editing else "",
                help="Display name for the agent",
                key=f"form_agent_name_{agent_data['id'] if agent_data is not None else 'new'}"
            )
            
            description = st.text_area(
                "Description",
                value=agent_data.get('description', '') if is_editing else "",
                help="Optional description",
                key=f"form_description_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        
        with col2:
            capabilities = st.text_input(
                "Capabilities",
                value=agent_data.get('capabilities', 'chat, dialogue') if is_editing else "chat, dialogue",
                help="Comma-separated list",
                key=f"form_capabilities_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        
        st.markdown("---")
        st.markdown("#### 🔌 Backend Configuration (Required)")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            backend_host = st.text_input(
                "Backend Host",
                value=extract_host(agent_data['backend_url']) if is_editing else "localhost",
                help="IP address or hostname",
                key=f"form_backend_host_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        with col2:
            backend_port = st.number_input(
                "Port",
                min_value=1,
                max_value=65535,
                value=extract_port(agent_data['backend_url']) if is_editing else 8000,
                key=f"form_backend_port_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        
        backend_url_full = st.text_input(
            "Or Full Backend URL",
            value=agent_data['backend_url'] if is_editing else f"http://{backend_host}:{backend_port}",
            help="Complete URL including protocol",
            key=f"form_backend_url_{agent_data['id'] if agent_data is not None else 'new'}"
        )
        
        st.markdown("#### 🌐 Frontend Configuration (Optional)")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            frontend_host = st.text_input(
                "Frontend Host",
                value=extract_host(agent_data.get('frontend_url', '')) if is_editing and agent_data.get('frontend_url') else backend_host,
                help="IP address or hostname (defaults to backend host)",
                key=f"form_frontend_host_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        with col2:
            frontend_port = st.number_input(
                "Port",
                min_value=1,
                max_value=65535,
                value=extract_port(agent_data.get('frontend_url', '')) if is_editing and agent_data.get('frontend_url') else 3000,
                key=f"form_frontend_port_{agent_data['id'] if agent_data is not None else 'new'}"
            )
        
        frontend_url_full = st.text_input(
            "Or Full Frontend URL",
            value=agent_data.get('frontend_url', '') if is_editing else f"http://{frontend_host}:{frontend_port}",
            help="Complete URL including protocol (leave empty if no frontend)",
            key=f"form_frontend_url_{agent_data['id'] if agent_data is not None else 'new'}"
        )
        
        st.markdown("---")
        
        col1, col2, col3 = st.columns([1, 1, 2])
        
        with col1:
            submitted = st.form_submit_button("💾 Save Agent", type="primary", use_container_width=True)
        
        with col2:
            test_before_save = st.form_submit_button("🧪 Test First", use_container_width=True)
        
        with col3:
            if st.form_submit_button("❌ Cancel", use_container_width=True):
                st.session_state['show_add_form'] = False
                st.session_state['editing_agent'] = None
                st.rerun()
        
        if test_before_save:
            # Test connection before saving
            backend_url = backend_url_full if backend_url_full.startswith('http') else f"http://{backend_host}:{backend_port}"
            
            with st.spinner("🧪 Testing connection..."):
                result = test_agent_connection_sync(backend_url)
            
            if result['success']:
                st.success(f"✅ Connection successful! Response time: {result.get('response_time', 0):.3f}s")
            else:
                st.error(f"❌ Connection failed: {result.get('error', 'Unknown error')}")
        
        if submitted:
            # Validate inputs
            errors = []
            
            if not agent_id or not agent_id.strip():
                errors.append("Agent ID is required")
            elif not is_editing and agent_exists(agent_id):
                errors.append("Agent ID already exists")
            elif not re.match(r'^[a-zA-Z0-9_-]+$', agent_id):
                errors.append("Agent ID can only contain letters, numbers, hyphens, and underscores")
            
            if not agent_name or not agent_name.strip():
                errors.append("Agent Name is required")
            
            # Determine final URLs
            if backend_url_full and backend_url_full.startswith('http'):
                final_backend_url = backend_url_full
            else:
                final_backend_url = f"http://{backend_host}:{backend_port}"
            
            if not validate_url(final_backend_url):
                errors.append("Backend URL is invalid")
            
            if frontend_url_full and frontend_url_full.strip():
                if frontend_url_full.startswith('http'):
                    final_frontend_url = frontend_url_full
                else:
                    final_frontend_url = f"http://{frontend_host}:{frontend_port}"
                
                if not validate_url(final_frontend_url):
                    errors.append("Frontend URL is invalid")
            else:
                final_frontend_url = ""
            
            if errors:
                for error in errors:
                    st.error(f"❌ {error}")
                return
            
            # Save agent
            try:
                conn = sqlite3.connect(DB_PATH)
                cursor = conn.cursor()
                
                if is_editing:
                    cursor.execute("""
                        UPDATE agents 
                        SET name = ?, backend_url = ?, frontend_url = ?, description = ?, capabilities = ?
                        WHERE id = ?
                    """, (agent_name, final_backend_url, final_frontend_url, description, capabilities, agent_id))
                    success_msg = f"✅ Agent '{agent_name}' updated successfully!"
                else:
                    cursor.execute("""
                        INSERT INTO agents (id, name, backend_url, frontend_url, description, capabilities, added_timestamp, status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (agent_id, agent_name, final_backend_url, final_frontend_url, description, capabilities, 
                          datetime.now().isoformat(), 'unknown'))
                    success_msg = f"✅ Agent '{agent_name}' added successfully!"
                
                conn.commit()
                conn.close()
                
                st.success(success_msg)
                st.session_state['show_add_form'] = False
                st.session_state['editing_agent'] = None
                time.sleep(1)
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Failed to save agent: {str(e)}")


def render_agent_card(agent):
    """Render a single agent card with action buttons"""
    # Get fresh health status
    health = check_agent_health(agent['backend_url'])
    status_emoji = "🟢" if health['status'] == 'online' else "🟡" if health['status'] == 'degraded' else "🔴"
    
    # Get test result if exists
    test_result = st.session_state.get('test_results', {}).get(agent['id'])
    
    card_html = f"""
    <div style="
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 1.5rem;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        margin-bottom: 1rem;
    ">
        <div style="display: flex; justify-content: space-between; align-items: start;">
            <div>
                <h3 style="margin: 0;">{agent['name']} {status_emoji}</h3>
                <p style="color: #666; margin: 0.5rem 0; font-size: 0.9rem;">{agent.get('description', '')}</p>
            </div>
            <div style="text-align: right;">
                <span style="background: {'#4CAF50' if health['status'] == 'online' else '#ff9800' if health['status'] == 'degraded' else '#f44336'}; 
                             color: white; padding: 0.25rem 0.75rem; border-radius: 12px; font-size: 0.85rem;">
                    {health['status'].upper()}
                </span>
            </div>
        </div>
        
        <div style="margin-top: 1rem;">
            <div style="margin-bottom: 0.5rem;">
                <strong>🔌 Backend:</strong> <code>{agent['backend_url']}</code>
            </div>
            <div style="margin-bottom: 0.5rem;">
                <strong>🌐 Frontend:</strong> <code>{agent['frontend_url'] or 'Not configured'}</code>
            </div>
            <div style="margin-bottom: 0.5rem;">
                <strong>🏷️ ID:</strong> <code>{agent['id']}</code>
            </div>
            {f'<div style="margin-bottom: 0.5rem;"><strong>⚡ Response:</strong> {health.get("response_time", "N/A"):.3f}s</div>' if health.get('response_time') else ''}
        </div>
    </div>
    """
    
    st.markdown(card_html, unsafe_allow_html=True)
    
    # Action buttons
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("✏️ Edit", key=f"edit_{agent['id']}", use_container_width=True):
            st.session_state['editing_agent'] = agent['id']
            st.session_state['show_add_form'] = True
            st.rerun()
    
    with col2:
        if st.button("🗑️ Delete", key=f"delete_{agent['id']}", use_container_width=True):
            st.session_state['agent_to_delete'] = agent['id']
            st.session_state['confirm_delete'] = agent['name']
            st.rerun()
    
    with col3:
        if st.button("🧪 Test", key=f"test_{agent['id']}", use_container_width=True):
            with st.spinner("Testing..."):
                result = test_agent_connection(agent['id'], agent['backend_url'])
            if result['success']:
                st.success(f"✅ {result.get('response_time', 0):.3f}s")
            else:
                st.error(f"❌ {result.get('error', 'Failed')[:30]}...")
    
    with col4:
        if agent['frontend_url']:
            if st.button("🌐 Open", key=f"open_{agent['id']}", use_container_width=True):
                st.link_button("🌐 Open Frontend", agent["frontend_url"], use_container_width=True)
    
    # Show test result if exists
    if test_result:
        if test_result['success']:
            st.success(f"✅ Last test: {test_result.get('timestamp', 'Unknown')} - Response: {test_result.get('response_time', 0):.3f}s")
        else:
            st.error(f"❌ Last test failed: {test_result.get('error', 'Unknown')}")
    
    # Delete confirmation
    if st.session_state.get('agent_to_delete') == agent['id']:
        st.warning(f"⚠️ Delete '{st.session_state.get('confirm_delete')}'?")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("✅ Yes, Delete", key=f"confirm_delete_{agent['id']}", type="primary", use_container_width=True):
                delete_agent(agent['id'])
                st.success(f"✅ Agent '{agent['name']}' deleted")
                st.session_state.pop('agent_to_delete', None)
                st.session_state.pop('confirm_delete', None)
                time.sleep(0.5)
                st.rerun()
        with col2:
            if st.button("❌ Cancel", key=f"cancel_delete_{agent['id']}", use_container_width=True):
                st.session_state.pop('agent_to_delete', None)
                st.session_state.pop('confirm_delete', None)
                st.rerun()
    
    # Edit form
    if st.session_state.get('editing_agent') == agent['id']:
        st.markdown("---")
        render_agent_form(agent_data=agent)


# ============================================================================
# HELPER FUNCTIONS FOR AGENT CONFIGURATION
# ============================================================================

def extract_host(url):
    """Extract host from URL"""
    if not url:
        return "localhost"
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.hostname or "localhost"
    except:
        return "localhost"


def extract_port(url):
    """Extract port from URL"""
    if not url:
        return 8000
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        return parsed.port or 8000
    except:
        return 8000


def validate_url(url):
    """Validate URL format"""
    if not url:
        return False
    # Simple but effective URL validation
    pattern = r'^https?://[a-zA-Z0-9.-]+(?::[0-9]+)?(?:/.*)?$'
    return bool(re.match(pattern, url, re.IGNORECASE))



def agent_exists(agent_id):
    """Check if agent ID already exists"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM agents WHERE id = ?", (agent_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count > 0


def delete_agent(agent_id):
    """Delete an agent from database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM agents WHERE id = ?", (agent_id,))
    conn.commit()
    conn.close()


def test_agent_connection(agent_id, backend_url):
    """Test connection to agent and store result"""
    result = test_agent_connection_sync(backend_url)
    result['timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    if 'test_results' not in st.session_state:
        st.session_state['test_results'] = {}
    st.session_state['test_results'][agent_id] = result
    
    return result


def test_agent_connection_sync(backend_url):
    """Synchronously test agent connection"""
    try:
        start_time = time.time()
        response = requests.get(f"{backend_url}/health", timeout=5)
        response_time = time.time() - start_time
        
        if response.status_code == 200:
            return {
                'success': True,
                'response_time': response_time,
                'status_code': response.status_code
            }
        else:
            return {
                'success': False,
                'error': f"HTTP {response.status_code}",
                'response_time': response_time
            }
    except requests.exceptions.Timeout:
        return {'success': False, 'error': 'Timeout (>5s)'}
    except requests.exceptions.ConnectionError:
        return {'success': False, 'error': 'Connection refused'}
    except Exception as e:
        return {'success': False, 'error': str(e)[:50]}
