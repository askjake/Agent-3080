
"""
Protocol Evolution Tracker
Monitors how agent protocols/prompts evolve over time through self-learning
"""

import sqlite3
import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import difflib
from collections import defaultdict

class ProtocolEvolution:
    """
    Tracks changes to agent protocols/prompts over time
    Provides insights into self-learning and adaptation
    """
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
    
    def snapshot_protocol(
        self,
        agent_id: str,
        protocol_content: str,
        version: str,
        changes_summary: Optional[str] = None
    ) -> str:
        """
        Create a snapshot of an agent's protocol at a point in time
        """
        protocol_hash = hashlib.sha256(protocol_content.encode()).hexdigest()[:16]
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Check if this exact protocol already exists
        cursor.execute("""
            SELECT id FROM protocol_versions
            WHERE agent_id = ? AND protocol_hash = ?
        """, (agent_id, protocol_hash))
        
        existing = cursor.fetchone()
        
        if existing:
            conn.close()
            return f"No changes detected (hash: {protocol_hash})"
        
        # Get previous version for comparison
        cursor.execute("""
            SELECT protocol_content
            FROM protocol_versions
            WHERE agent_id = ?
            ORDER BY timestamp DESC
            LIMIT 1
        """, (agent_id,))
        
        previous = cursor.fetchone()
        
        if previous and not changes_summary:
            # Auto-generate changes summary
            changes_summary = self._generate_diff_summary(previous[0], protocol_content)
        
        # Insert new version
        cursor.execute("""
            INSERT INTO protocol_versions (agent_id, timestamp, version, protocol_hash, protocol_content, changes_summary)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            agent_id,
            datetime.now().isoformat(),
            version,
            protocol_hash,
            protocol_content,
            changes_summary or "Initial version"
        ))
        
        conn.commit()
        version_id = cursor.lastrowid
        conn.close()
        
        return f"Protocol snapshot created (ID: {version_id}, hash: {protocol_hash})"
    
    def get_evolution_history(self, agent_id: str, limit: int = 50) -> List[Dict[str, Any]]:
        """Get complete evolution history for an agent"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, timestamp, version, protocol_hash, changes_summary
            FROM protocol_versions
            WHERE agent_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
        """, (agent_id, limit))
        
        rows = cursor.fetchall()
        conn.close()
        
        history = []
        for row in rows:
            history.append({
                'id': row[0],
                'timestamp': row[1],
                'version': row[2],
                'hash': row[3],
                'changes_summary': row[4]
            })
        
        return history
    
    def compare_versions(self, version_id_1: int, version_id_2: int) -> Dict[str, Any]:
        """Compare two protocol versions in detail"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT protocol_content, timestamp, version
            FROM protocol_versions
            WHERE id IN (?, ?)
        """, (version_id_1, version_id_2))
        
        versions = cursor.fetchall()
        conn.close()
        
        if len(versions) != 2:
            return {'error': 'One or both versions not found'}
        
        content1, time1, ver1 = versions[0]
        content2, time2, ver2 = versions[1]
        
        # Generate detailed diff
        diff = list(difflib.unified_diff(
            content1.splitlines(keepends=True),
            content2.splitlines(keepends=True),
            fromfile=f'Version {ver1}',
            tofile=f'Version {ver2}',
            lineterm=''
        ))
        
        # Analyze changes
        additions = sum(1 for line in diff if line.startswith('+') and not line.startswith('+++'))
        deletions = sum(1 for line in diff if line.startswith('-') and not line.startswith('---'))
        
        return {
            'version_1': {'version': ver1, 'timestamp': time1},
            'version_2': {'version': ver2, 'timestamp': time2},
            'diff': ''.join(diff),
            'stats': {
                'additions': additions,
                'deletions': deletions,
                'total_changes': additions + deletions
            }
        }
    
    def get_evolution_metrics(self, agent_id: str, days: int = 30) -> Dict[str, Any]:
        """Get metrics about protocol evolution"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        start_date = (datetime.now() - timedelta(days=days)).isoformat()
        
        cursor.execute("""
            SELECT COUNT(*) as version_count
            FROM protocol_versions
            WHERE agent_id = ? AND timestamp >= ?
        """, (agent_id, start_date))
        
        version_count = cursor.fetchone()[0]
        
        # Get change frequency
        cursor.execute("""
            SELECT timestamp
            FROM protocol_versions
            WHERE agent_id = ? AND timestamp >= ?
            ORDER BY timestamp
        """, (agent_id, start_date))
        
        timestamps = [row[0] for row in cursor.fetchall()]
        
        conn.close()
        
        # Calculate average time between changes
        if len(timestamps) > 1:
            time_diffs = []
            for i in range(1, len(timestamps)):
                t1 = datetime.fromisoformat(timestamps[i-1])
                t2 = datetime.fromisoformat(timestamps[i])
                time_diffs.append((t2 - t1).total_seconds() / 3600)  # hours
            
            avg_hours_between_changes = sum(time_diffs) / len(time_diffs)
        else:
            avg_hours_between_changes = None
        
        return {
            'total_versions': version_count,
            'versions_in_period': version_count,
            'avg_hours_between_changes': avg_hours_between_changes,
            'evolution_rate': self._calculate_evolution_rate(version_count, days),
            'stability_score': self._calculate_stability_score(version_count, days)
        }
    
    def identify_patterns(self, agent_id: str) -> Dict[str, Any]:
        """
        Identify patterns in protocol evolution
        E.g., frequently changed sections, improvement trends
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT changes_summary
            FROM protocol_versions
            WHERE agent_id = ?
            ORDER BY timestamp DESC
            LIMIT 20
        """, (agent_id,))
        
        changes = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        # Analyze change types
        keywords = {
            'error_handling': ['error', 'exception', 'try', 'catch', 'handle'],
            'optimization': ['optimize', 'improve', 'faster', 'efficient', 'performance'],
            'functionality': ['add', 'feature', 'new', 'implement'],
            'bugfix': ['fix', 'bug', 'issue', 'correct', 'resolve'],
            'refactor': ['refactor', 'restructure', 'reorganize', 'clean']
        }
        
        pattern_counts = defaultdict(int)
        
        for change in changes:
            if not change:
                continue
            change_lower = change.lower()
            for category, words in keywords.items():
                if any(word in change_lower for word in words):
                    pattern_counts[category] += 1
        
        return {
            'patterns': dict(pattern_counts),
            'total_changes_analyzed': len(changes),
            'most_common_change_type': max(pattern_counts.items(), key=lambda x: x[1])[0] if pattern_counts else 'unknown'
        }
    
    def get_version_by_id(self, version_id: int) -> Optional[Dict[str, Any]]:
        """Get full protocol version by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT *
            FROM protocol_versions
            WHERE id = ?
        """, (version_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'agent_id': row[1],
                'timestamp': row[2],
                'version': row[3],
                'hash': row[4],
                'content': row[5],
                'changes_summary': row[6]
            }
        return None
    
    def _generate_diff_summary(self, old_content: str, new_content: str) -> str:
        """Generate a human-readable summary of changes"""
        diff = list(difflib.unified_diff(
            old_content.splitlines(),
            new_content.splitlines(),
            lineterm=''
        ))
        
        if not diff:
            return "No changes"
        
        additions = [line for line in diff if line.startswith('+') and not line.startswith('+++')]
        deletions = [line for line in diff if line.startswith('-') and not line.startswith('---')]
        
        summary_parts = []
        
        if additions:
            summary_parts.append(f"{len(additions)} lines added")
        if deletions:
            summary_parts.append(f"{len(deletions)} lines removed")
        
        return ", ".join(summary_parts) if summary_parts else "Minor changes"
    
    def _calculate_evolution_rate(self, version_count: int, days: int) -> str:
        """Calculate how fast the protocol is evolving"""
        rate = version_count / days if days > 0 else 0
        
        if rate > 2:
            return "Very High (>2 changes/day)"
        elif rate > 1:
            return "High (1-2 changes/day)"
        elif rate > 0.5:
            return "Moderate (0.5-1 changes/day)"
        elif rate > 0.2:
            return "Low (0.2-0.5 changes/day)"
        else:
            return "Very Low (<0.2 changes/day)"
    
    def _calculate_stability_score(self, version_count: int, days: int) -> float:
        """
        Calculate stability score (0-100)
        Fewer changes = more stable
        """
        if days == 0:
            return 100.0
        
        changes_per_day = version_count / days
        
        # Inverse relationship: more changes = less stable
        if changes_per_day < 0.1:
            score = 100
        elif changes_per_day < 0.5:
            score = 90
        elif changes_per_day < 1:
            score = 75
        elif changes_per_day < 2:
            score = 50
        else:
            score = 25
        
        return score

print("✅ Protocol Evolution Tracker created!")
