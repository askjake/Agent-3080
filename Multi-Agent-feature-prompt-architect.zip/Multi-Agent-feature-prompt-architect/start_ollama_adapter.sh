#!/bin/bash
# Start Ollama Adapter Service

PORT=${1:-8100}

echo "🤖 Starting Ollama Adapter on port $PORT..."

# Check if Ollama is running
if ! curl -s http://localhost:11434/api/tags > /dev/null 2>&1; then
    echo "⚠️  WARNING: Ollama server not reachable at http://localhost:11434"
    echo "   Make sure Ollama is running: ollama serve"
    exit 1
fi

# Start adapter
cd /home/montjac/multi-agent-hub
python3 ollama_adapter.py $PORT
