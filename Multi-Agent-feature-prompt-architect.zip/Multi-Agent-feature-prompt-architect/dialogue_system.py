
"""
Multi-Agent Dialogue System
Enables Socratic dialogue between agents to collaboratively develop ideas
"""

import asyncio
import aiohttp
from typing import List, Dict, Any, Optional
import json
from datetime import datetime
import sqlite3
from pathlib import Path
import hashlib

class MultiAgentDialogue:
    """
    Orchestrates Socratic dialogues between multiple AI agents
    """
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
    
    async def initiate_dialogue(
        self,
        topic: str,
        agent_ids: List[str],
        agents_data: List[Dict[str, Any]],
        max_rounds: int = 10,
        consensus_threshold: float = 0.85
    ) -> str:
        """
        Start a multi-agent dialogue on a given topic
        
        Args:
            topic: The proposition or question to discuss
            agent_ids: List of agent IDs participating
            agents_data: Agent metadata (name, backend_url, etc.)
            max_rounds: Maximum dialogue rounds
            consensus_threshold: Agreement level to end dialogue
        
        Returns:
            dialogue_id: Unique identifier for this dialogue
        """
        dialogue_id = hashlib.md5(f"{topic}_{datetime.now().isoformat()}".encode()).hexdigest()[:16]
        
        # Initialize dialogue in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO dialogues (id, topic, agent_ids, started_timestamp, status, messages)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            dialogue_id,
            topic,
            json.dumps(agent_ids),
            datetime.now().isoformat(),
            'in_progress',
            json.dumps([])
        ))
        
        conn.commit()
        conn.close()
        
        # Start the dialogue
        messages = []
        consensus_reached = False
        
        # Initial prompt to all agents
        initial_message = {
            'role': 'system',
            'content': f"""You are participating in a collaborative Socratic dialogue with other AI agents.
Topic: {topic}

Your goal is to:
1. Share your perspective on the topic
2. Ask clarifying questions to other agents
3. Build on others' ideas
4. Work toward a comprehensive understanding or solution
5. Indicate when you believe consensus is reached or no further questions remain

Please provide your initial thoughts on this topic."""
        }
        
        for round_num in range(max_rounds):
            round_messages = []
            
            for agent_idx, agent in enumerate(agents_data):
                # Prepare context with previous messages
                context = self._build_context(messages, agent['name'])
                
                # Query agent
                try:
                    response = await self._query_agent(
                        agent['backend_url'],
                        context + [initial_message] if round_num == 0 else context
                    )
                    
                    message = {
                        'round': round_num + 1,
                        'agent_id': agent['id'],
                        'agent_name': agent['name'],
                        'timestamp': datetime.now().isoformat(),
                        'content': response['content'],
                        'metadata': response.get('metadata', {})
                    }
                    
                    round_messages.append(message)
                    messages.append(message)
                    
                    # Update database
                    self._update_dialogue_messages(dialogue_id, messages)
                    
                except Exception as e:
                    print(f"Error querying {agent['name']}: {str(e)}")
                    continue
            
            # Check for consensus
            if self._check_consensus(round_messages):
                consensus_reached = True
                break
        
        # Finalize dialogue
        status = 'completed' if consensus_reached else 'max_rounds_reached'
        final_consensus = self._extract_consensus(messages)
        
        self._finalize_dialogue(dialogue_id, status, final_consensus)
        
        return dialogue_id
    
    def _build_context(self, messages: List[Dict], current_agent: str) -> List[Dict]:
        """Build conversation context for an agent"""
        context = []
        
        for msg in messages[-10:]:  # Last 10 messages
            role = 'assistant' if msg['agent_name'] == current_agent else 'user'
            context.append({
                'role': role,
                'content': f"[{msg['agent_name']}]: {msg['content']}"
            })
        
        return context
    
    async def _query_agent(self, backend_url: str, messages: List[Dict]) -> Dict[str, Any]:
        """Query an agent with conversation context"""
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    f"{backend_url}/chat",
                    json={'messages': messages},
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'content': data.get('response', data.get('message', '')),
                            'metadata': data
                        }
                    else:
                        return {'content': f"[Error: HTTP {response.status}]", 'metadata': {}}
            except Exception as e:
                return {'content': f"[Error: {str(e)}]", 'metadata': {}}
    
    def _check_consensus(self, round_messages: List[Dict]) -> bool:
        """
        Check if agents have reached consensus
        Simple heuristic: look for keywords like "agree", "consensus", "no further questions"
        """
        consensus_keywords = [
            'agree', 'consensus', 'no further questions', 'complete understanding',
            'comprehensive solution', 'satisfied with', 'nothing more to add'
        ]
        
        agreement_count = 0
        for msg in round_messages:
            content_lower = msg['content'].lower()
            if any(keyword in content_lower for keyword in consensus_keywords):
                agreement_count += 1
        
        # If majority agrees, consider consensus reached
        return agreement_count >= len(round_messages) * 0.6
    
    def _extract_consensus(self, messages: List[Dict]) -> str:
        """Extract final consensus from dialogue"""
        # Simple approach: summarize key points from last few messages
        last_messages = messages[-5:]
        
        summary = "Dialogue Summary:\n\n"
        for msg in last_messages:
            summary += f"{msg['agent_name']}: {msg['content'][:200]}...\n\n"
        
        return summary
    
    def _update_dialogue_messages(self, dialogue_id: str, messages: List[Dict]):
        """Update dialogue messages in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE dialogues
            SET messages = ?
            WHERE id = ?
        """, (json.dumps(messages), dialogue_id))
        
        conn.commit()
        conn.close()
    
    def _finalize_dialogue(self, dialogue_id: str, status: str, final_consensus: str):
        """Mark dialogue as complete"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE dialogues
            SET status = ?, completed_timestamp = ?, final_consensus = ?
            WHERE id = ?
        """, (status, datetime.now().isoformat(), final_consensus, dialogue_id))
        
        conn.commit()
        conn.close()
    
    def get_dialogue(self, dialogue_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve dialogue by ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM dialogues WHERE id = ?", (dialogue_id,))
        row = cursor.fetchone()
        
        conn.close()
        
        if row:
            return {
                'id': row[0],
                'topic': row[1],
                'agent_ids': json.loads(row[2]),
                'started_timestamp': row[3],
                'completed_timestamp': row[4],
                'status': row[5],
                'messages': json.loads(row[6]),
                'final_consensus': row[7]
            }
        return None
    
    def get_all_dialogues(self) -> List[Dict[str, Any]]:
        """Get all dialogues"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM dialogues ORDER BY started_timestamp DESC")
        rows = cursor.fetchall()
        
        conn.close()
        
        dialogues = []
        for row in rows:
            dialogues.append({
                'id': row[0],
                'topic': row[1],
                'agent_ids': json.loads(row[2]),
                'started_timestamp': row[3],
                'completed_timestamp': row[4],
                'status': row[5],
                'messages': json.loads(row[6]),
                'final_consensus': row[7]
            })
        
        return dialogues

print("✅ Multi-Agent Dialogue System created!")
