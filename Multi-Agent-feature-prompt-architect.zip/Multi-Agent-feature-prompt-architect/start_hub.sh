#!/bin/bash
# Multi-Agent Hub - Simplified Startup (No Mock Agents)

echo "🚀 Starting Multi-Agent Hub"
echo "="*70

# Kill existing processes
echo "🧹 Cleaning up existing processes..."
pkill -f "streamlit.*agent_hub" 2>/dev/null
sleep 2

# Start Streamlit app
echo "🌐 Starting Streamlit application..."
cd /home/montjac/multi-agent-hub
/home/montjac/.local/bin/streamlit run agent_hub_app_complete.py --server.port 8501 > /tmp/agent_hub.log 2>&1 &
STREAMLIT_PID=$!

sleep 5

# Check if Streamlit is running
if lsof -i :8501 > /dev/null 2>&1; then
    echo "   ✅ Streamlit started successfully (PID: $STREAMLIT_PID)"
else
    echo "   ❌ Streamlit failed to start. Check /tmp/agent_hub.log"
    tail -20 /tmp/agent_hub.log
    exit 1
fi

echo ""
echo "="*70
echo "✅ MULTI-AGENT HUB IS READY!"
echo "="*70
echo ""
echo "📍 Access Point:"
echo "   Hub Interface: http://localhost:8501"
echo ""
echo "💡 To use Multi-Agent Dialogue:"
echo "   1. Register your agents in the Dashboard (if not already registered)"
echo "   2. Ensure your agents expose /chat endpoint:"
echo "      POST /chat"
echo "      Body: {"messages": [{"role": "user", "content": "..."}]}"
echo "      Returns: {"content": "response text"}"
echo "   3. Go to Multi-Agent Dialogue page"
echo "   4. Select 2+ agents and launch dialogue"
echo ""
echo "📝 Logs:"
echo "   tail -f /tmp/agent_hub.log"
echo ""
echo "🛑 To stop:"
echo "   pkill -f 'streamlit.*agent_hub'"
echo ""
