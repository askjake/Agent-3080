# Ollama Integration - Quick Reference

## Start Everything
```bash
# Terminal 1: Start Ollama (if not running)
ollama serve

# Terminal 2: Start Ollama Adapter
cd /home/montjac/multi-agent-hub
./start_ollama_adapter.sh

# Terminal 3: Start Multi-Agent Hub
./quickstart_v3.sh
```

## Test Ollama Adapter
```bash
# Health check
curl http://localhost:8100/health

# Test chat
curl -X POST http://localhost:8100/chat \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello!"}]}'
```

## Access Hub
http://localhost:8501

## Files Created
- `/home/montjac/multi-agent-hub/ollama_adapter.py`
- `/home/montjac/multi-agent-hub/start_ollama_adapter.sh`
- `/home/montjac/multi-agent-hub/ollama-adapter.service`

## Database Entry
- Agent ID: `ollama-gemma`
- Backend URL: `http://localhost:8100`
- Model: Gemma 9B (Q4_0)

## Troubleshooting
1. Ollama not running? → `ollama serve`
2. Model missing? → `ollama pull gemma`
3. Port conflict? → `./start_ollama_adapter.sh 8200`
4. Adapter offline? → Check logs, restart adapter
