#!/bin/bash
# Agent Management Hub Deployment Script

echo '╔══════════════════════════════════════════════════════════════╗'
echo '║         🤖 AI Agent Management Hub - Deploying...           ║'
echo '╚══════════════════════════════════════════════════════════════╝'
echo ''

cd ~/multi-agent-hub

# Check dependencies
echo '📦 Checking dependencies...'
python3 -c 'import streamlit, pandas, plotly, requests, aiohttp' 2>/dev/null
if [ $? -eq 0 ]; then
    echo '✓ All dependencies installed'
else
    echo '⚠ Installing missing dependencies...'
    pip install -q streamlit pandas plotly requests aiohttp
fi

echo ''
echo '🚀 Starting Agent Management Hub...'
echo ''
echo '   Dashboard URL: http://localhost:8501'
echo '   Press Ctrl+C to stop'
echo ''
echo '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'
echo ''

# Start Streamlit
streamlit run agent_hub_app_complete.py     --server.port 8501     --server.address localhost     --server.headless true     --browser.gatherUsageStats false

