#!/bin/bash
# Deploy Agent Hub in background mode

cd ~/multi-agent-hub

echo '🚀 Starting Agent Management Hub in background...'

# Kill any existing instance
pkill -f "streamlit run agent_hub_app_complete.py" 2>/dev/null

# Start in background
nohup streamlit run agent_hub_app_complete.py     --server.port 8501     --server.address 0.0.0.0     --server.headless true     --browser.gatherUsageStats false     > ~/multi-agent-hub/agent_hub.log 2>&1 &

PID=$!
echo "✓ Agent Hub started (PID: $PID)"
echo "📊 Dashboard: http://localhost:8501"
echo "📝 Logs: ~/multi-agent-hub/agent_hub.log"
echo ""
echo "To stop: pkill -f 'streamlit run agent_hub_app_complete.py'"
echo "To view logs: tail -f ~/multi-agent-hub/agent_hub.log"

