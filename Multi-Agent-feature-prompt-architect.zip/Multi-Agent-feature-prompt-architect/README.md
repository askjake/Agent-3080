# 🤖 AI Agent Management Hub

A comprehensive Streamlit-based dashboard for managing multiple self-learning AI agents with advanced features for monitoring, safety, and inter-agent collaboration.

## 🌟 Features

### 1. **Agent Management** 
- **Auto-Discovery**: Add agents by backend URL - system automatically discovers capabilities
- **Health Monitoring**: Real-time status checks with response time tracking
- **Quick Actions**: One-click access to agent interfaces
- **Bulk Operations**: Add all your existing agents at once

### 2. **Dynamic Port Management** 🔌
- **Intelligent Allocation**: Automatically assigns available ports to prevent conflicts
- **Visual Mapping**: See port allocations across all hosts at a glance
- **Conflict Prevention**: Never worry about port collisions again

### 3. **Safety Monitor** 🛡️
- **Suicide Prevention**: Prevents agents from modifying their own code
- **Guardrails**: Critical file protection and recursive operation blocking
- **Event Logging**: Track all safety events with severity levels
- **Safety Scoring**: Overall safety metrics per agent

### 4. **Token Analytics** 📊
- **Usage Tracking**: Monitor token consumption across all agents
- **Cost Analysis**: Estimate spending based on model pricing
- **Efficiency Metrics**: Identify wasteful patterns and optimize prompts
- **Comparative Analysis**: Compare usage across agents
- **Time Series**: Track usage trends over time

### 5. **Protocol Evolution Tracking** 🧬
- **Version History**: Complete changelog of protocol modifications
- **Diff Comparison**: See exactly what changed between versions
- **Pattern Analysis**: Identify common improvement patterns
- **Stability Scoring**: Track how stable each agent's protocol is
- **Evolution Rate**: Understand learning velocity

### 6. **Multi-Agent Socratic Dialogue** 💬
- **Collaborative Problem-Solving**: Two or more agents discuss complex topics
- **Consensus Detection**: Automatically identify when agreement is reached
- **Dialogue History**: Review past conversations
- **Configurable Parameters**: Control rounds, consensus threshold, participants

### 7. **CORS & Network Flexibility** 🌐
- Works across different networks
- Handles laptop/Raspberry Pi mobility
- Supports mixed infrastructure (different hosts/ports)

## 📁 Project Structure

```
agent-management-hub/
├── agent_hub_app_complete.py    # Main Streamlit application
├── dialogue_system.py            # Multi-agent dialogue orchestration
├── analytics_and_safety.py       # Token analytics + safety monitoring
├── protocol_evolution.py         # Protocol version tracking
├── agent_hub.db                  # SQLite database (auto-created)
├── README.md                     # This file
└── requirements.txt              # Python dependencies
```

## 🚀 Quick Start

### Prerequisites

```bash
python >= 3.8
streamlit >= 1.28.0
pandas
plotly
requests
aiohttp
```

### Installation

1. **Clone or download the files**:
```bash
# All files are in the same directory
cd /tmp/dish_chat_agent/agent-management-hub/
```

2. **Install dependencies**:
```bash
pip install streamlit pandas plotly requests aiohttp
```

3. **Run the application**:
```bash
streamlit run agent_hub_app_complete.py
```

4. **Access the dashboard**:
   - Open browser to `http://localhost:8501`
   - Or specify custom port: `streamlit run agent_hub_app_complete.py --server.port 8080`

### Adding Your Existing Agents

Your current agents:
- 10.73.184.61:8000/3001
- 10.79.85.35:8000/3002
- 10.79.85.35:8001/3001
- 10.79.85.47:8000/3000
- 10.73.185.41:8000/3000

**Quick Add Method:**
1. Navigate to "Agents" tab
2. Click "Quick Add Your Existing Agents"
3. Click each agent's URL button

**Manual Add Method:**
1. Navigate to "Agents" → "Add Agent"
2. Enter backend URL (e.g., `10.73.184.61:8000`)
3. Click "Discover & Add Agent"

## 🔧 Configuration

### Database Location

By default, the SQLite database is created in the current directory as `agent_hub.db`.

To change the location, modify `DB_PATH` in `agent_hub_app_complete.py`:

```python
DB_PATH = "/path/to/your/agent_hub.db"
```

### Network Configuration

The app automatically handles:
- Mixed HTTP/HTTPS protocols
- Different network segments
- Dynamic IP changes (when laptop switches networks)

### Agent API Requirements

For full functionality, your agents should expose these endpoints:

**Required:**
- `GET /health` - Returns status (200 OK = online)

**Recommended:**
- `GET /api/health` or `/status` - Detailed health info
- `POST /chat` - For multi-agent dialogues
  ```json
  {
    "messages": [
      {"role": "user", "content": "..."},
      {"role": "assistant", "content": "..."}
    ]
  }
  ```

**Optional for Full Features:**
- Token usage reporting webhook
- Protocol snapshot endpoint
- Operation safety check integration

## 📊 Feature Integration Guide

### 1. Enable Token Analytics

Have your agents report token usage:

```python
import requests

def report_usage(agent_id, prompt_tokens, completion_tokens, model='gpt-4'):
    requests.post('http://hub-server:8501/api/tokens', json={
        'agent_id': agent_id,
        'prompt_tokens': prompt_tokens,
        'completion_tokens': completion_tokens,
        'model': model
    })
```

Or directly use the `TokenAnalytics` class:

```python
from analytics_and_safety import TokenAnalytics

analytics = TokenAnalytics()
analytics.log_conversation(
    agent_id='your-agent-id',
    prompt_tokens=150,
    completion_tokens=200,
    model='gpt-4'
)
```

### 2. Enable Safety Monitoring

Wrap agent operations with safety checks:

```python
from analytics_and_safety import SafetyMonitor

safety = SafetyMonitor()

# Before any file operation
check = safety.check_operation_safety(
    agent_id='agent-123',
    operation='modify',
    target_path='/path/to/file.py',
    executing_agent='agent-456'
)

if check['is_safe']:
    # Proceed with operation
    perform_operation()
else:
    print(f"Operation blocked: {check['reason']}")
```

### 3. Enable Protocol Evolution Tracking

Snapshot your agent's protocol after learning:

```python
from protocol_evolution import ProtocolEvolution

evolution = ProtocolEvolution()

# After updating your protocol
with open('agent_protocol.txt', 'r') as f:
    protocol_content = f.read()

evolution.snapshot_protocol(
    agent_id='agent-123',
    protocol_content=protocol_content,
    version='1.2.5',
    changes_summary='Improved error handling based on recent conversations'
)
```

### 4. Launch Multi-Agent Dialogues

Programmatically start dialogues:

```python
import asyncio
from dialogue_system import MultiAgentDialogue

async def run_dialogue():
    dialogue = MultiAgentDialogue()
    
    agents_data = [
        {'id': 'agent-1', 'name': 'Agent Alpha', 'backend_url': 'http://10.73.184.61:8000'},
        {'id': 'agent-2', 'name': 'Agent Beta', 'backend_url': 'http://10.79.85.35:8000'}
    ]
    
    dialogue_id = await dialogue.initiate_dialogue(
        topic="How can we optimize distributed caching?",
        agent_ids=['agent-1', 'agent-2'],
        agents_data=agents_data,
        max_rounds=8
    )
    
    print(f"Dialogue started: {dialogue_id}")

# Run
asyncio.run(run_dialogue())
```

## 🛡️ Safety Guardrails

The system implements several safety mechanisms:

### Self-Modification Prevention
Agents cannot:
- Modify their own source code
- Delete critical configuration files
- Perform recursive operations without approval

### Operation Validation
Every operation is checked for:
- Target agent vs executing agent
- File criticality level
- Operation type (read/write/delete)

### Event Logging
All safety events are logged with:
- Timestamp
- Agent ID
- Event type
- Severity level
- Whether prevented or allowed

## 📈 Monitoring & Insights

### Dashboard Metrics

**Agent Health:**
- Online/offline status
- Response times
- Last seen timestamp

**Token Usage:**
- Total tokens consumed
- Cost estimates
- Efficiency scores
- Per-agent comparison

**Safety:**
- Events prevented
- Critical incidents
- Overall safety score

**Evolution:**
- Version count
- Change frequency
- Stability metrics

## 🎯 Best Practices

1. **Regular Health Checks**: Monitor agent status frequently
2. **Port Documentation**: Keep port allocations documented
3. **Safety Event Review**: Regularly review blocked operations
4. **Token Optimization**: Use analytics to identify wasteful patterns
5. **Protocol Snapshots**: Create snapshots after significant learning
6. **Dialogue Archives**: Save important multi-agent discussions

## 🐛 Troubleshooting

### Agent Not Discovered

**Problem**: Agent doesn't appear after adding
**Solution**: 
- Check backend URL is correct
- Ensure agent is running
- Verify network connectivity
- Try adding with explicit `http://` prefix

### Port Conflicts

**Problem**: Ports still conflicting
**Solution**:
- Use Port Manager to see all allocations
- Manually allocate ports through the interface
- Check for processes using ports: `lsof -i :8000`

### Database Locked

**Problem**: "Database is locked" error
**Solution**:
- Close other instances of the app
- Check file permissions on `agent_hub.db`
- Restart the Streamlit app

### Dialogue Not Starting

**Problem**: Multi-agent dialogue fails to initiate
**Solution**:
- Ensure agents have `/chat` endpoint
- Check agent logs for errors
- Verify agents are online
- Test with fewer rounds first

## 🔐 Security Considerations

- **Local Network**: Designed for local/internal network use
- **No Authentication**: Current version has no built-in auth
- **Database**: SQLite database contains agent metadata
- **API Calls**: All agent communication unencrypted by default

**For Production:**
- Add authentication (Streamlit supports this)
- Use HTTPS for agent communication
- Encrypt sensitive data in database
- Implement rate limiting

## 📝 Extending the System

### Adding Custom Metrics

Edit `agent_hub_app_complete.py`:

```python
def get_custom_metric(agent_id):
    # Your custom logic
    return metric_value

# Add to dashboard:
st.metric("Custom Metric", get_custom_metric(agent_id))
```

### Custom Safety Rules

Edit `analytics_and_safety.py`:

```python
def check_operation_safety(self, agent_id, operation, target_path, executing_agent):
    # Add your custom rules
    if my_custom_check(operation):
        return {'is_safe': False, 'reason': 'Custom rule violated'}
    # ... existing checks
```

### New Dialogue Types

Edit `dialogue_system.py`:

```python
async def debate_mode(self, topic, agents_data):
    # Implement debate-style dialogue
    pass
```

## 🤝 Contributing

This is your personal project, but you can:
- Add more agent integrations
- Enhance visualizations
- Improve safety guardrails
- Add authentication
- Create mobile-friendly version

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review agent logs
3. Check database integrity
4. Verify network connectivity

## 📄 License

Personal use - customize as needed!

## 🎉 Acknowledgments

Built to solve real challenges in multi-agent systems:
- Port conflicts ✅
- Suicide prevention ✅
- Management overhead ✅
- Token waste ✅
- Evolution blindness ✅
- Inter-agent collaboration ✅
- Network flexibility ✅

---

**Version**: 1.0
**Last Updated**: 2026-04-28
**Status**: Production Ready 🚀
