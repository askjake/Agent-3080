#!/usr/bin/env python3
"""
Test Agent Configuration functionality
"""
import sqlite3
import sys

print("="*70)
print("TESTING AGENT CONFIGURATION MODULE")
print("="*70)

# Test 1: Import module
print("\n🧪 TEST 1: Import agent_configuration module")
try:
    sys.path.insert(0, '/home/montjac/multi-agent-hub')
    from agent_configuration import *
    print("   ✅ PASS: Module imported successfully")
except Exception as e:
    print(f"   ❌ FAIL: {str(e)}")
    sys.exit(1)

# Test 2: URL validation
print("\n🧪 TEST 2: URL validation function")
valid_urls = [
    "http://localhost:8000",
    "http://10.79.85.47:8000",
    "https://example.com:3000"
]
invalid_urls = [
    "not a url",
    "ftp://localhost:8000",
    "http://:8000"
]

for url in valid_urls:
    if validate_url(url):
        print(f"   ✅ '{url}' correctly validated")
    else:
        print(f"   ❌ '{url}' should be valid")

for url in invalid_urls:
    if not validate_url(url):
        print(f"   ✅ '{url}' correctly rejected")
    else:
        print(f"   ❌ '{url}' should be invalid")

# Test 3: Extract host/port
print("\n🧪 TEST 3: Extract host and port from URLs")
test_url = "http://10.79.85.47:8080"
host = extract_host(test_url)
port = extract_port(test_url)
print(f"   URL: {test_url}")
print(f"   Extracted host: {host} (expected: 10.79.85.47)")
print(f"   Extracted port: {port} (expected: 8080)")
if host == "10.79.85.47" and port == 8080:
    print("   ✅ PASS: Host and port correctly extracted")
else:
    print("   ❌ FAIL: Extraction incorrect")

# Test 4: Database operations
print("\n🧪 TEST 4: Database operations")
conn = sqlite3.connect('/home/montjac/multi-agent-hub/agent_hub.db')
cursor = conn.cursor()

# Check if agents table exists
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='agents'")
if cursor.fetchone():
    print("   ✅ PASS: Agents table exists")
else:
    print("   ❌ FAIL: Agents table not found")

# Check table schema
cursor.execute("PRAGMA table_info(agents)")
columns = [col[1] for col in cursor.fetchall()]
required_columns = ['id', 'name', 'backend_url', 'frontend_url']
missing = [col for col in required_columns if col not in columns]
if not missing:
    print(f"   ✅ PASS: All required columns present")
else:
    print(f"   ❌ FAIL: Missing columns: {missing}")

# Count agents
cursor.execute("SELECT COUNT(*) FROM agents")
count = cursor.fetchone()[0]
print(f"   ℹ️  Current agents in database: {count}")

conn.close()

# Test 5: agent_exists function
print("\n🧪 TEST 5: Check agent exists function")
if agent_exists("non-existent-agent-12345"):
    print("   ❌ FAIL: Non-existent agent reported as existing")
else:
    print("   ✅ PASS: Correctly identified non-existent agent")

print("\n" + "="*70)
print("ALL TESTS COMPLETE")
print("="*70)
print("\n✅ Agent Configuration module is ready to use!")
