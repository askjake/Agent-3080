"""
ACHIEVEMENT SERVICE
Manages user achievements, progress tracking, and badge unlocking
"""

import sqlite3
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
import json

class AchievementService:
    """Service for managing achievements and user progress"""
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
    
    def _get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    # ========================================================================
    # USER STATS MANAGEMENT
    # ========================================================================
    
    def init_user_stats(self, user_id: str = "default_user") -> None:
        """Initialize stats for a new user"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                INSERT OR IGNORE INTO user_stats (user_id, created_at, last_active_at)
                VALUES (?, ?, ?)
            """, (user_id, datetime.now().isoformat(), datetime.now().isoformat()))
            
            conn.commit()
        finally:
            conn.close()
    
    def get_user_stats(self, user_id: str = "default_user") -> Dict[str, Any]:
        """Get comprehensive user statistics"""
        self.init_user_stats(user_id)  # Ensure user exists
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("SELECT * FROM user_stats WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            
            if not row:
                return self._default_user_stats(user_id)
            
            columns = [desc[0] for desc in cursor.description]
            stats = dict(zip(columns, row))
            
            # Parse JSON fields
            if stats.get('notification_preferences'):
                try:
                    stats['notification_preferences'] = json.loads(stats['notification_preferences'])
                except:
                    stats['notification_preferences'] = {}
            
            return stats
            
        finally:
            conn.close()
    
    def _default_user_stats(self, user_id: str) -> Dict[str, Any]:
        """Return default stats structure"""
        return {
            'user_id': user_id,
            'total_dialogues': 0,
            'total_consensus_achieved': 0,
            'avg_consensus_score': 0.0,
            'total_agents_used': 0,
            'unique_agents_used': 0,
            'current_streak_days': 0,
            'longest_streak_days': 0,
            'theme_preference': 'light',
            'notification_preferences': {},
            'total_points': 0,
            'current_level': 1,
            'points_to_next_level': 100
        }
    
    def update_dialogue_stats(self, user_id: str, dialogue_id: str, 
                              consensus_score: float, agents_used: List[str],
                              duration_seconds: int) -> None:
        """Update user stats after dialogue completion"""
        self.init_user_stats(user_id)
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Get current stats
            stats = self.get_user_stats(user_id)
            
            # Calculate new values
            new_total_dialogues = stats['total_dialogues'] + 1
            new_total_consensus = stats['total_consensus_achieved'] + (1 if consensus_score >= 0.8 else 0)
            
            # Recalculate average consensus
            old_avg = stats['avg_consensus_score']
            old_count = stats['total_dialogues']
            new_avg = ((old_avg * old_count) + consensus_score) / new_total_dialogues
            
            # Update total agents used
            new_total_agents = stats['total_agents_used'] + len(agents_used)
            
            # Get unique agents (simplified - track incrementally)
            # Note: More sophisticated tracking would join with user activity
            
            # Simplified: just track count
            new_unique_agents = len(set(agents_used))
            
            # Update stats
            cursor.execute("""
                UPDATE user_stats 
                SET total_dialogues = ?,
                    total_consensus_achieved = ?,
                    avg_consensus_score = ?,
                    total_agents_used = ?,
                    unique_agents_used = unique_agents_used + ?,
                    last_active_at = ?
                WHERE user_id = ?
            """, (
                new_total_dialogues,
                new_total_consensus,
                new_avg,
                new_total_agents,
                new_unique_agents,
                datetime.now().isoformat(),
                user_id
            ))
            
            # Log activity for streak calculation
            today = date.today().isoformat()
            cursor.execute("""
                INSERT OR REPLACE INTO user_activity_log 
                (user_id, activity_date, activity_type, activity_count)
                VALUES (?, ?, ?, 
                    COALESCE((SELECT activity_count + 1 FROM user_activity_log 
                              WHERE user_id = ? AND activity_date = ? AND activity_type = ?), 1))
            """, (user_id, today, 'dialogue_complete', user_id, today, 'dialogue_complete'))
            
            conn.commit()
            
            # Update streak
            self.update_streak(user_id)
            
        finally:
            conn.close()
    
    def update_streak(self, user_id: str) -> int:
        """Calculate and update user's current streak"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Get activity history
            cursor.execute("""
                SELECT DISTINCT activity_date 
                FROM user_activity_log 
                WHERE user_id = ? AND activity_type = 'dialogue_complete'
                ORDER BY activity_date DESC
            """, (user_id,))
            
            activity_dates = [datetime.fromisoformat(row[0]).date() for row in cursor.fetchall()]
            
            if not activity_dates:
                return 0
            
            # Calculate current streak
            today = date.today()
            current_streak = 0
            
            # Start from today or yesterday (give grace period)
            check_date = today if today in activity_dates else today - timedelta(days=1)
            
            while check_date in activity_dates:
                current_streak += 1
                check_date -= timedelta(days=1)
            
            # Get longest streak from database
            cursor.execute("SELECT longest_streak_days, last_streak_date FROM user_stats WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            longest_streak = row[0] if row else 0
            last_streak_date = row[1] if row else None
            
            # Update longest if current is higher
            new_longest = max(longest_streak, current_streak)
            
            # Update database
            cursor.execute("""
                UPDATE user_stats 
                SET current_streak_days = ?,
                    longest_streak_days = ?,
                    last_streak_date = ?
                WHERE user_id = ?
            """, (current_streak, new_longest, today.isoformat(), user_id))
            
            conn.commit()
            
            return current_streak
            
        finally:
            conn.close()
    
    # ========================================================================
    # ACHIEVEMENT CHECKING AND UNLOCKING
    # ========================================================================
    
    def check_and_award_achievements(self, user_id: str, dialogue_id: str = None) -> List[Dict[str, Any]]:
        """Check if user has earned any new achievements"""
        newly_unlocked = []
        
        stats = self.get_user_stats(user_id)
        
        # Get all achievement definitions
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("SELECT * FROM achievement_definitions")
            columns = [desc[0] for desc in cursor.description]
            achievement_defs = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            # Check each achievement
            for ach_def in achievement_defs:
                # Skip if already unlocked
                cursor.execute("""
                    SELECT COUNT(*) FROM user_achievements 
                    WHERE user_id = ? AND achievement_name = ?
                """, (user_id, ach_def['id']))
                
                if cursor.fetchone()[0] > 0:
                    continue  # Already unlocked
                
                # Check if requirements met
                is_met = self._check_achievement_requirement(stats, ach_def, cursor, user_id)
                
                if is_met:
                    # Award achievement
                    self._award_achievement(user_id, ach_def, cursor)
                    newly_unlocked.append(ach_def)
            
            conn.commit()
            
            # Award points for new achievements
            if newly_unlocked:
                total_points = sum(ach['points'] for ach in newly_unlocked)
                self.add_points(user_id, total_points)
            
            return newly_unlocked
            
        finally:
            conn.close()
    
    def _check_achievement_requirement(self, stats: Dict, ach_def: Dict, 
                                      cursor: sqlite3.Cursor, user_id: str) -> bool:
        """Check if achievement requirement is met"""
        
        requirement_type = ach_def['requirement_type']
        requirement_value = ach_def['requirement_value']
        category = ach_def['category']
        
        # Dialogue count requirements
        if category == 'dialogue' and requirement_type == 'count':
            return stats['total_dialogues'] >= requirement_value
        
        # Consensus requirements
        elif category == 'consensus':
            if requirement_type == 'threshold':
                # Check if any dialogue achieved this threshold
                cursor.execute("""
                    SELECT COUNT(*) FROM dialogues 
                    WHERE final_consensus IS NOT NULL 
                    AND CAST(final_consensus AS REAL) >= ?
                """, (requirement_value / 100.0,))
                return cursor.fetchone()[0] > 0
                
            elif requirement_type == 'count':
                # Count dialogues above 90%
                cursor.execute("""
                    SELECT COUNT(*) FROM dialogues 
                    WHERE final_consensus IS NOT NULL 
                    AND CAST(final_consensus AS REAL) >= 0.9
                """)
                return cursor.fetchone()[0] >= requirement_value
        
        # Agent mastery requirements
        elif category == 'agent':
            if requirement_type == 'count':
                return stats['unique_agents_used'] >= requirement_value
                
            elif requirement_type == 'threshold':
                # Check if any dialogue used this many agents
                cursor.execute("""
                    SELECT agent_ids FROM dialogues 
                    WHERE agent_ids IS NOT NULL
                """)
                for row in cursor.fetchall():
                    try:
                        agents = json.loads(row[0])
                        if len(agents) >= requirement_value:
                            return True
                    except:
                        pass
                return False
        
        # Speed requirements
        elif category == 'speed' and requirement_type == 'threshold':
            # Check if any dialogue completed within threshold
            cursor.execute("""
                SELECT started_timestamp, completed_timestamp 
                FROM dialogues 
                WHERE completed_timestamp IS NOT NULL
            """)
            for row in cursor.fetchall():
                try:
                    start = datetime.fromisoformat(row[0])
                    end = datetime.fromisoformat(row[1])
                    duration = (end - start).total_seconds()
                    if duration <= requirement_value:
                        return True
                except:
                    pass
            return False
        
        # Streak requirements
        elif category == 'streak' and requirement_type == 'count':
            return stats['current_streak_days'] >= requirement_value
        
        return False
    
    def _award_achievement(self, user_id: str, ach_def: Dict, cursor: sqlite3.Cursor) -> None:
        """Award an achievement to a user"""
        cursor.execute("""
            INSERT INTO user_achievements 
            (user_id, achievement_type, achievement_name, earned_at, metadata)
            VALUES (?, ?, ?, ?, ?)
        """, (
            user_id,
            ach_def['category'],
            ach_def['id'],
            datetime.now().isoformat(),
            json.dumps({
                'name': ach_def['name'],
                'description': ach_def['description'],
                'icon': ach_def['icon'],
                'points': ach_def['points'],
                'rarity': ach_def['rarity']
            })
        ))
        
        # Create notification
        cursor.execute("""
            INSERT INTO notifications 
            (user_id, notification_type, title, message, created_at)
            VALUES (?, ?, ?, ?, ?)
        """, (
            user_id,
            'achievement',
            '🏆 Achievement Unlocked!',
            f"{ach_def['icon']} {ach_def['name']}: {ach_def['description']}",
            datetime.now().isoformat()
        ))
    
    def get_user_achievements(self, user_id: str) -> List[Dict[str, Any]]:
        """Get all achievements earned by a user"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute("""
                SELECT achievement_name, earned_at, metadata 
                FROM user_achievements 
                WHERE user_id = ?
                ORDER BY earned_at DESC
            """, (user_id,))
            
            achievements = []
            for row in cursor.fetchall():
                try:
                    metadata = json.loads(row[2]) if row[2] else {}
                    achievements.append({
                        'id': row[0],
                        'earned_at': row[1],
                        **metadata
                    })
                except:
                    pass
            
            return achievements
            
        finally:
            conn.close()
    
    def get_achievement_progress(self, user_id: str) -> List[Dict[str, Any]]:
        """Get progress toward unearned achievements"""
        conn = self._get_connection()
        cursor = conn.cursor()
        stats = self.get_user_stats(user_id)
        
        try:
            # Get all achievements
            cursor.execute("SELECT * FROM achievement_definitions")
            columns = [desc[0] for desc in cursor.description]
            all_achievements = [dict(zip(columns, row)) for row in cursor.fetchall()]
            
            # Get earned achievements
            cursor.execute("SELECT achievement_name FROM user_achievements WHERE user_id = ?", (user_id,))
            earned_ids = {row[0] for row in cursor.fetchall()}
            
            # Calculate progress for unearned
            progress_list = []
            for ach in all_achievements:
                if ach['id'] in earned_ids:
                    continue
                
                # Calculate current progress
                current = self._calculate_current_progress(stats, ach, cursor)
                required = ach['requirement_value']
                
                progress_list.append({
                    'id': ach['id'],
                    'name': ach['name'],
                    'description': ach['description'],
                    'icon': ach['icon'],
                    'current': current,
                    'required': required,
                    'percentage': min(100, int((current / required) * 100)) if required > 0 else 0,
                    'points': ach['points'],
                    'rarity': ach['rarity']
                })
            
            # Sort by percentage progress (closest to completion first)
            progress_list.sort(key=lambda x: x['percentage'], reverse=True)
            
            return progress_list
            
        finally:
            conn.close()
    
    def _calculate_current_progress(self, stats: Dict, ach: Dict, cursor: sqlite3.Cursor) -> int:
        """Calculate current progress toward an achievement"""
        category = ach['category']
        requirement_type = ach['requirement_type']
        
        if category == 'dialogue' and requirement_type == 'count':
            return stats['total_dialogues']
        
        elif category == 'consensus' and requirement_type == 'count':
            cursor.execute("""
                SELECT COUNT(*) FROM dialogues 
                WHERE final_consensus IS NOT NULL 
                AND CAST(final_consensus AS REAL) >= 0.9
            """)
            return cursor.fetchone()[0]
        
        elif category == 'agent' and requirement_type == 'count':
            return stats['unique_agents_used']
        
        elif category == 'streak' and requirement_type == 'count':
            return stats['current_streak_days']
        
        return 0
    
    # ========================================================================
    # POINTS AND LEVELING
    # ========================================================================
    
    def add_points(self, user_id: str, points: int) -> Dict[str, Any]:
        """Add points and check for level up"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            stats = self.get_user_stats(user_id)
            new_total = stats['total_points'] + points
            current_level = stats['current_level']
            
            # Calculate level (simple formula: 100 points per level, increasing by 50 each level)
            points_for_next_level = 100 + (current_level * 50)
            
            new_level = current_level
            remaining_points = new_total
            
            # Check if leveled up
            while remaining_points >= points_for_next_level:
                remaining_points -= points_for_next_level
                new_level += 1
                points_for_next_level = 100 + (new_level * 50)
            
            leveled_up = new_level > current_level
            
            # Update database
            cursor.execute("""
                UPDATE user_stats 
                SET total_points = ?,
                    current_level = ?,
                    points_to_next_level = ?
                WHERE user_id = ?
            """, (new_total, new_level, points_for_next_level - remaining_points, user_id))
            
            conn.commit()
            
            return {
                'points_added': points,
                'new_total': new_total,
                'old_level': current_level,
                'new_level': new_level,
                'leveled_up': leveled_up,
                'points_to_next_level': points_for_next_level - remaining_points
            }
            
        finally:
            conn.close()
