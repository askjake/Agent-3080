"""
DAILY CHALLENGE SERVICE - Phase 2 Step 2.2
Auto-generates daily challenges with prompts and tracks completions
"""

import sqlite3
from datetime import datetime, date, timedelta
from typing import Dict, List, Any, Optional
import json
import random

class ChallengeService:
    """Service for managing daily challenges"""
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
        
        # Challenge templates by difficulty
        self.templates = {
            'easy': [
                ("Compare and contrast {topic1} and {topic2}", 2, 0.75),
                ("Explain {concept} in simple terms", 2, 0.75),
                ("List 5 benefits of {topic}", 2, 0.70),
                ("What are the pros and cons of {topic}?", 2, 0.75),
            ],
            'medium': [
                ("Analyze the ethical implications of {topic}", 3, 0.80),
                ("Design a solution for {problem}", 3, 0.80),
                ("Evaluate {topic} from multiple perspectives", 3, 0.85),
                ("Create a framework for {concept}", 3, 0.80),
            ],
            'hard': [
                ("Synthesize insights from {field1}, {field2}, and {field3}", 5, 0.85),
                ("Develop a comprehensive strategy for {complex_problem}", 5, 0.90),
                ("Debate: {controversial_topic}", 4, 0.85),
                ("Create an interdisciplinary analysis of {topic}", 5, 0.90),
            ]
        }
        
        # Topic pools
        self.topics = [
            "artificial intelligence", "climate change", "renewable energy",
            "cryptocurrency", "quantum computing", "gene editing",
            "space exploration", "cybersecurity", "blockchain technology",
            "neural networks", "sustainable development", "automation",
            "privacy rights", "education reform", "healthcare innovation",
            "urban planning", "food security", "ocean conservation"
        ]
        
        self.concepts = [
            "machine learning", "consensus mechanisms", "distributed systems",
            "ethical AI", "carbon neutrality", "circular economy",
            "quantum entanglement", "CRISPR technology", "smart contracts"
        ]
    
    def _get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    # ========================================================================
    # CHALLENGE GENERATION
    # ========================================================================
    
    def generate_daily_challenge(self, target_date: Optional[date] = None) -> Dict[str, Any]:
        """
        Generate a challenge for the specified date
        
        Args:
            target_date: Date for challenge (default: today)
        
        Returns:
            Challenge data dictionary
        """
        if target_date is None:
            target_date = date.today()
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Check if challenge already exists for this date
            cursor.execute("""
                SELECT id, prompt, difficulty, required_agents, target_consensus, reward_points
                FROM daily_challenges
                WHERE challenge_date = ?
            """, (target_date.isoformat(),))
            
            existing = cursor.fetchone()
            if existing:
                return {
                    'id': existing[0],
                    'prompt': existing[1],
                    'difficulty': existing[2],
                    'required_agents': existing[3],
                    'target_consensus': existing[4],
                    'reward_points': existing[5],
                    'date': target_date.isoformat()
                }
            
            # Generate new challenge
            # Rotate difficulty: easy (40%), medium (40%), hard (20%)
            rand = random.random()
            if rand < 0.4:
                difficulty = 'easy'
            elif rand < 0.8:
                difficulty = 'medium'
            else:
                difficulty = 'hard'
            
            # Select template and fill in
            template, required_agents, target_consensus = random.choice(self.templates[difficulty])
            
            # Fill template with topics
            prompt = template
            if '{topic1}' in prompt:
                prompt = prompt.replace('{topic1}', random.choice(self.topics))
            if '{topic2}' in prompt:
                prompt = prompt.replace('{topic2}', random.choice(self.topics))
            if '{topic}' in prompt:
                prompt = prompt.replace('{topic}', random.choice(self.topics))
            if '{concept}' in prompt:
                prompt = prompt.replace('{concept}', random.choice(self.concepts))
            if '{problem}' in prompt:
                prompt = prompt.replace('{problem}', f"{random.choice(self.topics)} challenges")
            if '{field1}' in prompt:
                fields = random.sample(self.topics, 3)
                prompt = prompt.replace('{field1}', fields[0])
                prompt = prompt.replace('{field2}', fields[1])
                prompt = prompt.replace('{field3}', fields[2])
            if '{controversial_topic}' in prompt:
                prompt = prompt.replace('{controversial_topic}', random.choice(self.topics))
            if '{complex_problem}' in prompt:
                prompt = prompt.replace('{complex_problem}', random.choice(self.topics))
            
            # Calculate reward points
            reward_points = {
                'easy': 10,
                'medium': 25,
                'hard': 50
            }[difficulty]
            
            # Insert into database
            cursor.execute("""
                INSERT INTO daily_challenges 
                (challenge_date, prompt, difficulty, required_agents, target_consensus, reward_points, bonus_multiplier)
                VALUES (?, ?, ?, ?, ?, ?, 1.5)
            """, (target_date.isoformat(), prompt, difficulty, required_agents, target_consensus, reward_points))
            
            conn.commit()
            challenge_id = cursor.lastrowid
            
            return {
                'id': challenge_id,
                'prompt': prompt,
                'difficulty': difficulty,
                'required_agents': required_agents,
                'target_consensus': target_consensus,
                'reward_points': reward_points,
                'date': target_date.isoformat()
            }
        
        finally:
            conn.close()
    
    def get_todays_challenge(self) -> Optional[Dict[str, Any]]:
        """Get today's challenge, generating if needed"""
        return self.generate_daily_challenge()
    
    # ========================================================================
    # CHALLENGE COMPLETION
    # ========================================================================
    
    def complete_challenge(self, challenge_id: int, user_id: str, 
                          dialogue_id: str, consensus_achieved: float) -> Dict[str, Any]:
        """
        Mark challenge as completed and award points
        
        Args:
            challenge_id: Challenge ID
            user_id: User ID
            dialogue_id: Dialogue ID
            consensus_achieved: Final consensus score
        
        Returns:
            Completion data with points awarded
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Get challenge details
            cursor.execute("""
                SELECT target_consensus, reward_points, bonus_multiplier
                FROM daily_challenges
                WHERE id = ?
            """, (challenge_id,))
            
            challenge = cursor.fetchone()
            if not challenge:
                return {'success': False, 'error': 'Challenge not found'}
            
            target_consensus, base_points, bonus_multiplier = challenge
            
            # Check if already completed
            cursor.execute("""
                SELECT id FROM challenge_completions
                WHERE challenge_id = ? AND user_id = ?
            """, (challenge_id, user_id))
            
            if cursor.fetchone():
                return {'success': False, 'error': 'Challenge already completed'}
            
            # Calculate points
            points = base_points
            bonus_points = 0
            
            # Bonus for exceeding target (10%+ over target = 50% bonus)
            if consensus_achieved >= target_consensus + 0.10:
                bonus_points = int(base_points * (bonus_multiplier - 1))
                points += bonus_points
            
            # Record completion
            cursor.execute("""
                INSERT INTO challenge_completions
                (challenge_id, user_id, dialogue_id, consensus_achieved, bonus_points, total_points)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (challenge_id, user_id, dialogue_id, consensus_achieved, bonus_points, points))
            
            conn.commit()
            
            return {
                'success': True,
                'base_points': base_points,
                'bonus_points': bonus_points,
                'total_points': points,
                'consensus_achieved': consensus_achieved,
                'target_consensus': target_consensus
            }
        
        finally:
            conn.close()
    
    def get_user_challenge_history(self, user_id: str, days: int = 30) -> List[Dict[str, Any]]:
        """Get user's challenge completion history"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            threshold = (datetime.now() - timedelta(days=days)).isoformat()
            
            cursor.execute("""
                SELECT 
                    dc.challenge_date,
                    dc.prompt,
                    dc.difficulty,
                    cc.consensus_achieved,
                    cc.total_points,
                    cc.completed_at
                FROM challenge_completions cc
                JOIN daily_challenges dc ON cc.challenge_id = dc.id
                WHERE cc.user_id = ?
                AND cc.completed_at >= ?
                ORDER BY cc.completed_at DESC
            """, (user_id, threshold))
            
            history = []
            for row in cursor.fetchall():
                history.append({
                    'date': row[0],
                    'prompt': row[1],
                    'difficulty': row[2],
                    'consensus': row[3],
                    'points': row[4],
                    'completed_at': row[5]
                })
            
            return history
        
        finally:
            conn.close()
    
    def get_challenge_leaderboard(self, period: str = 'week') -> List[Dict[str, Any]]:
        """Get challenge leaderboard for specified period"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            if period == 'day':
                threshold = date.today().isoformat()
            elif period == 'week':
                threshold = (date.today() - timedelta(days=7)).isoformat()
            elif period == 'month':
                threshold = (date.today() - timedelta(days=30)).isoformat()
            else:
                threshold = '2000-01-01'
            
            cursor.execute("""
                SELECT 
                    cc.user_id,
                    COUNT(*) as challenges_completed,
                    SUM(cc.total_points) as total_points,
                    AVG(cc.consensus_achieved) as avg_consensus
                FROM challenge_completions cc
                JOIN daily_challenges dc ON cc.challenge_id = dc.id
                WHERE dc.challenge_date >= ?
                GROUP BY cc.user_id
                ORDER BY total_points DESC, challenges_completed DESC
                LIMIT 10
            """, (threshold,))
            
            leaderboard = []
            for row in cursor.fetchall():
                leaderboard.append({
                    'user_id': row[0],
                    'challenges_completed': row[1],
                    'total_points': row[2],
                    'avg_consensus': row[3]
                })
            
            return leaderboard
        
        finally:
            conn.close()
