"""Services package for multi-agent hub"""
