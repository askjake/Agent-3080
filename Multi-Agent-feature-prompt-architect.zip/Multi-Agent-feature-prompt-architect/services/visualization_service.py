"""
VISUALIZATION SERVICE - Phase 2 Step 2.1
Interactive visualizations for agent performance, consensus, and dialogue analysis
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any, Tuple
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from collections import defaultdict
import numpy as np

class VisualizationService:
    """Service for generating interactive data visualizations"""
    
    def __init__(self, db_path: str = "agent_hub.db"):
        self.db_path = db_path
    
    def _get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    # ========================================================================
    # 1. AGENT PERFORMANCE 3D SCATTER
    # ========================================================================
    
    def get_agent_performance_3d(self, days: int = 30) -> go.Figure:
        """
        Create 3D scatter plot: response_time vs consensus vs dialogue_count
        
        Args:
            days: Number of days to analyze
        
        Returns:
            Plotly 3D scatter figure
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Get date threshold
            threshold = (datetime.now() - timedelta(days=days)).isoformat()
            
            # Query agent performance data
            cursor.execute("""
                SELECT 
                    agent_ids,
                    final_consensus,
                    started_timestamp,
                    completed_timestamp
                FROM dialogues
                WHERE started_timestamp >= ?
                AND status = 'completed'
                AND final_consensus IS NOT NULL
            """, (threshold,))
            
            # Process data
            agent_stats = defaultdict(lambda: {
                'dialogue_count': 0,
                'avg_consensus': [],
                'avg_response_time': []
            })
            
            for row in cursor.fetchall():
                try:
                    agents = json.loads(row[0]) if row[0] else []
                    consensus = float(row[1]) if row[1] else 0
                    
                    # Calculate response time
                    if row[2] and row[3]:
                        start = datetime.fromisoformat(row[2])
                        end = datetime.fromisoformat(row[3])
                        response_time = (end - start).total_seconds()
                    else:
                        response_time = 0
                    
                    for agent_id in agents:
                        agent_stats[agent_id]['dialogue_count'] += 1
                        agent_stats[agent_id]['avg_consensus'].append(consensus)
                        agent_stats[agent_id]['avg_response_time'].append(response_time)
                
                except (json.JSONDecodeError, ValueError):
                    continue
            
            # Prepare data for plotting
            agent_names = []
            dialogue_counts = []
            avg_consensuses = []
            avg_response_times = []
            
            for agent_id, stats in agent_stats.items():
                if stats['dialogue_count'] > 0:
                    agent_names.append(agent_id)
                    dialogue_counts.append(stats['dialogue_count'])
                    avg_consensuses.append(np.mean(stats['avg_consensus']))
                    avg_response_times.append(np.mean(stats['avg_response_time']))
            
            # Create 3D scatter plot
            fig = go.Figure(data=[go.Scatter3d(
                x=avg_response_times,
                y=avg_consensuses,
                z=dialogue_counts,
                mode='markers+text',
                marker=dict(
                    size=10,
                    color=avg_consensuses,
                    colorscale='Viridis',
                    showscale=True,
                    colorbar=dict(title="Consensus"),
                    line=dict(width=0.5, color='white')
                ),
                text=agent_names,
                textposition="top center",
                hovertemplate='<b>%{text}</b><br>' +
                              'Response Time: %{x:.1f}s<br>' +
                              'Avg Consensus: %{y:.1%}<br>' +
                              'Dialogues: %{z}<br>' +
                              '<extra></extra>'
            )])
            
            fig.update_layout(
                title=f'Agent Performance (Last {days} Days)',
                scene=dict(
                    xaxis_title='Avg Response Time (seconds)',
                    yaxis_title='Avg Consensus Score',
                    zaxis_title='Dialogue Count',
                    camera=dict(eye=dict(x=1.5, y=1.5, z=1.3))
                ),
                height=600,
                margin=dict(l=0, r=0, b=0, t=40)
            )
            
            return fig
        
        finally:
            conn.close()
    
    # ========================================================================
    # 2. CONSENSUS HEATMAP
    # ========================================================================
    
    def get_consensus_heatmap(self, days: int = 30) -> go.Figure:
        """
        Create heatmap showing consensus scores between agent pairs over time
        
        Args:
            days: Number of days to analyze
        
        Returns:
            Plotly heatmap figure
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            threshold = (datetime.now() - timedelta(days=days)).isoformat()
            
            # Query agent pair consensus
            cursor.execute("""
                SELECT 
                    agent_ids,
                    final_consensus
                FROM dialogues
                WHERE started_timestamp >= ?
                AND status = 'completed'
                AND final_consensus IS NOT NULL
            """, (threshold,))
            
            # Build agent pair consensus matrix
            pair_consensus = defaultdict(list)
            all_agents = set()
            
            for row in cursor.fetchall():
                try:
                    agents = json.loads(row[0]) if row[0] else []
                    consensus = float(row[1]) if row[1] else 0
                    
                    all_agents.update(agents)
                    
                    # Record consensus for each pair
                    for i, agent1 in enumerate(agents):
                        for agent2 in agents[i+1:]:
                            pair_key = tuple(sorted([agent1, agent2]))
                            pair_consensus[pair_key].append(consensus)
                
                except (json.JSONDecodeError, ValueError):
                    continue
            
            # Build matrix
            agent_list = sorted(list(all_agents))
            n = len(agent_list)
            matrix = np.zeros((n, n))
            
            for i, agent1 in enumerate(agent_list):
                for j, agent2 in enumerate(agent_list):
                    if i == j:
                        matrix[i][j] = 1.0  # Self consensus is 100%
                    else:
                        pair_key = tuple(sorted([agent1, agent2]))
                        if pair_key in pair_consensus:
                            matrix[i][j] = np.mean(pair_consensus[pair_key])
            
            # Create heatmap
            fig = go.Figure(data=go.Heatmap(
                z=matrix,
                x=agent_list,
                y=agent_list,
                colorscale='RdYlGn',
                zmin=0,
                zmax=1,
                text=matrix,
                texttemplate='%{z:.0%}',
                textfont={"size": 10},
                hovertemplate='%{y} + %{x}<br>Consensus: %{z:.1%}<extra></extra>'
            ))
            
            fig.update_layout(
                title=f'Agent Pair Consensus Heatmap (Last {days} Days)',
                xaxis_title='Agent',
                yaxis_title='Agent',
                height=500,
                margin=dict(l=100, r=20, b=100, t=60)
            )
            
            return fig
        
        finally:
            conn.close()
    
    # ========================================================================
    # 3. TOKEN USAGE TREND
    # ========================================================================
    
    def get_token_usage_trend(self, user_id: str, days: int = 30) -> go.Figure:
        """
        Create dual-axis chart: token usage over time with cost projection
        
        Args:
            user_id: User ID to analyze
            days: Number of days to analyze
        
        Returns:
            Plotly figure with dual y-axes
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            threshold = (datetime.now() - timedelta(days=days)).isoformat()
            
            # Query token usage from conversations table
            cursor.execute("""
                SELECT 
                    timestamp,
                    tokens_used,
                    cost
                FROM conversations
                WHERE timestamp >= ?
                ORDER BY timestamp
            """, (threshold,))
            
            dates = []
            tokens = []
            costs = []
            
            for row in cursor.fetchall():
                dates.append(datetime.fromisoformat(row[0]).date())
                tokens.append(row[1] if row[1] else 0)
                costs.append(row[2] if row[2] else 0)
            
            # If no data, use dialogue data as fallback
            if not dates:
                cursor.execute("""
                    SELECT 
                        DATE(started_timestamp) as date,
                        COUNT(*) as count
                    FROM dialogues
                    WHERE started_timestamp >= ?
                    GROUP BY date
                    ORDER BY date
                """, (threshold,))
                
                for row in cursor.fetchall():
                    dates.append(row[0])
                    # Estimate: ~1000 tokens per dialogue
                    tokens.append(row[1] * 1000)
                    costs.append(row[1] * 0.002)  # $0.002 per 1K tokens
            
            # Create figure with dual axes
            fig = go.Figure()
            
            # Token usage (left y-axis)
            fig.add_trace(go.Scatter(
                x=dates,
                y=tokens,
                name='Tokens Used',
                mode='lines+markers',
                line=dict(color='#3498db', width=2),
                yaxis='y'
            ))
            
            # Cost (right y-axis)
            fig.add_trace(go.Scatter(
                x=dates,
                y=costs,
                name='Estimated Cost',
                mode='lines+markers',
                line=dict(color='#e74c3c', width=2, dash='dash'),
                yaxis='y2'
            ))
            
            fig.update_layout(
                title=f'Token Usage and Cost Trend (Last {days} Days)',
                xaxis=dict(title='Date'),
                yaxis=dict(
                    title='Tokens Used',
                    side='left',
                    showgrid=True
                ),
                yaxis2=dict(
                    title='Cost (USD)',
                    side='right',
                    overlaying='y',
                    showgrid=False
                ),
                hovermode='x unified',
                height=400,
                margin=dict(l=60, r=60, b=60, t=60),
                legend=dict(x=0.01, y=0.99)
            )
            
            return fig
        
        finally:
            conn.close()
    
    # ========================================================================
    # 4. DIALOGUE TREE VISUALIZATION
    # ========================================================================
    
    def get_dialogue_tree_visualization(self, dialogue_id: str) -> go.Figure:
        """
        Create network graph showing conversation flow
        
        Args:
            dialogue_id: Dialogue ID to visualize
        
        Returns:
            Plotly network graph figure
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # Get dialogue data
            cursor.execute("""
                SELECT messages, agent_ids, topic
                FROM dialogues
                WHERE id = ?
            """, (dialogue_id,))
            
            row = cursor.fetchone()
            if not row:
                # Return empty figure
                fig = go.Figure()
                fig.add_annotation(
                    text="Dialogue not found",
                    xref="paper", yref="paper",
                    x=0.5, y=0.5, showarrow=False
                )
                return fig
            
            messages = json.loads(row[0]) if row[0] else []
            agent_ids = json.loads(row[1]) if row[1] else []
            topic = row[2] if row[2] else "Unknown"
            
            # Build graph structure
            nodes = []
            edges = []
            
            # Add topic node
            nodes.append({
                'id': 'topic',
                'label': f"Topic: {topic[:30]}...",
                'x': 0,
                'y': 0,
                'color': '#9b59b6'
            })
            
            # Add agent nodes and message flows
            num_agents = len(agent_ids)
            angle_step = 2 * np.pi / num_agents if num_agents > 0 else 0
            
            for i, agent_id in enumerate(agent_ids):
                angle = i * angle_step
                x = np.cos(angle)
                y = np.sin(angle)
                
                nodes.append({
                    'id': agent_id,
                    'label': agent_id,
                    'x': x,
                    'y': y,
                    'color': '#3498db'
                })
                
                # Edge from topic to agent
                edges.append({
                    'from': 'topic',
                    'to': agent_id
                })
            
            # Create network graph
            edge_x = []
            edge_y = []
            
            for edge in edges:
                from_node = next(n for n in nodes if n['id'] == edge['from'])
                to_node = next(n for n in nodes if n['id'] == edge['to'])
                edge_x.extend([from_node['x'], to_node['x'], None])
                edge_y.extend([from_node['y'], to_node['y'], None])
            
            edge_trace = go.Scatter(
                x=edge_x, y=edge_y,
                line=dict(width=2, color='#95a5a6'),
                hoverinfo='none',
                mode='lines'
            )
            
            node_x = [n['x'] for n in nodes]
            node_y = [n['y'] for n in nodes]
            node_text = [n['label'] for n in nodes]
            node_color = [n['color'] for n in nodes]
            
            node_trace = go.Scatter(
                x=node_x, y=node_y,
                mode='markers+text',
                hoverinfo='text',
                text=node_text,
                textposition="top center",
                marker=dict(
                    size=20,
                    color=node_color,
                    line=dict(width=2, color='white')
                )
            )
            
            fig = go.Figure(data=[edge_trace, node_trace])
            
            fig.update_layout(
                title=f'Dialogue Flow: {dialogue_id}',
                showlegend=False,
                hovermode='closest',
                height=500,
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                plot_bgcolor='rgba(0,0,0,0)',
                margin=dict(l=20, r=20, b=20, t=60)
            )
            
            return fig
        
        finally:
            conn.close()
