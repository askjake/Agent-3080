"""
Validation Framework for Agent Hub v3.0
Provides ethical validation metrics and user feedback tracking.
"""

import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Optional, Any
import statistics


def initialize_validation_db(db_path: str):
    """Initialize the validation database schema."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Dialogue ratings table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS dialogue_ratings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dialogue_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            rating INTEGER NOT NULL,
            feedback TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(dialogue_id, user_id)
        )
    """)
    
    # Inverted metrics table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS inverted_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dialogue_id TEXT NOT NULL UNIQUE,
            manipulation_risk REAL,
            complexity_burden REAL,
            time_pressure REAL,
            dialogue_health REAL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # User cohorts table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_cohorts (
            user_id TEXT PRIMARY KEY,
            cohort TEXT NOT NULL,
            engagement_level INTEGER,
            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    conn.commit()
    conn.close()


def save_dialogue_rating(dialogue_id: str, user_id: str, rating: int, 
                        feedback: Optional[str], db_path: str):
    """
    Save user rating for a dialogue.
    
    Args:
        dialogue_id: Unique identifier for the dialogue
        user_id: User providing the rating
        rating: Integer rating (1-5)
        feedback: Optional text feedback
        db_path: Path to SQLite database
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Ensure tables exist
    initialize_validation_db(db_path)
    
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO dialogue_ratings 
            (dialogue_id, user_id, rating, feedback, timestamp)
            VALUES (?, ?, ?, ?, ?)
        """, (dialogue_id, user_id, rating, feedback, datetime.now()))
        
        conn.commit()
    except Exception as e:
        print(f"Error saving dialogue rating: {e}")
        conn.rollback()
    finally:
        conn.close()


def save_inverted_metrics(dialogue_id: str, metrics: Dict[str, float], db_path: str):
    """
    Save inverted metrics for a dialogue.
    
    Inverted metrics measure aspects we want to MINIMIZE:
    - manipulation_risk: Risk of manipulative patterns
    - complexity_burden: Cognitive load on user
    - time_pressure: Urgency or pressure tactics
    - dialogue_health: Overall health score (inverted from traditional metrics)
    
    Args:
        dialogue_id: Unique identifier for the dialogue
        metrics: Dictionary containing metric values
        db_path: Path to SQLite database
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Ensure tables exist
    initialize_validation_db(db_path)
    
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO inverted_metrics 
            (dialogue_id, manipulation_risk, complexity_burden, time_pressure, 
             dialogue_health, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            dialogue_id,
            metrics.get('manipulation_risk', 0.0),
            metrics.get('complexity_burden', 0.0),
            metrics.get('time_pressure', 0.0),
            metrics.get('dialogue_health', 0.0),
            datetime.now()
        ))
        
        conn.commit()
    except Exception as e:
        print(f"Error saving inverted metrics: {e}")
        conn.rollback()
    finally:
        conn.close()


def calculate_inverted_metrics(messages: List[Dict[str, Any]]) -> Dict[str, float]:
    """
    Calculate inverted metrics from dialogue messages.
    
    These metrics measure aspects we want to MINIMIZE rather than maximize,
    encouraging ethical AI design.
    
    Args:
        messages: List of message dictionaries from the dialogue
        
    Returns:
        Dictionary containing:
        - manipulation_risk: 0-1 score of manipulative language patterns
        - complexity_burden: 0-1 score of cognitive complexity
        - time_pressure: 0-1 score of urgency/pressure tactics
    """
    if not messages:
        return {
            'manipulation_risk': 0.0,
            'complexity_burden': 0.0,
            'time_pressure': 0.0
        }
    
    # Calculate manipulation risk
    manipulation_keywords = [
        'must', 'should', 'need to', 'have to', 'required', 'mandatory',
        'urgent', 'immediately', 'now', 'asap', 'critical'
    ]
    
    # Calculate complexity burden
    avg_message_length = statistics.mean([
        len(msg.get('content', '').split()) 
        for msg in messages 
        if msg.get('role') == 'assistant'
    ]) if messages else 0
    
    # Calculate time pressure
    time_pressure_keywords = [
        'urgent', 'immediately', 'right now', 'asap', 'hurry',
        'quickly', 'deadline', 'time-sensitive'
    ]
    
    # Analyze messages
    manipulation_count = 0
    time_pressure_count = 0
    total_assistant_msgs = 0
    
    for msg in messages:
        if msg.get('role') == 'assistant':
            content = msg.get('content', '').lower()
            total_assistant_msgs += 1
            
            # Count manipulation indicators
            manipulation_count += sum(
                1 for keyword in manipulation_keywords 
                if keyword in content
            )
            
            # Count time pressure indicators
            time_pressure_count += sum(
                1 for keyword in time_pressure_keywords 
                if keyword in content
            )
    
    # Normalize scores to 0-1 range
    manipulation_risk = min(1.0, manipulation_count / max(1, total_assistant_msgs * 2))
    time_pressure = min(1.0, time_pressure_count / max(1, total_assistant_msgs))
    
    # Complexity burden based on message length (normalize to 0-1)
    # Assume 50+ words is high complexity
    complexity_burden = min(1.0, avg_message_length / 100.0)
    
    return {
        'manipulation_risk': round(manipulation_risk, 3),
        'complexity_burden': round(complexity_burden, 3),
        'time_pressure': round(time_pressure, 3)
    }


def classify_user_cohort(engagement_level: int) -> str:
    """
    Classify user into engagement cohort based on their activity.
    
    Args:
        engagement_level: Number of dialogues rated or interactions
        
    Returns:
        Cohort name: 'Explorer', 'Regular', 'Power User', or 'Contributor'
    """
    if engagement_level == 0:
        return "Observer"
    elif engagement_level <= 3:
        return "Explorer"
    elif engagement_level <= 10:
        return "Regular User"
    elif engagement_level <= 25:
        return "Power User"
    else:
        return "Contributor"


def calculate_correlation(metrics_list: List[Dict[str, float]], 
                         ratings_list: List[int]) -> Dict[str, float]:
    """
    Calculate correlation between inverted metrics and user ratings.
    
    Args:
        metrics_list: List of metric dictionaries
        ratings_list: List of corresponding ratings
        
    Returns:
        Dictionary of correlation coefficients for each metric
    """
    if len(metrics_list) != len(ratings_list) or len(metrics_list) < 2:
        return {
            'manipulation_risk': 0.0,
            'complexity_burden': 0.0,
            'time_pressure': 0.0,
            'dialogue_health': 0.0
        }
    
    # Simple Pearson correlation calculation
    def pearson_correlation(x: List[float], y: List[float]) -> float:
        if len(x) != len(y) or len(x) < 2:
            return 0.0
        
        n = len(x)
        mean_x = statistics.mean(x)
        mean_y = statistics.mean(y)
        
        numerator = sum((x[i] - mean_x) * (y[i] - mean_y) for i in range(n))
        
        std_x = statistics.stdev(x)
        std_y = statistics.stdev(y)
        
        if std_x == 0 or std_y == 0:
            return 0.0
        
        denominator = std_x * std_y * n
        
        return numerator / denominator if denominator != 0 else 0.0
    
    # Extract metric values
    manipulation_risks = [m.get('manipulation_risk', 0.0) for m in metrics_list]
    complexity_burdens = [m.get('complexity_burden', 0.0) for m in metrics_list]
    time_pressures = [m.get('time_pressure', 0.0) for m in metrics_list]
    dialogue_healths = [m.get('dialogue_health', 0.0) for m in metrics_list]
    
    return {
        'manipulation_risk': round(pearson_correlation(manipulation_risks, ratings_list), 3),
        'complexity_burden': round(pearson_correlation(complexity_burdens, ratings_list), 3),
        'time_pressure': round(pearson_correlation(time_pressures, ratings_list), 3),
        'dialogue_health': round(pearson_correlation(dialogue_healths, ratings_list), 3)
    }


def get_dialogue_ratings(dialogue_id: str, db_path: str) -> List[Dict[str, Any]]:
    """Get all ratings for a specific dialogue."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT user_id, rating, feedback, timestamp
        FROM dialogue_ratings
        WHERE dialogue_id = ?
        ORDER BY timestamp DESC
    """, (dialogue_id,))
    
    ratings = []
    for row in cursor.fetchall():
        ratings.append({
            'user_id': row[0],
            'rating': row[1],
            'feedback': row[2],
            'timestamp': row[3]
        })
    
    conn.close()
    return ratings


def get_inverted_metrics_summary(db_path: str, limit: int = 100) -> Dict[str, Any]:
    """Get summary statistics of inverted metrics across all dialogues."""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT manipulation_risk, complexity_burden, time_pressure, dialogue_health
        FROM inverted_metrics
        ORDER BY timestamp DESC
        LIMIT ?
    """, (limit,))
    
    rows = cursor.fetchall()
    conn.close()
    
    if not rows:
        return {
            'count': 0,
            'averages': {},
            'trends': {}
        }
    
    metrics = {
        'manipulation_risk': [r[0] for r in rows],
        'complexity_burden': [r[1] for r in rows],
        'time_pressure': [r[2] for r in rows],
        'dialogue_health': [r[3] for r in rows]
    }
    
    return {
        'count': len(rows),
        'averages': {
            key: round(statistics.mean(values), 3)
            for key, values in metrics.items()
        },
        'medians': {
            key: round(statistics.median(values), 3)
            for key, values in metrics.items()
        }
    }
