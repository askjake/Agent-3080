"""
Opt-In Framework Module

Implements ethical design principles from agents 3080 & 3090-1's second dialogue.

Core Principle: "Design for heterogeneity, not optimization"

After metrics validate, features are offered as EXPLICIT OPT-IN with:
  - Clear descriptions (what it does)
  - Benefits (why it might help)
  - Risks (potential downsides)
  - Research basis (evidence)

Users construct their own engagement architecture from modular components.
"""

from typing import Dict, List
from datetime import datetime
import sqlite3


# Feature Registry
EXPERIMENTAL_FEATURES = {
    'progress_visualization': {
        'name': 'Progress Visualization',
        'description': 'Shows progress bar during dialogues with milestone celebrations',
        'benefits': [
            'Goal gradient effect: accelerates completion as you approach the end',
            'Visual feedback on how far through dialogue',
            'Celebration at 50% completion'
        ],
        'risks': [
            'May focus attention on completion rather than quality',
            'Could create pressure to finish quickly',
            'Milestone celebrations might feel patronizing'
        ],
        'research': 'Kivetz et al. (2006) - Coffee card study on goal gradient effect',
        'category': 'scaffolding'
    },
    'real_time_feedback': {
        'name': 'Real-Time Collaboration Feedback',
        'description': 'Live notifications when agents reference each other or build on ideas',
        'benefits': [
            'Immediate positive reinforcement for quality interactions',
            'Helps you recognize productive patterns',
            'Increases engagement during dialogue'
        ],
        'risks': [
            'Notifications may be distracting',
            'Could interrupt flow state',
            'May make you self-conscious about dialogue style'
        ],
        'research': 'Skinner (1938) - Operant conditioning; immediate feedback increases satisfaction',
        'category': 'feedback'
    },
    'streak_tracking': {
        'name': 'Daily Dialogue Streaks',
        'description': 'Tracks consecutive days with at least one dialogue',
        'benefits': [
            'Helps build consistent critical thinking habit',
            'Loss aversion motivates daily practice',
            'Visual flame icons show progress'
        ],
        'risks': [
            'Can create anxiety about maintaining streak',
            'May prioritize quantity over quality',
            'FOMO if you miss a day',
            'Could feel manipulative if not aligned with your goals'
        ],
        'research': 'Kahneman & Tversky (1979) - Loss aversion; Duolingo case study',
        'category': 'habit_formation'
    },
    'achievement_system': {
        'name': 'Achievement Badges',
        'description': 'Earn badges for dialogue quality milestones',
        'benefits': [
            'Variable reward schedule increases engagement',
            'Recognition for quality achievements',
            'Gamifies improvement process'
        ],
        'risks': [
            'May shift focus from intrinsic to extrinsic motivation',
            'Badge-chasing could override genuine curiosity',
            'Can feel juvenile or patronizing'
        ],
        'research': 'Schultz et al. (1997) - Dopamine and reward prediction',
        'category': 'gamification'
    },
    'social_comparison': {
        'name': 'Performance Comparison',
        'description': 'Compare your dialogue quality to community averages',
        'benefits': [
            'Competitive motivation for improvement',
            'Benchmark your progress',
            'Discover what high-quality dialogues look like'
        ],
        'risks': [
            'Can create unhealthy competition',
            'May discourage if you score below average',
            'Shifts focus to relative rather than absolute improvement'
        ],
        'research': 'Festinger (1954) - Social comparison theory',
        'category': 'social'
    }
}


def get_user_enabled_features(user_id: str, db_path: str) -> List[str]:
    """Get list of features user has opted into"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT feature_id 
        FROM user_feature_optin 
        WHERE user_id = ? AND enabled = 1
    """, (user_id,))
    
    features = [row[0] for row in cursor.fetchall()]
    conn.close()
    
    return features


def enable_feature(user_id: str, feature_id: str, db_path: str):
    """User opts into a feature"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        INSERT OR REPLACE INTO user_feature_optin 
        (user_id, feature_id, enabled, opted_in_timestamp)
        VALUES (?, ?, 1, ?)
    """, (user_id, feature_id, datetime.now().isoformat()))
    
    conn.commit()
    conn.close()


def disable_feature(user_id: str, feature_id: str, db_path: str):
    """User opts out of a feature"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        UPDATE user_feature_optin 
        SET enabled = 0, opted_out_timestamp = ?
        WHERE user_id = ? AND feature_id = ?
    """, (datetime.now().isoformat(), user_id, feature_id))
    
    conn.commit()
    conn.close()


def start_feature_experiment(user_id: str, feature_id: str, duration_days: int, db_path: str):
    """User starts time-limited experiment with a feature"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    from datetime import timedelta
    end_date = (datetime.now() + timedelta(days=duration_days)).isoformat()
    
    cursor.execute("""
        INSERT INTO user_experiments 
        (user_id, feature_id, start_date, end_date, status)
        VALUES (?, ?, ?, ?, 'active')
    """, (user_id, feature_id, datetime.now().isoformat(), end_date))
    
    # Also enable the feature
    enable_feature(user_id, feature_id, db_path)
    
    conn.commit()
    conn.close()


def get_active_experiments(user_id: str, db_path: str) -> List[Dict]:
    """Get user's active experiments"""
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        SELECT feature_id, start_date, end_date 
        FROM user_experiments 
        WHERE user_id = ? AND status = 'active'
        ORDER BY start_date DESC
    """, (user_id,))
    
    experiments = []
    for row in cursor.fetchall():
        experiments.append({
            'feature_id': row[0],
            'start_date': row[1],
            'end_date': row[2]
        })
    
    conn.close()
    return experiments


def get_experiment_results(user_id: str, feature_id: str, db_path: str) -> Dict:
    """
    Calculate before/after metrics for feature experiment
    
    As proposed by Agent 3080: "Show them evidence and let them draw conclusions"
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Get experiment period
    cursor.execute("""
        SELECT start_date FROM user_experiments 
        WHERE user_id = ? AND feature_id = ? 
        ORDER BY start_date DESC LIMIT 1
    """, (user_id, feature_id))
    
    result = cursor.fetchone()
    if not result:
        conn.close()
        return {}
    
    start_date = result[0]
    
    # Get metrics before experiment
    cursor.execute("""
        SELECT 
            COUNT(*) as dialogue_count,
            AVG(rating) as avg_rating
        FROM dialogue_ratings 
        WHERE user_id = ? AND timestamp < ?
        LIMIT 20
    """, (user_id, start_date))
    
    before = cursor.fetchone()
    
    # Get metrics during experiment
    cursor.execute("""
        SELECT 
            COUNT(*) as dialogue_count,
            AVG(rating) as avg_rating
        FROM dialogue_ratings 
        WHERE user_id = ? AND timestamp >= ?
    """, (user_id, start_date))
    
    during = cursor.fetchone()
    
    conn.close()
    
    return {
        'feature_id': feature_id,
        'before': {
            'dialogue_count': before[0] if before else 0,
            'avg_rating': before[1] if before else 0.0
        },
        'during': {
            'dialogue_count': during[0] if during else 0,
            'avg_rating': during[1] if during else 0.0
        }
    }
