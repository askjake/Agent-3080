#!/usr/bin/env python3
"""
End-to-end test of multi-agent dialogue system
"""
import sys
sys.path.insert(0, '/home/montjac/multi-agent-hub')

from dialogue_manager import DialogueManager
import time

print("="*70)
print("REAL DIALOGUE TEST")
print("="*70)

# Initialize manager
manager = DialogueManager()

# Define agents (using mock agents on ports 8100, 8101)
agents = [
    {
        'id': 'mock-agent-8100',
        'name': 'Agent Alpha',
        'backend_url': 'http://localhost:8100'
    },
    {
        'id': 'mock-agent-8101',
        'name': 'Agent Beta',
        'backend_url': 'http://localhost:8101'
    }
]

print("\n📝 Creating dialogue session...")
dialogue_id = manager.create_dialogue_session(
    topic="What is the best way to handle errors in distributed systems?",
    agents=agents,
    max_rounds=3,
    consensus_threshold=0.70,
    dialogue_style="Socratic (Question-driven)"
)

print(f"   ✅ Session created: {dialogue_id}")

# Run dialogue rounds
print("\n🔄 Starting dialogue rounds...")
print("-" * 70)

for round_num in range(3):
    print(f"\n🎯 ROUND {round_num + 1}")
    print("-" * 70)
    
    result = manager.orchestrate_round(dialogue_id)
    
    if result['success']:
        print(f"   ✅ Round {result['round']} completed")
        print(f"   📊 Consensus: {result['consensus']:.1%}")
        
        # Display messages from this round
        for msg in result['messages']:
            if msg.get('role') != 'error':
                print(f"\n   🤖 {msg['agent_name']}:")
                print(f"      {msg['content'][:150]}...")
        
        if result['should_end']:
            print(f"\n   🏁 Dialogue concluded: {result['reason']}")
            break
    else:
        print(f"   ❌ Error: {result.get('error')}")
        break
    
    time.sleep(0.5)

# Export results
print("\n" + "="*70)
print("EXPORTING RESULTS")
print("="*70)

session = manager.get_session(dialogue_id)
print(f"\n📊 Final Statistics:")
print(f"   Topic: {session.get('topic', 'N/A')}")
print(f"   Rounds completed: {session.get('current_round', 0)}")
print(f"   Total messages: {len(session.get('messages', []))}")
print(f"   Final consensus: {session.get('consensus_score', 0):.1%}")
print(f"   Status: {session.get('status', 'unknown')}")

print("\n📄 Markdown Export Preview:")
print("-" * 70)
export = manager.export_dialogue(dialogue_id, format='markdown')
print(export[:500] + "\n..." if len(export) > 500 else export)

print("\n" + "="*70)
print("✅ DIALOGUE TEST COMPLETE")
print("="*70)
