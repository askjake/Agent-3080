"""
DialogueManager v4.0 - With File Upload & Master Coordinator
Handles communication, consensus detection, file processing, and discussion moderation
"""

import requests
import json
import time
from dialogue_tools import DialogueToolExecutor
import sqlite3
from datetime import datetime
from typing import List, Dict, Any, Optional
import hashlib
from difflib import SequenceMatcher
from semantic_consensus import calculate_dialogue_health, calculate_consensus_legacy
import asyncio
import aiohttp

# NEW: Import file processor and master coordinator
from master_coordinator import MasterCoordinator
import base64
import io

# File processing imports
try:
    from PIL import Image
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False
    
try:
    import PyPDF2
    PYPDF2_AVAILABLE = True
except ImportError:
    PYPDF2_AVAILABLE = False


class FileProcessor:
    """Process uploaded files and extract content for agent analysis"""
    
    @staticmethod
    def process_file(file_data: Dict[str, Any]) -> str:
        """
        Convert file data into text that can be injected into agent prompts
        
        Args:
            file_data: Dictionary with file info (type, content, metadata)
            
        Returns:
            str: Formatted text description for agent context
        """
        file_type = file_data.get('type', 'unknown')
        filename = file_data.get('filename', 'unknown')
        
        context = f"\n\n--- FILE: {filename} ---\n"
        
        if file_type in ['text', 'code', 'pdf']:
            content = file_data.get('content', '')
            if len(content) > 5000:
                context += f"File content (first 5000 chars):\n{content[:5000]}...\n"
                context += f"(Total: {len(content)} characters)\n"
            else:
                context += f"File content:\n{content}\n"
                
            if file_type == 'code':
                context += f"\nCode Statistics:\n"
                context += f"- Functions: {file_data.get('functions', 0)}\n"
                context += f"- Classes: {file_data.get('classes', 0)}\n"
                context += f"- Imports: {file_data.get('imports', 0)}\n"
                
        elif file_type == 'image':
            context += f"Image file: {file_data.get('description', 'No description')}\n"
            context += f"Format: {file_data.get('format', 'unknown')}\n"
            context += f"Size: {file_data.get('size', (0,0))}\n"
            context += "(Image content available but not shown in text format)\n"
            
        context += "--- END FILE ---\n\n"
        return context


class DialogueManager:
    """Manages multi-agent dialogue sessions with file upload and master coordination"""
    
    def __init__(self, db_path: str = "/home/montjac/multi-agent-hub/agent_hub.db"):
        self.db_path = db_path
        self.tool_executor = DialogueToolExecutor()
        self.active_sessions = {}
        
        # NEW: Master coordinator for discussion moderation
        self.master_coordinator = MasterCoordinator(intervention_threshold=0.3)
        
        # NEW: File storage for uploaded files
        self.uploaded_files = {}
    
    def create_dialogue_session(self, 
                                topic: str, 
                                agents: List[Dict], 
                                max_rounds: int = 10, 
                                consensus_threshold: float = 0.85,
                                dialogue_style: str = "Socratic",
                                uploaded_files: Optional[List[Dict]] = None,
                                master_enabled: bool = True) -> str:
        """
        Create a new dialogue session with optional file uploads
        
        Args:
            topic: The question or topic to discuss
            agents: List of agent dictionaries with id, name, backend_url
            max_rounds: Maximum number of discussion rounds
            consensus_threshold: Agreement level (0-1) required to conclude
            dialogue_style: How agents should interact
            uploaded_files: Optional list of processed file data
            master_enabled: Whether to enable master coordinator
        
        Returns:
            dialogue_id: Unique session identifier
        """
        dialogue_id = f"dialogue_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{hashlib.md5(topic.encode()).hexdigest()[:6]}"
        
        # NEW: Store uploaded files for this session
        if uploaded_files:
            self.uploaded_files[dialogue_id] = uploaded_files
            
            # Add file context to topic
            file_context = "\n\n=== UPLOADED FILES FOR ANALYSIS ===\n"
            for file_data in uploaded_files:
                file_context += FileProcessor.process_file(file_data)
            file_context += "=== END UPLOADED FILES ===\n\n"
            
            # Prepend file context to topic
            topic = file_context + topic
        
        # Initialize session
        session = {
            'dialogue_id': dialogue_id,
            'topic': topic,
            'agents': agents,
            'max_rounds': max_rounds,
            'consensus_threshold': consensus_threshold,
            'dialogue_style': dialogue_style,
            'current_round': 0,
            'messages': [],
            'consensus_scores': [],
            'status': 'initialized',
            'created_at': datetime.now().isoformat(),
            'master_enabled': master_enabled,
            'uploaded_files': uploaded_files or []
        }
        
        self.active_sessions[dialogue_id] = session
        
        # NEW: Reset master coordinator for new session
        if master_enabled:
            self.master_coordinator.reset()
        
        # Save to database
        self._save_session_to_db(session)
        
        return dialogue_id
    
    def run_dialogue_round(self, dialogue_id: str) -> Dict[str, Any]:
        """
        Execute one round of dialogue with optional master intervention
        
        Returns:
            Dict with round results including any master interventions
        """
        if dialogue_id not in self.active_sessions:
            return {'error': 'Session not found'}
        
        session = self.active_sessions[dialogue_id]
        
        # Check if dialogue is complete
        if session['current_round'] >= session['max_rounds']:
            session['status'] = 'completed'
            return {'status': 'completed', 'reason': 'max_rounds_reached'}
        
        # NEW: Check if master should intervene BEFORE agents speak
        should_intervene = False
        if session.get('master_enabled') and session['current_round'] > 0:
            dialogue_state = {
                'messages': session['messages'],
                'current_round': session['current_round'],
                'max_rounds': session['max_rounds'],
                'consensus_score': session.get('consensus_scores', [0])[-1] if session.get('consensus_scores') else 0,
                'topic': session['topic']
            }
            should_intervene = self.master_coordinator.should_intervene(dialogue_state)
        
        # If master intervenes, inject message and skip regular round
        if should_intervene:
            intervention = self.master_coordinator.generate_intervention(
                dialogue_state,
                session.get('uploaded_files', [])
            )
            
            master_message = {
                'agent_id': 'master_coordinator',
                'agent_name': '👑 Master Coordinator',
                'content': intervention,
                'round': session['current_round'],
                'timestamp': datetime.now().isoformat(),
                'role': 'moderator'
            }
            
            session['messages'].append(master_message)
            
            return {
                'status': 'intervention',
                'message': master_message,
                'round': session['current_round']
            }
        
        # Regular agent round
        session['current_round'] += 1
        round_messages = []
        
        for agent in session['agents']:
            prompt = self._build_agent_prompt(session, agent)
            
            try:
                response = self._call_agent(agent, prompt)
                
                message = {
                    'agent_id': agent['id'],
                    'agent_name': agent['name'],
                    'content': response,
                    'round': session['current_round'],
                    'timestamp': datetime.now().isoformat(),
                    'role': 'participant'
                }
                
                session['messages'].append(message)
                round_messages.append(message)
                
            except Exception as e:
                error_message = {
                    'agent_id': agent['id'],
                    'agent_name': agent['name'],
                    'content': f"Error: {str(e)}",
                    'round': session['current_round'],
                    'timestamp': datetime.now().isoformat(),
                    'role': 'error'
                }
                session['messages'].append(error_message)
                round_messages.append(error_message)
        
        # Calculate consensus
        consensus = self._calculate_consensus(session['messages'])
        session['consensus_scores'].append(consensus)
        
        # Check if consensus reached
        if consensus >= session['consensus_threshold']:
            session['status'] = 'completed'
            
            # NEW: Generate master summary if enabled
            if session.get('master_enabled'):
                summary = self.master_coordinator.generate_summary({
                    'messages': session['messages'],
                    'current_round': session['current_round'],
                    'consensus_score': consensus,
                    'final_consensus': self._extract_consensus_points(session['messages'])
                })
                
                summary_message = {
                    'agent_id': 'master_coordinator',
                    'agent_name': '👑 Master Coordinator',
                    'content': summary,
                    'round': session['current_round'],
                    'timestamp': datetime.now().isoformat(),
                    'role': 'summary'
                }
                
                session['messages'].append(summary_message)
            
            return {
                'status': 'completed',
                'reason': 'consensus_reached',
                'consensus': consensus,
                'round_messages': round_messages
            }
        
        return {
            'status': 'ongoing',
            'round': session['current_round'],
            'consensus': consensus,
            'round_messages': round_messages
        }
    
    def _build_agent_prompt(self, session: Dict, agent: Dict) -> str:
        """Build prompt with file context and conversation history"""
        
        # System prompt (includes file context from topic)
        prompt = f"""You are {agent['name']} participating in a multi-agent dialogue.

Topic: {session['topic']}

Dialogue Style: {session['dialogue_style']}

Previous Messages:
"""
        
        # Add conversation history
        for msg in session['messages'][-10:]:  # Last 10 messages
            if msg['role'] in ['participant', 'moderator']:
                prompt += f"\n{msg['agent_name']}: {msg['content'][:500]}...\n"
        
        prompt += f"\n\nYour turn to respond. Provide your insights and analysis."
        
        return prompt
    
    def _call_agent(self, agent: Dict, prompt: str) -> str:
        """Call agent API with correct endpoint format"""
        base_url = agent['backend_url'].rstrip('/')
        
        # Try /api/chat endpoint (used by most agents)
        try:
            response = requests.post(
                f"{base_url}/api/chat",
                json={'messages': [{'role': 'user', 'content': prompt}]},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                # Extract response content
                if 'content' in data:
                    return data['content']
                elif 'response' in data:
                    return data['response']
                elif 'message' in data:
                    return data['message']
                    
        except Exception as e:
            pass  # Try next endpoint
        
        # Fallback: Try /chat endpoint
        try:
            response = requests.post(
                f"{base_url}/chat",
                json={'messages': [{'role': 'user', 'content': prompt}]},
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                if 'content' in data:
                    return data['content']
                elif 'response' in data:
                    return data['response']
                    
        except Exception:
            pass
        
        # If all failed, return mock response
        return f"[Agent {agent['name']} is offline - could not reach any endpoint]"



    def orchestrate_round(self, dialogue_id: str):
        """Compatibility wrapper - converts return format for app"""
        result = self.run_dialogue_round(dialogue_id)
        
        if "error" in result:
            return {"success": False, "error": result["error"]}
        
        status = result.get("status")
        if status == "completed":
            return {"success": True, "should_end": True, "reason": result.get("reason"), "round": result.get("round", 0)}
        elif status == "intervention":
            return {"success": True, "should_end": False, "round": result.get("round", 0), "intervention": True}
        else:
            return {"success": True, "should_end": False, "round": result.get("round", 0)}

    def _calculate_consensus(self, messages: List[Dict]) -> float:
        """Calculate consensus score using semantic similarity"""
        if len(messages) < 2:
            return 0.0
        
        # Get last N messages from different agents
        recent_messages = [m for m in messages[-6:] if m['role'] == 'participant']
        
        if len(recent_messages) < 2:
            return 0.0
        
        # Simple similarity calculation
        total_similarity = 0
        comparisons = 0
        
        for i in range(len(recent_messages)):
            for j in range(i + 1, len(recent_messages)):
                content1 = recent_messages[i]['content'].lower()
                content2 = recent_messages[j]['content'].lower()
                
                similarity = SequenceMatcher(None, content1, content2).ratio()
                total_similarity += similarity
                comparisons += 1
        
        if comparisons == 0:
            return 0.0
        
        return total_similarity / comparisons
    
    def _extract_consensus_points(self, messages: List[Dict]) -> str:
        """Extract key consensus points from discussion"""
        # Simple extraction - get last few messages
        last_messages = messages[-3:]
        summary = "Key points from discussion:\n"
        for msg in last_messages:
            if msg['role'] == 'participant':
                summary += f"- {msg['content'][:200]}...\n"
        return summary
    
    def _save_session_to_db(self, session: Dict):
        """Save session to database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT OR REPLACE INTO dialogues 
                (id, topic, agent_ids, started_timestamp, status, messages, final_consensus)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                session['dialogue_id'],
                session['topic'],
                json.dumps([a['id'] for a in session['agents']]),
                session['created_at'],
                session['status'],
                json.dumps(session['messages']),
                ''
            ))
            
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Database error: {e}")
    
    def get_session(self, dialogue_id: str) -> Optional[Dict]:
        """Retrieve session data"""
        return self.active_sessions.get(dialogue_id)
