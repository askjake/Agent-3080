"""
Semantic Consensus Calculation Module

Implements the dual-metric system proposed by agents 3080 and 3090-1:
1. Semantic Similarity - Using sentence transformers instead of character matching  
2. Task Coverage - Measuring collective problem-solving
3. Collaboration Score - Detecting cross-references and building behavior
"""

from typing import List, Dict
import re
from difflib import SequenceMatcher

try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    SEMANTIC_AVAILABLE = True
    MODEL = None
except ImportError:
    SEMANTIC_AVAILABLE = False
    MODEL = None


def get_semantic_model():
    global MODEL
    if MODEL is None and SEMANTIC_AVAILABLE:
        try:
            MODEL = SentenceTransformer('all-MiniLM-L6-v2')
        except:
            pass
    return MODEL


def calculate_semantic_similarity(messages: List[Dict]) -> float:
    if len(messages) < 2:
        return 0.0
    
    agent_last_messages = {}
    for msg in reversed(messages):
        agent_id = msg.get('agent_id')
        if agent_id and agent_id not in agent_last_messages:
            agent_last_messages[agent_id] = msg.get('content', '')
    
    if len(agent_last_messages) < 2:
        return 0.0
    
    contents = list(agent_last_messages.values())
    
    model = get_semantic_model()
    if model and SEMANTIC_AVAILABLE:
        try:
            embeddings = model.encode(contents)
            similarities = []
            for i in range(len(embeddings)):
                for j in range(i + 1, len(embeddings)):
                    cos_sim = np.dot(embeddings[i], embeddings[j]) / (
                        np.linalg.norm(embeddings[i]) * np.linalg.norm(embeddings[j])
                    )
                    similarities.append(float(cos_sim))
            return sum(similarities) / len(similarities) if similarities else 0.0
        except:
            pass
    
    similarities = []
    for i in range(len(contents)):
        for j in range(i + 1, len(contents)):
            similarity = SequenceMatcher(None, contents[i], contents[j]).ratio()
            similarities.append(similarity)
    return sum(similarities) / len(similarities) if similarities else 0.0


def calculate_collaboration_score(messages: List[Dict], agents: List[Dict]) -> float:
    if len(messages) < 2:
        return 0.0
    
    agent_names = {a['id']: a['name'] for a in agents}
    cross_references = 0
    collaborative_markers = 0
    
    for msg in messages:
        content = msg.get('content', '')
        msg_agent_id = msg.get('agent_id')
        
        for agent_id, agent_name in agent_names.items():
            if agent_id != msg_agent_id and agent_name in content:
                cross_references += 1
                break
        
        collab_words = ['building on', 'agree with', 'right', 'good point', 
                       'excellent', 'to add', 'yes']
        content_lower = content.lower()
        for word in collab_words:
            if word in content_lower:
                collaborative_markers += 1
                break
    
    total_messages = len(messages)
    if total_messages == 0:
        return 0.0
    
    cross_ref_score = min(cross_references / total_messages, 1.0)
    collab_score = min(collaborative_markers / total_messages, 1.0)
    
    return (cross_ref_score * 0.6 + collab_score * 0.4)


def calculate_task_coverage(messages: List[Dict], topic: str) -> float:
    if not messages or not topic:
        return 0.0
    
    topic_words = set(re.findall(r'\b\w{4,}\b', topic.lower()))
    if not topic_words:
        return 0.5
    
    addressed_concepts = set()
    for msg in messages:
        content = msg.get('content', '').lower()
        for word in topic_words:
            if word in content:
                addressed_concepts.add(word)
    
    coverage = len(addressed_concepts) / len(topic_words) if topic_words else 0.0
    return min(coverage, 1.0)


def calculate_dialogue_health(messages: List[Dict], agents: List[Dict], 
                              topic: str, dialogue_style: str = 'Collaborative',
                              use_semantic: bool = True) -> Dict[str, float]:
    semantic_sim = calculate_semantic_similarity(messages) if use_semantic else 0.0
    collaboration = calculate_collaboration_score(messages, agents)
    task_coverage = calculate_task_coverage(messages, topic)
    
    if dialogue_style.startswith('Collaborative'):
        weights = {'semantic': 0.2, 'collaboration': 0.4, 'coverage': 0.4}
    elif dialogue_style.startswith('Debate'):
        weights = {'semantic': 0.3, 'collaboration': 0.2, 'coverage': 0.5}
    else:
        weights = {'semantic': 0.4, 'collaboration': 0.3, 'coverage': 0.3}
    
    composite_score = (
        semantic_sim * weights['semantic'] +
        collaboration * weights['collaboration'] +
        task_coverage * weights['coverage']
    )
    
    return {
        'semantic_similarity': round(semantic_sim, 3),
        'collaboration_score': round(collaboration, 3),
        'task_coverage': round(task_coverage, 3),
        'dialogue_health': round(composite_score, 3),
        'method': 'semantic' if use_semantic and SEMANTIC_AVAILABLE else 'sequence_matcher'
    }


def calculate_consensus_legacy(messages: List[Dict]) -> float:
    """
    Legacy consensus calculation using SequenceMatcher
    
    This is the OLD method that agents 3080 & 3090-1 identified as broken.
    Kept for comparison and backward compatibility.
    
    Uses character-level text similarity which incorrectly scores
    semantically equivalent but differently worded responses as low similarity.
    """
    if len(messages) < 2:
        return 0.0
    
    # Get last message from each agent
    agent_last_messages = {}
    for msg in reversed(messages):
        agent_id = msg.get('agent_id')
        if agent_id and agent_id not in agent_last_messages:
            agent_last_messages[agent_id] = msg.get('content', '')
    
    if len(agent_last_messages) < 2:
        return 0.0
    
    contents = list(agent_last_messages.values())
    similarities = []
    
    for i in range(len(contents)):
        for j in range(i + 1, len(contents)):
            similarity = SequenceMatcher(None, contents[i], contents[j]).ratio()
            similarities.append(similarity)
    
    consensus = sum(similarities) / len(similarities) if similarities else 0.0
    return round(consensus, 3)
