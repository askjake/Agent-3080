#!/usr/bin/env python3
"""
Test Agent Configuration GUI and Enhanced Endpoint Detection
"""
import sqlite3
import sys

print("="*70)
print("VERIFICATION TEST FOR AGENT CONFIGURATION & ENDPOINT DETECTION")
print("="*70)

# Test 1: Check database schema
print("\n🧪 TEST 1: Database Schema")
print("-"*70)

conn = sqlite3.connect('/home/montjac/multi-agent-hub/agent_hub.db')
cursor = conn.cursor()

cursor.execute("PRAGMA table_info(agents)")
columns = [col[1] for col in cursor.fetchall()]

required_cols = ['id', 'name', 'backend_url', 'frontend_url', 'preferred_endpoint']
missing = [col for col in required_cols if col not in columns]

if not missing:
    print("   ✅ PASS: All required columns present")
    for col in required_cols:
        print(f"      ✓ {col}")
else:
    print(f"   ❌ FAIL: Missing columns: {missing}")
    sys.exit(1)

# Test 2: Check for placeholder names
print("\n🧪 TEST 2: No Placeholder Agent Names")
print("-"*70)

cursor.execute("SELECT id, name FROM agents WHERE name = 'Agent' OR name IS NULL OR TRIM(name) = ''")
placeholders = cursor.fetchall()

if not placeholders:
    print("   ✅ PASS: No placeholder names found")
else:
    print(f"   ⚠️  WARNING: Found {len(placeholders)} placeholder names:")
    for agent_id, name in placeholders:
        print(f"      - {agent_id}: '{name}'")

# Test 3: Check agent names are descriptive
cursor.execute("SELECT id, name, backend_url FROM agents")
agents = cursor.fetchall()

print(f"\n   Current agents ({len(agents)}):")
for agent_id, name, url in agents:
    print(f"      ✓ {name:<30} → {url}")

conn.close()

# Test 4: Import and check dialogue_manager
print("\n🧪 TEST 3: DialogueManager Enhanced Methods")
print("-"*70)

try:
    sys.path.insert(0, '/home/montjac/multi-agent-hub')
    from dialogue_manager import DialogueManager
    
    dm = DialogueManager()
    
    # Check for new methods
    has_discover = hasattr(dm, '_discover_endpoints')
    has_cache = hasattr(dm, '_cache_successful_endpoint')
    has_enhanced_send = hasattr(dm, 'send_message_to_agent')
    
    print(f"   _discover_endpoints: {'✅ Present' if has_discover else '❌ Missing'}")
    print(f"   _cache_successful_endpoint: {'✅ Present' if has_cache else '❌ Missing'}")
    print(f"   send_message_to_agent: {'✅ Present' if has_enhanced_send else '❌ Missing'}")
    
    if all([has_discover, has_cache, has_enhanced_send]):
        print("   ✅ PASS: All enhanced methods present")
    else:
        print("   ❌ FAIL: Some methods missing")
        sys.exit(1)

except Exception as e:
    print(f"   ❌ FAIL: {str(e)}")
    sys.exit(1)

# Test 5: Import agent_configuration
print("\n🧪 TEST 4: Agent Configuration Module")
print("-"*70)

try:
    from agent_configuration import render_agent_configuration_page
    print("   ✅ PASS: agent_configuration module imports successfully")
    print("   ✅ render_agent_configuration_page function available")
except Exception as e:
    print(f"   ❌ FAIL: {str(e)}")
    sys.exit(1)

# Test 6: Check main app integration
print("\n🧪 TEST 5: Main App Integration")
print("-"*70)

with open('/home/montjac/multi-agent-hub/agent_hub_app_complete.py', 'r') as f:
    app_content = f.read()

has_config_in_nav = '⚙️ Agent Configuration' in app_content
has_config_routing = 'render_agent_configuration_page()' in app_content
has_config_import = 'from agent_configuration import' in app_content

print(f"   Navigation menu entry: {'✅ Present' if has_config_in_nav else '❌ Missing'}")
print(f"   Page routing: {'✅ Present' if has_config_routing else '❌ Missing'}")
print(f"   Import statement: {'✅ Present' if has_config_import else '❌ Missing'}")

if all([has_config_in_nav, has_config_routing, has_config_import]):
    print("   ✅ PASS: Agent Configuration fully integrated")
else:
    print("   ❌ FAIL: Integration incomplete")
    sys.exit(1)

print("\n" + "="*70)
print("✅ ALL TESTS PASSED!")
print("="*70)
print("\n📋 Summary:")
print("   ✅ Database schema updated (preferred_endpoint column)")
print("   ✅ No placeholder agent names")
print("   ✅ Enhanced endpoint detection integrated")
print("   ✅ Agent Configuration GUI fully integrated")
print("   ✅ All modules compile successfully")
print("\n🚀 System ready for use!")
