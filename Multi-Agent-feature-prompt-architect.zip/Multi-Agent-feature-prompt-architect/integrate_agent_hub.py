#!/usr/bin/env python3
"""
Integrate Agent Hub reporting into dish-chat agent
Automatically patches the usage_tracking service
"""

import os
import shutil
from datetime import datetime

# Paths
AGENT_DIR = os.path.expanduser("~/Jakes-agent/dish-chat/app/usage_tracking")
SERVICE_FILE = os.path.join(AGENT_DIR, "service.py")
BACKUP_FILE = os.path.join(AGENT_DIR, f"service.py.backup.{datetime.now().strftime('%Y%m%d_%H%M%S')}")
HUB_REPORTER = os.path.expanduser("~/multi-agent-hub/agent_hub_reporter.py")

def backup_file():
    """Create backup of original file"""
    if os.path.exists(SERVICE_FILE):
        shutil.copy2(SERVICE_FILE, BACKUP_FILE)
        print(f"✓ Backed up to: {BACKUP_FILE}")
        return True
    return False

def integrate_hub_reporting():
    """Integrate hub reporting into service.py"""
    
    if not os.path.exists(SERVICE_FILE):
        print(f"❌ Service file not found: {SERVICE_FILE}")
        return False
    
    if not os.path.exists(HUB_REPORTER):
        print(f"❌ Hub reporter not found: {HUB_REPORTER}")
        return False
    
    # Read current file
    with open(SERVICE_FILE, 'r') as f:
        content = f.read()
    
    # Check if already integrated
    if 'hub_reporter' in content or 'agent_hub_reporter' in content:
        print("⚠ Hub reporting already integrated!")
        return False
    
    # Create backup
    if not backup_file():
        print("❌ Failed to create backup")
        return False
    
    # Find the imports section
    import_section = """from .schemas import UsageTrackingCreate, TokenUsageResp
from .repository import UsageTrackingRepository"""
    
    hub_imports = """from .schemas import UsageTrackingCreate, TokenUsageResp
from .repository import UsageTrackingRepository

# Agent Hub Integration
import sys
sys.path.append('/home/montjac/multi-agent-hub')
try:
    from agent_hub_reporter import create_reporter
    hub_reporter = create_reporter(
        hub_url="http://localhost:8502",
        agent_id="dishchat-main-agent"
    )
    HUB_REPORTING_ENABLED = True
    logger.info("✓ Agent Hub reporting enabled")
except ImportError as e:
    hub_reporter = None
    HUB_REPORTING_ENABLED = False
    logger.warning(f"Agent Hub reporting disabled: {e}")"""
    
    content = content.replace(import_section, hub_imports)
    
    # Find the section where usage is saved
    save_section = """                try:
                    await self.usage_tracking_repo.create_many(db, objs_in=records)
                    logger.info(f"Saved {len(records)} usage tracking records")"""
    
    save_with_hub = """                try:
                    await self.usage_tracking_repo.create_many(db, objs_in=records)
                    logger.info(f"Saved {len(records)} usage tracking records")
                    
                    # Report to Agent Hub
                    if HUB_REPORTING_ENABLED and hub_reporter:
                        for model_name, usage_metadata in cb.usage_metadata.items():
                            try:
                                hub_reporter.report_token_usage(
                                    prompt_tokens=usage_metadata.get("input_tokens", 0),
                                    completion_tokens=usage_metadata.get("output_tokens", 0),
                                    model=model_name,
                                    task=profile.get("task", "chat"),
                                    chat_id=str(profile.get("chat_id", "")),
                                    user_email=profile.get("owner_email", ""),
                                    metadata={
                                        "cache_read": usage_metadata.get("input_token_details", {}).get("cache_read", 0),
                                        "cache_create": usage_metadata.get("input_token_details", {}).get("cache_creation", 0),
                                    }
                                )
                            except Exception as hub_error:
                                logger.debug(f"Failed to report to Agent Hub: {hub_error}")"""
    
    content = content.replace(save_section, save_with_hub)
    
    # Write modified file
    with open(SERVICE_FILE, 'w') as f:
        f.write(content)
    
    print(f"✓ Integrated hub reporting into: {SERVICE_FILE}")
    return True

def verify_integration():
    """Verify the integration was successful"""
    with open(SERVICE_FILE, 'r') as f:
        content = f.read()
    
    checks = [
        ('hub_reporter' in content, "Hub reporter import"),
        ('HUB_REPORTING_ENABLED' in content, "Hub reporting flag"),
        ('report_token_usage' in content, "Token reporting call"),
    ]
    
    all_passed = True
    print("\nVerification:")
    for passed, check_name in checks:
        status = "✓" if passed else "❌"
        print(f"  {status} {check_name}")
        if not passed:
            all_passed = False
    
    return all_passed

if __name__ == "__main__":
    print("=" * 60)
    print("Agent Hub Integration Script")
    print("=" * 60)
    print()
    
    if integrate_hub_reporting():
        if verify_integration():
            print("\n🎉 Integration successful!")
            print("\nNext steps:")
            print("  1. Restart your agent: systemctl restart dishchat")
            print("  2. Make a test query")
            print("  3. Check hub dashboard: http://localhost:8501")
        else:
            print("\n⚠ Integration completed but verification failed")
            print(f"Check: {SERVICE_FILE}")
    else:
        print("\n❌ Integration failed")
        print("Manual integration may be required")
