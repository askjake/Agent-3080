-- ============================================================================
-- ENGAGEMENT REFACTOR - DATABASE SCHEMA MIGRATION
-- Version: 001
-- Created: 2026-05-05
-- Description: Add comprehensive engagement features (achievements, stats, 
--              challenges, leaderboard)
-- ============================================================================

-- ============================================================================
-- USER ACHIEVEMENTS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_achievements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    achievement_type TEXT NOT NULL,
    achievement_name TEXT NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT,  -- JSON metadata
    UNIQUE(user_id, achievement_type, achievement_name)
);

CREATE INDEX IF NOT EXISTS idx_achievements_user ON user_achievements(user_id);
CREATE INDEX IF NOT EXISTS idx_achievements_earned ON user_achievements(earned_at DESC);

-- ============================================================================
-- USER STATS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_stats (
    user_id TEXT PRIMARY KEY,
    total_dialogues INTEGER DEFAULT 0,
    total_consensus_achieved INTEGER DEFAULT 0,
    avg_consensus_score REAL DEFAULT 0.0,
    total_agents_used INTEGER DEFAULT 0,
    unique_agents_used INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    current_streak_days INTEGER DEFAULT 0,
    longest_streak_days INTEGER DEFAULT 0,
    last_streak_date DATE,
    theme_preference TEXT DEFAULT 'light',
    notification_preferences TEXT DEFAULT '{}',  -- JSON
    total_points INTEGER DEFAULT 0,
    current_level INTEGER DEFAULT 1,
    points_to_next_level INTEGER DEFAULT 100
);

-- ============================================================================
-- DIALOGUE RATINGS TABLE (Enhanced)
-- ============================================================================
-- Note: This table already exists, so we use ALTER TABLE to add missing columns
-- If the table structure is different, this may need adjustment

-- Check if tags column exists (we'll handle this in Python for safety)

-- ============================================================================
-- LEADERBOARD CACHE TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS leaderboard_cache (
    period TEXT PRIMARY KEY,  -- 'daily', 'weekly', 'monthly', 'all_time'
    data TEXT NOT NULL,  -- JSON data
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- DAILY CHALLENGES TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS daily_challenges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    challenge_date DATE NOT NULL UNIQUE,
    prompt TEXT NOT NULL,
    difficulty TEXT CHECK(difficulty IN ('easy', 'medium', 'hard')) DEFAULT 'medium',
    required_agents INTEGER DEFAULT 2,
    target_consensus REAL DEFAULT 0.8,
    reward_points INTEGER DEFAULT 10,
    bonus_multiplier REAL DEFAULT 1.5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_challenge_date ON daily_challenges(challenge_date DESC);

-- ============================================================================
-- CHALLENGE COMPLETIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS challenge_completions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    challenge_id INTEGER NOT NULL,
    user_id TEXT NOT NULL,
    dialogue_id TEXT NOT NULL,
    completed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    consensus_achieved REAL,
    bonus_points INTEGER DEFAULT 0,
    total_points INTEGER DEFAULT 0,
    FOREIGN KEY (challenge_id) REFERENCES daily_challenges(id),
    UNIQUE(challenge_id, user_id)
);

CREATE INDEX IF NOT EXISTS idx_completions_user ON challenge_completions(user_id);
CREATE INDEX IF NOT EXISTS idx_completions_challenge ON challenge_completions(challenge_id);

-- ============================================================================
-- ACHIEVEMENT DEFINITIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS achievement_definitions (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    icon TEXT NOT NULL,
    category TEXT NOT NULL,  -- 'dialogue', 'consensus', 'agent', 'speed', 'streak'
    requirement_type TEXT NOT NULL,  -- 'count', 'threshold', 'streak'
    requirement_value INTEGER NOT NULL,
    points INTEGER DEFAULT 10,
    rarity TEXT DEFAULT 'common',  -- 'common', 'rare', 'epic', 'legendary'
    hidden BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- INSERT DEFAULT ACHIEVEMENT DEFINITIONS
-- ============================================================================
INSERT OR IGNORE INTO achievement_definitions (id, name, description, icon, category, requirement_type, requirement_value, points, rarity) VALUES
-- Dialogue Milestones
('first_dialogue', 'First Steps', 'Complete your first dialogue', '🎬', 'dialogue', 'count', 1, 10, 'common'),
('dialogue_bronze', 'Bronze Speaker', 'Complete 10 dialogues', '🥉', 'dialogue', 'count', 10, 25, 'common'),
('dialogue_silver', 'Silver Orator', 'Complete 50 dialogues', '🥈', 'dialogue', 'count', 50, 50, 'rare'),
('dialogue_gold', 'Gold Debater', 'Complete 100 dialogues', '🥇', 'dialogue', 'count', 100, 100, 'epic'),
('dialogue_platinum', 'Platinum Master', 'Complete 500 dialogues', '💎', 'dialogue', 'count', 500, 500, 'legendary'),

-- Consensus Achievements
('consensus_seeker', 'Consensus Seeker', 'Achieve 80%+ consensus', '🎯', 'consensus', 'threshold', 80, 15, 'common'),
('consensus_master', 'Consensus Master', 'Achieve 90%+ consensus 10 times', '🎓', 'consensus', 'count', 10, 50, 'rare'),
('consensus_perfect', 'Perfect Harmony', 'Achieve 100% consensus', '✨', 'consensus', 'threshold', 100, 100, 'epic'),
('consensus_sniper', 'Precision Sniper', 'Achieve 95%+ consensus 5 times in a row', '🎯', 'consensus', 'streak', 5, 75, 'rare'),

-- Agent Mastery
('agent_explorer', 'Agent Explorer', 'Use 10 different agents', '🔍', 'agent', 'count', 10, 30, 'common'),
('agent_master', 'Agent Master', 'Use 25 different agents', '👑', 'agent', 'count', 25, 75, 'rare'),
('ringmaster', 'Ringmaster', 'Orchestrate dialogue with 5+ agents at once', '🎪', 'agent', 'threshold', 5, 50, 'rare'),
('agent_loyalist', 'Agent Loyalist', 'Complete 50 dialogues with the same agent', '💝', 'agent', 'count', 50, 40, 'rare'),

-- Speed Achievements
('speed_demon', 'Speed Demon', 'Complete dialogue in under 30 seconds', '⚡', 'speed', 'threshold', 30, 50, 'rare'),
('efficiency_expert', 'Efficiency Expert', 'Complete 10 dialogues in under 1 minute each', '🚀', 'speed', 'count', 10, 75, 'epic'),

-- Streak Achievements
('streak_starter', 'Streak Starter', 'Complete dialogues 3 days in a row', '🔥', 'streak', 'count', 3, 20, 'common'),
('streak_week', 'Week Warrior', 'Complete dialogues 7 days in a row', '📅', 'streak', 'count', 7, 50, 'rare'),
('streak_month', 'Monthly Devotee', 'Complete dialogues 30 days in a row', '🗓️', 'streak', 'count', 30, 200, 'epic'),
('streak_legend', 'Streak Legend', 'Complete dialogues 100 days in a row', '👑', 'streak', 'count', 100, 1000, 'legendary'),

-- Special Achievements
('night_owl', 'Night Owl', 'Complete dialogue between midnight and 5 AM', '🦉', 'special', 'custom', 1, 25, 'rare'),
('early_bird', 'Early Bird', 'Complete dialogue between 5 AM and 7 AM', '🐦', 'special', 'custom', 1, 25, 'rare'),
('social_butterfly', 'Social Butterfly', 'Share 5 dialogue results', '🦋', 'special', 'count', 5, 30, 'rare'),
('teacher', 'Teacher', 'Rate 25 dialogues with feedback', '📝', 'special', 'count', 25, 40, 'rare');

-- ============================================================================
-- USER ACTIVITY LOG (for streak calculation)
-- ============================================================================
CREATE TABLE IF NOT EXISTS user_activity_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    activity_date DATE NOT NULL,
    activity_type TEXT NOT NULL,  -- 'dialogue_complete', 'login', 'rating'
    activity_count INTEGER DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, activity_date, activity_type)
);

CREATE INDEX IF NOT EXISTS idx_activity_user_date ON user_activity_log(user_id, activity_date DESC);

-- ============================================================================
-- NOTIFICATIONS TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    notification_type TEXT NOT NULL,  -- 'achievement', 'challenge', 'level_up', 'announcement'
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN DEFAULT 0,
    action_url TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, read);

-- ============================================================================
-- MIGRATION COMPLETE
-- ============================================================================
-- This migration adds all required tables for Phase 1 engagement features:
-- ✅ Achievements system
-- ✅ User statistics tracking
-- ✅ Leaderboard caching
-- ✅ Daily challenges
-- ✅ Streak tracking
-- ✅ Notifications
