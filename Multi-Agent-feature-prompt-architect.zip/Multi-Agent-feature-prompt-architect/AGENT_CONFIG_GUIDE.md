# ⚙️ Agent Configuration - User Guide

## ✨ Overview

The Agent Configuration page allows you to manage all your AI agents through an intuitive GUI. You can add new agents, edit existing ones, delete agents, and test connectivity - all without touching code or databases directly!

---

## 🚀 Quick Start

### Accessing Agent Configuration

1. Open Multi-Agent Hub: http://localhost:8501
2. Click **"⚙️ Agent Configuration"** in the sidebar
3. You'll see all your registered agents

### Adding a New Agent

**Method 1: Simple Form (Recommended)**

1. Click **"➕ Add New Agent"**
2. Fill in the required fields:
   - **Agent ID**: Unique identifier (e.g., `my-agent-1`)
   - **Agent Name**: Display name (e.g., `My First Agent`)
   - **Backend Host**: IP or hostname (e.g., `10.79.85.47`)
   - **Backend Port**: Port number (e.g., `8000`)
   - **Frontend Host**: (Optional) UI host
   - **Frontend Port**: (Optional) UI port (e.g., `3000`)
3. Click **"💾 Save Agent"**

**Method 2: Full URL**

1. Click **"➕ Add New Agent"**
2. Enter **Agent ID** and **Agent Name**
3. Enter **Full Backend URL**: `http://10.79.85.47:8000`
4. (Optional) Enter **Full Frontend URL**: `http://10.79.85.47:3000`
5. Click **"💾 Save Agent"**

### Editing an Existing Agent

1. Find the agent card
2. Click **"✏️ Edit"**
3. Modify any fields (except Agent ID)
4. Click **"💾 Save Agent"**

### Deleting an Agent

1. Find the agent card
2. Click **"🗑️ Delete"**
3. Confirm deletion by clicking **"✅ Yes, Delete"**

**⚠️ Warning:** Deletion is permanent and cannot be undone!

### Testing Connectivity

**Test Single Agent:**
1. Click **"🧪 Test"** on any agent card
2. Results show immediately:
   - ✅ Success with response time
   - ❌ Error with reason

**Test All Agents:**
1. Click **"🧪 Test All"** at the top
2. All agents are tested in sequence
3. Results displayed on each card

**Test Before Saving:**
1. While adding/editing an agent
2. Click **"🧪 Test First"** in the form
3. Verify connectivity before saving

---

## 📋 Field Reference

### Required Fields

**Agent ID**
- Unique identifier for the agent
- Alphanumeric characters, hyphens, underscores only
- Cannot be changed after creation
- Example: `agent-alpha`, `my_agent_1`

**Agent Name**
- Human-readable display name
- Can contain spaces and special characters
- Can be changed anytime
- Example: `Agent Alpha`, `My AI Assistant`

**Backend URL/Host/Port**
- HTTP endpoint for agent API
- Must be accessible from the Hub server
- Format: `http://host:port` or `https://host:port`
- Examples:
  - `http://localhost:8000`
  - `http://10.79.85.47:8000`
  - `https://my-agent.example.com:443`

### Optional Fields

**Description**
- Text description of agent capabilities
- Displayed on agent card
- Example: `GPT-4 powered agent for code analysis`

**Frontend URL/Host/Port**
- Web UI for the agent (if available)
- Used by "🌐 Open" button
- Format: `http://host:port`
- Example: `http://10.79.85.47:3000`

**Capabilities**
- Comma-separated list of agent features
- Example: `chat, dialogue, analysis, code-review`
- Used for filtering and display

---

## ✅ Validation Rules

### Agent ID
- ✅ Must be unique
- ✅ 1-100 characters
- ✅ Only: letters, numbers, `-`, `_`
- ❌ No spaces
- ❌ No special characters

### URLs
- ✅ Must start with `http://` or `https://`
- ✅ Valid hostname or IP address
- ✅ Port number 1-65535
- ❌ No `ftp://` or other protocols
- ❌ No missing host

### Ports
- ✅ Must be 1-65535
- ❌ No negative numbers
- ❌ No port 0

---

## 🎨 Agent Card Features

Each agent card displays:

**Status Indicator**
- 🟢 **Online**: Responding normally (HTTP 200-299)
- 🟡 **Degraded**: Responding but with issues
- 🔴 **Offline**: Not responding or connection refused

**Information Displayed**
- Agent name and description
- Backend URL
- Frontend URL (if configured)
- Agent ID
- Response time (when tested)

**Action Buttons**
- **✏️ Edit**: Modify agent configuration
- **🗑️ Delete**: Remove agent (with confirmation)
- **🧪 Test**: Check connectivity
- **🌐 Open**: Open frontend URL in new tab (if configured)

---

## 🔧 Common Tasks

### Changing an Agent's Port

1. Click **"✏️ Edit"** on the agent
2. Modify **Backend Port** field
3. Or edit the **Full Backend URL**
4. Click **"🧪 Test First"** to verify
5. Click **"💾 Save Agent"**

### Moving an Agent to a New Server

1. Click **"✏️ Edit"**
2. Update **Backend Host** to new IP/hostname
3. Update **Frontend Host** if applicable
4. Click **"🧪 Test First"**
5. If successful, click **"💾 Save Agent"**

### Adding a Frontend to an Existing Agent

1. Click **"✏️ Edit"**
2. Fill in **Frontend Host** and **Port**
3. Or enter **Full Frontend URL**
4. Click **"💾 Save Agent"**
5. The **"🌐 Open"** button now appears

### Troubleshooting Connection Issues

1. Click **"🧪 Test"** to see specific error
2. Common errors:
   - **Connection refused**: Agent not running
   - **Timeout (>5s)**: Agent too slow or hung
   - **HTTP 404**: No /health endpoint
   - **HTTP 500**: Agent internal error

3. Fix steps:
   - Verify agent is running: `ps aux | grep agent`
   - Check URL is correct
   - Test manually: `curl http://host:port/health`
   - Check firewall rules
   - Review agent logs

---

## 🧪 Testing Features

### Health Check Behavior

When you test an agent:
1. Hub sends GET request to `{backend_url}/health`
2. Waits up to 5 seconds
3. Evaluates response:
   - **HTTP 200-299**: ✅ Online
   - **HTTP 400-499**: 🟡 Degraded (server up, auth issue)
   - **HTTP 500-599**: 🔴 Offline (server error)
   - **Connection refused**: 🔴 Offline
   - **Timeout**: 🔴 Offline

### Test Results Storage

- Results stored in session
- Displayed on agent card after testing
- Includes timestamp and response time
- Cleared on page refresh

### Automatic Status Updates

- Status checked when page loads
- Updated when you click "🔄 Refresh"
- Updated after testing
- Updates when agent is edited

---

## 💡 Best Practices

### Agent Naming
- Use descriptive names: `GPT-4 Code Reviewer` not `Agent1`
- Include version if relevant: `Claude v3.5 Analyst`
- Indicate specialization: `SQL Query Assistant`

### URL Configuration
- Use IP addresses for local networks: `http://10.79.85.47:8000`
- Use hostnames for DNS-resolved: `http://agent-server:8000`
- Always include port number explicitly
- Test after any URL change

### Organization
- Add descriptions to agents
- Use consistent naming conventions
- List capabilities clearly
- Delete unused agents

### Security
- Use HTTPS for public-facing agents
- Don't expose agents on 0.0.0.0 unnecessarily
- Use authentication on agent endpoints
- Rotate credentials regularly

---

## 🐛 Troubleshooting

### "Agent ID already exists"
- Each agent must have a unique ID
- Check existing agents first
- Use a different ID or edit the existing agent

### "Backend URL is invalid"
- Must start with `http://` or `https://`
- Check for typos in hostname
- Ensure port is included
- Example valid: `http://10.79.85.47:8000`

### "Connection refused"
- Agent is not running
- Wrong port number
- Firewall blocking connection
- Check: `curl http://host:port/health`

### "Timeout (>5s)"
- Agent is slow or hung
- Network latency too high
- Agent /health endpoint is blocking
- Consider increasing timeout in code

### Changes not saving
- Check for validation errors (shown in red)
- Ensure required fields are filled
- Try "🧪 Test First" to diagnose
- Check browser console for errors

### Agent shows offline but it's running
- /health endpoint may not exist
- Agent returning non-200 status
- URL/port misconfigured
- Test manually: `curl -v http://host:port/health`

---

## 📊 Example Configurations

### Local Development Agent
```
Agent ID: dev-agent-local
Agent Name: Development Agent (Local)
Backend: http://localhost:8000
Frontend: http://localhost:3000
Description: Local development instance
Capabilities: chat, dialogue, testing
```

### Production Agent
```
Agent ID: prod-gpt4-analyzer
Agent Name: GPT-4 Code Analyzer (Production)
Backend: https://agent-api.company.com:443
Frontend: https://agent-ui.company.com
Description: Production GPT-4 agent for code analysis
Capabilities: chat, code-review, analysis, documentation
```

### Remote Agent
```
Agent ID: remote-claude-assistant
Agent Name: Claude Assistant (Remote Server)
Backend: http://10.79.85.47:8080
Frontend: http://10.79.85.47:3080
Description: Claude-powered assistant on remote server
Capabilities: chat, dialogue, research, writing
```

---

## 🔄 Updating from Previous Versions

If you have agents registered through code or scripts:
1. They will appear in Agent Configuration automatically
2. Edit them to add missing fields (description, capabilities)
3. Verify and update URLs if needed
4. Test connectivity

---

## 🎓 Advanced Usage

### Bulk Import (Coming Soon)
- Import agents from CSV
- Migrate from other systems
- Batch configuration updates

### Agent Groups (Coming Soon)
- Organize agents by purpose
- Filter by capabilities
- Quick select for dialogues

### Health Monitoring (Coming Soon)
- Automatic health checks
- Alert on failures
- Uptime tracking

---

## 📞 Need Help?

### Quick Checks
1. Is the agent actually running?
2. Can you curl the health endpoint?
3. Is the URL/port correct?
4. Any firewall issues?

### Logs to Check
- Hub logs: `/tmp/agent_hub.log`
- Agent logs: Check agent's log file
- System logs: `journalctl -u agent-service`

### Still Stuck?
- Review validation error messages carefully
- Test connectivity manually with curl
- Check agent's own health endpoint
- Verify network connectivity

---

**Status:** ✅ Fully Implemented and Tested

**Made with ❤️ by Dish-Chat AI Assistant**

---

*Last Updated: 2026-04-29*
