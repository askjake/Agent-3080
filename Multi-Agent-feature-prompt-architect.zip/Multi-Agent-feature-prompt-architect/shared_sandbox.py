
"""
shared_sandbox.py
=================
Intelligent shared workspace for multi-agent collaboration.
Agents can read/write files with automatic conflict resolution and versioning.
"""

import os
import json
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any, Optional
import sqlite3

class SharedSandbox:
    """
    Intelligent shared workspace for multi-agent dialogues.
    
    Features:
    - Per-dialogue isolated sandboxes
    - File versioning and conflict detection
    - Access logging
    - Intelligent read/write recommendations
    - Auto-cleanup after dialogue completion
    """
    
    def __init__(self, base_path: str = "/home/montjac/multi-agent-hub/sandboxes",
                 db_path: str = "/home/montjac/multi-agent-hub/agent_hub.db"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        self._initialize_db()
    
    def _initialize_db(self):
        """Initialize sandbox tracking in database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sandbox_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                dialogue_id TEXT NOT NULL,
                filename TEXT NOT NULL,
                agent_id TEXT NOT NULL,
                agent_name TEXT NOT NULL,
                operation TEXT NOT NULL,
                content_hash TEXT,
                file_size INTEGER,
                timestamp TEXT NOT NULL,
                purpose TEXT,
                UNIQUE(dialogue_id, filename, timestamp)
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sandbox_metadata (
                dialogue_id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                file_count INTEGER DEFAULT 0,
                total_size INTEGER DEFAULT 0,
                last_activity TEXT
            )
        """)
        
        conn.commit()
        conn.close()
    
    def create_sandbox(self, dialogue_id: str) -> Path:
        """
        Create isolated sandbox for a dialogue.
        
        Args:
            dialogue_id: Unique dialogue identifier
        
        Returns:
            Path to sandbox directory
        """
        sandbox_path = self.base_path / dialogue_id
        sandbox_path.mkdir(parents=True, exist_ok=True)
        
        # Create README
        readme = sandbox_path / "README.md"
        readme.write_text(f"""# Shared Sandbox for Dialogue: {dialogue_id}

Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Purpose
This is a shared workspace where agents can collaborate by creating and reading files.

## Guidelines for Agents

### When to Write Files:
- ✅ Creating structured data (JSON, CSV)
- ✅ Documenting decisions or analysis
- ✅ Storing code snippets or configurations
- ✅ Sharing diagrams or visualizations (text-based)

### When to Read Files:
- ✅ Before creating a file (check if it exists)
- ✅ When another agent mentions a file
- ✅ To understand prior work
- ✅ To build upon existing content

### Intelligent File Management:
1. **Check first:** Always check if file exists before creating
2. **Name clearly:** Use descriptive names (e.g., `decision_matrix.json`)
3. **Add purpose:** Include comments/headers explaining the file
4. **Version if needed:** Use v1, v2 suffixes if iterating
5. **Don't overwrite:** Unless explicitly improving content

## Available Files:
*Agents: List files you create below*

""")
        
        # Track in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT OR REPLACE INTO sandbox_metadata (dialogue_id, created_at, last_activity)
            VALUES (?, ?, ?)
        """, (dialogue_id, datetime.now().isoformat(), datetime.now().isoformat()))
        
        conn.commit()
        conn.close()
        
        return sandbox_path
    
    def write_file(self, dialogue_id: str, filename: str, content: str,
                   agent_id: str, agent_name: str, purpose: str = "") -> Dict[str, Any]:
        """
        Write file to sandbox with intelligent conflict detection.
        
        Args:
            dialogue_id: Dialogue identifier
            filename: Name of file to write
            content: File content
            agent_id: ID of agent writing
            agent_name: Name of agent
            purpose: Why this file is being created
        
        Returns:
            Result dictionary with status and any warnings
        """
        sandbox_path = self.base_path / dialogue_id
        sandbox_path.mkdir(parents=True, exist_ok=True)
        
        file_path = sandbox_path / filename
        
        result = {
            'success': False,
            'path': str(file_path),
            'warnings': [],
            'recommendations': []
        }
        
        # Check if file exists
        if file_path.exists():
            existing_content = file_path.read_text()
            existing_hash = hashlib.md5(existing_content.encode()).hexdigest()
            new_hash = hashlib.md5(content.encode()).hexdigest()
            
            if existing_hash == new_hash:
                result['warnings'].append("File already exists with identical content")
                result['recommendations'].append("No write needed - content unchanged")
                result['success'] = True
                return result
            else:
                result['warnings'].append(f"File exists - created versioned copy: {filename}.v{self._get_version(dialogue_id, filename)}")
                # Create versioned file
                version = self._get_version(dialogue_id, filename)
                versioned_filename = f"{filename}.v{version}"
                file_path = sandbox_path / versioned_filename
                result['path'] = str(file_path)
        
        # Write file
        try:
            file_path.write_text(content)
            
            # Calculate hash and size
            content_hash = hashlib.md5(content.encode()).hexdigest()
            file_size = len(content)
            
            # Log to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO sandbox_files (dialogue_id, filename, agent_id, agent_name, 
                                          operation, content_hash, file_size, timestamp, purpose)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (dialogue_id, filename, agent_id, agent_name, 'write',
                  content_hash, file_size, datetime.now().isoformat(), purpose))
            
            # Update metadata
            cursor.execute("""
                UPDATE sandbox_metadata 
                SET file_count = (SELECT COUNT(DISTINCT filename) FROM sandbox_files WHERE dialogue_id = ?),
                    total_size = (SELECT SUM(file_size) FROM sandbox_files WHERE dialogue_id = ?),
                    last_activity = ?
                WHERE dialogue_id = ?
            """, (dialogue_id, dialogue_id, datetime.now().isoformat(), dialogue_id))
            
            conn.commit()
            conn.close()
            
            result['success'] = True
            result['recommendations'].append(f"File created successfully: {file_path.name}")
            
        except Exception as e:
            result['warnings'].append(f"Error writing file: {str(e)}")
        
        return result
    
    def read_file(self, dialogue_id: str, filename: str, 
                  agent_id: str, agent_name: str) -> Dict[str, Any]:
        """
        Read file from sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
            filename: Name of file to read
            agent_id: ID of agent reading
            agent_name: Name of agent
        
        Returns:
            Result dictionary with content or error
        """
        file_path = self.base_path / dialogue_id / filename
        
        result = {
            'success': False,
            'content': None,
            'metadata': {}
        }
        
        if not file_path.exists():
            result['error'] = f"File not found: {filename}"
            result['available_files'] = self.list_files(dialogue_id)
            return result
        
        try:
            content = file_path.read_text()
            result['content'] = content
            result['success'] = True
            result['metadata'] = {
                'filename': filename,
                'size': len(content),
                'lines': content.count('\n'),
                'created_by': self._get_file_creator(dialogue_id, filename)
            }
            
            # Log read access
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO sandbox_files (dialogue_id, filename, agent_id, agent_name, 
                                          operation, timestamp, purpose)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (dialogue_id, filename, agent_id, agent_name, 'read',
                  datetime.now().isoformat(), 'read access'))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            result['error'] = f"Error reading file: {str(e)}"
        
        return result
    
    def list_files(self, dialogue_id: str) -> List[Dict[str, Any]]:
        """
        List all files in sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
        
        Returns:
            List of file metadata dictionaries
        """
        sandbox_path = self.base_path / dialogue_id
        
        if not sandbox_path.exists():
            return []
        
        files = []
        for file_path in sandbox_path.iterdir():
            if file_path.is_file() and file_path.name != 'README.md':
                files.append({
                    'name': file_path.name,
                    'size': file_path.stat().st_size,
                    'created': datetime.fromtimestamp(file_path.stat().st_ctime).isoformat(),
                    'modified': datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
                    'creator': self._get_file_creator(dialogue_id, file_path.name)
                })
        
        return files
    
    def get_sandbox_summary(self, dialogue_id: str) -> Dict[str, Any]:
        """
        Get summary of sandbox activity.
        
        Args:
            dialogue_id: Dialogue identifier
        
        Returns:
            Summary dictionary
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get metadata
        cursor.execute("""
            SELECT file_count, total_size, last_activity
            FROM sandbox_metadata
            WHERE dialogue_id = ?
        """, (dialogue_id,))
        
        meta = cursor.fetchone()
        
        # Get file operations
        cursor.execute("""
            SELECT filename, agent_name, operation, timestamp, purpose
            FROM sandbox_files
            WHERE dialogue_id = ?
            ORDER BY timestamp DESC
        """, (dialogue_id,))
        
        operations = cursor.fetchall()
        
        conn.close()
        
        return {
            'file_count': meta[0] if meta else 0,
            'total_size': meta[1] if meta else 0,
            'last_activity': meta[2] if meta else None,
            'operations': [
                {
                    'filename': op[0],
                    'agent': op[1],
                    'operation': op[2],
                    'timestamp': op[3],
                    'purpose': op[4]
                }
                for op in operations
            ],
            'files': self.list_files(dialogue_id)
        }
    
    def suggest_intelligent_action(self, dialogue_id: str, agent_id: str,
                                   context: str) -> Dict[str, Any]:
        """
        Suggest intelligent file operations based on dialogue context.
        
        Args:
            dialogue_id: Dialogue identifier
            agent_id: Current agent
            context: Recent dialogue content
        
        Returns:
            Suggestions dictionary
        """
        suggestions = {
            'should_read': [],
            'should_write': [],
            'reasoning': []
        }
        
        files = self.list_files(dialogue_id)
        
        # Suggest reads
        for file in files:
            if file['creator'] != agent_id:
                suggestions['should_read'].append({
                    'filename': file['name'],
                    'reason': f"Created by {file['creator']}, may contain relevant context"
                })
        
        # Suggest writes based on context keywords
        context_lower = context.lower()
        
        if 'decision' in context_lower or 'agree' in context_lower:
            suggestions['should_write'].append({
                'filename': 'decisions.json',
                'reason': 'Document decisions made in dialogue'
            })
        
        if 'code' in context_lower or 'implement' in context_lower:
            suggestions['should_write'].append({
                'filename': 'implementation_plan.md',
                'reason': 'Capture implementation approach'
            })
        
        if 'analysis' in context_lower or 'evaluate' in context_lower:
            suggestions['should_write'].append({
                'filename': 'analysis_results.json',
                'reason': 'Store analysis findings'
            })
        
        return suggestions
    
    def _get_version(self, dialogue_id: str, filename: str) -> int:
        """Get next version number for a file"""
        sandbox_path = self.base_path / dialogue_id
        version = 1
        
        while (sandbox_path / f"{filename}.v{version}").exists():
            version += 1
        
        return version
    
    def _get_file_creator(self, dialogue_id: str, filename: str) -> str:
        """Get the agent who created a file"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT agent_name FROM sandbox_files
            WHERE dialogue_id = ? AND filename = ? AND operation = 'write'
            ORDER BY timestamp ASC
            LIMIT 1
        """, (dialogue_id, filename))
        
        result = cursor.fetchone()
        conn.close()
        
        return result[0] if result else "Unknown"
    
    def cleanup_sandbox(self, dialogue_id: str, archive: bool = True) -> bool:
        """
        Clean up sandbox after dialogue completion.
        
        Args:
            dialogue_id: Dialogue identifier
            archive: If True, move to archive instead of delete
        
        Returns:
            Success boolean
        """
        sandbox_path = self.base_path / dialogue_id
        
        if not sandbox_path.exists():
            return True
        
        try:
            if archive:
                archive_path = self.base_path / "archive" / dialogue_id
                archive_path.parent.mkdir(parents=True, exist_ok=True)
                sandbox_path.rename(archive_path)
            else:
                import shutil
                shutil.rmtree(sandbox_path)
            
            return True
        except Exception as e:
            print(f"Error cleaning up sandbox: {e}")
            return False


# Test the sandbox
if __name__ == "__main__":
    sandbox = SharedSandbox()
    
    test_dialogue_id = "test_dialogue_001"
    
    print("=" * 80)
    print("SHARED SANDBOX SYSTEM TEST")
    print("=" * 80)
    
    # Create sandbox
    path = sandbox.create_sandbox(test_dialogue_id)
    print(f"\n✅ Created sandbox: {path}")
    
    # Write file
    result = sandbox.write_file(
        dialogue_id=test_dialogue_id,
        filename="test_document.md",
        content="# Test Document\n\nThis is a test.",
        agent_id="agent1",
        agent_name="Agent Alpha",
        purpose="Testing sandbox functionality"
    )
    print(f"\n✅ Write result: {result}")
    
    # List files
    files = sandbox.list_files(test_dialogue_id)
    print(f"\n📁 Files in sandbox: {len(files)}")
    for f in files:
        print(f"   - {f['name']} ({f['size']} bytes)")
    
    # Get summary
    summary = sandbox.get_sandbox_summary(test_dialogue_id)
    print(f"\n📊 Sandbox summary: {summary['file_count']} files, {summary['total_size']} bytes")
    
    print("\n✅ SharedSandbox ready to use!")
