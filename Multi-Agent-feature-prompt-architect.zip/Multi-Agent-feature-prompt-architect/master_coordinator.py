#!/usr/bin/env python3
"""
Master Coordinator Agent
========================
A supervisor agent that monitors multi-agent discussions and intervenes
when discussions go off-track, become circular, or need guidance.

Features:
- Monitors consensus and progress
- Detects circular discussions
- Injects guidance at key moments
- Summarizes and refocuses debates
"""

from typing import Dict, List, Any, Optional
from datetime import datetime
import re


class MasterCoordinator:
    """
    Master agent that oversees multi-agent discussions.
    Acts as a moderator and guide when needed.
    """
    
    def __init__(self, intervention_threshold: float = 0.3):
        self.intervention_threshold = intervention_threshold
        self.intervention_count = 0
        self.last_intervention_round = -1
        
    def analyze_discussion_health(self, dialogue_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze the health and progress of the discussion.
        
        Returns:
            health_metrics: Dict with various health indicators
        """
        messages = dialogue_state.get('messages', [])
        current_round = dialogue_state.get('current_round', 0)
        max_rounds = dialogue_state.get('max_rounds', 20)
        consensus = dialogue_state.get('consensus_score', 0.0)
        
        health = {
            'overall_health': 'good',
            'issues': [],
            'recommendations': [],
            'should_intervene': False
        }
        
        # Check 1: Circular discussion detection
        if len(messages) >= 4:
            last_4_contents = [msg.get('content', '')[:200] for msg in messages[-4:]]
            unique_contents = len(set(last_4_contents))
            
            if unique_contents <= 2:
                health['issues'].append('Circular discussion detected')
                health['overall_health'] = 'poor'
                health['should_intervene'] = True
        
        # Check 2: Low consensus after many rounds
        if current_round >= max_rounds // 2 and consensus < self.intervention_threshold:
            health['issues'].append(f'Low consensus ({consensus:.1%}) at midpoint')
            health['overall_health'] = 'concerning'
            health['should_intervene'] = True
        
        # Check 3: Confusion signals
        if messages:
            last_msg = messages[-1].get('content', '').lower()
            confusion_keywords = ['confused', 'unclear', "don't understand", 
                                 'not sure', 'uncertain', 'lost', 'what do you mean']
            
            if any(keyword in last_msg for keyword in confusion_keywords):
                health['issues'].append('Agent expressing confusion')
                health['overall_health'] = 'concerning'
                health['should_intervene'] = True
        
        # Check 4: No progress in recent rounds
        if len(messages) >= 6:
            recent_consensus_changes = []
            for i in range(len(messages) - 6, len(messages)):
                if 'consensus' in messages[i]:
                    recent_consensus_changes.append(messages[i]['consensus'])
            
            if recent_consensus_changes and max(recent_consensus_changes) - min(recent_consensus_changes) < 0.05:
                health['issues'].append('Consensus stagnation detected')
                health['recommendations'].append('Suggest new perspective or approach')
        
        # Check 5: Too frequent interventions
        if current_round - self.last_intervention_round <= 2:
            health['should_intervene'] = False  # Don't intervene too frequently
            health['recommendations'].append('Wait before next intervention')
        
        return health
    
    def should_intervene(self, dialogue_state: Dict[str, Any]) -> bool:
        """
        Determine if master agent should intervene.
        
        Args:
            dialogue_state: Current state of the dialogue
            
        Returns:
            bool: True if intervention needed
        """
        health = self.analyze_discussion_health(dialogue_state)
        return health['should_intervene']
    
    def generate_intervention(self, 
                            dialogue_state: Dict[str, Any], 
                            uploaded_files: Optional[List[Dict]] = None) -> str:
        """
        Generate a master coordinator intervention message.
        
        Args:
            dialogue_state: Current dialogue state
            uploaded_files: Optional list of uploaded file metadata
            
        Returns:
            str: Intervention message
        """
        self.intervention_count += 1
        self.last_intervention_round = dialogue_state.get('current_round', 0)
        
        messages = dialogue_state.get('messages', [])
        topic = dialogue_state.get('topic', 'the discussion')
        current_round = dialogue_state.get('current_round', 0)
        max_rounds = dialogue_state.get('max_rounds', 20)
        consensus = dialogue_state.get('consensus_score', 0.0)
        
        health = self.analyze_discussion_health(dialogue_state)
        
        intervention = f"""👑 **MASTER COORDINATOR - INTERVENTION #{self.intervention_count}**

I've been monitoring this discussion and I'd like to provide guidance.

**Current Status:**
- Round {current_round} of {max_rounds} ({(current_round/max_rounds)*100:.0f}% complete)
- Consensus Level: {consensus:.1%}
- Messages Exchanged: {len(messages)}
- Discussion Health: {health['overall_health'].upper()}
"""
        
        # Add identified issues
        if health['issues']:
            intervention += "\n\n**Issues Identified:**\n"
            for issue in health['issues']:
                intervention += f"⚠️  {issue}\n"
        
        # Add file context if available
        if uploaded_files:
            intervention += "\n\n**Available Context Files:**\n"
            for file in uploaded_files:
                file_type = file.get('type', 'unknown')
                file_name = file.get('filename', 'unknown')
                file_desc = self._describe_file(file)
                intervention += f"📄 **{file_name}** ({file_type}): {file_desc}\n"
        
        # Provide specific guidance based on issues
        intervention += "\n\n**Recommended Actions:**\n"
        
        if 'Circular discussion' in str(health['issues']):
            intervention += """
1. 🔄 **Break the Circle**: Each agent, state ONE new insight you haven't mentioned yet
2. 🎯 **Refocus**: Return to the original question: "{topic}"
3. ✅ **Concrete Output**: Propose a specific, actionable recommendation
""".format(topic=topic)
        
        elif 'Low consensus' in str(health['issues']):
            intervention += """
1. 🤝 **Find Common Ground**: What do all agents agree on? Start there.
2. 📊 **Prioritize**: Rank your top 3 points by importance
3. 💡 **Compromise**: Can disagreements be resolved with "it depends" or phased approaches?
"""
        
        elif 'confusion' in str(health['issues']).lower():
            intervention += """
1. 🔍 **Clarify Terms**: Define key concepts everyone is using
2. 📝 **Simple Summary**: Each agent, summarize your main point in ONE sentence
3. 🗂️ **Structure**: Let's organize the discussion into clear categories
"""
        
        else:
            intervention += """
1. 📊 **Progress Check**: Summarize what we've agreed on so far
2. 🎯 **Next Steps**: What specific question should we tackle next?
3. ⏰ **Time Management**: We have {remaining} rounds remaining - prioritize!
""".format(remaining=max_rounds - current_round)
        
        # Add encouraging note
        intervention += "\n\n💪 **Great work so far!** Let's push toward a concrete conclusion.\n"
        
        return intervention
    
    def _describe_file(self, file_data: Dict[str, Any]) -> str:
        """Generate a brief description of a file for context"""
        file_type = file_data.get('type', 'unknown')
        
        if file_type == 'text' or file_type == 'code':
            lines = file_data.get('lines', 0)
            chars = file_data.get('chars', 0)
            return f"{lines} lines, {chars} characters"
        elif file_type == 'image':
            size = file_data.get('size', (0, 0))
            return f"{size[0]}x{size[1]} pixels"
        elif file_type == 'pdf':
            pages = file_data.get('pages', 0)
            return f"{pages} pages"
        else:
            return "binary file"
    
    def generate_summary(self, dialogue_state: Dict[str, Any]) -> str:
        """
        Generate a final summary when dialogue concludes.
        
        Args:
            dialogue_state: Final dialogue state
            
        Returns:
            str: Summary message
        """
        messages = dialogue_state.get('messages', [])
        consensus = dialogue_state.get('consensus_score', 0.0)
        final_summary = dialogue_state.get('final_consensus', '')
        
        summary = f"""👑 **MASTER COORDINATOR - FINAL SUMMARY**

**Discussion Concluded**

"""
        
        summary += f"- Total Rounds: {dialogue_state.get('current_round', 0)}\n"
        summary += f"- Messages Exchanged: {len(messages)}\n"
        summary += f"- Final Consensus: {consensus:.1%}\n"
        summary += f"- Interventions Required: {self.intervention_count}\n\n"
        
        if consensus >= 0.8:
            summary += "✅ **Strong Consensus Reached**\n\n"
        elif consensus >= 0.6:
            summary += "📊 **Moderate Consensus**\n\n"
        else:
            summary += "⚠️ **Low Consensus** - Significant disagreement remains\n\n"
        
        if final_summary:
            summary += f"**Key Takeaways:**\n{final_summary}\n\n"
        
        summary += "Thank you to all participating agents for a productive discussion!\n"
        
        return summary
    
    def reset(self):
        """Reset coordinator state for new dialogue"""
        self.intervention_count = 0
        self.last_intervention_round = -1


# Test the coordinator
if __name__ == "__main__":
    print("="*80)
    print("MASTER COORDINATOR TEST")
    print("="*80)
    
    coordinator = MasterCoordinator(intervention_threshold=0.3)
    
    # Test scenario: circular discussion
    test_dialogue = {
        'messages': [
            {'agent': 'Agent1', 'content': 'We should use microservices'},
            {'agent': 'Agent2', 'content': 'I think monolith is better'},
            {'agent': 'Agent1', 'content': 'We should use microservices'},
            {'agent': 'Agent2', 'content': 'I think monolith is better'},
        ],
        'current_round': 4,
        'max_rounds': 10,
        'consensus_score': 0.2,
        'topic': 'What architecture should we use?'
    }
    
    print("\nTest 1: Circular Discussion Detection")
    print("-" * 80)
    should_intervene = coordinator.should_intervene(test_dialogue)
    print(f"Should intervene: {should_intervene}")
    
    if should_intervene:
        intervention = coordinator.generate_intervention(test_dialogue)
        print("\nIntervention Message:")
        print(intervention)
    
    print("\n" + "="*80)
    print("✅ Master Coordinator Ready!")
