
#!/usr/bin/env python3
"""
Test DialogueManager functionality
"""
import sys
sys.path.insert(0, '/home/montjac/multi-agent-hub')

from dialogue_manager import DialogueManager
import json

print("="*70)
print("TESTING DIALOGUE MANAGER")
print("="*70)

# Initialize manager
manager = DialogueManager()
print("\n✅ DialogueManager initialized")

# Test 1: Create session
print("\n🧪 TEST 1: Create dialogue session")
agents = [
    {'id': 'test-agent-1', 'name': 'Agent Alpha', 'backend_url': 'http://localhost:8000'},
    {'id': 'test-agent-2', 'name': 'Agent Beta', 'backend_url': 'http://localhost:8001'}
]

dialogue_id = manager.create_dialogue_session(
    topic="What is the best way to handle errors in distributed systems?",
    agents=agents,
    max_rounds=3,
    consensus_threshold=0.75
)

print(f"   ✅ Created session: {dialogue_id}")

# Test 2: Session retrieval
print("\n🧪 TEST 2: Retrieve session")
session = manager.get_session(dialogue_id)
if session:
    print(f"   ✅ Session retrieved")
    print(f"      Topic: {session['topic']}")
    print(f"      Agents: {len(agents)}")
    print(f"      Max rounds: {session.get('max_rounds', 'N/A')}")
else:
    print("   ❌ Failed to retrieve session")

# Test 3: Consensus calculation
print("\n🧪 TEST 3: Consensus calculation")
test_messages = [
    {'agent_id': 'a1', 'content': 'We should use retry mechanisms with exponential backoff'},
    {'agent_id': 'a2', 'content': 'I agree, retry with exponential backoff is essential'},
]
consensus = manager.calculate_consensus(test_messages)
print(f"   ✅ Consensus score: {consensus:.2%}")
print(f"      Expected: High similarity (messages agree)")

test_messages_low = [
    {'agent_id': 'a1', 'content': 'Circuit breakers are the best approach'},
    {'agent_id': 'a2', 'content': 'Database transactions solve everything'},
]
consensus_low = manager.calculate_consensus(test_messages_low)
print(f"   ✅ Low consensus: {consensus_low:.2%}")
print(f"      Expected: Low similarity (messages disagree)")

# Test 4: Export functionality
print("\n🧪 TEST 4: Export dialogue")
export_md = manager.export_dialogue(dialogue_id, format='markdown')
export_json = manager.export_dialogue(dialogue_id, format='json')

print(f"   ✅ Markdown export: {len(export_md)} characters")
print(f"   ✅ JSON export: {len(export_json)} characters")

# Test 5: Message sending (will fail gracefully if agents not running)
print("\n🧪 TEST 5: Send message to agent (graceful failure expected)")
test_agent = {'id': 'test', 'name': 'Test Agent', 'backend_url': 'http://localhost:9999'}
test_messages = [{'role': 'user', 'content': 'Hello'}]

response = manager.send_message_to_agent(test_agent, test_messages)
print(f"   Response: {response}")
if not response['success']:
    print(f"   ✅ Graceful failure: {response.get('error', 'Unknown')[:50]}...")
else:
    print(f"   ✅ Success: {response['content'][:50]}...")

print("\n" + "="*70)
print("TESTING COMPLETE")
print("="*70)
print("\n📊 Summary:")
print("   ✅ Session creation: Working")
print("   ✅ Session retrieval: Working")
print("   ✅ Consensus calculation: Working")
print("   ✅ Export functionality: Working")
print("   ✅ Error handling: Graceful")
