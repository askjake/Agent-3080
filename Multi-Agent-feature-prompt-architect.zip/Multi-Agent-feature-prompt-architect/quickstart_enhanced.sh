#!/bin/bash
# Quick Start Script for Enhanced Agent Management Hub v4.0 with File Upload

echo "🚀 AI Agent Management Hub v4.0 - Production Edition"
echo "===================================================="
echo ""
echo "✨ NEW v4.0 FEATURES:"
echo "   📁 Drag-and-drop file uploads"
echo "   🖼️  Multi-format support (text, code, images, PDFs)"
echo "   👑 Master coordinator for discussion moderation"
echo "   🤖 Enhanced dialogue system"
echo "   🎯 Circular discussion detection"
echo "   📊 Automatic intervention logic"
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | grep -Po '(?<=Python )(.+)')
echo "✓ Python version: $python_version"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip install -q streamlit pandas plotly requests aiohttp pillow pypdf2 2>/dev/null

if [ $? -eq 0 ]; then
    echo "✓ Dependencies installed"
else
    echo "⚠️  Some dependencies may have failed (continuing anyway)"
fi

# Start the app
echo ""
echo "🚀 Starting Enhanced Agent Management Hub v4.0..."
echo "   Access at: http://localhost:8501"
echo ""
echo "   Press Ctrl+C to stop"
echo ""

# Check for production file first, fallback to v3 if needed
if [ -f "agent_hub_app_production.py" ]; then
    echo "✓ Using production version (v4.0 with file upload)"
    streamlit run agent_hub_app_production.py
elif [ -f "agent_hub_app_v4_fileupload.py" ]; then
    echo "✓ Using v4 file upload version"
    streamlit run agent_hub_app_v4_fileupload.py
elif [ -f "agent_hub_app_v3_validation_enhanced.py" ]; then
    echo "⚠️  v4 not found, falling back to v3 (no file upload)"
    streamlit run agent_hub_app_v3_validation_enhanced.py
else
    echo "❌ Error: No app file found"
    echo "   Please ensure one of these exists:"
    echo "   - agent_hub_app_production.py (preferred)"
    echo "   - agent_hub_app_v4_fileupload.py"
    echo "   - agent_hub_app_v3_validation_enhanced.py"
    exit 1
fi
