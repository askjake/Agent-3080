#!/usr/bin/env python3
"""
Mock AI Agent Server for testing Multi-Agent Dialogue
Provides /chat endpoint that responds intelligently to topics
"""

from flask import Flask, request, jsonify
import random
import sys

app = Flask(__name__)

# Agent personality and knowledge base
AGENT_RESPONSES = {
    "error handling": [
        "I believe circuit breakers are essential for handling cascading failures. They prevent system-wide outages by failing fast.",
        "Retry mechanisms with exponential backoff are crucial. We should implement jitter to avoid thundering herd problems.",
        "Error logging and monitoring are foundational. Without visibility, we're flying blind in production.",
        "Bulkheads can isolate failures to specific components. This architectural pattern prevents one failure from bringing down everything."
    ],
    "optimization": [
        "Caching is often the first step in optimization. We should identify hot paths and cache aggressively there.",
        "Database query optimization can yield massive gains. Have we profiled our queries and added appropriate indexes?",
        "Lazy loading and pagination reduce initial load times significantly. Users don't need everything at once.",
        "Code-level optimizations like algorithmic improvements often beat infrastructure scaling."
    ],
    "architecture": [
        "Microservices offer flexibility but add operational complexity. We need to carefully consider team size and maturity.",
        "Event-driven architecture provides loose coupling and scalability. However, debugging distributed events is challenging.",
        "A modular monolith might be the sweet spot for many teams. It provides separation without distributed system complexity.",
        "API versioning strategy is critical. We need a plan before we release to avoid breaking clients."
    ],
    "security": [
        "Defense in depth is essential. We can't rely on a single security layer.",
        "Input validation must happen on the server side, never trust client-side validation alone.",
        "Principle of least privilege should guide all our access control decisions.",
        "Regular security audits and penetration testing help identify vulnerabilities before attackers do."
    ],
    "default": [
        "That's an interesting point. I think we need to consider multiple perspectives here.",
        "Building on that idea, we should also think about the trade-offs involved.",
        "I'd like to explore this further. What are the potential downsides we should consider?",
        "This aligns with best practices, but we need to adapt it to our specific context."
    ]
}

QUESTIONS = [
    "What about edge cases?",
    "How would this scale?",
    "What are the cost implications?",
    "Have we considered the user experience impact?",
    "What monitoring would we need?",
    "How does this affect deployment complexity?",
    "What's the rollback strategy?",
    "Could this create technical debt?"
]

def get_agent_name():
    """Get agent name from port"""
    port = sys.argv[1] if len(sys.argv) > 1 else "8000"
    return f"Agent-{port}"

def generate_response(conversation_history):
    """Generate intelligent response based on conversation"""
    
    # Extract topic from conversation
    full_text = " ".join([msg.get('content', '') for msg in conversation_history]).lower()
    
    # Determine topic category
    category = "default"
    for key in AGENT_RESPONSES.keys():
        if key in full_text:
            category = key
            break
    
    # Get base response
    responses = AGENT_RESPONSES[category]
    response = random.choice(responses)
    
    # 30% chance to add a question (Socratic style)
    if random.random() < 0.3:
        response += "\n\n" + random.choice(QUESTIONS)
    
    # 20% chance to reference another agent's point
    if len(conversation_history) > 1 and random.random() < 0.2:
        response += "\n\nI agree with the point about " + random.choice([
            "monitoring", "scalability", "reliability", "user experience", "cost-effectiveness"
        ]) + "."
    
    return response

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'name': get_agent_name(),
        'version': '1.0.0',
        'capabilities': ['chat', 'dialogue']
    })

@app.route('/chat', methods=['POST'])
@app.route('/api/chat', methods=['POST'])
def chat():
    """Chat endpoint for dialogue"""
    try:
        data = request.json
        messages = data.get('messages', [])
        
        if not messages:
            return jsonify({'error': 'No messages provided'}), 400
        
        # Generate response
        response_content = generate_response(messages)
        
        return jsonify({
            'content': response_content,
            'agent': get_agent_name(),
            'timestamp': '2026-04-29T09:00:00Z'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/', methods=['GET'])
def root():
    """Root endpoint"""
    return jsonify({
        'name': get_agent_name(),
        'status': 'online',
        'endpoints': ['/health', '/chat', '/api/chat']
    })

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"🤖 Starting {get_agent_name()} on port {port}")
    print(f"   Health: http://localhost:{port}/health")
    print(f"   Chat: http://localhost:{port}/chat")
    app.run(host='0.0.0.0', port=port, debug=False)
