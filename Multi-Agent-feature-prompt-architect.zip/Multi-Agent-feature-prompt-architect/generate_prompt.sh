#!/bin/bash
# Prompt Architect - Generate Comprehensive Project Prompts
# Usage: ./generate_prompt.sh [project_path]

PROJECT_PATH="${1:-.}"
echo "🎯 PROMPT ARCHITECT v1.0"
echo "================================"
echo ""
echo "Analyzing project: $PROJECT_PATH"
echo ""

python3 - "$PROJECT_PATH" << 'PYTHON_EOF'
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from prompt_architect import PromptArchitect

project_path = sys.argv[1]
architect = PromptArchitect(project_path)
analysis = architect.analyze_project()

# Generate comprehensive prompt (would need full implementation)
print("\n✅ Analysis Complete!")
print(f"   - Files analyzed: {sum(s['file_count'] for s in analysis['structure'].values())}")
print(f"   - Documentation: {len(analysis['documentation'])}")
print(f"   - Entry points: {len(analysis['entry_points'])}")
print(f"\n📄 Comprehensive prompt saved to:")
print(f"   COMPREHENSIVE_PROJECT_PROMPT.md")
PYTHON_EOF

echo ""
echo "✅ Done! Use COMPREHENSIVE_PROJECT_PROMPT.md to brief AI agents."
