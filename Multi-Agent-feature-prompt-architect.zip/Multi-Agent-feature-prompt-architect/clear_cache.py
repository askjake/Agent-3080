#!/usr/bin/env python3
"""
Clear Streamlit cache and restart properly
"""
import os
import shutil
import sys

print("="*70)
print("CLEARING STREAMLIT CACHE")
print("="*70)

# Streamlit cache locations
cache_dirs = [
    os.path.expanduser("~/.streamlit/cache"),
    ".streamlit/cache",
    "/home/montjac/.streamlit/cache",
    "__pycache__",
    "agent_configuration.pyc",
]

for cache_dir in cache_dirs:
    if os.path.exists(cache_dir):
        try:
            if os.path.isdir(cache_dir):
                shutil.rmtree(cache_dir)
                print(f"✅ Removed directory: {cache_dir}")
            else:
                os.remove(cache_dir)
                print(f"✅ Removed file: {cache_dir}")
        except Exception as e:
            print(f"⚠️  Could not remove {cache_dir}: {str(e)}")
    else:
        print(f"ℹ️  Not found: {cache_dir}")

# Remove Python bytecode cache
pycache_dirs = []
for root, dirs, files in os.walk('/home/montjac/multi-agent-hub'):
    if '__pycache__' in dirs:
        pycache_dirs.append(os.path.join(root, '__pycache__'))

for pycache in pycache_dirs:
    try:
        shutil.rmtree(pycache)
        print(f"✅ Removed: {pycache}")
    except Exception as e:
        print(f"⚠️  Could not remove {pycache}: {str(e)}")

# Remove .pyc files
for root, dirs, files in os.walk('/home/montjac/multi-agent-hub'):
    for file in files:
        if file.endswith('.pyc'):
            filepath = os.path.join(root, file)
            try:
                os.remove(filepath)
                print(f"✅ Removed: {filepath}")
            except Exception as e:
                print(f"⚠️  Could not remove {filepath}: {str(e)}")

print("\n" + "="*70)
print("✅ CACHE CLEARED")
print("="*70)
print("\nNow restart the app:")
print("  ./quickstart.sh")
print("\nOr manually:")
print("  streamlit run agent_hub_app_complete.py --server.port 8503")
