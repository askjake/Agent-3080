#!/usr/bin/env python3
"""
Enhanced Multi-Agent Dialogue Diagnostic Tool
Now supports Dish-Chat style agents!
"""
import sqlite3
import requests
import json

DB_PATH = "/home/montjac/multi-agent-hub/agent_hub.db"

def get_agents():
    """Get all agents from database"""
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, backend_url FROM agents")
    agents = []
    for row in cursor.fetchall():
        agents.append({
            'id': row[0],
            'name': row[1],
            'backend_url': row[2]
        })
    conn.close()
    return agents

def test_dishchat_agent(agent):
    """Test if agent uses Dish-Chat API"""
    backend_url = agent['backend_url'].rstrip('/')
    
    try:
        # Test health
        health_resp = requests.get(f"{backend_url}/rest/api/v1/health", timeout=3)
        
        if health_resp.status_code == 200:
            print(f"   ✅ Dish-Chat health endpoint works")
            
            # Try to create session
            create_resp = requests.post(
                f"{backend_url}/rest/api/v1/chats",
                json={"name": "Diagnostic Test"},
                timeout=5
            )
            
            if create_resp.status_code == 200:
                chat_id = create_resp.json().get('chat_id')
                print(f"   ✅ Created Dish-Chat session")
                
                # Try to send message
                msg_resp = requests.post(
                    f"{backend_url}/rest/api/v1/chats/{chat_id}/messages",
                    json={"content": "Test", "role": "user"},
                    timeout=10
                )
                
                if msg_resp.status_code == 200:
                    print(f"   ✅ Dish-Chat message endpoint works!")
                    print(f"\n   ✅ Agent is READY for multi-agent dialogue\n")
                    return True
                else:
                    print(f"   ❌ Message failed: HTTP {msg_resp.status_code}")
            else:
                print(f"   ❌ Session creation failed: HTTP {create_resp.status_code}")
        
    except requests.exceptions.Timeout:
        print(f"   ⚠️  Timeout")
    except requests.exceptions.ConnectionError:
        print(f"   ❌ Connection refused")
    except Exception as e:
        print(f"   ⚠️  Error: {str(e)[:50]}")
    
    return False

def test_standard_agent(agent):
    """Test standard chat endpoints"""
    backend_url = agent['backend_url'].rstrip('/')
    
    endpoints = ['/chat', '/api/chat', '/v1/chat/completions', '/v1/chat', '/message', '/api/message']
    
    for endpoint in endpoints:
        try:
            response = requests.post(
                f"{backend_url}{endpoint}",
                json={"messages": [{"role": "user", "content": "test"}]},
                timeout=5
            )
            
            if response.status_code == 200:
                print(f"   ✅ {endpoint} works!")
                print(f"\n   ✅ Agent is READY for multi-agent dialogue\n")
                return True
            elif response.status_code != 404:
                print(f"   ⚠️  {endpoint}: HTTP {response.status_code}")
                
        except requests.exceptions.Timeout:
            print(f"   ❌ {endpoint} timeout")
        except requests.exceptions.ConnectionError:
            continue
        except Exception:
            continue
    
    return False

# Main diagnostic
print("="*70)
print("MULTI-AGENT DIALOGUE DIAGNOSTIC (Enhanced)")
print("="*70)

agents = get_agents()
print(f"\n📋 Testing {len(agents)} agents:\n")

ready_count = 0

for agent in agents:
    print("="*70)
    print(f"🤖 {agent['name']}")
    print("="*70)
    print(f"Backend URL: {agent['backend_url']}")
    
    # Try Dish-Chat API first
    print("\n1️⃣  Testing Dish-Chat API:")
    if test_dishchat_agent(agent):
        ready_count += 1
        continue
    
    # Try standard endpoints
    print("\n2️⃣  Testing Standard Chat Endpoints:")
    if test_standard_agent(agent):
        ready_count += 1
        continue
    
    print("\n   ❌ No working endpoint found")
    print("   💡 Solutions:")
    print("      1. Ensure agent server is running")
    print("      2. Check if agent supports Dish-Chat or standard chat API")
    print("      3. Check firewall/network settings")
    print()

print("="*70)
print("DIAGNOSTIC SUMMARY")
print("="*70)
print(f"\n📊 Status: {ready_count}/{len(agents)} agents ready\n")

if ready_count >= 2:
    print("✅ READY FOR MULTI-AGENT DIALOGUE")
    print("\nYou have enough working agents! Go to:")
    print("• Multi-Agent Dialogue page")
    print("• Select 2+ agents")
    print("• Start dialogue")
elif ready_count == 1:
    print("⚠️  NEED MORE AGENTS")
    print("\nOnly 1 agent working. Need at least 2 for dialogue.")
    print("\n💡 Solutions:")
    print("   • Start more agent servers")
    print("   • Fix non-working agents")
    print("   • Add new agents in Agent Configuration")
else:
    print("❌ NO AGENTS READY")
    print("\n💡 Solutions:")
    print("   • Ensure agents are running")
    print("   • Check agent configurations")
    print("   • Verify network connectivity")
