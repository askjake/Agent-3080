#!/usr/bin/env python3
"""
Ollama Agent Adapter Service
Wraps Ollama API to provide simple /chat endpoint compatible with Multi-Agent Hub
"""

from flask import Flask, request, jsonify
import requests
import sys
from typing import Dict, List

app = Flask(__name__)

# Ollama configuration
OLLAMA_BASE_URL = "http://localhost:11434"
OLLAMA_MODEL = "llama3.1:8b"

def call_ollama(messages: List[Dict]) -> str:
    """
    Call Ollama API with chat messages
    
    Args:
        messages: List of message dicts with 'role' and 'content'
    
    Returns:
        Response content from Ollama
    """
    try:
        # Convert messages to Ollama format
        # Ollama expects a simple prompt for /api/generate
        # or messages for /api/chat
        
        # Build context from message history
        prompt = ""
        for msg in messages:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            if role == 'system':
                prompt += f"System: {content}\n"
            elif role == 'user':
                prompt += f"User: {content}\n"
            elif role == 'assistant':
                prompt += f"Assistant: {content}\n"
        
        prompt += "Assistant: "
        
        # Call Ollama API
        url = f"{OLLAMA_BASE_URL}/api/generate"
        payload = {
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": 0.7,
                "top_p": 0.9,
                "top_k": 40
            }
        }
        
        response = requests.post(url, json=payload, timeout=60)
        response.raise_for_status()
        
        result = response.json()
        return result.get('response', 'No response generated')
        
    except requests.exceptions.Timeout:
        return "Error: Ollama request timed out (>60s)"
    except requests.exceptions.ConnectionError:
        return "Error: Cannot connect to Ollama server"
    except Exception as e:
        return f"Error: {str(e)}"

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    try:
        # Check if Ollama is reachable
        response = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=3)
        if response.status_code == 200:
            models = response.json().get('models', [])
            model_names = [m.get('name') for m in models]
            return jsonify({
                'status': 'healthy',
                'service': 'ollama-adapter',
                'ollama_url': OLLAMA_BASE_URL,
                'model': OLLAMA_MODEL,
                'available_models': model_names
            })
        else:
            return jsonify({
                'status': 'degraded',
                'error': f'Ollama returned status {response.status_code}'
            }), 503
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e)
        }), 503

@app.route('/chat', methods=['POST'])
@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Chat endpoint compatible with Multi-Agent Hub format
    
    Expected input:
    {
        "messages": [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there!"},
            {"role": "user", "content": "How are you?"}
        ],
        "agent_id": "ollama-gemma" (optional)
    }
    
    Returns:
    {
        "content": "I'm doing well, thanks for asking!",
        "agent": "Ollama Gemma",
        "timestamp": "2026-04-29T15:00:00Z"
    }
    """
    try:
        data = request.json
        messages = data.get('messages', [])
        
        if not messages:
            return jsonify({'error': 'No messages provided'}), 400
        
        # Call Ollama
        response_content = call_ollama(messages)
        
        from datetime import datetime
        return jsonify({
            'content': response_content,
            'agent': f'Ollama ({OLLAMA_MODEL})',
            'timestamp': datetime.now().isoformat() + 'Z'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/', methods=['GET'])
def root():
    """Root endpoint with service info"""
    return jsonify({
        'service': 'ollama-adapter',
        'version': '1.0.0',
        'ollama_url': OLLAMA_BASE_URL,
        'model': OLLAMA_MODEL,
        'endpoints': ['/health', '/chat', '/api/chat']
    })

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8100
    print(f"🤖 Starting Ollama Adapter on port {port}")
    print(f"   Ollama URL: {OLLAMA_BASE_URL}")
    print(f"   Model: {OLLAMA_MODEL}")
    print(f"   Health: http://localhost:{port}/health")
    print(f"   Chat: http://localhost:{port}/chat")
    app.run(host='0.0.0.0', port=port, debug=False)
