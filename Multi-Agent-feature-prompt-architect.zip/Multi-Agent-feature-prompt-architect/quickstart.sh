#!/bin/bash
# Production Launcher for Agent Hub v4.0

echo "🚀 AI Agent Management Hub v4.0 - PRODUCTION"
echo "============================================="
echo ""
echo "Features:"
echo "  📁 Drag-and-drop file uploads"
echo "  🖼️  Multi-format support (text, code, images, PDFs)"
echo "  👑 Master coordinator for discussion moderation"
echo "  🤖 Real-time multi-agent collaboration"
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | grep -Po '(?<=Python )(.+)')
echo "✓ Python version: $python_version"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip install -q streamlit pandas plotly requests aiohttp pillow pypdf2 2>/dev/null

# Check if production file exists
if [ ! -f "agent_hub_app_production.py" ]; then
    echo "❌ Error: agent_hub_app_production.py not found"
    echo "   Attempting to use v4 file..."
    
    if [ -f "agent_hub_app_v4_fileupload.py" ]; then
        cp agent_hub_app_v4_fileupload.py agent_hub_app_production.py
        echo "✓ Copied v4 to production"
    else
        echo "❌ No app file found. Exiting."
        exit 1
    fi
fi

echo ""
echo "🚀 Starting Agent Hub v4.0..."
echo "   Access at: http://localhost:8501"
echo ""
echo "   Press Ctrl+C to stop"
echo ""

streamlit run agent_hub_app_production.py
