#!/bin/bash
cd /home/montjac/multi-agent-hub
/home/montjac/.local/bin/streamlit run agent_hub_app_complete.py --server.port 8501
