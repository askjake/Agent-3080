# 🎯 Prompt Architect - Comprehensive Project Briefing Tool

## What Is This?

**Prompt Architect** is a tool that analyzes your codebase and automatically generates a comprehensive "briefing document" (prompt) that you can provide to ANY AI agent to give them complete understanding of your project.

## The Problem It Solves

When working with AI assistants on complex projects, you often have to:
- ❌ Explain the same context multiple times
- ❌ Hope the AI finds the right files
- ❌ Manually copy-paste documentation fragments
- ❌ Watch the AI make incorrect assumptions

**Prompt Architect eliminates all of this.**

## How It Works

1. **Analyzes** your entire project structure
2. **Extracts** key information (architecture, dependencies, entry points, docs)
3. **Generates** a comprehensive briefing document
4. **Outputs** a ready-to-use prompt for AI agents

## Usage

### Quick Start
```bash
cd ~/multi-agent-hub
./generate_prompt.sh
```

This will:
- ✅ Analyze the current directory
- ✅ Generate `COMPREHENSIVE_PROJECT_PROMPT.md`
- ✅ Show statistics about what was found

### Analyze Different Project
```bash
./generate_prompt.sh /path/to/other/project
```

### Use The Generated Prompt

Once generated, **copy the entire `COMPREHENSIVE_PROJECT_PROMPT.md` file** and paste it into your conversation with any AI assistant:

**Example:**
> "I need you to understand this project completely. [PASTE COMPREHENSIVE_PROJECT_PROMPT.md HERE]
> 
> Now help me with: Add a new feature to export dialogues as PDF"

The AI will have:
- ✅ Full project context
- ✅ Architecture understanding
- ✅ Technology stack knowledge
- ✅ Entry points and key files
- ✅ Documentation references
- ✅ Testing procedures
- ✅ Deployment instructions

## What Gets Analyzed

### 📁 Directory Structure
- Maps entire project hierarchy
- Identifies key directories
- Counts files and subdirectories

### 🔑 Key Files
- **Entry points:** `main.py`, `app.py`, `quickstart.sh`
- **Config files:** `config.py`, `settings.py`, `requirements.txt`
- **Documentation:** `README.md`, `*.md` files
- **Tests:** `test_*.py`, `*_test.py`

### 🛠️ Technologies
- Programming languages (Python, JavaScript, etc.)
- Frameworks (Streamlit, Flask, Django)
- Databases (SQLite, PostgreSQL)
- Libraries (Pandas, Plotly, etc.)

### 📚 Documentation
- Scans all `.md`, `.txt`, `.rst` files
- Extracts project goals and purpose
- Identifies feature lists
- Finds workflow guides

### 🏗️ Architecture
- Infers architectural patterns (Multi-Agent, Web App, API, etc.)
- Identifies system components
- Maps data flow
- Detects deployment methods

## Example Output

```markdown
# 🎯 COMPREHENSIVE PROJECT GUIDE & PROMPT
# Multi-Agent Hub - Complete Understanding Package

## 📋 EXECUTIVE SUMMARY
**Project:** multi-agent-hub
**Type:** Web Application
**Technologies:** Streamlit, Python, Plotly, SQLite, Pandas

### What This Project Does:
A comprehensive Streamlit-based dashboard for managing multiple 
self-learning AI agents with advanced features for monitoring, 
safety, and inter-agent collaboration.

### Core Innovation:
First AI platform that measures what SHOULD NOT happen 
(manipulation, pressure, complexity) instead of just what 
does happen (responses generated).

[... continues with full analysis ...]
```

## Generated Sections

The comprehensive prompt includes:

1. **Executive Summary** - Project overview and goals
2. **System Architecture** - Components and patterns
3. **Quick Start Guide** - Installation and startup commands
4. **Project Structure** - Key files explained
5. **Core Features** - What the system can do
6. **Database Schema** - Data structure (if applicable)
7. **Configuration** - How to customize
8. **Testing & Validation** - How to verify it works
9. **Understanding the Code** - Code walkthrough
10. **Key Concepts** - Important ideas explained
11. **Integration Guide** - How to extend
12. **Warnings & Limitations** - What to watch out for
13. **Deployment Guide** - How to deploy
14. **Future Enhancements** - Roadmap
15. **Quick Reference Commands** - Common operations
16. **Verification Checklist** - Confirm understanding

## When To Use This

### ✅ Use Prompt Architect When:
- Starting a new conversation with an AI about your project
- Onboarding a new AI "team member" to help with development
- Switching between different AI assistants
- Working on a complex codebase with multiple modules
- You need the AI to make architectural decisions
- Explaining your project to stakeholders (via AI summary)

### ⚠️ Not Needed When:
- Asking quick, isolated questions
- Working on a single, small file
- The AI already has context from earlier in the conversation

## Advanced Features

### Custom Analysis
You can modify `prompt_architect.py` to:
- Add custom file patterns to analyze
- Include/exclude specific directories
- Add project-specific sections
- Customize the prompt template

### Integration With Multi-Agent Hub
The Prompt Architect itself can be used AS A DIALOGUE TOPIC:

```python
# In Multi-Agent Hub
topic = f"Review this project and suggest improvements: {open('COMPREHENSIVE_PROJECT_PROMPT.md').read()}"
# Start dialogue with 3-4 agents
# Get multi-perspective analysis!
```

## Benefits

### For You
- ⏱️ **Save Time:** No more re-explaining context
- 🎯 **Better Results:** AI has full picture, makes informed decisions
- 📚 **Documentation:** Auto-generated project overview
- 🔄 **Reusable:** Generate once, use with any AI

### For AI Agents
- 🧠 **Complete Context:** Full understanding before starting
- 🏗️ **Architecture Awareness:** Know the big picture
- 📖 **Documentation Access:** All guides and references
- ✅ **Verification Steps:** Know how to test changes

## Technical Details

### How It Works Internally

```python
class PromptArchitect:
    def analyze_project(self):
        1. Walk directory tree
        2. Identify key file patterns
        3. Parse documentation
        4. Extract technologies from dependencies
        5. Infer architecture from patterns
        6. Generate comprehensive prompt
```

### Technologies Used
- **Python 3.8+**: Core language
- **Pathlib**: File system operations
- **JSON**: Data serialization
- **Bash**: Shell script wrapper

### Output Format
- **Markdown**: Easy to read and paste
- **Structured**: Consistent sections
- **Complete**: All context in one file

## Examples

### Example 1: Bug Fix
```bash
# Generate prompt
./generate_prompt.sh

# Copy COMPREHENSIVE_PROJECT_PROMPT.md and paste to AI:
"[PROMPT] Now fix the bug where consensus calculation returns negative values"

# AI Response:
"Based on the architecture (Multi-Agent Web App with SQLite), 
the consensus calculation is in validation_framework.py. 
I see the issue - the threshold comparison is inverted. 
Here's the fix: [detailed solution]"
```

### Example 2: New Feature
```bash
# Generate prompt
./generate_prompt.sh

# Paste to AI:
"[PROMPT] Add a feature to export dialogues as PDF with proper formatting"

# AI Response:
"I understand this is a Streamlit app with SQLite database.
I'll add this to agent_hub_app_v3_validation.py following 
the existing patterns. Here's the implementation: [code]"
```

### Example 3: Refactoring
```bash
# Generate prompt
./generate_prompt.sh

# Paste to AI:
"[PROMPT] Refactor the dialogue manager to support async operations"

# AI Response:
"Looking at dialogue_manager.py, I see it currently uses 
synchronous operations. Given your stack (aiohttp already installed),
I'll convert it to async/await. Here's the refactored version: [code]"
```

## Maintenance

### Updating The Prompt
Run `./generate_prompt.sh` whenever:
- You add major new features
- Project structure changes significantly
- Documentation is updated
- Starting a new development phase

### Version Control
- ✅ Commit `prompt_architect.py` (the tool)
- ✅ Commit `generate_prompt.sh` (the runner)
- ⚠️ Optional: Commit `COMPREHENSIVE_PROJECT_PROMPT.md` (the output)
  - Some prefer to regenerate fresh each time
  - Others commit for historical reference

## Customization

### Add Custom Sections
Edit `prompt_architect.py`:

```python
def generate_comprehensive_prompt(self):
    prompt = f"""
    ... existing sections ...
    
    ## 🎨 MY CUSTOM SECTION
    {self._generate_my_custom_section()}
    """
    return prompt

def _generate_my_custom_section(self):
    # Your custom analysis logic
    return "Custom section content"
```

### Exclude Sensitive Info
Modify `_analyze_structure()` to skip sensitive directories:

```python
dirs[:] = [d for d in dirs if d not in [
    '.git\, '__pycache__', 
    'node_modules', venv, 
    '.env', 'secrets'  # <-- Add here
]]
```

## Troubleshooting

### "No such file or directory"
**Solution:** Make sure you're in the project directory
```bash
cd ~/multi-agent-hub
./generate_prompt.sh
```

### "Permission denied"
**Solution:** Make script executable
```bash
chmod +x generate_prompt.sh
```

### "Module not found"
**Solution:** Ensure Python 3 is installed
```bash
python3 --version  # Should be 3.8+
```

### Prompt Too Long
**Solution:** AI token limits vary - if needed, edit `prompt_architect.py` to:
- Reduce example snippets
- Summarize documentation instead of full text
- Skip less important sections

## Comparison With Manual Briefing

| Method | Time | Completeness | Consistency |
|--------|------|--------------|-------------|
| **Manual Briefing** | 20-30 min | ⚠️ Often incomplete | ❌ Varies each time |
| **Prompt Architect** | 2 seconds | ✅ Comprehensive | ✅ Always consistent |

## Future Enhancements

Potential improvements:
- 🎯 Generate different prompt lengths (brief/detailed/comprehensive)
- 🔍 Semantic code analysis (understand logic, not just structure)
- 📊 Include performance metrics from previous AI sessions
- 🌐 Multi-project analysis (compare multiple codebases)
- 🎨 Visual architecture diagrams (Mermaid/PlantUML)
- 🤖 AI-generated project summaries (meta-prompt!)

## Credits

**Created by:** Dish-Chat AI Assistant
**For:** montjac's Multi-Agent Hub
**Purpose:** Eliminate context re-explanation when working with AI agents
**Philosophy:** "Brief once, work forever"

## License

Part of Multi-Agent Hub project. Use and modify freely.

---

## Quick Reference

```bash
# Generate prompt for current project
./generate_prompt.sh

# Generate for different project
./generate_prompt.sh /path/to/project

# View generated prompt
cat COMPREHENSIVE_PROJECT_PROMPT.md

# Copy to clipboard (Linux)
cat COMPREHENSIVE_PROJECT_PROMPT.md | xclip -selection clipboard

# Copy to clipboard (macOS)
cat COMPREHENSIVE_PROJECT_PROMPT.md | pbcopy
```

---

**Remember:** A well-briefed AI is a productive AI! 🚀
