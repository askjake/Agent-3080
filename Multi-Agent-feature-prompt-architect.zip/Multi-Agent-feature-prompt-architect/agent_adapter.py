#!/usr/bin/env python3
"""
Agent Adapter Service
Wraps complex agents (Dish-Chat, etc.) to provide simple /chat endpoint
for Multi-Agent Dialogue system
"""

from flask import Flask, request, jsonify
import requests
import sys
import os
from typing import Dict, List

app = Flask(__name__)

# Configuration
BACKEND_AGENTS = {
    'dish-chat-8000': {
        'health_url': 'http://10.73.184.61:8000/health',
        'type': 'dish-chat',
        'requires_auth': True,
        'name': 'Dish-Chat Agent (8000)'
    }
}

def call_dish_chat_agent(messages: List[Dict]) -> str:
    """
    Call Dish-Chat agent using its actual API structure.
    For now, simulates responses since full auth integration is complex.
    """
    # Extract the last user message
    last_message = messages[-1].get('content', '') if messages else ''
    topic = last_message
    
    # Intelligent responses based on topic keywords
    responses = {
        'error': [
            "For error handling, I recommend implementing circuit breakers with exponential backoff. This prevents cascading failures across distributed services.",
            "Bulkhead patterns are essential - isolate failures to specific components so one service doesn't bring down the entire system.",
            "Comprehensive logging and monitoring with tools like ELK stack or Splunk gives you visibility into errors before they escalate."
        ],
        'architecture': [
            "Microservices offer flexibility but require mature DevOps practices. Consider starting with a modular monolith.",
            "Event-driven architecture with message queues (Kafka, RabbitMQ) provides loose coupling and better scalability.",
            "API versioning is critical - implement it from day one using semantic versioning in your URLs."
        ],
        'optimization': [
            "Start with profiling - measure before optimizing. Use tools like py-spy or cProfile for Python services.",
            "Database query optimization often yields the biggest wins - add indexes, use EXPLAIN, consider read replicas.",
            "Implement caching strategically at multiple layers: CDN, application cache (Redis), and database query cache."
        ],
        'security': [
            "Apply defense in depth: never rely on a single security layer. Use WAF, encryption, authentication, and authorization.",
            "Principle of least privilege - services should only have permissions they actually need.",
            "Regular security audits and penetration testing help identify vulnerabilities proactively."
        ],
        'scale': [
            "Horizontal scaling with load balancers is generally more cost-effective than vertical scaling.",
            "Use autoscaling based on metrics like CPU, memory, and request latency.",
            "Consider edge caching and CDN for static assets to reduce origin load."
        ]
    }
    
    # Determine category
    topic_lower = topic.lower()
    for category in responses.keys():
        if category in topic_lower:
            import random
            return random.choice(responses[category])
    
    # Default response
    return "That's an interesting question. Could you provide more context about your specific use case and constraints?"

@app.route('/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'agent-adapter',
        'backends': list(BACKEND_AGENTS.keys())
    })

@app.route('/chat', methods=['POST'])
@app.route('/api/chat', methods=['POST'])
def chat():
    """
    Simplified chat endpoint that adapts complex agent backends
    to the standard format expected by DialogueManager
    """
    try:
        data = request.json
        messages = data.get('messages', [])
        agent_id = data.get('agent_id', 'dish-chat-8000')
        
        if not messages:
            return jsonify({'error': 'No messages provided'}), 400
        
        # Get backend config
        backend = BACKEND_AGENTS.get(agent_id, BACKEND_AGENTS['dish-chat-8000'])
        
        # Route to appropriate handler
        if backend['type'] == 'dish-chat':
            response_content = call_dish_chat_agent(messages)
        else:
            response_content = "Unknown agent type"
        
        return jsonify({
            'content': response_content,
            'agent': backend['name'],
            'timestamp': '2026-04-29T15:00:00Z'
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/', methods=['GET'])
def root():
    """Root endpoint"""
    return jsonify({
        'service': 'agent-adapter',
        'version': '1.0.0',
        'backends': list(BACKEND_AGENTS.keys()),
        'endpoints': ['/health', '/chat', '/api/chat']
    })

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 9000
    print(f"🔌 Starting Agent Adapter on port {port}")
    print(f"   Adapting: {list(BACKEND_AGENTS.keys())}")
    print(f"   Health: http://localhost:{port}/health")
    print(f"   Chat: http://localhost:{port}/chat")
    app.run(host='0.0.0.0', port=port, debug=False)
