
"""
ENGAGEMENT FEATURES - Add this to agent_hub_app_complete.py
"""

import streamlit as st
from datetime import datetime
import json

# ============================================================================
# ONBOARDING SYSTEM
# ============================================================================

def show_onboarding():
    """Interactive onboarding wizard for first-time users"""
    
    if 'onboarding_complete' not in st.session_state:
        st.session_state.onboarding_complete = False
    
    if 'onboarding_step' not in st.session_state:
        st.session_state.onboarding_step = 0
    
    if st.session_state.onboarding_complete:
        return
    
    # Onboarding modal
    with st.container():
        st.markdown("""
        <div style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                    padding: 2rem; border-radius: 15px; margin-bottom: 2rem;'>
            <h2 style='color: white; margin: 0;'>👋 Welcome to AI Agent Management Hub!</h2>
            <p style='color: rgba(255,255,255,0.9); margin-top: 0.5rem;'>
                Let's get you started in just a few steps
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        steps = [
            {
                "title": "🤖 Discover Agents",
                "description": "Add AI agents to your hub by entering their backend URL",
                "action": "Try adding an agent now!",
                "demo": "http://localhost:8100"
            },
            {
                "title": "💬 Create Dialogues",
                "description": "Set up multi-agent conversations with custom topics",
                "action": "Explore dialogue templates",
                "demo": None
            },
            {
                "title": "📊 Monitor Performance",
                "description": "Track agent health, response times, and analytics",
                "action": "View your dashboard",
                "demo": None
            },
            {
                "title": "🎯 Quick Actions",
                "description": "Use the action bar for common tasks",
                "action": "Check out quick actions above",
                "demo": None
            },
            {
                "title": "🚀 You're Ready!",
                "description": "Start managing your AI agents like a pro",
                "action": "Complete onboarding",
                "demo": None
            }
        ]
        
        current_step = st.session_state.onboarding_step
        
        # Progress bar
        progress = (current_step + 1) / len(steps)
        st.progress(progress)
        st.markdown(f"**Step {current_step + 1} of {len(steps)}**")
        
        # Current step content
        step = steps[current_step]
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown(f"### {step['title']}")
            st.write(step['description'])
            
            if step['demo']:
                st.code(step['demo'], language="text")
        
        with col2:
            st.markdown("### 💡 Tip")
            st.info(step['action'])
        
        # Navigation buttons
        col_prev, col_skip, col_next = st.columns([1, 1, 1])
        
        with col_prev:
            if current_step > 0:
                if st.button("⬅️ Previous", use_container_width=True):
                    st.session_state.onboarding_step -= 1
                    st.rerun()
        
        with col_skip:
            if st.button("⏭️ Skip Tutorial", use_container_width=True):
                st.session_state.onboarding_complete = True
                st.toast("✅ Onboarding skipped! You can restart from Settings.", icon="✅")
                st.rerun()
        
        with col_next:
            if current_step < len(steps) - 1:
                if st.button("Next ➡️", use_container_width=True, type="primary"):
                    st.session_state.onboarding_step += 1
                    st.rerun()
            else:
                if st.button("🎉 Get Started!", use_container_width=True, type="primary"):
                    st.session_state.onboarding_complete = True
                    st.balloons()
                    st.toast("🎉 Welcome aboard! You've completed the onboarding!", icon="🎉")
                    st.rerun()


# ============================================================================
# QUICK ACTIONS BAR
# ============================================================================

def show_quick_actions():
    """Quick action buttons for common tasks"""
    
    st.markdown("""
    <div style='background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); 
                padding: 1rem; border-radius: 10px; margin-bottom: 1rem;'>
        <h3 style='color: white; margin: 0; font-size: 1.2rem;'>⚡ Quick Actions</h3>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        if st.button("🔍 Test All Agents", use_container_width=True, help="Check health of all agents"):
            with st.spinner("Testing agents..."):
                # Simulate testing
                import time
                time.sleep(1)
                st.toast("✅ All agents tested successfully!", icon="✅")
    
    with col2:
        if st.button("💬 Sample Dialogue", use_container_width=True, help="Run a demo conversation"):
            st.toast("🚀 Starting sample dialogue...", icon="🚀")
            st.session_state.page = "Multi-Agent Dialogue"
            st.rerun()
    
    with col3:
        if st.button("📊 Generate Report", use_container_width=True, help="Create analytics report"):
            with st.spinner("Generating report..."):
                import time
                time.sleep(1)
                st.toast("📊 Report generated! Check Analytics tab.", icon="📊")
    
    with col4:
        if st.button("📥 Export Data", use_container_width=True, help="Download all data"):
            st.toast("📥 Preparing export...", icon="📥")
            # Trigger export
    
    with col5:
        if st.button("🔄 Refresh All", use_container_width=True, help="Reload all data"):
            st.toast("🔄 Refreshing...", icon="🔄")
            st.rerun()


# ============================================================================
# ACHIEVEMENT SYSTEM
# ============================================================================

def init_achievements_db():
    """Initialize achievements database"""
    import sqlite3
    conn = sqlite3.connect("agent_hub.db")
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS achievements (
            id TEXT PRIMARY KEY,
            name TEXT,
            description TEXT,
            icon TEXT,
            unlocked INTEGER DEFAULT 0,
            unlocked_at TEXT,
            progress INTEGER DEFAULT 0,
            target INTEGER DEFAULT 1
        )
    """)
    
    # Default achievements
    achievements = [
        ("first_agent", "Agent Whisperer", "Added your first agent", "🎉", 1),
        ("five_agents", "Agent Collector", "Manage 5+ agents", "🌟", 5),
        ("first_dialogue", "Conversation Starter", "Ran first dialogue", "💬", 1),
        ("ten_dialogues", "Chatty", "Completed 10 dialogues", "🗣️", 10),
        ("power_user", "Power User", "100+ dialogues", "⚡", 100),
        ("speed_demon", "Speed Demon", "Sub-100ms response time", "🚀", 1),
        ("marathon", "Marathon Runner", "24hr uptime streak", "🏃", 1),
        ("explorer", "Explorer", "Used all features", "🔍", 5),
    ]
    
    for ach_id, name, desc, icon, target in achievements:
        cursor.execute("""
            INSERT OR IGNORE INTO achievements (id, name, description, icon, target)
            VALUES (?, ?, ?, ?, ?)
        """, (ach_id, name, desc, icon, target))
    
    conn.commit()
    conn.close()


def check_achievement(achievement_id: str, progress: int = 1):
    """Check and unlock achievement"""
    import sqlite3
    conn = sqlite3.connect("agent_hub.db")
    cursor = conn.cursor()
    
    # Get achievement
    cursor.execute("SELECT * FROM achievements WHERE id = ?", (achievement_id,))
    ach = cursor.fetchone()
    
    if not ach:
        conn.close()
        return
    
    current_progress = ach[6]
    target = ach[7]
    unlocked = ach[3]
    
    if not unlocked:
        new_progress = current_progress + progress
        
        if new_progress >= target:
            # Unlock achievement!
            cursor.execute("""
                UPDATE achievements 
                SET unlocked = 1, unlocked_at = ?, progress = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), target, achievement_id))
            
            conn.commit()
            conn.close()
            
            # Show celebration
            st.balloons()
            st.toast(f"🎉 Achievement Unlocked: {ach[1]}!", icon="🎉")
            return True
        else:
            # Update progress
            cursor.execute("""
                UPDATE achievements SET progress = ? WHERE id = ?
            """, (new_progress, achievement_id))
            conn.commit()
    
    conn.close()
    return False


def show_achievements():
    """Display achievements panel"""
    import sqlite3
    
    st.markdown("### 🏆 Achievements")
    
    conn = sqlite3.connect("agent_hub.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM achievements ORDER BY unlocked DESC, id")
    achievements = cursor.fetchall()
    conn.close()
    
    unlocked_count = sum(1 for a in achievements if a[3])
    total_count = len(achievements)
    
    st.progress(unlocked_count / total_count)
    st.markdown(f"**{unlocked_count}/{total_count} Unlocked**")
    
    for ach in achievements:
        ach_id, name, desc, icon, unlocked, unlocked_at, progress, target = ach
        
        with st.container():
            col1, col2 = st.columns([1, 4])
            
            with col1:
                if unlocked:
                    st.markdown(f"<div style='font-size: 3rem;'>{icon}</div>", unsafe_allow_html=True)
                else:
                    st.markdown(f"<div style='font-size: 3rem; opacity: 0.3;'>{icon}</div>", unsafe_allow_html=True)
            
            with col2:
                if unlocked:
                    st.markdown(f"**{name}** ✅")
                    st.caption(f"{desc} • Unlocked {unlocked_at[:10]}")
                else:
                    st.markdown(f"**{name}** 🔒")
                    st.caption(desc)
                    if target > 1:
                        st.progress(progress / target)
                        st.caption(f"Progress: {progress}/{target}")
            
            st.markdown("---")


# ============================================================================
# NOTIFICATION SYSTEM
# ============================================================================

def show_notification(message: str, type: str = "info"):
    """Show toast notification"""
    icons = {
        "success": "✅",
        "error": "❌",
        "warning": "⚠️",
        "info": "ℹ️"
    }
    st.toast(message, icon=icons.get(type, "ℹ️"))


# ============================================================================
# DARK MODE TOGGLE
# ============================================================================

def show_theme_toggle():
    """Theme switcher"""
    
    if 'dark_mode' not in st.session_state:
        st.session_state.dark_mode = False
    
    with st.sidebar:
        st.markdown("---")
        dark_mode = st.toggle("🌙 Dark Mode", value=st.session_state.dark_mode)
        
        if dark_mode != st.session_state.dark_mode:
            st.session_state.dark_mode = dark_mode
            st.rerun()
        
        if st.session_state.dark_mode:
            st.markdown("""
            <style>
                .stApp {
                    background-color: #1e1e1e;
                    color: #ffffff;
                }
                .agent-card {
                    background: #2d2d2d !important;
                    border-color: #444 !important;
                }
            </style>
            """, unsafe_allow_html=True)


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================

"""
TO INTEGRATE INTO agent_hub_app_complete.py:

1. Add at the top of main():
   
   init_achievements_db()
   show_theme_toggle()

2. Add after page title:
   
   if not st.session_state.get('onboarding_complete', False):
       show_onboarding()
   else:
       show_quick_actions()

3. Add to sidebar:
   
   with st.sidebar:
       if st.button("🏆 View Achievements"):
           show_achievements()

4. Track achievements:
   
   # When agent is added:
   check_achievement("first_agent")
   
   # When dialogue completes:
   check_achievement("first_dialogue")
   
   # When testing agents:
   if response_time < 100:
       check_achievement("speed_demon")

5. Use notifications:
   
   show_notification("Agent added successfully!", "success")
   show_notification("Connection failed", "error")
"""
