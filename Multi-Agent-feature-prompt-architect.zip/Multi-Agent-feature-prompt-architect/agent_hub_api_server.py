
#!/usr/bin/env python3
"""
Agent Management Hub - API Server
Receives token usage reports and other data from agents
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import sqlite3
from datetime import datetime
import uvicorn
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Agent Hub API",
    description="API for receiving agent metrics and reports",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Database path
DB_PATH = "~/multi-agent-hub/agent_hub.db"

# Pricing configuration
TOKEN_PRICING = {
    'gpt-4': {'input': 0.03, 'output': 0.06},
    'gpt-4-turbo': {'input': 0.01, 'output': 0.03},
    'gpt-3.5-turbo': {'input': 0.0015, 'output': 0.002},
    'claude-3-opus': {'input': 0.015, 'output': 0.075},
    'claude-3-sonnet': {'input': 0.003, 'output': 0.015},
    'claude-3-haiku': {'input': 0.00025, 'output': 0.00125},
    'claude-3.5-sonnet': {'input': 0.003, 'output': 0.015},
}

# Pydantic models
class TokenUsageReport(BaseModel):
    agent_id: str
    prompt_tokens: int
    completion_tokens: int
    model: str = "gpt-4"
    task: str = "chat"
    chat_id: Optional[str] = None
    user_email: Optional[str] = None
    metadata: Optional[dict] = None

class SafetyEvent(BaseModel):
    agent_id: str
    event_type: str
    severity: str  # low, medium, high, critical
    description: str
    prevented: bool = True

class ProtocolSnapshot(BaseModel):
    agent_id: str
    version: str
    protocol_content: str
    changes_summary: Optional[str] = None

# Helper functions
def get_db_connection():
    """Get database connection"""
    import os
    db_path = os.path.expanduser(DB_PATH)
    return sqlite3.connect(db_path)

def calculate_cost(prompt_tokens: int, completion_tokens: int, model: str) -> float:
    """Calculate cost based on token usage"""
    # Normalize model name
    model_lower = model.lower()
    
    # Find matching pricing
    pricing = None
    for key in TOKEN_PRICING:
        if key in model_lower:
            pricing = TOKEN_PRICING[key]
            break
    
    if not pricing:
        pricing = TOKEN_PRICING['gpt-4']  # Default
    
    cost = (prompt_tokens / 1000 * pricing['input']) + \
           (completion_tokens / 1000 * pricing['output'])
    
    return round(cost, 6)

# API Endpoints

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Agent Hub API",
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        conn.close()
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail=f"Service unhealthy: {str(e)}")

@app.post("/api/token_usage")
async def report_token_usage(report: TokenUsageReport):
    """
    Receive token usage report from an agent
    
    Example:
    ```
    {
        "agent_id": "abc123def456",
        "prompt_tokens": 150,
        "completion_tokens": 200,
        "model": "gpt-4",
        "task": "chat",
        "metadata": {"user_id": "123"}
    }
    ```
    """
    try:
        # Calculate cost
        cost = calculate_cost(
            report.prompt_tokens,
            report.completion_tokens,
            report.model
        )
        
        total_tokens = report.prompt_tokens + report.completion_tokens
        
        # Generate conversation ID
        conv_id = f"conv_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{report.agent_id[:6]}"
        
        # Store in database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO conversations 
            (id, agent_id, timestamp, tokens_used, prompt_tokens, completion_tokens, cost, conversation_data)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            conv_id,
            report.agent_id,
            datetime.now().isoformat(),
            total_tokens,
            report.prompt_tokens,
            report.completion_tokens,
            cost,
            str(report.metadata or {})
        ))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Token usage logged: {conv_id} - {total_tokens} tokens, ${cost}")
        
        return {
            "status": "success",
            "conversation_id": conv_id,
            "tokens_logged": total_tokens,
            "cost": cost,
            "model": report.model
        }
        
    except Exception as e:
        logger.error(f"Error logging token usage: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to log usage: {str(e)}")

@app.post("/api/safety_event")
async def report_safety_event(event: SafetyEvent):
    """
    Report a safety event (e.g., attempted self-modification)
    
    Example:
    ```
    {
        "agent_id": "abc123def456",
        "event_type": "self_modification_attempt",
        "severity": "high",
        "description": "Agent attempted to modify config.py",
        "prevented": true
    }
    ```
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO safety_events 
            (agent_id, timestamp, event_type, severity, description, prevented)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            event.agent_id,
            datetime.now().isoformat(),
            event.event_type,
            event.severity,
            event.description,
            event.prevented
        ))
        
        conn.commit()
        conn.close()
        
        logger.warning(f"Safety event: {event.agent_id} - {event.event_type} ({event.severity})")
        
        return {
            "status": "success",
            "event_logged": True,
            "severity": event.severity
        }
        
    except Exception as e:
        logger.error(f"Error logging safety event: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to log event: {str(e)}")

@app.post("/api/protocol_snapshot")
async def report_protocol_snapshot(snapshot: ProtocolSnapshot):
    """
    Report a protocol/prompt snapshot for evolution tracking
    
    Example:
    ```
    {
        "agent_id": "abc123def456",
        "version": "1.2.3",
        "protocol_content": "System: You are a helpful assistant...",
        "changes_summary": "Improved error handling"
    }
    ```
    """
    try:
        import hashlib
        
        # Calculate hash
        protocol_hash = hashlib.sha256(snapshot.protocol_content.encode()).hexdigest()[:16]
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if this exact version exists
        cursor.execute("""
            SELECT id FROM protocol_versions 
            WHERE agent_id = ? AND protocol_hash = ?
        """, (snapshot.agent_id, protocol_hash))
        
        if cursor.fetchone():
            conn.close()
            return {
                "status": "unchanged",
                "message": "Protocol unchanged - no new version created"
            }
        
        # Insert new version
        cursor.execute("""
            INSERT INTO protocol_versions 
            (agent_id, timestamp, version, protocol_hash, protocol_content, changes_summary)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            snapshot.agent_id,
            datetime.now().isoformat(),
            snapshot.version,
            protocol_hash,
            snapshot.protocol_content,
            snapshot.changes_summary or "Version snapshot"
        ))
        
        version_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        logger.info(f"Protocol snapshot: {snapshot.agent_id} v{snapshot.version}")
        
        return {
            "status": "success",
            "version_id": version_id,
            "version": snapshot.version,
            "protocol_hash": protocol_hash
        }
        
    except Exception as e:
        logger.error(f"Error logging protocol snapshot: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to log snapshot: {str(e)}")

@app.get("/api/stats")
async def get_stats():
    """Get overall statistics"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get token stats
        cursor.execute("""
            SELECT 
                COUNT(*) as total_conversations,
                SUM(tokens_used) as total_tokens,
                SUM(cost) as total_cost
            FROM conversations
        """)
        conv_stats = cursor.fetchone()
        
        # Get agent count
        cursor.execute("SELECT COUNT(*) FROM agents")
        agent_count = cursor.fetchone()[0]
        
        # Get safety events
        cursor.execute("SELECT COUNT(*) FROM safety_events WHERE prevented = 1")
        safety_events = cursor.fetchone()[0]
        
        conn.close()
        
        return {
            "agents": agent_count,
            "conversations": conv_stats[0] or 0,
            "total_tokens": conv_stats[1] or 0,
            "total_cost": round(conv_stats[2] or 0, 2),
            "safety_events_prevented": safety_events,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting stats: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to get stats: {str(e)}")

# Main
if __name__ == "__main__":
    import os
    
    # Expand path
    db_path_expanded = os.path.expanduser(DB_PATH)
    logger.info(f"Using database: {db_path_expanded}")
    
    # Run server
    logger.info("Starting Agent Hub API server on http://0.0.0.0:8502")
    logger.info("API docs available at http://localhost:8502/docs")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8502,
        log_level="info"
    )
