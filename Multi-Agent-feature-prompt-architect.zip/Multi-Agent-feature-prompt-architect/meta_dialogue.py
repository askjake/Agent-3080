"""
Meta-Dialogue Module

Implements "dialogue about your dialogue patterns" feature from agents' discussion.

Agent 3090-1's proposal: "What if users could have a Socratic conversation 
with an agent about their engagement data? Instead of just showing a 
visualization, the system could ask 'I notice your dialogue frequency 
increased after enabling streaks, but your depth scores decreased slightly. 
What do you make of that pattern?'"

This extends collaborative discovery all the way down.
"""

from typing import Dict, List
import random


def generate_reflection_questions(user_stats: Dict, feature_enabled: str = None) -> List[str]:
    """
    Generate Socratic questions about user's dialogue patterns
    
    Following Agent 3080 & 3090-1's framework: help users discover 
    insights rather than prescribing them
    """
    questions = []
    
    # Pattern: Frequency changes
    if 'dialogue_count' in user_stats:
        count = user_stats['dialogue_count']
        if count > 10:
            questions.append(
                f"I notice you've completed {count} dialogues. "
                f"What draws you back to multi-agent conversations?"
            )
        elif count < 5:
            questions.append(
                "You're just getting started with multi-agent dialogues. "
                "What would make you want to explore more topics?"
            )
    
    # Pattern: Quality trends
    if 'avg_rating' in user_stats:
        rating = user_stats['avg_rating']
        if rating >= 4.0:
            questions.append(
                f"Your dialogues average {rating:.1f}/5 stars. "
                f"What patterns do you notice in your highest-rated conversations?"
            )
        elif rating < 3.0:
            questions.append(
                f"Your recent ratings average {rating:.1f}/5. "
                f"What would make these dialogues more valuable for you?"
            )
    
    # Pattern: Feature impact
    if feature_enabled:
        questions.append(
            f"You've been using {feature_enabled} for a while. "
            f"Has it affected how you approach dialogues? If so, how?"
        )
        
        questions.append(
            f"Imagine disabling {feature_enabled} tomorrow. "
            f"Would that change your dialogue experience? What would you miss, if anything?"
        )
    
    # Pattern: Depth vs frequency trade-off
    if 'depth_trend' in user_stats:
        trend = user_stats['depth_trend']
        if trend == 'increasing':
            questions.append(
                "Your dialogue depth has been increasing over time. "
                "What's contributing to that growth?"
            )
        elif trend == 'decreasing':
            questions.append(
                "I notice your dialogue depth scores have decreased recently, "
                "even as frequency increased. What do you make of that trade-off?"
            )
    
    # Pattern: Voluntary vs prompted engagement
    if 'initiation_rate' in user_stats:
        rate = user_stats['initiation_rate']
        if rate > 0.8:
            questions.append(
                f"{int(rate*100)}% of your dialogues are self-initiated (not prompted by notifications). "
                f"That suggests strong intrinsic motivation. What drives you to start conversations?"
            )
        elif rate < 0.4:
            questions.append(
                f"Most of your dialogues start after notifications. "
                f"Is that helpful structure, or would you prefer to drive your own timing?"
            )
    
    # Ethical reflection questions
    questions.extend([
        "If all the gamification features (streaks, badges, etc.) disappeared tomorrow, "
        "would you still find value in multi-agent dialogues? What would change?",
        
        "Think about your most valuable dialogue so far. "
        "What made it valuable—the topic, the agent interaction, or something else?",
        
        "Are you using these dialogues to explore questions you already care about, "
        "or discovering new areas of curiosity? Which feels more valuable to you?"
    ])
    
    # Return random selection of 3-4 questions
    return random.sample(questions, min(4, len(questions)))


def generate_comparative_insight(before_stats: Dict, after_stats: Dict, feature: str) -> str:
    """
    Generate natural language comparison of before/after feature adoption
    
    Agent 3080's proposal: Show evidence, let users draw conclusions
    """
    insights = []
    
    # Frequency comparison
    if 'dialogue_count' in before_stats and 'dialogue_count' in after_stats:
        before_count = before_stats['dialogue_count']
        after_count = after_stats['dialogue_count']
        
        if after_count > before_count * 1.2:
            insights.append(
                f"With {feature} enabled, you're having {after_count} dialogues "
                f"compared to {before_count} before—about {int((after_count/before_count - 1)*100)}% more frequent."
            )
        elif after_count < before_count * 0.8:
            insights.append(
                f"With {feature} enabled, dialogue frequency decreased from {before_count} to {after_count}. "
                f"That might mean you're being more selective about when to engage."
            )
    
    # Quality comparison
    if 'avg_rating' in before_stats and 'avg_rating' in after_stats:
        before_rating = before_stats['avg_rating']
        after_rating = after_stats['avg_rating']
        
        if after_rating > before_rating + 0.5:
            insights.append(
                f"Your satisfaction increased from {before_rating:.1f} to {after_rating:.1f} stars. "
                f"The feature seems aligned with your goals."
            )
        elif after_rating < before_rating - 0.5:
            insights.append(
                f"Your satisfaction decreased from {before_rating:.1f} to {after_rating:.1f} stars. "
                f"The feature might not be serving you well."
            )
    
    # Synthesize insight
    if not insights:
        return f"The data on {feature} impact is still inconclusive. Continue the experiment to see clearer patterns."
    
    return " ".join(insights) + "\n\nWhat's your interpretation? Does this match your subjective experience?"


def generate_autonomy_reflection(user_metrics: Dict) -> str:
    """
    Generate reflection on user's autonomy vs dependence
    
    Agent 3090-1's metric: Healthy engagement shows increasing autonomy over time
    """
    reflections = []
    
    if 'voluntary_initiation_rate' in user_metrics:
        rate = user_metrics['voluntary_initiation_rate']
        
        if rate > 0.7:
            reflections.append(
                "**High Autonomy Detected**\n"
                f"You initiate {int(rate*100)}% of dialogues independently, without prompts. "
                "This suggests you're using the system as a tool for your own goals, not responding to nudges."
            )
        elif rate < 0.3:
            reflections.append(
                "**Prompt-Dependent Pattern**\n"
                f"Only {int(rate*100)}% of your dialogues are self-initiated. "
                "Consider: Are notifications helping you maintain a helpful habit, "
                "or have you become reliant on external triggers?"
            )
    
    if 'feature_disengagement_tolerance' in user_metrics:
        tolerance = user_metrics['feature_disengagement_tolerance']
        
        if tolerance < 0.3:
            reflections.append(
                "**Low Disengagement Tolerance**\n"
                "When features are disabled, your usage drops significantly. "
                "This might indicate extrinsic motivation—engagement driven by the gamification "
                "rather than intrinsic interest in dialogue quality."
            )
        elif tolerance > 0.7:
            reflections.append(
                "**High Disengagement Tolerance**\n"
                "Your usage remains stable even when features are disabled. "
                "This suggests strong intrinsic motivation—you value the core dialogue experience "
                "independent of gamification."
            )
    
    if reflections:
        return "\n\n".join(reflections)
    else:
        return "Not enough data yet to assess autonomy patterns. Keep using the system to see how features affect your independence."


def create_experiment_prompt(feature_id: str, feature_name: str) -> str:
    """
    Generate user-friendly experiment setup prompt
    
    Agent 3080's principle: Users should be "active investigators of their own cognitive patterns"
    """
    return f"""
### 🔬 Self-Experiment: {feature_name}

Would you like to try this feature for a defined period and then evaluate its impact?

**How it works:**
1. Enable {feature_name} for 14 or 30 days
2. Use the system naturally
3. After the period, we'll show you:
   - Dialogue frequency (before vs during)
   - Average satisfaction rating (before vs during)
   - Depth progression (before vs during)
   - Your own notes on subjective experience

4. You decide: Keep it, disable it, or adjust settings

**This is your experiment, not ours.** We're providing the mirror; you're doing the interpreting.

Choose experiment duration:
- [ ] 14 days (good for quick tests)
- [ ] 30 days (better for habit formation assessment)
- [ ] No thanks, I'll just enable/disable as I go
"""
