#!/usr/bin/env python3
"""
Multi-Agent Hub v2.0 - Verification Script
Tests all enhancements and fixes
"""

import requests
import time
import sys

def test_app_running():
    """Test if the app is running"""
    print("\n🔍 TEST 1: Checking if app is running...")
    try:
        response = requests.get("http://localhost:8501", timeout=5)
        if response.status_code == 200:
            print("   ✅ PASS: App is running on port 8501")
            return True
        else:
            print(f"   ⚠️  WARNING: App returned status {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("   ❌ FAIL: Cannot connect to port 8501")
        print("   💡 Start the app with: cd ~/multi-agent-hub && ./start_enhanced.sh")
        return False
    except Exception as e:
        print(f"   ❌ ERROR: {str(e)}")
        return False

def test_database():
    """Test database connectivity"""
    print("\n🔍 TEST 2: Checking database...")
    try:
        import sqlite3
        conn = sqlite3.connect('/home/montjac/multi-agent-hub/agent_hub.db')
        cursor = conn.cursor()
        
        # Check tables exist
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        required_tables = ['agents', 'conversations', 'dialogues', 'safety_events', 'protocol_versions']
        missing = [t for t in required_tables if t not in tables]
        
        if missing:
            print(f"   ⚠️  WARNING: Missing tables: {missing}")
        else:
            print("   ✅ PASS: All required tables exist")
        
        # Check agents
        cursor.execute("SELECT COUNT(*) FROM agents")
        agent_count = cursor.fetchone()[0]
        print(f"   📊 Agents in database: {agent_count}")
        
        conn.close()
        return True
    except Exception as e:
        print(f"   ❌ ERROR: {str(e)}")
        return False

def test_file_structure():
    """Test file structure"""
    print("\n🔍 TEST 3: Checking file structure...")
    import os
    
    required_files = [
        'agent_hub_app_complete.py',
        'agent_hub_app_enhanced.py',
        'agent_hub.db',
        'README.md',
        'README_ENHANCED.md',
        'DEPLOYMENT_SUMMARY_v2.0.txt',
        'start_enhanced.sh'
    ]
    
    base_path = '/home/montjac/multi-agent-hub'
    
    all_good = True
    for file in required_files:
        file_path = os.path.join(base_path, file)
        if os.path.exists(file_path):
            size = os.path.getsize(file_path)
            print(f"   ✅ {file} ({size:,} bytes)")
        else:
            print(f"   ❌ MISSING: {file}")
            all_good = False
    
    return all_good

def test_enhancements():
    """Test that enhancements are present in the code"""
    print("\n🔍 TEST 4: Verifying enhancements in code...")
    
    with open('/home/montjac/multi-agent-hub/agent_hub_app_complete.py', 'r') as f:
        content = f.read()
    
    tests = [
        ("Health check fix", "200 <= response.status_code < 300"),
        ("Multiple endpoints", "health_endpoints = ['/health', '/api/health', '/status']"),
        ("Info chips", "info-chip"),
        ("Enhanced dialogue", "Topic Templates"),
        ("Frontend URL validation", "frontend_url"),
    ]
    
    all_pass = True
    for test_name, search_str in tests:
        if search_str in content:
            print(f"   ✅ {test_name}: Found")
        else:
            print(f"   ❌ {test_name}: NOT FOUND")
            all_pass = False
    
    return all_pass

def main():
    print("="*70)
    print("   MULTI-AGENT HUB v2.0 - VERIFICATION SUITE")
    print("="*70)
    
    results = []
    
    results.append(("App Running", test_app_running()))
    results.append(("Database", test_database()))
    results.append(("File Structure", test_file_structure()))
    results.append(("Code Enhancements", test_enhancements()))
    
    print("\n" + "="*70)
    print("   VERIFICATION SUMMARY")
    print("="*70)
    
    for test_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"   {status}: {test_name}")
    
    all_passed = all(r[1] for r in results)
    
    print("\n" + "="*70)
    if all_passed:
        print("   🎉 ALL TESTS PASSED! Your enhanced hub is ready to use!")
        print("   🌐 Access it at: http://localhost:8501")
    else:
        print("   ⚠️  SOME TESTS FAILED - Review the output above")
        print("   💡 Check the deployment summary for troubleshooting tips")
    print("="*70)
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())
