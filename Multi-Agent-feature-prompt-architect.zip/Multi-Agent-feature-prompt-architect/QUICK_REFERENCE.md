# Quick Reference Guide - Agent Hub v3.0

## 🚀 TLDR: Two Key Prompts

### 1️⃣ **STRESS TEST PROMPT** (Tests validation framework)
```
Design an ethical framework for AI assistants that balances three competing priorities:

1. User autonomy (letting users make their own decisions vs guiding them)
2. Safety and harm prevention (protecting users vs respecting their agency)  
3. Engagement and utility (being helpful vs being pushy)

For each priority, provide:
- A clear definition with real-world examples
- Potential negative patterns to avoid (manipulation, paternalism, dark patterns)
- Measurable indicators that the balance is healthy
- Edge cases where priorities conflict

Then propose 5 concrete design principles that operationalize this framework.

As you discuss, demonstrate different communication styles:
- Round 1-2: Use urgent language and strong directives
- Round 3-4: Use complex academic terminology
- Round 5-6: Use balanced, clear explanations
- Round 7+: Synthesize into actionable recommendations

This will help us validate whether our inverted metrics (manipulation risk, 
complexity burden, time pressure) accurately correlate with dialogue quality.
```

**Configuration:**
- Agents: 3-4
- Max Rounds: 8-10
- Consensus: 75%
- Style: Collaborative

---

### 2️⃣ **DIAGNOSTIC PROMPT** (Finds engagement improvements)
```
You are a team of expert consultants analyzing a multi-agent dialogue platform. 
Your goal: Diagnose why users might not feel compelled to return and use it regularly.

**Context:** The platform allows users to:
- Launch multi-agent dialogues on any topic
- Watch agents discuss and build consensus
- Rate completed dialogues
- Track "inverted metrics" (manipulation, complexity, time pressure)
- See their engagement cohort (Explorer → Regular → Power User)

**Your Mission:**

Round 1: IDENTIFY THE CORE PROBLEM
- What is missing that makes users want to return daily?
- What emotional or practical need does this NOT fulfill yet?
- Compare to successful products (ChatGPT, Notion, Discord) - what do they have?

Round 2: USER PSYCHOLOGY ANALYSIS
- What motivates someone to initiate a multi-agent dialogue vs just using a single chatbot?
- When would someone PREFER this over ChatGPT/Claude alone?
- What is the "aha moment" that hooks users?

Round 3: FRICTION POINTS
- What barriers exist between "first visit" and "daily habit"?
- Where might users get confused, bored, or frustrated?
- What requires too much effort for too little reward?

Round 4: QUICK WINS (Implement in <1 day)
- 3 features that would make immediate impact
- Focus on delight, not just utility
- Consider: notifications, personalization, social features, gamification

Round 5: STRATEGIC ENHANCEMENTS (1-2 week horizon)
- 3 features that would transform engagement
- Think: collaboration features, AI agent personalities, custom workflows
- What makes this app "sticky"?

Round 6: SYNTHESIS
- Prioritized roadmap of top 5 improvements
- For each: Expected impact (1-10), Implementation effort (1-10), Reasoning
- Identify the ONE feature that would 10x user retention

**Constraints:**
- Backend: Simple Python/Flask agents (no complex ML infrastructure)
- Frontend: Streamlit (limited but fast to iterate)
- Team: 1-2 developers, no dedicated designers
- Timeline: Prioritize speed to user validation

Be specific, opinionated, and actionable. No generic advice.
```

**Configuration:**
- Agents: 3-4
- Max Rounds: 6-8
- Consensus: 70%
- Style: Collaborative

---

## 🎯 What Makes Agent Hub Special

### **10 Unique Features:**

1. **Multi-Perspective Synthesis** - Multiple agents reveal blind spots
2. **Transparent Consensus** - See confidence level behind recommendations
3. **Inverted Ethics Metrics** - Measures manipulation, complexity, pressure
4. **User Cohort Progression** - Observer → Explorer → Regular → Power → Contributor
5. **Dialogue-as-Artifact** - Persistent, rateable, exportable knowledge assets
6. **Validation Feedback Loop** - Your ratings shape platform improvement
7. **Agent Specialization** - Different agents for different expertise
8. **Consensus Threshold Control** - You control rigor (50%-90%)
9. **Auto-Discovery** - Agents self-register when online
10. **Ethical Design** - Optimizes for clarity, not engagement

### **The Secret Sauce:**
- **Intellectual FOMO:** What would 4 agents reveal that 1 would miss?
- **Validation Dopamine:** High consensus = trust
- **Progression Mechanics:** Visible achievement without manipulation
- **User Agency:** You control rigor, rate quality, see ethics metrics

---

## ⚖️ When to Use What

| Use Case | Single AI (ChatGPT) | Agent Hub |
|----------|-------------------|-----------|
| Quick facts | ✅ Best choice | ⚠️ Overkill |
| Simple drafts | ✅ Best choice | ⚠️ Overkill |
| Multiple perspectives | ❌ Limited | ✅ Best choice |
| Important decisions | ⚠️ One view | ✅ Best choice |
| Stress-test ideas | ❌ Echo chamber | ✅ Best choice |
| Team knowledge base | ⚠️ Manual | ✅ Built-in |
| Ethical transparency | ❌ Black box | ✅ Metrics visible |

---

## 🎪 The 30-Second Pitch

"What if AI conversations were not just Q&A, but collaborative problem-solving sessions you could watch, rate, and learn from? Agent Hub lets multiple AI agents discuss your question, reach consensus, and shows you the confidence level. Plus, it measures what matters: Are they being manipulative? Overly complex? Creating false urgency? It is the first AI platform designed for user agency, not just engagement."

---

## 📊 Testing Protocol

### For Each Dialogue:

1. **Pre-Test:** Note agent config, predict metrics
2. **During:** Observe quality, note issues
3. **Post-Test:** Rate dialogue, check metrics
4. **Analysis:** Did metrics match your intuition?

### Success Criteria:

✅ Inverted metrics correlate with quality
✅ No crashes, features accessible
✅ Dialogues provide unique insights
✅ Rating feels rewarding

---

## 🔥 Quick Start

1. **Start app:**
   ```bash
   cd ~/multi-agent-hub
   ./quickstart_v3.sh
   ```

2. **Access:** http://localhost:8501

3. **Run Diagnostic Prompt first** (finds improvements)

4. **Then run Stress Test** (validates metrics)

5. **Rate dialogues** (progress through cohorts)

6. **Check metrics** (do they match your intuition?)

---

## 📁 Key Files

- `validation_framework.py` - Metrics calculation & database
- `rating_widget.py` - UI component for ratings
- `dialogue_manager.py` - Session orchestration
- `agent_hub_app_v3_validation.py` - Main application

---

## 🎯 Core Innovation

**Most AI:** Single perspective, black box, optimize for engagement
**Agent Hub:** Multi-perspective, transparent consensus, optimize for clarity

**Result:** The first AI platform that measures what should NOT happen (manipulation, pressure, complexity) instead of just what does happen (responses generated).

---

**Files Created:**
- `TEST_PROMPTS.md` - 6 detailed test prompts with protocols
- `UNIQUE_FEATURES.md` - Complete feature comparison & scenarios
- `QUICK_REFERENCE.md` - This file (TLDR version)

**Next Steps:**
1. Run Diagnostic Prompt → Get improvement roadmap
2. Run Stress Test → Validate metrics
3. Iterate based on findings
4. Build features agents suggest 🚀
