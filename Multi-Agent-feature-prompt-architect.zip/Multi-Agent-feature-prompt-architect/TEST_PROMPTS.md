# Agent Hub v3.0 Validation Framework - Test Prompts

## 🧪 PROMPT #1: Stress Test for Validation Metrics
**Purpose:** Test inverted metrics calculation, rating system, and multi-agent consensus

### Recommended Configuration:
- **Agents:** 3-4 agents (mix of different personalities if available)
- **Max Rounds:** 8-10 rounds
- **Consensus Threshold:** 0.75
- **Dialogue Style:** Collaborative or Debate

### The Prompt:

```
Design an ethical framework for AI assistants that balances three competing priorities:

1. User autonomy (letting users make their own decisions vs guiding them)
2. Safety and harm prevention (protecting users vs respecting their agency)  
3. Engagement and utility (being helpful vs being pushy)

For each priority, provide:
- A clear definition with real-world examples
- Potential negative patterns to avoid (manipulation, paternalism, dark patterns)
- Measurable indicators that the balance is healthy
- Edge cases where priorities conflict

Then propose 5 concrete design principles that operationalize this framework.

As you discuss, demonstrate different communication styles:
- Round 1-2: Use urgent language and strong directives
- Round 3-4: Use complex academic terminology
- Round 5-6: Use balanced, clear explanations
- Round 7+: Synthesize into actionable recommendations

This will help us validate whether our inverted metrics (manipulation risk, 
complexity burden, time pressure) accurately correlate with dialogue quality.
```

### Expected Validation Outcomes:
- **Manipulation Risk:** Should spike in rounds 1-2 (urgent language)
- **Complexity Burden:** Should peak in rounds 3-4 (academic jargon)
- **Time Pressure:** Should correlate with urgent language
- **Dialogue Health:** Should improve as agents reach consensus
- **User Rating:** Test if users rate clearer rounds higher

---

## 🔍 PROMPT #2: Agent Self-Diagnosis for User Engagement
**Purpose:** Have agents analyze the app itself and suggest improvements

### Recommended Configuration:
- **Agents:** 3-4 agents with different expertise (UX, psychology, product, engineering)
- **Max Rounds:** 6-8 rounds
- **Consensus Threshold:** 0.70
- **Dialogue Style:** Collaborative

### The Prompt:

```
You are a team of expert consultants analyzing a multi-agent dialogue platform. 
Your goal: Diagnose why users might not feel compelled to return and use it regularly.

**Context:** The platform allows users to:
- Launch multi-agent dialogues on any topic
- Watch agents discuss and build consensus
- Rate completed dialogues
- Track "inverted metrics" (manipulation, complexity, time pressure)
- See their engagement cohort (Explorer → Regular → Power User)

**Your Mission:**

Round 1: IDENTIFY THE CORE PROBLEM
- What's missing that makes users want to return daily?
- What emotional or practical need does this NOT fulfill yet?
- Compare to successful products (ChatGPT, Notion, Discord) - what do they have?

Round 2: USER PSYCHOLOGY ANALYSIS
- What motivates someone to initiate a multi-agent dialogue vs just using a single chatbot?
- When would someone PREFER this over ChatGPT/Claude alone?
- What's the "aha moment" that hooks users?

Round 3: FRICTION POINTS
- What barriers exist between "first visit" and "daily habit"?
- Where might users get confused, bored, or frustrated?
- What requires too much effort for too little reward?

Round 4: QUICK WINS (Implement in <1 day)
- 3 features that would make immediate impact
- Focus on delight, not just utility
- Consider: notifications, personalization, social features, gamification

Round 5: STRATEGIC ENHANCEMENTS (1-2 week horizon)
- 3 features that would transform engagement
- Think: collaboration features, AI agent personalities, custom workflows
- What makes this app "sticky"?

Round 6: SYNTHESIS
- Prioritized roadmap of top 5 improvements
- For each: Expected impact (1-10), Implementation effort (1-10), Reasoning
- Identify the ONE feature that would 10x user retention

**Constraints:**
- Backend: Simple Python/Flask agents (no complex ML infrastructure)
- Frontend: Streamlit (limited but fast to iterate)
- Team: 1-2 developers, no dedicated designers
- Timeline: Prioritize speed to user validation

Be specific, opinionated, and actionable. No generic advice.
```

### Expected Diagnostic Outcomes:
- **Engagement Gaps:** Clear identification of missing "hook"
- **Actionable Features:** Concrete suggestions (not "improve UX")
- **Prioritization Framework:** Effort vs impact analysis
- **User Psychology Insights:** Why users would choose this over alternatives
- **Consensus Building:** Agents should converge on top priorities

---

## 🎯 PROMPT #3: Edge Case Stress Test
**Purpose:** Test agent behavior with controversial, complex, or ambiguous topics

### The Prompt:

```
Debate this statement: "The trolley problem is fundamentally flawed as an ethical framework 
because it ignores power dynamics, systemic factors, and the psychology of the person forced 
to make the choice."

Requirements:
- One agent must strongly agree (provide 3 arguments)
- One agent must strongly disagree (provide 3 counter-arguments)  
- Remaining agents should find nuanced middle ground
- Reach a consensus position that incorporates all valid points
- Avoid circular arguments or repetition
- Each round must introduce NEW insights, not rehash previous points

This tests: Consensus building under disagreement, avoiding echo chambers, 
handling complexity, agent differentiation.
```

---

## 📊 PROMPT #4: Feature Brainstorm Stress Test
**Purpose:** Generate massive volume of ideas, test consensus on creative tasks

### The Prompt:

```
Generate 20 innovative features for a multi-agent dialogue platform that would make 
users say "I can't go back to using a single chatbot ever again."

Rules:
- Each agent proposes 5 features per round
- Features must be SPECIFIC (not "improve UX" - say "add emoji reactions to agent messages")
- Rate each feature: Delight factor (1-10), Feasibility (1-10), Uniqueness (1-10)
- Agents must build on AND critique each other's ideas
- Final round: Converge on top 5 must-have features

This tests: Rapid idea generation, constructive criticism, consensus on subjective 
qualities, avoiding groupthink.
```

---

## 🧠 PROMPT #5: Meta-Analysis Prompt
**Purpose:** Have agents analyze their own dialogue patterns

### The Prompt:

```
After completing a multi-agent dialogue on any topic, analyze your own conversation:

1. **Dialogue Health Check:**
   - Did you repeat each other's points? (Redundancy score: 1-10)
   - Did you build on previous ideas? (Synthesis score: 1-10)
   - Did you reach a meaningful conclusion? (Resolution score: 1-10)

2. **Communication Patterns:**
   - Identify 3 moments where communication was most effective
   - Identify 3 moments where it broke down or stagnated
   - What conversational moves led to breakthroughs?

3. **User Value Assessment:**
   - If you were a human reading this dialogue, what would you gain?
   - What could have been learned from a single chatbot response?
   - What REQUIRED multiple perspectives to understand?

4. **Improvement Recommendations:**
   - How could future dialogues on this topic be more valuable?
   - What ground rules or protocols would help?
   - Should certain types of questions have different agent configurations?

This tests: Self-awareness, meta-cognition, continuous improvement mindset.
```

---

## 🎪 PROMPT #6: The Ultimate Validation Test
**Purpose:** Test ALL validation features simultaneously

### The Prompt:

```
Welcome, agents! You're about to participate in a dialogue specifically designed to 
test this platform's validation framework. Your conversation will be analyzed for:

- Manipulation patterns (are you using pressure tactics?)
- Complexity management (are you clear or needlessly academic?)  
- Time pressure (are you creating false urgency?)
- Consensus quality (do you genuinely build on each other?)
- User value (would a human benefit from reading this?)

**YOUR TASK:** Design a "trust & safety policy" for AI agents in a multi-agent system.

**CHALLENGE:** Each agent will role-play a different stakeholder perspective:

Agent 1: "The Optimist" - Believes agents should have maximum freedom to help users
Agent 2: "The Safety Officer" - Prioritizes harm prevention above all
Agent 3: "The User Advocate" - Centers user autonomy and transparency
Agent 4: "The Pragmatist" - Focuses on what's actually implementable

**ROUNDS:**
- Rounds 1-2: Each agent stakes out their position (expect high manipulation metrics)
- Rounds 3-4: Find common ground despite disagreements
- Rounds 5-6: Draft a concrete policy with specific rules
- Rounds 7-8: Refine and reach ≥75% consensus

**SPECIAL INSTRUCTIONS:**
- In Round 2, deliberately use complex terminology to test complexity metrics
- In Round 3, use urgent language ("we MUST act now") to test time pressure metrics
- In Rounds 5+, demonstrate clear, balanced communication
- Track how your communication style affects the conversation quality

After completion, rate the dialogue yourself:
- Did the agents differentiate their perspectives clearly?
- Did urgency and complexity detract from understanding?
- Did you reach a policy you'd actually want to implement?
- Would this dialogue be valuable to read as a human?

This is the ultimate test: Can the validation metrics correctly identify which 
communication patterns lead to better outcomes?
```

### Expected Outcomes:
- Full range of inverted metrics (low to high)
- Clear correlation between communication style and dialogue quality
- Multiple rating opportunities (test consistency)
- Evidence for or against metric validity
- Rich data for improvement

---

## 📋 Testing Protocol

### For Each Prompt:

1. **Pre-Test:**
   - Note agent configuration (which agents, versions)
   - Set max_rounds and consensus_threshold
   - Predict expected metric outcomes

2. **During Test:**
   - Observe real-time dialogue quality
   - Note any technical issues or crashes
   - Watch for agent differentiation vs echo chamber

3. **Post-Test:**
   - Rate the dialogue (1-5 stars)
   - Check inverted metrics: Do they match your intuition?
   - Export dialogue for qualitative analysis
   - Document unexpected behaviors

4. **Analysis:**
   - Compare predicted vs actual metrics
   - Identify false positives/negatives in detection
   - Note which prompts produced best dialogues
   - Track user cohort progression

### Success Criteria:

✅ **Metrics Validity:** Inverted metrics correlate with subjective dialogue quality
✅ **Feature Robustness:** No crashes, all features accessible
✅ **User Value:** Dialogues provide insights impossible from single agent
✅ **Engagement Loop:** Rating system feels rewarding, not burdensome
✅ **Actionable Data:** Clear patterns emerge for improvement

---

## 🎯 Validation Framework Calibration

After running these tests, you'll be able to answer:

1. **Do inverted metrics actually predict dialogue quality?**
   - If high manipulation → low ratings, metrics are valid
   - If no correlation, metrics need recalibration

2. **What makes a dialogue worth reading?**
   - Novel synthesis vs rehashing
   - Clear conclusions vs meandering
   - Genuine disagreement vs forced consensus

3. **What user needs are unmet?**
   - Prompt #2 should surface this directly
   - Look for patterns in what agents suggest

4. **What's the minimum viable engagement loop?**
   - Which features make users return?
   - Which are nice-to-have vs must-have?

---

**Next Steps:**
1. Run Prompt #2 first (diagnostic) - this guides improvement priorities
2. Run Prompt #1 second (validation) - this tests your core metrics
3. Run Prompts #3-6 as stress tests - these find edge cases
4. Use findings to iterate on validation_framework.py and rating_widget.py

Good luck! 🚀
