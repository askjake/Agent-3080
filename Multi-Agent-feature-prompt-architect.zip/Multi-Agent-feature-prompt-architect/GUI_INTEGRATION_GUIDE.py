
# GUI Integration Code for agent_hub_app_v3_validation.py
# Add these imports at the top (after line 48):

from dialogue_prompt_generator import DialoguePromptGenerator
from shared_sandbox import SharedSandbox

# Initialize at module level (after imports):
dialogue_prompt_gen = DialoguePromptGenerator()
shared_sandbox = SharedSandbox()

# === INTEGRATION POINT 1: After Dialogue Completion ===
# Find where dialogues complete and add this code:

def generate_dialogue_prompt_ui(dialogue_id, dialogue_data):
    """Display generated prompt after dialogue completion"""
    
    st.markdown("---")
    st.markdown("### 📝 Generated Comprehensive Prompt")
    
    with st.expander("🎯 Click to view generated prompt (ready to paste to AI agents)", expanded=False):
        st.info("""
        This prompt contains a complete summary of the dialogue and can be pasted
        to any AI agent to give them full context about this discussion.
        """)
        
        # Generate the prompt
        prompt = dialogue_prompt_gen.generate_prompt(dialogue_data)
        
        # Display in code block for easy copying
        st.code(prompt, language="markdown")
        
        # Download button
        st.download_button(
            label="📥 Download Prompt as .md file",
            data=prompt,
            file_name=f"dialogue_{dialogue_id}_prompt.md",
            mime="text/markdown"
        )
        
        # Copy to clipboard button (requires streamlit-extras or similar)
        col1, col2 = st.columns([1, 3])
        with col1:
            if st.button("📋 Copy to Clipboard"):
                st.toast("Prompt copied! (Use Ctrl+C on the code block above)")
        
        # Stats
        st.caption(f"Prompt length: {len(prompt):,} characters | {prompt.count(chr(10)):,} lines")

# === INTEGRATION POINT 2: Shared Sandbox UI ===

def render_shared_sandbox_ui(dialogue_id):
    """Render shared sandbox interface"""
    
    st.markdown("---")
    st.markdown("### 📁 Shared Sandbox")
    
    # Create sandbox if doesn't exist
    sandbox_path = shared_sandbox.create_sandbox(dialogue_id)
    
    tab1, tab2, tab3 = st.tabs(["📂 Files", "➕ Create File", "📊 Activity Log"])
    
    with tab1:
        st.markdown("**Files in shared workspace:**")
        
        files = shared_sandbox.list_files(dialogue_id)
        
        if files:
            for file in files:
                with st.expander(f"📄 {file['name']} ({file['size']} bytes)", expanded=False):
                    # Read file content
                    result = shared_sandbox.read_file(
                        dialogue_id=dialogue_id,
                        filename=file['name'],
                        agent_id="user",
                        agent_name="User"
                    )
                    
                    if result['success']:
                        st.code(result['content'], language=None)
                        
                        st.caption(f"Created by: {file.get('creator', 'Unknown')} | "
                                 f"Size: {file['size']} bytes | "
                                 f"Modified: {file.get('modified', 'N/A')}")
                        
                        # Download button
                        st.download_button(
                            label="📥 Download",
                            data=result['content'],
                            file_name=file['name'],
                            key=f"download_{dialogue_id}_{file['name']}"
                        )
        else:
            st.info("No files created yet. Agents can create files during the dialogue.")
    
    with tab2:
        st.markdown("**Manually create a file:**")
        
        filename = st.text_input("Filename", placeholder="notes.md")
        content = st.text_area("Content", placeholder="Enter file content here...", height=200)
        purpose = st.text_input("Purpose", placeholder="Why are you creating this file?")
        
        if st.button("💾 Create File"):
            if filename and content:
                result = shared_sandbox.write_file(
                    dialogue_id=dialogue_id,
                    filename=filename,
                    content=content,
                    agent_id="user",
                    agent_name="User",
                    purpose=purpose or "Manual creation"
                )
                
                if result['success']:
                    st.success(f"✅ File created: {filename}")
                    if result['warnings']:
                        for warning in result['warnings']:
                            st.warning(warning)
                    st.rerun()
                else:
                    st.error("Failed to create file")
            else:
                st.warning("Please provide both filename and content")
    
    with tab3:
        st.markdown("**Sandbox activity log:**")
        
        summary = shared_sandbox.get_sandbox_summary(dialogue_id)
        
        st.metric("Total Files", summary['file_count'])
        st.metric("Total Size", f"{summary['total_size']} bytes")
        
        if summary['operations']:
            st.markdown("**Recent operations:**")
            for op in summary['operations'][:10]:
                st.text(f"{op['timestamp']}: {op['agent']} {op['operation']}d {op['filename']}")
        else:
            st.info("No activity yet")

# === INTEGRATION POINT 3: Add to Dialogue Display ===

def enhanced_dialogue_display(dialogue_id, dialogue_data):
    """Enhanced dialogue display with prompt generation and sandbox"""
    
    # ... existing dialogue display code ...
    
    # Add after displaying messages:
    
    # Show shared sandbox
    render_shared_sandbox_ui(dialogue_id)
    
    # If dialogue is complete, show generated prompt
    if dialogue_data.get('status') == 'completed':
        generate_dialogue_prompt_ui(dialogue_id, dialogue_data)

# === USAGE IN MAIN APP ===

# In the "Multi-Agent Dialogue" section, replace dialogue display with:
#
# enhanced_dialogue_display(dialogue_id, dialogue_data)
#
# This will add sandbox and prompt generation automatically

