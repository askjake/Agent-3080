
"""
Agent Hub Integration Library
Import this in your agent to report token usage to the central hub
"""

import requests
import logging
from typing import Optional, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)

class AgentHubReporter:
    """
    Client for reporting metrics to Agent Management Hub
    """
    
    def __init__(self, hub_url: str = "http://localhost:8502", agent_id: str = None):
        """
        Initialize reporter
        
        Args:
            hub_url: URL of the Agent Hub API (default: http://localhost:8502)
            agent_id: Your agent's unique identifier
        """
        self.hub_url = hub_url.rstrip('/')
        self.agent_id = agent_id or self._generate_agent_id()
        self.enabled = True
        
        # Test connection
        try:
            response = requests.get(f"{self.hub_url}/health", timeout=2)
            if response.status_code == 200:
                logger.info(f"Connected to Agent Hub at {self.hub_url}")
            else:
                logger.warning(f"Agent Hub returned status {response.status_code}")
                self.enabled = False
        except Exception as e:
            logger.warning(f"Could not connect to Agent Hub: {e}")
            self.enabled = False
    
    def _generate_agent_id(self) -> str:
        """Generate a unique agent ID based on hostname"""
        import socket
        import hashlib
        hostname = socket.gethostname()
        return hashlib.md5(hostname.encode()).hexdigest()[:12]
    
    def report_token_usage(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        model: str = "gpt-4",
        task: str = "chat",
        chat_id: Optional[str] = None,
        user_email: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Report token usage to the hub
        
        Args:
            prompt_tokens: Number of input tokens
            completion_tokens: Number of output tokens
            model: Model name (e.g., "gpt-4", "claude-3-sonnet")
            task: Task type (e.g., "chat", "tool", "embedding")
            chat_id: Optional chat session ID
            user_email: Optional user identifier
            metadata: Optional additional data
            
        Returns:
            True if reported successfully, False otherwise
        """
        if not self.enabled:
            return False
        
        try:
            payload = {
                "agent_id": self.agent_id,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "model": model,
                "task": task,
                "chat_id": chat_id,
                "user_email": user_email,
                "metadata": metadata or {}
            }
            
            response = requests.post(
                f"{self.hub_url}/api/token_usage",
                json=payload,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                logger.info(
                    f"Token usage reported: {prompt_tokens + completion_tokens} tokens, "
                    f"${data.get('cost', 0):.4f}"
                )
                return True
            else:
                logger.error(f"Failed to report tokens: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Error reporting token usage: {e}")
            return False
    
    def report_safety_event(
        self,
        event_type: str,
        severity: str,
        description: str,
        prevented: bool = True
    ) -> bool:
        """
        Report a safety event (e.g., blocked self-modification)
        
        Args:
            event_type: Type of event (e.g., "self_modification_attempt")
            severity: Severity level ("low", "medium", "high", "critical")
            description: Human-readable description
            prevented: Whether the event was prevented
            
        Returns:
            True if reported successfully
        """
        if not self.enabled:
            return False
        
        try:
            payload = {
                "agent_id": self.agent_id,
                "event_type": event_type,
                "severity": severity,
                "description": description,
                "prevented": prevented
            }
            
            response = requests.post(
                f"{self.hub_url}/api/safety_event",
                json=payload,
                timeout=5
            )
            
            if response.status_code == 200:
                logger.warning(f"Safety event reported: {event_type} ({severity})")
                return True
            else:
                logger.error(f"Failed to report safety event: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Error reporting safety event: {e}")
            return False
    
    def report_protocol_snapshot(
        self,
        version: str,
        protocol_content: str,
        changes_summary: Optional[str] = None
    ) -> bool:
        """
        Report a protocol/system prompt snapshot for evolution tracking
        
        Args:
            version: Version identifier (e.g., "1.2.3")
            protocol_content: Full protocol/system prompt text
            changes_summary: Optional summary of changes
            
        Returns:
            True if reported successfully
        """
        if not self.enabled:
            return False
        
        try:
            payload = {
                "agent_id": self.agent_id,
                "version": version,
                "protocol_content": protocol_content,
                "changes_summary": changes_summary
            }
            
            response = requests.post(
                f"{self.hub_url}/api/protocol_snapshot",
                json=payload,
                timeout=5
            )
            
            if response.status_code == 200:
                data = response.json()
                if data.get("status") == "unchanged":
                    logger.debug("Protocol unchanged - no snapshot created")
                else:
                    logger.info(f"Protocol snapshot reported: v{version}")
                return True
            else:
                logger.error(f"Failed to report protocol: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Error reporting protocol snapshot: {e}")
            return False

# Convenience function
def create_reporter(hub_url: str = "http://localhost:8502", agent_id: str = None) -> AgentHubReporter:
    """
    Create and return an AgentHubReporter instance
    
    Args:
        hub_url: URL of the Agent Hub API
        agent_id: Your agent's unique identifier (auto-generated if not provided)
    
    Returns:
        AgentHubReporter instance
    """
    return AgentHubReporter(hub_url=hub_url, agent_id=agent_id)


# Example usage:
if __name__ == "__main__":
    # Create reporter
    reporter = create_reporter(agent_id="my-agent-123")
    
    # Report token usage
    reporter.report_token_usage(
        prompt_tokens=150,
        completion_tokens=200,
        model="gpt-4",
        task="chat",
        chat_id="chat_abc123",
        metadata={"user_id": "user_456"}
    )
    
    # Report safety event
    reporter.report_safety_event(
        event_type="self_modification_attempt",
        severity="high",
        description="Agent attempted to modify own config file",
        prevented=True
    )
    
    # Report protocol version
    reporter.report_protocol_snapshot(
        version="1.2.3",
        protocol_content="You are a helpful AI assistant...",
        changes_summary="Improved error handling"
    )
