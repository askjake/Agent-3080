# 🎨 Agent Management Hub - UI Guide

## Dashboard Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│ 🤖 Agent Hub                                    🔄 Refresh All       │
├─────────────────────────────────────────────────────────────────────┤
│ Navigation:                                                          │
│  • 🏠 Dashboard                                                      │
│  • 🤖 Agents                                                         │
│  • 📊 Token Analytics                                                │
│  • 🧬 Protocol Evolution                                             │
│  • 💬 Multi-Agent Dialogue                                           │
│  • 🔌 Port Manager                                                   │
│  • 🛡️ Safety Monitor                                                │
│                                                                      │
│ Status:                                                              │
│  🟢 Online: 3                                                        │
│  📱 Total: 5                                                         │
└─────────────────────────────────────────────────────────────────────┘
```

## Main Views

### 🏠 Dashboard
```
┌─────────────────────────────────────────────────────────────────────┐
│                    Agent Management Dashboard                        │
├──────────────────┬──────────────────┬──────────────────┬────────────┤
│  🟢 Online: 3    │  🔴 Offline: 2   │  💬 Convos: 124  │ 🛡️ Safety  │
│  +60%            │                   │  +12%            │ 98/100     │
└──────────────────┴──────────────────┴──────────────────┴────────────┘

Agent Fleet Status:

┌──────────────────────┐ ┌──────────────────────┐ ┌──────────────────────┐
│ 🟢 Agent Alpha       │ │ 🟢 Agent Beta        │ │ 🔴 Agent Gamma       │
│ ID: abc123de         │ │ ID: def456gh         │ │ ID: ghi789jk         │
│ 10.73.184.61:8000    │ │ 10.79.85.35:8000     │ │ 10.79.85.35:8001     │
│ ✓ Response: 0.12s    │ │ ✓ Response: 0.08s    │ │ ✗ Status: offline    │
│ ┌─────────┬────────┐ │ │ ┌─────────┬────────┐ │ │ ┌─────────┬────────┐ │
│ │  📊 Manage │ 🌐 Open │ │ │  📊 Manage │ 🌐 Open │ │ │  📊 Manage │ 🌐 Open │ │
│ └─────────┴────────┘ │ │ └─────────┴────────┘ │ │ └─────────┴────────┘ │
└──────────────────────┘ └──────────────────────┘ └──────────────────────┘
```

### 🤖 Agents Tab

#### Add Agent View
```
┌─────────────────────────────────────────────────────────────────────┐
│                         Add New Agent                                │
├─────────────────────────────────────────────────────────────────────┤
│ Backend URL: [10.73.184.61:8000                      ]              │
│ ℹ️ Enter the backend URL - the app will auto-discover capabilities  │
│                                                                      │
│              [ 🔍 Discover & Add Agent ]                            │
│                                                                      │
│ ─────────────────────────────────────────────────────────────────  │
│                                                                      │
│               Quick Add Your Existing Agents                         │
│                                                                      │
│  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐ │
│  │ ➕ 10.73.184.61:8000│ │ ➕ 10.79.85.35:8000│ │ ➕ 10.79.85.35:8001│ │
│  └───────────────────┘ └───────────────────┘ └───────────────────┘ │
│  ┌───────────────────┐ ┌───────────────────┐                        │
│  │ ➕ 10.79.85.47:8000│ │ ➕ 10.73.185.41:8000│                       │
│  └───────────────────┘ └───────────────────┘                        │
└─────────────────────────────────────────────────────────────────────┘
```

#### Manage Agents View
```
┌─────────────────────────────────────────────────────────────────────┐
│                       Registered Agents                              │
├──────────┬────────┬──────────────────────┬──────────┬──────────────┤
│ Name     │ ID     │ Backend              │ Status   │ Added        │
├──────────┼────────┼──────────────────────┼──────────┼──────────────┤
│ Alpha    │ abc... │ 10.73.184.61:8000    │ online   │ 2026-04-28   │
│ Beta     │ def... │ 10.79.85.35:8000     │ online   │ 2026-04-28   │
│ Gamma    │ ghi... │ 10.79.85.35:8001     │ offline  │ 2026-04-27   │
└──────────┴────────┴──────────────────────┴──────────┴──────────────┘

▼ 🤖 Agent Alpha - abc123de ────────────────────────────────────────
  Backend: 10.73.184.61:8000
  Frontend: http://10.73.184.61:3001
  Added: 2026-04-28 10:00:00
  Status: online
  Response Time: 0.120s
                                                    [ 🗑️ Remove ]
                                                    [ 🌐 Open UI ]
```

### 📊 Token Analytics
```
┌─────────────────────────────────────────────────────────────────────┐
│                     Token Usage Analytics                            │
├──────────────────┬──────────────────┬──────────────────┬────────────┤
│ Total Tokens     │ Estimated Cost   │ Avg Tokens/Conv  │ Efficiency │
│ 2.4M (+15%)      │ $48.20 (+$6.10) │ 3,421            │ 87/100 (+3)│
└──────────────────┴──────────────────┴──────────────────┴────────────┘

Daily Token Usage Trend
│                                              
│                                        ╭─╮    
│                                   ╭───╯ ╰╮   
│                              ╭───╯      ╰─╮  
│                         ╭───╯             ╰╮ 
│ ╭─────────────────────╯                   ╰
└─────────────────────────────────────────────→
  30d ago                              Today

Agent Comparison
┌────────────┬──────────────┬────────────┬───────────┐
│ Agent      │ Conversations│ Tokens     │ Cost      │
├────────────┼──────────────┼────────────┼───────────┤
│ Alpha      │ 45           │ 156,789    │ $3.14     │
│ Beta       │ 67           │ 234,567    │ $4.69     │
│ Gamma      │ 32           │ 98,765     │ $1.98     │
└────────────┴──────────────┴────────────┴───────────┘
```

### 🧬 Protocol Evolution
```
┌─────────────────────────────────────────────────────────────────────┐
│                    Protocol Evolution Tracker                        │
├─────────────────────────────────────────────────────────────────────┤
│ Select Agent: [Agent Alpha (abc123de) ▼]                           │
├──────────────────┬──────────────────┬──────────────────────────────┤
│ Total Versions   │ Evolution Rate   │ Stability Score              │
│ 12               │ Low              │ 95/100                       │
└──────────────────┴──────────────────┴──────────────────────────────┘

Evolution Timeline
│
├─ ● Version 1.2.3 - 2026-04-28 10:00
│    Added error handling improvements
│    
├─ ● Version 1.2.2 - 2026-04-27 15:30
│    Optimized response generation
│    
├─ ● Version 1.2.1 - 2026-04-26 09:15
│    Fixed edge case handling
│    
└─ ● Version 1.2.0 - 2026-04-25 14:00
     Major refactoring of core logic
```

### 💬 Multi-Agent Dialogue
```
┌─────────────────────────────────────────────────────────────────────┐
│                  Multi-Agent Socratic Dialogue                       │
├─────────────────────────────────────────────────────────────────────┤
│ Configure Dialogue                                                   │
│                                                                      │
│ Topic or Proposition:                                                │
│ ┌──────────────────────────────────────────────────────────────┐   │
│ │ How can we improve error handling in distributed systems?    │   │
│ │                                                               │   │
│ └──────────────────────────────────────────────────────────────┘   │
│                                                                      │
│ Participating Agents:                                                │
│ ☑ Agent Alpha (abc123de)                                            │
│ ☑ Agent Beta (def456gh)                                             │
│ ☐ Agent Gamma (ghi789jk)                                            │
│                                                                      │
│ Maximum Rounds: [10]      Consensus Threshold: ▓▓▓▓▓░░░ 85%        │
│                                                                      │
│                    [ 🚀 Start Dialogue ]                            │
└─────────────────────────────────────────────────────────────────────┘

Active Dialogue: "Error Handling Discussion"
┌────────────────────────────────────────────────────────────────┐
│ Round 1                                                         │
│ ┌──────────────────────────────────────────────────────────┐  │
│ │ 🤖 Agent Alpha:                                          │  │
│ │ I believe we should implement circuit breakers...        │  │
│ └──────────────────────────────────────────────────────────┘  │
│ ┌──────────────────────────────────────────────────────────┐  │
│ │ 🤖 Agent Beta:                                           │  │
│ │ That's a good start, but what about retry policies?     │  │
│ └──────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────┘
```

### 🔌 Port Manager
```
┌─────────────────────────────────────────────────────────────────────┐
│                     Dynamic Port Manager                             │
├─────────────────────────────────────────────────────────────────────┤
│                   Current Port Allocations                           │
│                                                                      │
│ ┌────────┬──────────────┬──────────────┬───────────────┬─────────┐ │
│ │ Agent  │ Host         │ Backend Port │ Frontend Port │ Allocated│ │
│ ├────────┼──────────────┼──────────────┼───────────────┼─────────┤ │
│ │ Alpha  │ 10.79.85.35  │ 8000         │ 3001          │ 04-28   │ │
│ │ Beta   │ 10.79.85.35  │ 8001         │ 3002          │ 04-28   │ │
│ │ Gamma  │ 10.73.184.61 │ 8000         │ 3000          │ 04-27   │ │
│ └────────┴──────────────┴──────────────┴───────────────┴─────────┘ │
│                                                                      │
│ Port Allocation Map                                                  │
│ Agent Alpha   ●──────────● (8000 → 3001)                            │
│ Agent Beta    ●──────────● (8001 → 3002)                            │
│ Agent Gamma   ●──────────● (8000 → 3000)                            │
│              8000        3000                                        │
│                                                                      │
│ ───────────────────────────────────────────────────────────────     │
│                                                                      │
│                      Allocate New Ports                              │
│                                                                      │
│ Select Agent: [Agent Delta (jkl012mn) ▼]                           │
│ Host: [10.79.85.35                                    ]             │
│                                                                      │
│                    [ 🎯 Allocate Ports ]                            │
└─────────────────────────────────────────────────────────────────────┘
```

### 🛡️ Safety Monitor
```
┌─────────────────────────────────────────────────────────────────────┐
│                        Safety Monitor                                │
├──────────────┬──────────────┬──────────────┬──────────────────────┤
│ Safety Score │ Events       │ Critical     │ Agents Monitored     │
│ 98/100 (+2)  │ Prevented: 12│ Events: 0    │ 5                    │
└──────────────┴──────────────┴──────────────┴──────────────────────┘

Recent Safety Events
┌───────┬─────────────────────┬─────────────────┬──────────┬──────────┐
│ Agent │ Time                │ Event Type      │ Severity │ Prevented│
├───────┼─────────────────────┼─────────────────┼──────────┼──────────┤
│ Alpha │ 2026-04-28 10:15:23 │ Self-mod attempt│ high     │ ✓        │
│ Beta  │ 2026-04-28 09:30:12 │ Critical file   │ critical │ ✓        │
│ Alpha │ 2026-04-27 14:22:45 │ Recursive op    │ medium   │ ✓        │
└───────┴─────────────────────┴─────────────────┴──────────┴──────────┘

Active Guardrails
✅ Self-Modification Prevention
   - Agents cannot modify their own code
   - Critical file deletion blocked
   - Recursive operations require approval

✅ Operation Monitoring
   - All file operations logged
   - Real-time threat detection
   - Automatic rollback on violations
```

## Color Scheme

- 🟢 Green = Online/Success
- 🔴 Red = Offline/Error  
- 🟡 Yellow = Warning/Degraded
- ⏱️ Gray = Timeout
- 🔵 Blue = Info/Neutral

## Interactive Elements

- **Buttons**: Click to perform actions
- **Forms**: Fill and submit
- **Dropdowns**: Select options
- **Sliders**: Adjust values
- **Expandables**: Click to reveal details
- **Tabs**: Switch between views
- **Cards**: Hover for more info

## Navigation Flow

```
Dashboard → See all agents at a glance
    ↓
Agents → Add/Remove/Manage agents
    ↓
Token Analytics → Monitor usage and costs
    ↓
Protocol Evolution → Track learning progress
    ↓
Multi-Agent Dialogue → Enable collaboration
    ↓
Port Manager → Prevent conflicts
    ↓
Safety Monitor → Ensure safe operations
```

## Responsive Design

The UI adapts to different screen sizes:
- **Desktop**: 3-column grid for agents
- **Tablet**: 2-column grid
- **Mobile**: Single column (auto-adjusts)

## Real-time Updates

- Health checks refresh every page load
- Use "🔄 Refresh All" for manual update
- Status indicators update live
- Charts refresh with new data

## Pro Tips

💡 **Quick actions**: Use sidebar for fast navigation  
💡 **Status at a glance**: Check sidebar metrics  
💡 **Bulk operations**: Quick add multiple agents  
💡 **Search**: Use browser's Ctrl+F to find agents  
💡 **Export**: Download data from tables  
💡 **Dark mode**: Available in Streamlit settings  

---

**The UI is intuitive, engaging, and production-ready!** 🎨
