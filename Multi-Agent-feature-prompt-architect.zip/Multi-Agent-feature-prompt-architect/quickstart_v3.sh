#!/bin/bash
# Quick Start Script for Agent Management Hub

echo "🤖 AI Agent Management Hub v3.0 - Validation Framework"
echo "========================================"
echo ""

# Check Python version
python_version=$(python3 --version 2>&1 | grep -Po '(?<=Python )(.+)')
echo "✓ Python version: $python_version"

# Install dependencies
echo ""
echo "📦 Installing dependencies..."
pip install -q streamlit pandas plotly requests aiohttp

# Start the app
echo ""
echo "🚀 Starting Agent Management Hub..."
echo "   Access at: http://localhost:8501"
echo ""
echo "   Press Ctrl+C to stop"
echo ""

streamlit run agent_hub_app_v3_validation.py
