# 🤖 Ollama Integration for Multi-Agent Hub

## Overview
This integration adds Ollama (local LLM server) support to the Multi-Agent Hub, allowing you to use locally-run models like Gemma for chat and dialogue interactions.

## What Was Added

### 1. Ollama Adapter (`ollama_adapter.py`)
- **Location**: `/home/montjac/multi-agent-hub/ollama_adapter.py`
- **Purpose**: Flask-based adapter that wraps Ollama API to be compatible with Multi-Agent Hub
- **Port**: 8100 (default)
- **Endpoints**:
  - `GET /health` - Health check
  - `POST /chat` - Chat endpoint (Multi-Agent Hub compatible)
  - `POST /api/chat` - Alternative chat endpoint
  - `GET /` - Service information

### 2. Startup Script (`start_ollama_adapter.sh`)
- **Location**: `/home/montjac/multi-agent-hub/start_ollama_adapter.sh`
- **Purpose**: Convenient script to start the Ollama adapter
- **Usage**: `./start_ollama_adapter.sh [PORT]`

### 3. Systemd Service File (`ollama-adapter.service`)
- **Location**: `/home/montjac/multi-agent-hub/ollama-adapter.service`
- **Purpose**: Optional systemd service for automatic startup
- **Installation**: `sudo cp ollama-adapter.service /etc/systemd/system/`

### 4. Database Entry
- **Agent ID**: `ollama-gemma`
- **Agent Name**: Ollama Gemma
- **Backend URL**: http://localhost:8100
- **Model**: Gemma 9B (Q4_0 quantization)

## How It Works

```
┌─────────────────┐
│ Multi-Agent Hub │
│ (Streamlit App) │
│   Port 8501     │
└────────┬────────┘
         │
         │ HTTP POST /chat
         │ {messages: [...]}
         ▼
┌────────────────────┐
│  Ollama Adapter    │
│   Flask Server     │
│    Port 8100       │
└────────┬───────────┘
         │
         │ HTTP POST /api/generate
         │ {model: "gemma", prompt: "..."}
         ▼
┌────────────────────┐
│   Ollama Server    │
│  Running Gemma 9B  │
│    Port 11434      │
└────────────────────┘
```

## Prerequisites

1. **Ollama must be running**:
   ```bash
   ollama serve
   ```

2. **Gemma model must be pulled**:
   ```bash
   ollama pull gemma
   ```

3. **Python dependencies**:
   - Flask
   - requests
   
   Install with: `pip install flask requests`

## Quick Start

### Option 1: Manual Start

1. **Start Ollama** (if not already running):
   ```bash
   ollama serve
   ```

2. **Start the Ollama Adapter**:
   ```bash
   cd /home/montjac/multi-agent-hub
   ./start_ollama_adapter.sh
   ```
   
   Or specify a custom port:
   ```bash
   ./start_ollama_adapter.sh 8100
   ```

3. **Start Multi-Agent Hub**:
   ```bash
   ./quickstart_v3.sh
   ```

4. **Access the Hub**:
   - Open browser: http://localhost:8501
   - Navigate to "Agent Configuration" page
   - You should see "Ollama Gemma" in the agent list
   - Test the connection with the "🧪 Test" button

### Option 2: Systemd Service (Auto-start)

1. **Install the service**:
   ```bash
   sudo cp /home/montjac/multi-agent-hub/ollama-adapter.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable ollama-adapter.service
   sudo systemctl start ollama-adapter.service
   ```

2. **Check status**:
   ```bash
   sudo systemctl status ollama-adapter.service
   ```

3. **View logs**:
   ```bash
   sudo journalctl -u ollama-adapter.service -f
   ```

## Testing the Integration

### 1. Test Ollama Server
```bash
curl http://localhost:11434/api/tags
```
Should return list of available models including gemma.

### 2. Test Ollama Adapter Health
```bash
curl http://localhost:8100/health
```
Expected output:
```json
{
  "status": "healthy",
  "service": "ollama-adapter",
  "ollama_url": "http://localhost:11434",
  "model": "gemma:latest",
  "available_models": ["gemma:latest"]
}
```

### 3. Test Ollama Adapter Chat
```bash
curl -X POST http://localhost:8100/chat \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [
      {"role": "user", "content": "Hello! What is 2+2?"}
    ]
  }'
```

Expected output:
```json
{
  "content": "2+2 equals 4",
  "agent": "Ollama (gemma:latest)",
  "timestamp": "2026-04-29T..."
}
```

### 4. Test in Multi-Agent Hub UI

1. Go to http://localhost:8501
2. Navigate to "Agent Configuration"
3. Find "Ollama Gemma" agent
4. Click "🧪 Test" button
5. Should show green ✅ with response time
6. Go to "Chat" or "Multi-Agent Dialogue"
7. Select "Ollama Gemma" as an agent
8. Send a message and verify it responds

## Configuration

### Change Ollama Model

Edit `/home/montjac/multi-agent-hub/ollama_adapter.py`:

```python
OLLAMA_MODEL = "gemma:latest"  # Change to desired model
```

Available options:
- `gemma:latest` - Gemma 9B
- `llama2:latest` - Llama 2
- `mistral:latest` - Mistral 7B
- etc.

Then restart the adapter.

### Change Adapter Port

```bash
./start_ollama_adapter.sh 8200  # Use port 8200 instead
```

Don't forget to update the database:
```python
UPDATE agents SET backend_url = 'http://localhost:8200' WHERE id = 'ollama-gemma';
```

### Adjust Ollama Parameters

Edit the `call_ollama()` function in `ollama_adapter.py`:

```python
"options": {
    "temperature": 0.7,   # 0.0 = deterministic, 1.0 = creative
    "top_p": 0.9,         # Nucleus sampling
    "top_k": 40,          # Top-k sampling
    "num_predict": 128    # Max tokens to generate
}
```

## Troubleshooting

### Issue: "Cannot connect to Ollama server"

**Solution**:
1. Check if Ollama is running: `ps aux | grep ollama`
2. Start Ollama: `ollama serve`
3. Verify: `curl http://localhost:11434/api/tags`

### Issue: "Model not found"

**Solution**:
1. List models: `ollama list`
2. Pull Gemma: `ollama pull gemma`
3. Restart adapter

### Issue: Adapter shows "offline" in Hub

**Solution**:
1. Check adapter is running: `curl http://localhost:8100/health`
2. Check logs: `ps aux | grep ollama_adapter`
3. Restart: `./start_ollama_adapter.sh`

### Issue: Slow responses

**Explanation**: Gemma 9B is running locally, response times depend on:
- CPU/GPU available
- Model quantization (Q4_0 is faster but less accurate)
- Prompt length

**Solutions**:
- Use GPU if available (Ollama auto-detects)
- Reduce `num_predict` parameter
- Use smaller model like `gemma:2b`

### Issue: Port 8100 already in use

**Solution**:
```bash
# Find what's using port 8100
sudo lsof -i :8100

# Kill the process or use different port
./start_ollama_adapter.sh 8200
```

## Advanced Usage

### Custom System Prompts

Modify the `call_ollama()` function to inject system prompts:

```python
# Add at start of message building
prompt = "System: You are a helpful AI assistant specialized in Dish Network systems.\n"
```

### Multi-Model Support

Extend the adapter to support multiple models:

```python
MODELS = {
    "gemma": "gemma:latest",
    "llama2": "llama2:latest",
    "mistral": "mistral:latest"
}

# In chat() function
model_name = data.get('model', 'gemma')
model = MODELS.get(model_name, MODELS['gemma'])
```

## Files Modified/Created

### Created
- `/home/montjac/multi-agent-hub/ollama_adapter.py` (Adapter service)
- `/home/montjac/multi-agent-hub/start_ollama_adapter.sh` (Startup script)
- `/home/montjac/multi-agent-hub/ollama-adapter.service` (Systemd service)

### Modified
- `/home/montjac/multi-agent-hub/agent_hub.db` (Added ollama-gemma agent)

## Next Steps

1. **Start the adapter**: `./start_ollama_adapter.sh`
2. **Verify in UI**: Check Agent Configuration page
3. **Test chat**: Send messages to Ollama Gemma
4. **Optional**: Set up systemd service for auto-start
5. **Experiment**: Try different models, adjust parameters

## Support

For issues:
1. Check Ollama is running: `ollama serve`
2. Check adapter logs
3. Test endpoints manually with curl
4. Verify database entry: `SELECT * FROM agents WHERE id='ollama-gemma'`

## Performance Notes

- **Gemma 9B Q4_0**: ~5GB RAM, 2-5 seconds response time on CPU
- **With GPU**: Much faster, <1 second responses
- **Quantization**: Q4_0 is 4-bit quantized (faster, less accurate than Q8_0)

---
**Created**: 2026-04-29
**Last Updated**: 2026-04-29
**Protocol**: Followed verification protocol - all changes documented
