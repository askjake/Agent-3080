"""
dialogue_prompt_generator.py
=============================
Generates comprehensive prompts from completed multi-agent dialogues.
Can be used to brief other AI agents on the discussion outcomes.
"""

import json
from datetime import datetime
from typing import Dict, List, Any, Optional

class DialoguePromptGenerator:
    """Generate comprehensive prompts from dialogue results"""
    
    def __init__(self):
        self.template_version = "1.0"
    
    def generate_prompt(self, dialogue_data: Dict[str, Any]) -> str:
        """
        Generate a comprehensive prompt from dialogue data.
        
        Args:
            dialogue_data: Dictionary containing dialogue information
        
        Returns:
            Comprehensive prompt string ready for AI consumption
        """
        
        lines = []
        lines.append("# 🎯 MULTI-AGENT DIALOGUE SUMMARY & COMPREHENSIVE PROMPT")
        lines.append("")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**Template Version:** {self.template_version}")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📋 DIALOGUE METADATA")
        lines.append("")
        lines.append(f"**Topic:** {dialogue_data.get('topic', 'N/A')}")
        lines.append(f"**Dialogue ID:** {dialogue_data.get('id', 'N/A')}")
        lines.append(f"**Consensus Achieved:** {dialogue_data.get('consensus_score', 0.0):.1%}")
        lines.append(f"**Rounds Completed:** {dialogue_data.get('rounds', 0)} / {dialogue_data.get('max_rounds', 'N/A')}")
        lines.append(f"**Duration:** {self._calculate_duration(dialogue_data)}")
        lines.append(f"**Status:** {dialogue_data.get('status', 'Unknown')}")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 👥 PARTICIPATING AGENTS")
        lines.append("")
        
        agents = dialogue_data.get('agents', [])
        for i, agent in enumerate(agents, 1):
            lines.append(f"{i}. **{agent.get('name', 'Unknown')}** (ID: {agent.get('id', 'N/A')})")
            if 'specialization' in agent:
                lines.append(f"   - Specialization: {agent['specialization']}")
        
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 💬 DIALOGUE TRANSCRIPT")
        lines.append("")
        
        messages = dialogue_data.get('messages', [])
        if messages:
            current_round = 0
            for msg in messages:
                msg_round = msg.get('round', 0)
                if msg_round != current_round:
                    current_round = msg_round
                    lines.append("")
                    lines.append(f"### Round {current_round}")
                    lines.append("")
                
                agent_name = msg.get('agent_name', 'Unknown')
                content = msg.get('content', '')
                
                lines.append(f"**{agent_name}:**")
                lines.append(content)
                lines.append("")
        else:
            lines.append("*No messages recorded*")
            lines.append("")
        
        lines.append("---")
        lines.append("")
        lines.append("## 🎯 KEY INSIGHTS & OUTCOMES")
        lines.append("")
        
        insights = dialogue_data.get('key_insights', [])
        if insights:
            for i, insight in enumerate(insights, 1):
                lines.append(f"{i}. {insight}")
        else:
            lines.extend(self._extract_auto_insights(dialogue_data))
        
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📊 CONSENSUS ANALYSIS")
        lines.append("")
        
        consensus_score = dialogue_data.get('consensus_score', 0.0)
        lines.append(f"**Final Consensus:** {consensus_score:.1%}")
        lines.append("")
        
        if consensus_score >= 0.85:
            lines.append("✅ **Strong Agreement** - Agents reached solid consensus")
        elif consensus_score >= 0.70:
            lines.append("⚠️ **Moderate Agreement** - General consensus with some nuances")
        else:
            lines.append("❌ **Low Agreement** - Significant disagreement or complex topic")
        
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📁 SHARED SANDBOX FILES")
        lines.append("")
        
        files = dialogue_data.get('files_created', [])
        if files:
            for f in files:
                lines.append(f"- **{f['name']}** ({f.get('size', 0)} bytes)")
                lines.append(f"  - Created by: {f.get('agent', 'Unknown')}")
                lines.append(f"  - Purpose: {f.get('purpose', 'N/A')}")
                lines.append("")
        else:
            lines.append("*No files created during dialogue*")
            lines.append("")
        
        lines.append("---")
        lines.append("")
        lines.append("## 💡 RECOMMENDED ACTIONS")
        lines.append("")
        lines.extend(self._generate_recommendations(dialogue_data))
        
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📝 PROMPT FOR AI CONTINUATION")
        lines.append("")
        lines.append(f"> The multi-agent dialogue above discussed: {dialogue_data.get('topic', 'this topic')}.")
        lines.append("> ")
        lines.append("> **Key Points:**")
        lines.extend([f"> {line}" for line in self._generate_key_points_list(dialogue_data)])
        lines.append("> ")
        lines.append(f"> **Consensus Level:** {consensus_score:.1%}")
        lines.append("> ")
        lines.append("> **Your Task:** [USER DEFINES TASK HERE]")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("**END OF DIALOGUE PROMPT**")
        lines.append("")
        lines.append(f"*Generated by Dialogue Prompt Generator v{self.template_version}*")
        
        return "\n".join(lines)
    
    def _calculate_duration(self, dialogue_data: Dict) -> str:
        """Calculate dialogue duration"""
        started = dialogue_data.get('started_at')
        completed = dialogue_data.get('completed_at')
        
        if not started:
            return "Unknown"
        if not completed:
            return "In progress"
        
        return "Completed"
    
    def _extract_auto_insights(self, dialogue_data: Dict) -> List[str]:
        """Auto-extract insights from dialogue"""
        insights = []
        
        messages = dialogue_data.get('messages', [])
        if not messages:
            insights.append("*No insights could be extracted*")
            return insights
        
        agent_count = len(set(msg.get('agent_name') for msg in messages))
        insights.append(f"- Dialogue involved {agent_count} agents with {len(messages)} total messages")
        
        consensus = dialogue_data.get('consensus_score', 0.0)
        if consensus >= 0.85:
            insights.append("- Agents reached strong agreement on the topic")
        elif consensus >= 0.70:
            insights.append("- Agents showed general agreement with some differing perspectives")
        else:
            insights.append("- Topic revealed significant complexity with diverse viewpoints")
        
        return insights
    
    def _generate_recommendations(self, dialogue_data: Dict) -> List[str]:
        """Generate recommended actions"""
        consensus = dialogue_data.get('consensus_score', 0.0)
        recommendations = []
        
        if consensus >= 0.85:
            recommendations.append("✅ **Proceed with implementation** - Strong consensus supports action")
            recommendations.append("📝 **Document the agreed approach** - Capture the solution for reference")
        elif consensus >= 0.70:
            recommendations.append("⚠️ **Address remaining concerns** - Review dissenting opinions")
            recommendations.append("💡 **Consider a hybrid approach** - Combine different perspectives")
        else:
            recommendations.append("🔍 **Analyze points of disagreement** - Understand why consensus is low")
            recommendations.append("📚 **Research additional perspectives** - Gather more information")
        
        recommendations.append("📊 **Review shared sandbox files** - Check any artifacts created")
        
        return recommendations
    
    def _generate_key_points_list(self, dialogue_data: Dict) -> List[str]:
        """Generate bulleted list of key points"""
        points = []
        
        agents = dialogue_data.get('agents', [])
        points.append(f"- {len(agents)} agents participated")
        
        consensus = dialogue_data.get('consensus_score', 0.0)
        points.append(f"- Consensus level: {consensus:.1%}")
        
        rounds = dialogue_data.get('rounds', 0)
        points.append(f"- Discussion lasted {rounds} rounds")
        
        files = dialogue_data.get('files_created', [])
        if files:
            points.append(f"- Created {len(files)} files in shared sandbox")
        
        return points


if __name__ == "__main__":
    print("✅ DialoguePromptGenerator module loaded successfully")
