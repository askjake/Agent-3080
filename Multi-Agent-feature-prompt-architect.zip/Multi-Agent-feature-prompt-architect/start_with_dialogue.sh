#!/bin/bash
# Multi-Agent Hub - Complete Startup Script with Agent Adapters
# Starts mock agents, adapters, and the hub application

echo "🚀 Starting Multi-Agent Hub with Dialogue System"
echo "======================================================================"

# Kill existing processes
echo "🧹 Cleaning up existing processes..."
pkill -f "mock_agent.py" 2>/dev/null
pkill -f "agent_adapter.py" 2>/dev/null
pkill -f "streamlit.*agent_hub" 2>/dev/null
sleep 2

cd /home/montjac/multi-agent-hub

# Start mock agents for testing
echo ""
echo "🤖 Starting Mock Agents..."
python3 mock_agent.py 8100 > /tmp/mock_agent_8100.log 2>&1 &
echo "   ✅ Mock Agent Alpha on port 8100"

python3 mock_agent.py 8101 > /tmp/mock_agent_8101.log 2>&1 &
echo "   ✅ Mock Agent Beta on port 8101"

sleep 3

# Start agent adapters
echo ""
echo "🔌 Starting Agent Adapters..."
python3 agent_adapter.py 9000 > /tmp/agent_adapter_9000.log 2>&1 &
echo "   ✅ Dish-Chat Adapter on port 9000"

python3 agent_adapter.py 9001 > /tmp/agent_adapter_9001.log 2>&1 &
echo "   ✅ Backup Adapter on port 9001"

sleep 3

# Verify services
echo ""
echo "🔍 Verifying Services..."

check_service() {
    local url=$1
    local name=$2
    if curl -s --max-time 3 "$url" > /dev/null 2>&1; then
        echo "   ✅ $name is healthy"
        return 0
    else
        echo "   ⚠️  $name failed health check"
        return 1
    fi
}

check_service "http://localhost:8100/health" "Mock Agent Alpha"
check_service "http://localhost:8101/health" "Mock Agent Beta"
check_service "http://localhost:9000/health" "Adapter 9000"
check_service "http://localhost:9001/health" "Adapter 9001"

# Register agents in database
echo ""
echo "📝 Registering Agents in Database..."
python3 << 'PYTHON_EOF'
import sqlite3
import json
from datetime import datetime

conn = sqlite3.connect('/home/montjac/multi-agent-hub/agent_hub.db')
cursor = conn.cursor()

agents = [
    {
        'id': 'mock-agent-alpha',
        'name': 'Mock Agent Alpha',
        'backend_url': 'http://localhost:8100',
        'description': 'Intelligent mock agent for testing - optimized responses',
        'capabilities': json.dumps(['chat', 'dialogue', 'reasoning']),
        'metadata': json.dumps({'port': 8100, 'type': 'mock', 'category': 'test'})
    },
    {
        'id': 'mock-agent-beta',
        'name': 'Mock Agent Beta',
        'backend_url': 'http://localhost:8101',
        'description': 'Intelligent mock agent for testing - balanced responses',
        'capabilities': json.dumps(['chat', 'dialogue', 'reasoning']),
        'metadata': json.dumps({'port': 8101, 'type': 'mock', 'category': 'test'})
    },
    {
        'id': 'dish-chat-adapted',
        'name': 'Dish-Chat Agent (Adapted)',
        'backend_url': 'http://localhost:9000',
        'description': 'Adapted Dish-Chat backend with intelligent responses',
        'capabilities': json.dumps(['chat', 'dialogue', 'analysis']),
        'metadata': json.dumps({'port': 9000, 'type': 'adapter', 'backend': 'dish-chat'})
    },
    {
        'id': 'backup-adapted',
        'name': 'Backup Agent (Adapted)',
        'backend_url': 'http://localhost:9001',
        'description': 'Backup adapted agent for redundancy',
        'capabilities': json.dumps(['chat', 'dialogue']),
        'metadata': json.dumps({'port': 9001, 'type': 'adapter', 'backend': 'generic'})
    }
]

for agent in agents:
    cursor.execute("SELECT id FROM agents WHERE id = ?", (agent['id'],))
    existing = cursor.fetchone()
    
    if existing:
        cursor.execute("""
            UPDATE agents 
            SET name = ?, backend_url = ?, description = ?, capabilities = ?, metadata = ?,
                frontend_url = ''
            WHERE id = ?
        """, (agent['name'], agent['backend_url'], agent['description'], 
              agent['capabilities'], agent['metadata'], agent['id']))
        print(f"   ✅ Updated: {agent['name']}")
    else:
        cursor.execute("""
            INSERT INTO agents (id, name, backend_url, frontend_url, description, capabilities, metadata, registered_timestamp)
            VALUES (?, ?, ?, '', ?, ?, ?, ?)
        """, (agent['id'], agent['name'], agent['backend_url'],
              agent['description'], agent['capabilities'], agent['metadata'], datetime.now().isoformat()))
        print(f"   ✅ Registered: {agent['name']}")

conn.commit()
conn.close()
print()
PYTHON_EOF

# Start Streamlit app
echo "🌐 Starting Streamlit Application..."
/home/montjac/.local/bin/streamlit run agent_hub_app_complete.py --server.port 8501 > /tmp/agent_hub.log 2>&1 &
STREAMLIT_PID=$!

sleep 5

# Check if Streamlit is running
if lsof -i :8501 > /dev/null 2>&1; then
    echo "   ✅ Streamlit started successfully"
else
    echo "   ❌ Streamlit failed to start. Check /tmp/agent_hub.log"
    exit 1
fi

echo ""
echo "======================================================================"
echo "✅ MULTI-AGENT HUB IS READY!"
echo "======================================================================"
echo ""
echo "📍 Access Points:"
echo "   🌐 Hub Interface:        http://localhost:8501"
echo "   🤖 Mock Agent Alpha:     http://localhost:8100/health"
echo "   🤖 Mock Agent Beta:      http://localhost:8101/health"
echo "   🔌 Dish-Chat Adapter:    http://localhost:9000/health"
echo "   🔌 Backup Adapter:       http://localhost:9001/health"
echo ""
echo "🧪 Quick Test:"
echo "   1. Open http://localhost:8501"
echo "   2. Navigate to '💬 Multi-Agent Dialogue'"
echo "   3. Select any 2 agents"
echo "   4. Choose a topic template"
echo "   5. Click '🚀 Launch Dialogue Session'"
echo "   6. Click '⏩ Run All Rounds'"
echo ""
echo "📊 Available Agents:"
echo "   • Mock Agent Alpha - Fast, test-focused responses"
echo "   • Mock Agent Beta - Balanced, thoughtful responses"
echo "   • Dish-Chat Agent (Adapted) - Enterprise-grade analysis"
echo "   • Backup Agent (Adapted) - Redundancy and reliability"
echo ""
echo "📝 Logs:"
echo "   tail -f /tmp/agent_hub.log"
echo "   tail -f /tmp/mock_agent_8100.log"
echo "   tail -f /tmp/agent_adapter_9000.log"
echo ""
echo "🛑 To Stop Everything:"
echo "   pkill -f 'mock_agent.py'"
echo "   pkill -f 'agent_adapter.py'"
echo "   pkill -f 'streamlit.*agent_hub'"
echo ""
echo "======================================================================"
echo "🎉 Ready for Multi-Agent Dialogues!"
echo "======================================================================"
