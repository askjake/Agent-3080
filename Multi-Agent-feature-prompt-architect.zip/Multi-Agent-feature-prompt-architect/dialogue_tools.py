"""
dialogue_tools.py
=================
Tool execution system for multi-agent dialogues.
Provides git clone, file operations, and data retrieval capabilities.
"""

import os
import subprocess
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
import requests


class DialogueToolExecutor:
    """
    Executes tools requested by agents during multi-agent dialogues.
    
    Features:
    - Git repository cloning
    - File reading and writing
    - Directory listing
    - Web search (basic)
    - Safe sandboxed execution
    """
    
    def __init__(self, sandbox_base: str = "/home/montjac/multi-agent-hub/sandboxes"):
        self.sandbox_base = Path(sandbox_base)
        self.sandbox_base.mkdir(parents=True, exist_ok=True)
        
        # Define available tools
        self.tools = {
            'git_clone': self.git_clone,
            'read_file': self.read_file,
            'write_file': self.write_file,
            'list_directory': self.list_directory,
            'search_files': self.search_files,
        }
    
    def get_sandbox_path(self, dialogue_id: str) -> Path:
        """Get sandbox path for a dialogue"""
        path = self.sandbox_base / dialogue_id
        path.mkdir(parents=True, exist_ok=True)
        return path
    
    def git_clone(self, dialogue_id: str, repo_url: str, branch: str = "main") -> Dict[str, Any]:
        """
        Clone a git repository into the dialogue sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
            repo_url: Git repository URL
            branch: Branch to checkout (default: main)
        
        Returns:
            Result dictionary with status and details
        """
        sandbox = self.get_sandbox_path(dialogue_id)
        
        # Extract repo name from URL
        repo_name = repo_url.rstrip('/').split('/')[-1].replace('.git', '')
        repo_path = sandbox / repo_name
        
        result = {
            'success': False,
            'tool': 'git_clone',
            'repo_url': repo_url,
            'branch': branch,
            'output': '',
            'error': None
        }
        
        try:
            # Check if already cloned
            if repo_path.exists():
                result['output'] = f"Repository already exists at {repo_path}"
                result['success'] = True
                return result
            
            # Clone the repository
            cmd = ['git', 'clone', '--branch', branch, '--depth', '1', repo_url, str(repo_path)]
            process = subprocess.run(
                cmd,
                cwd=str(sandbox),
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if process.returncode == 0:
                # List contents
                files = list(repo_path.rglob('*'))
                file_count = len([f for f in files if f.is_file()])
                dir_count = len([f for f in files if f.is_dir()])
                
                result['success'] = True
                result['output'] = f"✅ Cloned {repo_url} to {repo_path}\n"
                result['output'] += f"   Branch: {branch}\n"
                result['output'] += f"   Files: {file_count}, Directories: {dir_count}\n"
                result['repo_path'] = str(repo_path)
                result['file_count'] = file_count
            else:
                result['error'] = process.stderr
                result['output'] = f"❌ Failed to clone: {process.stderr}"
        
        except subprocess.TimeoutExpired:
            result['error'] = "Git clone timed out after 120 seconds"
            result['output'] = "❌ Clone operation timed out"
        except Exception as e:
            result['error'] = str(e)
            result['output'] = f"❌ Error: {str(e)}"
        
        return result
    
    def read_file(self, dialogue_id: str, file_path: str, max_lines: int = 500) -> Dict[str, Any]:
        """
        Read a file from the sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
            file_path: Relative path to file within sandbox
            max_lines: Maximum lines to read (default: 500)
        
        Returns:
            Result dictionary with file contents
        """
        sandbox = self.get_sandbox_path(dialogue_id)
        full_path = sandbox / file_path
        
        result = {
            'success': False,
            'tool': 'read_file',
            'file_path': file_path,
            'content': '',
            'error': None
        }
        
        try:
            # Security check - ensure path is within sandbox
            if not str(full_path.resolve()).startswith(str(sandbox.resolve())):
                result['error'] = "Path outside sandbox not allowed"
                result['output'] = "❌ Security error: Path outside sandbox"
                return result
            
            if not full_path.exists():
                result['error'] = "File not found"
                result['output'] = f"❌ File not found: {file_path}"
                return result
            
            # Read file
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
                if len(lines) > max_lines:
                    content = ''.join(lines[:max_lines])
                    content += f"\n\n... (truncated, showing {max_lines} of {len(lines)} lines)"
                else:
                    content = ''.join(lines)
            
            result['success'] = True
            result['content'] = content
            result['line_count'] = len(lines)
            result['size'] = full_path.stat().st_size
            result['output'] = f"✅ Read {file_path} ({len(lines)} lines, {result['size']} bytes)"
        
        except UnicodeDecodeError:
            result['error'] = "Binary file or encoding issue"
            result['output'] = f"❌ Cannot read {file_path}: binary file or encoding issue"
        except Exception as e:
            result['error'] = str(e)
            result['output'] = f"❌ Error reading {file_path}: {str(e)}"
        
        return result
    
    def write_file(self, dialogue_id: str, file_path: str, content: str) -> Dict[str, Any]:
        """
        Write a file to the sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
            file_path: Relative path to file within sandbox
            content: File content
        
        Returns:
            Result dictionary
        """
        sandbox = self.get_sandbox_path(dialogue_id)
        full_path = sandbox / file_path
        
        result = {
            'success': False,
            'tool': 'write_file',
            'file_path': file_path,
            'error': None
        }
        
        try:
            # Security check
            if not str(full_path.resolve()).startswith(str(sandbox.resolve())):
                result['error'] = "Path outside sandbox not allowed"
                result['output'] = "❌ Security error: Path outside sandbox"
                return result
            
            # Create parent directories
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Write file
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            result['success'] = True
            result['size'] = len(content)
            result['output'] = f"✅ Wrote {file_path} ({result['size']} bytes)"
        
        except Exception as e:
            result['error'] = str(e)
            result['output'] = f"❌ Error writing {file_path}: {str(e)}"
        
        return result
    
    def list_directory(self, dialogue_id: str, dir_path: str = ".") -> Dict[str, Any]:
        """
        List contents of a directory in the sandbox.
        
        Args:
            dialogue_id: Dialogue identifier
            dir_path: Relative directory path (default: root)
        
        Returns:
            Result dictionary with directory listing
        """
        sandbox = self.get_sandbox_path(dialogue_id)
        full_path = sandbox / dir_path
        
        result = {
            'success': False,
            'tool': 'list_directory',
            'dir_path': dir_path,
            'files': [],
            'error': None
        }
        
        try:
            # Security check
            if not str(full_path.resolve()).startswith(str(sandbox.resolve())):
                result['error'] = "Path outside sandbox not allowed"
                result['output'] = "❌ Security error: Path outside sandbox"
                return result
            
            if not full_path.exists():
                result['error'] = "Directory not found"
                result['output'] = f"❌ Directory not found: {dir_path}"
                return result
            
            # List contents
            items = []
            for item in sorted(full_path.iterdir()):
                item_type = 'dir' if item.is_dir() else 'file'
                size = item.stat().st_size if item.is_file() else 0
                
                items.append({
                    'name': item.name,
                    'type': item_type,
                    'size': size,
                    'path': str(item.relative_to(sandbox))
                })
            
            result['success'] = True
            result['files'] = items
            result['count'] = len(items)
            
            # Format output
            output_lines = [f"📁 Contents of {dir_path}:"]
            for item in items:
                icon = "📁" if item['type'] == 'dir' else "📄"
                size_str = f"({item['size']} bytes)" if item['type'] == 'file' else ""
                output_lines.append(f"   {icon} {item['name']} {size_str}")
            
            result['output'] = '\n'.join(output_lines)
        
        except Exception as e:
            result['error'] = str(e)
            result['output'] = f"❌ Error listing {dir_path}: {str(e)}"
        
        return result
    
    def search_files(self, dialogue_id: str, pattern: str, dir_path: str = ".") -> Dict[str, Any]:
        """
        Search for files matching a pattern.
        
        Args:
            dialogue_id: Dialogue identifier
            pattern: File name pattern (supports wildcards)
            dir_path: Directory to search (default: root)
        
        Returns:
            Result dictionary with matching files
        """
        sandbox = self.get_sandbox_path(dialogue_id)
        full_path = sandbox / dir_path
        
        result = {
            'success': False,
            'tool': 'search_files',
            'pattern': pattern,
            'matches': [],
            'error': None
        }
        
        try:
            # Security check
            if not str(full_path.resolve()).startswith(str(sandbox.resolve())):
                result['error'] = "Path outside sandbox not allowed"
                result['output'] = "❌ Security error: Path outside sandbox"
                return result
            
            # Search for matching files
            matches = []
            for file_path in full_path.rglob(pattern):
                if file_path.is_file():
                    matches.append({
                        'name': file_path.name,
                        'path': str(file_path.relative_to(sandbox)),
                        'size': file_path.stat().st_size
                    })
            
            result['success'] = True
            result['matches'] = matches
            result['count'] = len(matches)
            
            # Format output
            if matches:
                output_lines = [f"🔍 Found {len(matches)} files matching '{pattern}':"]
                for match in matches[:20]:  # Limit to first 20
                    output_lines.append(f"   📄 {match['path']} ({match['size']} bytes)")
                if len(matches) > 20:
                    output_lines.append(f"   ... and {len(matches) - 20} more")
            else:
                output_lines = [f"🔍 No files found matching '{pattern}'"]
            
            result['output'] = '\n'.join(output_lines)
        
        except Exception as e:
            result['error'] = str(e)
            result['output'] = f"❌ Error searching: {str(e)}"
        
        return result
    
    def parse_tool_request(self, agent_response: str) -> Optional[Dict[str, Any]]:
        """
        Parse agent response for tool requests.
        
        Looks for patterns like:
        - [TOOL: git_clone repo_url="..." branch="..."]
        - [TOOL: read_file file_path="..."]
        
        Args:
            agent_response: Agent's text response
        
        Returns:
            Tool request dict or None
        """
        import re
        
        # Pattern: [TOOL: tool_name param1="value1" param2="value2"]
        pattern = r'\[TOOL:\s*(\w+)\s+([^\]]+)\]'
        match = re.search(pattern, agent_response)
        
        if not match:
            return None
        
        tool_name = match.group(1)
        params_str = match.group(2)
        
        # Parse parameters
        param_pattern = r'(\w+)="([^"]*)"'
        params = dict(re.findall(param_pattern, params_str))
        
        return {
            'tool': tool_name,
            'params': params,
            'raw_match': match.group(0)
        }
    
    def execute_tool(self, dialogue_id: str, tool_request: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool request.
        
        Args:
            dialogue_id: Dialogue identifier
            tool_request: Parsed tool request
        
        Returns:
            Tool execution result
        """
        tool_name = tool_request['tool']
        params = tool_request['params']
        
        if tool_name not in self.tools:
            return {
                'success': False,
                'tool': tool_name,
                'error': f"Unknown tool: {tool_name}",
                'output': f"❌ Tool '{tool_name}' not found. Available: {', '.join(self.tools.keys())}"
            }
        
        # Execute tool
        tool_func = self.tools[tool_name]
        
        try:
            result = tool_func(dialogue_id=dialogue_id, **params)
            return result
        except TypeError as e:
            return {
                'success': False,
                'tool': tool_name,
                'error': f"Invalid parameters: {str(e)}",
                'output': f"❌ Invalid parameters for {tool_name}: {str(e)}"
            }
        except Exception as e:
            return {
                'success': False,
                'tool': tool_name,
                'error': str(e),
                'output': f"❌ Error executing {tool_name}: {str(e)}"
            }


# Test the tool executor
if __name__ == "__main__":
    executor = DialogueToolExecutor()
    
    test_dialogue_id = "test_tools_001"
    
    print("=" * 80)
    print("DIALOGUE TOOL EXECUTOR TEST")
    print("=" * 80)
    
    # Test 1: Git clone
    print("\n1️⃣ Testing git_clone...")
    result = executor.git_clone(
        dialogue_id=test_dialogue_id,
        repo_url="https://github.com/askjake/RealTouch.git"
    )
    print(f"   Success: {result['success']}")
    print(f"   Output: {result['output'][:200]}")
    
    # Test 2: List directory
    print("\n2️⃣ Testing list_directory...")
    result = executor.list_directory(
        dialogue_id=test_dialogue_id,
        dir_path="RealTouch"
    )
    print(f"   Success: {result['success']}")
    print(f"   Files found: {result.get('count', 0)}")
    
    # Test 3: Read file
    print("\n3️⃣ Testing read_file...")
    result = executor.read_file(
        dialogue_id=test_dialogue_id,
        file_path="RealTouch/README.md"
    )
    print(f"   Success: {result['success']}")
    print(f"   Content length: {len(result.get('content', ''))}")
    
    # Test 4: Parse tool request
    print("\n4️⃣ Testing parse_tool_request...")
    test_response = 'I will clone the repo [TOOL: git_clone repo_url="https://github.com/test/repo.git" branch="main"]'
    parsed = executor.parse_tool_request(test_response)
    print(f"   Parsed: {parsed}")
    
    print("\n✅ DialogueToolExecutor ready!")
