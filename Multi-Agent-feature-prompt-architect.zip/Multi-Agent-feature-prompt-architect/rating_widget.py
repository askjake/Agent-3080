"""
Dialogue Rating Widget
Provides a reusable component for rating completed dialogues.
"""

import streamlit as st
from validation_framework import (
    calculate_inverted_metrics,
    save_dialogue_rating,
    save_inverted_metrics,
    classify_user_cohort
)


def render_rating_widget(dialogue_id: str, session: dict, db_path: str):
    """
    Render the dialogue rating widget for a completed dialogue.
    
    Args:
        dialogue_id: Unique ID of the dialogue session
        session: Session dictionary containing messages and metadata
        db_path: Path to SQLite database
    """
    # Check if already rated
    if st.session_state.get(f'rated_{dialogue_id}'):
        st.success("✅ You've already rated this dialogue. Thank you!")
        return
    
    # Only show for completed dialogues
    if session.get('status') != 'completed':
        return
    
    st.markdown("---")
    st.markdown("### 🌟 Rate This Dialogue")
    st.info("""
        **Help us validate our quality metrics!**  
        Your feedback helps us understand what makes dialogues valuable.  
        *(This is part of Week 1 validation - metrics are hidden until validated)*
    """)
    
    col1, col2 = st.columns([1, 2])
    
    with col1:
        rating = st.slider(
            "How useful was this dialogue?",
            min_value=1,
            max_value=5,
            value=3,
            help="1 = Not useful, 5 = Extremely useful",
            key=f"rating_slider_{dialogue_id}"
        )
    
    with col2:
        feedback = st.text_area(
            "What made it useful or not useful? (optional)",
            placeholder="E.g., 'Agents built on each other's ideas' or 'Too repetitive'",
            height=100,
            key=f"rating_feedback_{dialogue_id}"
        )
    
    if st.button("📝 Submit Rating", type="primary", key=f"submit_rating_{dialogue_id}"):
        # Get or create user ID (in production, use actual auth)
        if 'user_id' not in st.session_state:
            import uuid
            st.session_state.user_id = str(uuid.uuid4())[:8]
        
        user_id = st.session_state.user_id
        
        # Save rating
        try:
            save_dialogue_rating(dialogue_id, user_id, rating, feedback, db_path)
            
            # Calculate and save inverted metrics
            messages = session.get('messages', [])
            metrics = calculate_inverted_metrics(messages)
            metrics['dialogue_health'] = session.get('consensus_score', 0.0)
            save_inverted_metrics(dialogue_id, metrics, db_path)
            
            # Mark as rated
            st.session_state[f'rated_{dialogue_id}'] = True
            
            # Show user their cohort
            rated_count = len([k for k in st.session_state.keys() if k.startswith('rated_')])
            cohort = classify_user_cohort(rated_count)
            
            st.success(f"""
                ✅ **Rating saved! Thank you for your feedback.**  
                Your cohort: **{cohort}**  
                You've helped validate {rated_count} dialogue(s)!
            """)
            
            st.balloons()
            st.rerun()
            
        except Exception as e:
            st.error(f"Error saving rating: {str(e)}")
