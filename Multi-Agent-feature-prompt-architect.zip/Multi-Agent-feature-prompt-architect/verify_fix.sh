#!/bin/bash
echo "🔍 Verifying Agent Hub v3.0 Validation Framework Fixes"
echo "======================================================"
echo

# Check Python version
echo "✓ Python version:"
python3 --version
echo

# Check file existence and sizes
echo "✓ Created/Modified files:"
ls -lh validation_framework.py rating_widget.py FIX_SUMMARY.md | awk '{print "  " $9 " (" $5 ")"}'
echo

# Test imports
echo "✓ Testing imports..."
python3 -c "
from validation_framework import calculate_inverted_metrics, save_dialogue_rating
from rating_widget import render_rating_widget
print('  All imports successful')
"
echo

# Check syntax
echo "✓ Checking Python syntax..."
python3 -m py_compile agent_hub_app_v3_validation.py validation_framework.py rating_widget.py 2>&1
if [ $? -eq 0 ]; then
    echo "  All files compile successfully"
else
    echo "  ❌ Syntax errors found"
    exit 1
fi
echo

# Summary
echo "======================================================"
echo "✅ All checks passed - Application ready to run!"
echo
echo "To start the application:"
echo "  ./quickstart_v3.sh"
echo
echo "Then access at: http://localhost:8501"
echo "======================================================"
